package kyc.review.evaluation.orchestration;

import java.util.List;

import kyc.review.domain.ReviewId;
import kyc.review.evaluation.rule.RuleOutcome;

public record EvaluationReport(ReviewId reviewId, Result result, List<RuleOutcome> outcomes) {

    public enum Result { APPLIED, SKIPPED, NOT_EVALUABLE, DRY_RUN }

    public static EvaluationReport applied(ReviewId id, List<RuleOutcome> o) { return new EvaluationReport(id, Result.APPLIED, o); }
    public static EvaluationReport skipped(ReviewId id) { return new EvaluationReport(id, Result.SKIPPED, List.of()); }
    public static EvaluationReport notEvaluable(ReviewId id) { return new EvaluationReport(id, Result.NOT_EVALUABLE, List.of()); }
    public static EvaluationReport dryRun(ReviewId id, List<RuleOutcome> o) { return new EvaluationReport(id, Result.DRY_RUN, o); }
}
