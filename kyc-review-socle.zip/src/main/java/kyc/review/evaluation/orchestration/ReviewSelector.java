package kyc.review.evaluation.orchestration;

import java.util.List;
import java.util.Optional;

import kyc.review.domain.ReviewId;

/** Keyset pagination on the review ids in CCO, Prepare com or Blocked (ticket 13). */
public interface ReviewSelector {
    List<ReviewId> nextPage(Optional<ReviewId> after, int size);
}
