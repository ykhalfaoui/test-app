package kyc.review.evaluation.orchestration;

import java.util.List;
import java.util.Optional;

import kyc.review.domain.ReviewId;
import kyc.review.evaluation.context.ReviewContext;
import kyc.review.evaluation.context.ReviewContextService;
import kyc.review.evaluation.rule.ReviewRule;
import kyc.review.evaluation.rule.RuleOutcome;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/** Orchestrator (ticket 12): phase 1 collect + decide without transaction, phase 2 apply. */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReviewEvaluationService {

    private final ReviewContextService contextService;
    private final List<ReviewRule> rules;                 // ordered by @Order: FR 0.0, 0.A, 0.B, 0.C
    private final ReviewOutcomeApplier applier;
    private final ReviewEvaluationProperties properties;

    public EvaluationReport evaluate(ReviewId reviewId) {
        Optional<ReviewContext> context = contextService.build(reviewId);
        if (context.isEmpty()) {
            return EvaluationReport.notEvaluable(reviewId);
        }
        ReviewContext ctx = context.get();
        List<RuleOutcome> outcomes = rules.stream().map(rule -> rule.evaluate(ctx)).toList();

        if (properties.dryRun()) {
            log.info("[dry-run] review {}: {}", reviewId, outcomes);
            return EvaluationReport.dryRun(reviewId, outcomes);
        }
        return applier.apply(reviewId, ctx.review().getVersion(), outcomes);
    }
}
