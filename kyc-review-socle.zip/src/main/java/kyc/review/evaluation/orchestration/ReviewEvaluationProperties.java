package kyc.review.evaluation.orchestration;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "kyc.review-evaluation")
public record ReviewEvaluationProperties(boolean enabled, String cron, int batchSize, boolean dryRun) {
}
