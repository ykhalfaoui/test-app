package kyc.review.evaluation.orchestration;

import java.util.List;

import kyc.review.domain.Review;
import kyc.review.domain.ReviewId;
import kyc.review.domain.ReviewRepository;
import kyc.review.evaluation.command.ReviewCommandDispatcher;
import kyc.review.evaluation.rule.RuleOutcome;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Phase 2: one short transaction per review, local database only (ticket 12). */
@Service
@RequiredArgsConstructor
class ReviewOutcomeApplier {

    private final ReviewRepository reviewRepository;
    private final ReviewCommandDispatcher dispatcher;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public EvaluationReport apply(ReviewId reviewId, long expectedVersion, List<RuleOutcome> outcomes) {
        Review review = reviewRepository.findByIdForUpdate(reviewId).orElseThrow();
        if (review.getVersion() != expectedVersion) {
            return EvaluationReport.skipped(reviewId);
        }
        for (RuleOutcome outcome : outcomes) {
            switch (outcome) {
                case RuleOutcome.NotApplicable n -> { }
                case RuleOutcome.AutomaticAction a -> dispatcher.dispatch(review, a.command());
                case RuleOutcome.TaskRequested t -> review.requestTask(t.taskType());
            }
        }
        review.markDocumentsEvaluated();      // reset of the persisted newValidation marker (ticket 1)
        reviewRepository.save(review);        // status + actions + events + history (synchronous listener)
        return EvaluationReport.applied(reviewId, outcomes);
    }
}
