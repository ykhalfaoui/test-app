package kyc.review.evaluation.orchestration;

import java.util.List;
import java.util.Optional;

import kyc.review.domain.ReviewId;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Cron (ticket 13): one instance at a time, one failing review never stops the run. */
@Slf4j
@Component
@RequiredArgsConstructor
class ReviewEvaluationJob {

    private final ReviewSelector selector;
    private final ReviewEvaluationService evaluationService;
    private final ReviewEvaluationProperties properties;

    @Scheduled(cron = "${kyc.review-evaluation.cron}")
    @SchedulerLock(name = "kyc-review-evaluation", lockAtMostFor = "PT2H")
    void run() {
        if (!properties.enabled()) {
            return;
        }
        int evaluated = 0;
        int failed = 0;
        Optional<ReviewId> after = Optional.empty();
        List<ReviewId> page;
        do {
            page = selector.nextPage(after, properties.batchSize());
            for (ReviewId id : page) {
                try {
                    evaluationService.evaluate(id);
                    evaluated++;
                } catch (RuntimeException e) {
                    failed++;
                    log.error("Evaluation failed for review {}", id, e);
                }
            }
            after = page.isEmpty() ? after : Optional.of(page.get(page.size() - 1));
        } while (page.size() == properties.batchSize());
        log.info("KYC review evaluation done: {} evaluated, {} failed", evaluated, failed);
    }
}
