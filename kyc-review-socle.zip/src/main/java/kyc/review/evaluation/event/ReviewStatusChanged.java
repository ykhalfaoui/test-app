package kyc.review.evaluation.event;

import java.time.Instant;
import kyc.review.domain.ReviewId;
import kyc.review.domain.ReviewStatus;
import kyc.review.domain.TransitionMode;

/** Listened by: history. */
public record ReviewStatusChanged(ReviewId reviewId, ReviewStatus from, ReviewStatus to, TransitionMode mode, String actor, Instant at) {
}
