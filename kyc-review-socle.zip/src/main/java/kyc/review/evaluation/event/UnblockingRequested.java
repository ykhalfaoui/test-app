package kyc.review.evaluation.event;

import kyc.review.domain.ReviewId;

/** Listened by: unblocking outbox (ticket 6). */
public record UnblockingRequested(ReviewId reviewId) {
}
