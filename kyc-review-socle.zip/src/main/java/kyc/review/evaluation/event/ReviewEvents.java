package kyc.review.evaluation.event;

/** Marker for documentation: the events published by the Review aggregate (ticket 4). */
public final class ReviewEvents {
    private ReviewEvents() {
    }
}
