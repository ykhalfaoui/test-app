package kyc.review.evaluation.event;

import kyc.review.domain.ReviewId;

/** Listened by: blocking outbox (ticket 7). */
public record ReviewBlocked(ReviewId reviewId) {
}
