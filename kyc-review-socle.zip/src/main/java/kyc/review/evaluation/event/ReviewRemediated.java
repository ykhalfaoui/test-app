package kyc.review.evaluation.event;

import kyc.review.domain.ReviewId;

/** Listened by: audit, other modules. */
public record ReviewRemediated(ReviewId reviewId) {
}
