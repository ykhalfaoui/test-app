package kyc.review.evaluation.event;

import kyc.review.domain.ReviewId;

/** Listened by: optional re-evaluation for FR 0.C. */
public record ReviewBackToClientCommunication(ReviewId reviewId) {
}
