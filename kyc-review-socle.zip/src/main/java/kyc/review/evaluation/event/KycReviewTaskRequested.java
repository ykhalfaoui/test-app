package kyc.review.evaluation.event;

import java.time.Instant;
import kyc.review.domain.ReviewId;
import kyc.review.evaluation.task.TaskType;

/** Listened by: task. */
public record KycReviewTaskRequested(ReviewId reviewId, TaskType taskType, Instant occurredAt) {
}
