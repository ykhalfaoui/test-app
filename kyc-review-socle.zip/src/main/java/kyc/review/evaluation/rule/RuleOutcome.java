package kyc.review.evaluation.rule;

import kyc.review.evaluation.command.ReviewCommand;
import kyc.review.evaluation.task.TaskType;

/** What a rule returns. The rule never executes anything itself. */
public sealed interface RuleOutcome {

    RuleType rule();

    record NotApplicable(RuleType rule) implements RuleOutcome {
    }

    record AutomaticAction(RuleType rule, ReviewCommand command) implements RuleOutcome {
    }

    record TaskRequested(RuleType rule, TaskType taskType) implements RuleOutcome {
    }
}
