package kyc.review.evaluation.rule;

import kyc.review.evaluation.command.ReviewCommand;
import kyc.review.evaluation.context.ReviewContext;
import kyc.review.evaluation.task.TaskType;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/** Rule FR_0_0. Conditions implemented in ticket 8. */
@Component
@Order(1)
public class DocumentsCompletedRule extends ReviewRule {

    @Override
    public RuleType type() {
        return RuleType.FR_0_0;
    }

    @Override
    protected boolean isEligible(ReviewContext ctx) {
        // TODO ticket 8: eligibility conditions
        return false;
    }

    @Override
    protected boolean canAutomate(ReviewContext ctx) {
        return false;   // FR 0.0 is never automatic
    }

    @Override
    protected ReviewCommand command(ReviewContext ctx) {
        throw new IllegalStateException("FR 0.0 has no automatic action");
    }

    @Override
    protected TaskType taskType() {
        return TaskType.FR_0_0;
    }
}
