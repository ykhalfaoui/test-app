package kyc.review.evaluation.rule;

import kyc.review.evaluation.command.ReviewCommand;
import kyc.review.evaluation.context.ReviewContext;
import kyc.review.evaluation.task.TaskType;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/** Rule FR_0_A. Conditions implemented in ticket 9. */
@Component
@Order(2)
public class BlockingRule extends ReviewRule {

    @Override
    public RuleType type() {
        return RuleType.FR_0_A;
    }

    @Override
    protected boolean isEligible(ReviewContext ctx) {
        // TODO ticket 9: eligibility conditions
        return false;
    }

    @Override
    protected boolean canAutomate(ReviewContext ctx) {
        // TODO ticket 9: automation conditions
        return false;
    }

    @Override
    protected ReviewCommand command(ReviewContext ctx) {
        return new ReviewCommand.BlockReview(ctx.review().getId());
    }

    @Override
    protected TaskType taskType() {
        return TaskType.FR_0_A;
    }
}
