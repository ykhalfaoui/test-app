package kyc.review.evaluation.rule;

import kyc.review.evaluation.command.ReviewCommand;
import kyc.review.evaluation.context.ReviewContext;
import kyc.review.evaluation.task.TaskType;

/**
 * Template of a rule (ticket 4): eligible? -> automatic? -> command, otherwise task.
 * Rules are pure functions of the context: no repository, no service call
 * (the tiering is fetched lazily through the context).
 */
public abstract class ReviewRule {

    public final RuleOutcome evaluate(ReviewContext ctx) {
        if (!isEligible(ctx)) {
            return new RuleOutcome.NotApplicable(type());
        }
        if (canAutomate(ctx)) {
            return new RuleOutcome.AutomaticAction(type(), command(ctx));
        }
        return new RuleOutcome.TaskRequested(type(), taskType());
    }

    public abstract RuleType type();

    protected abstract boolean isEligible(ReviewContext ctx);

    protected abstract boolean canAutomate(ReviewContext ctx);

    protected abstract ReviewCommand command(ReviewContext ctx);

    protected abstract TaskType taskType();
}
