package kyc.review.evaluation.rule;

public enum RuleType {
    FR_0_0, FR_0_A, FR_0_B, FR_0_C
}
