package kyc.review.evaluation.context;

import java.util.Optional;

/** Port on the party tiering API. Empty when the API fails or the tiering is unknown. */
public interface PartyTieringPort {
    Optional<Integer> tieringOf(String partyId);
}
