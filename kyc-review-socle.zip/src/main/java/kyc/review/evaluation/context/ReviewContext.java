package kyc.review.evaluation.context;

import kyc.review.domain.ProcessActionStatus;
import kyc.review.domain.Review;

/** Facts only, no decision (ticket 2). The Review is read only for the rules. */
public record ReviewContext(
        Review review,
        ReviewDocumentResult documents,
        boolean nonIhubBlocksOk,
        boolean kycDataAndKytOk,
        ProcessActionStatus unblockingAction,
        PartyTieringLookup partyTiering) {
}
