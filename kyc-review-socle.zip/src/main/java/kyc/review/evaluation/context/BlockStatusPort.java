package kyc.review.evaluation.context;

import kyc.review.domain.ReviewId;

/** Port on the existing service exposing KYC data, KYT and non i-Hub blocks (ticket 2). */
public interface BlockStatusPort {

    BlockStatus statusOf(ReviewId reviewId);

    record BlockStatus(boolean nonIhubBlocksOk, boolean kycDataAndKytOk) {
    }
}
