package kyc.review.evaluation.context;

import java.util.Optional;
import java.util.Set;

import kyc.review.domain.ProcessActionType;
import kyc.review.domain.Review;
import kyc.review.domain.ReviewId;
import kyc.review.domain.ReviewRepository;
import kyc.review.domain.ReviewStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** Entry point of the evaluation: collects the facts of one review (ticket 2). No global transaction. */
@Service
@RequiredArgsConstructor
public class ReviewContextService {

    private static final Set<ReviewStatus> EVALUABLE =
            Set.of(ReviewStatus.CLIENT_COMMUNICATION_ONGOING, ReviewStatus.PREPARE_CLIENT_COMMUNICATION, ReviewStatus.BLOCKED);

    private final ReviewRepository reviewRepository;
    private final ReviewDocumentsEvaluator documentsEvaluator;
    private final BlockStatusPort blockStatusPort;
    private final PartyTieringPort partyTieringPort;

    public Optional<ReviewContext> build(ReviewId reviewId) {
        Optional<Review> loaded = reviewRepository.findById(reviewId);
        if (loaded.isEmpty() || !EVALUABLE.contains(loaded.get().getStatus())) {
            return Optional.empty();
        }
        Review review = loaded.get();
        ReviewDocumentResult documents = documentsEvaluator.evaluate(review);   // FTKYP-646, own local transactions
        BlockStatusPort.BlockStatus blocks = blockStatusPort.statusOf(reviewId);
        PartyTieringLookup tiering = new PartyTieringLookup(
                () -> partyTieringPort.tieringOf(review.getMainPartyId()));
        return Optional.of(new ReviewContext(
                review,
                documents,
                blocks.nonIhubBlocksOk(),
                blocks.kycDataAndKytOk(),
                review.processAction(ProcessActionType.UNBLOCKING_ACCOUNT).getStatus(),
                tiering));
    }
}
