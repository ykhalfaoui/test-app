package kyc.review.evaluation.context;

import java.util.Optional;
import java.util.function.Supplier;

/** Lazy and memoized tiering: the API is called on the first get() only, at most once per evaluation. */
public final class PartyTieringLookup {

    private final Supplier<Optional<Integer>> loader;
    private Optional<Integer> value;

    public PartyTieringLookup(Supplier<Optional<Integer>> loader) {
        this.loader = loader;
    }

    public Optional<Integer> get() {
        if (value == null) {
            Optional<Integer> loaded;
            try {
                loaded = loader.get();
            } catch (RuntimeException e) {
                loaded = Optional.empty();
            }
            value = loaded == null ? Optional.empty() : loaded;
        }
        return value;
    }
}
