package kyc.review.evaluation.context;

/** Consolidated i-Hub document result of a review (ticket 1). */
public record ReviewDocumentResult(
        boolean newValidation,
        boolean allBlocksCompliant,
        boolean pending,
        boolean rejected) {
}
