package kyc.review.evaluation.context;

import kyc.review.domain.Review;

/** Port implemented by ticket 1: members not removed -> FTKYP-646 per member -> consolidation. */
public interface ReviewDocumentsEvaluator {
    ReviewDocumentResult evaluate(Review review);
}
