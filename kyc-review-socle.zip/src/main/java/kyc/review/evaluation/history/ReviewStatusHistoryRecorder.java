package kyc.review.evaluation.history;

import kyc.review.evaluation.event.ReviewStatusChanged;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/** Synchronous: runs inside the transaction of reviewRepository.save(). Review and history committed together. */
@Component
@RequiredArgsConstructor
class ReviewStatusHistoryRecorder {

    private final ReviewStatusHistoryService reviewStatusHistoryService;   // existing service

    @EventListener
    void on(ReviewStatusChanged e) {
        reviewStatusHistoryService.createHistoryFor(e.reviewId(), e.mode(), e.from(), e.to(), e.actor(), e.at());
    }
}
