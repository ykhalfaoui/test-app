package kyc.review.evaluation.history;

import java.time.Instant;

import kyc.review.domain.ReviewId;
import kyc.review.domain.ReviewStatus;
import kyc.review.domain.TransitionMode;

/** Adapt to the existing ReviewStatusHistoryService signature. */
public interface ReviewStatusHistoryService {
    void createHistoryFor(ReviewId reviewId, TransitionMode mode, ReviewStatus from, ReviewStatus to, String actor, Instant at);
}
