package kyc.review.evaluation.command;

import kyc.review.domain.Review;

/** One handler per command. Works on the Review loaded and locked by phase 2; never saves. */
public interface ReviewCommandHandler<C extends ReviewCommand> {

    Class<C> supports();

    CommandResult handle(Review review, C command);
}
