package kyc.review.evaluation.command;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import kyc.review.domain.Review;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/** Dispatches a command to its handler; a refused command falls back to the task of its rule. */
@Slf4j
@Component
public class ReviewCommandDispatcher {

    private final Map<Class<?>, ReviewCommandHandler<?>> handlers;

    public ReviewCommandDispatcher(List<ReviewCommandHandler<?>> handlers) {
        this.handlers = handlers.stream().collect(Collectors.toMap(ReviewCommandHandler::supports, Function.identity()));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public CommandResult dispatch(Review review, ReviewCommand command) {
        ReviewCommandHandler handler = handlers.get(command.getClass());
        if (handler == null) {
            throw new IllegalStateException("No handler for " + command.getClass().getSimpleName());
        }
        CommandResult result = handler.handle(review, command);
        if (result instanceof CommandResult.Refused refused) {
            log.warn("{} refused for review {}: {}", command.getClass().getSimpleName(), review.getId(), refused.reason());
            review.requestTask(command.fallbackTask());
        }
        return result;
    }
}
