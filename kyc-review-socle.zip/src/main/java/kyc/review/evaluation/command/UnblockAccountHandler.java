package kyc.review.evaluation.command;

import kyc.review.domain.Review;
import org.springframework.stereotype.Component;

@Component
class UnblockAccountHandler implements ReviewCommandHandler<ReviewCommand.UnblockAccount> {

    @Override
    public Class<ReviewCommand.UnblockAccount> supports() {
        return ReviewCommand.UnblockAccount.class;
    }

    @Override
    public CommandResult handle(Review review, ReviewCommand.UnblockAccount command) {
        if (!review.canRequestUnblock()) {
            return CommandResult.refused("status " + review.getStatus() + " or unblocking action not ready");
        }
        review.requestUnblock();   // UNBLOCKING_ACCOUNT -> IN_PROGRESS, status stays BLOCKED
        return CommandResult.done();
    }
}
