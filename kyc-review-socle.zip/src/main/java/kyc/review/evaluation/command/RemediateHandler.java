package kyc.review.evaluation.command;

import kyc.review.domain.Actor;
import kyc.review.domain.Review;
import org.springframework.stereotype.Component;

@Component
class RemediateHandler implements ReviewCommandHandler<ReviewCommand.Remediate> {

    @Override
    public Class<ReviewCommand.Remediate> supports() {
        return ReviewCommand.Remediate.class;
    }

    @Override
    public CommandResult handle(Review review, ReviewCommand.Remediate command) {
        if (!review.canRemediate()) {
            return CommandResult.refused("status " + review.getStatus());
        }
        review.remediate(Actor.system("FR_0_C"));
        return CommandResult.done();
    }
}
