package kyc.review.evaluation.command;

public sealed interface CommandResult {

    record Done() implements CommandResult {
    }

    record Refused(String reason) implements CommandResult {
    }

    static CommandResult done() { return new Done(); }

    static CommandResult refused(String reason) { return new Refused(reason); }
}
