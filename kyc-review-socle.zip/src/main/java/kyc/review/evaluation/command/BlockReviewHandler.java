package kyc.review.evaluation.command;

import kyc.review.domain.Actor;
import kyc.review.domain.Review;
import org.springframework.stereotype.Component;

@Component
class BlockReviewHandler implements ReviewCommandHandler<ReviewCommand.BlockReview> {

    @Override
    public Class<ReviewCommand.BlockReview> supports() {
        return ReviewCommand.BlockReview.class;
    }

    @Override
    public CommandResult handle(Review review, ReviewCommand.BlockReview command) {
        if (!review.canBlock()) {
            return CommandResult.refused("status " + review.getStatus());
        }
        review.block(Actor.system("FR_0_A"));
        return CommandResult.done();
    }
}
