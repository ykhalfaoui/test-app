package kyc.review.evaluation.command;

import kyc.review.domain.ReviewId;
import kyc.review.evaluation.task.TaskType;

/** Automatic actions decided by the rules. Each one knows the task to create if it is refused. */
public sealed interface ReviewCommand {

    ReviewId reviewId();

    TaskType fallbackTask();

    record BlockReview(ReviewId reviewId) implements ReviewCommand {
        public TaskType fallbackTask() { return TaskType.FR_0_A; }
    }

    record UnblockAccount(ReviewId reviewId) implements ReviewCommand {
        public TaskType fallbackTask() { return TaskType.FR_0_B; }
    }

    record Remediate(ReviewId reviewId) implements ReviewCommand {
        public TaskType fallbackTask() { return TaskType.FR_0_C; }
    }
}
