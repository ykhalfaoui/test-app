package kyc.review.evaluation.task;

import kyc.review.evaluation.event.KycReviewTaskRequested;
import lombok.RequiredArgsConstructor;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

/** After commit, guaranteed by the Spring Modulith event publication registry (ticket 3). */
@Component
@RequiredArgsConstructor
class KycReviewTaskListener {

    private final SalesforceTaskPort salesforce;

    @ApplicationModuleListener
    void on(KycReviewTaskRequested event) {
        salesforce.find(event.reviewId(), event.taskType()).ifPresentOrElse(task -> {
            if (task.closed()) {
                salesforce.reopen(task);
            }
            salesforce.update(task, event.taskType());
        }, () -> salesforce.create(event.reviewId(), event.taskType()));
    }
}
