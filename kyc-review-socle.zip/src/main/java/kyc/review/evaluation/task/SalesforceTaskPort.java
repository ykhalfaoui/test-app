package kyc.review.evaluation.task;

import java.util.Optional;

import kyc.review.domain.ReviewId;

public interface SalesforceTaskPort {

    Optional<SalesforceTask> find(ReviewId reviewId, TaskType type);

    void create(ReviewId reviewId, TaskType type);

    void update(SalesforceTask task, TaskType type);

    void reopen(SalesforceTask task);

    record SalesforceTask(String id, boolean closed) {
    }
}
