package kyc.review.evaluation.task;

/** Salesforce task configuration (ticket 3). Descriptions, queues and priorities to be provided by the business. */
public enum TaskType {

    FR_0_0("KYC REVIEW - i-HUB documents complete. Ready for follow-up", "TODO description", "TODO queue", Priority.NORMAL),
    FR_0_A("KYC REVIEW - The customer eligible for blocking", "TODO description", "TODO queue", Priority.HIGH),
    FR_0_B("KYC REVIEW - Restrictions of the customer to be manually lifted", "TODO description", "TODO queue", Priority.HIGH),
    FR_0_C("KYC REVIEW - The review meets the criteria for a finalization", "TODO description", "TODO queue", Priority.NORMAL);

    public enum Priority { NORMAL, HIGH }

    private final String subject;
    private final String description;
    private final String queue;
    private final Priority priority;

    TaskType(String subject, String description, String queue, Priority priority) {
        this.subject = subject;
        this.description = description;
        this.queue = queue;
        this.priority = priority;
    }

    public String subject() { return subject; }
    public String description() { return description; }
    public String queue() { return queue; }
    public Priority priority() { return priority; }
}
