# Code foundation - Automatic evaluation of KYC reviews

Foundation (socle) shared by all tickets. The business specifics are implemented afterwards in separate tickets,
by filling the `TODO ticket N` and implementing the ports.

Not compiled here: it depends on your existing domain (`Review`, `ReviewId`, `ReviewStatus`, `ProcessAction...`,
`ReviewRepository`) and on Spring Boot 3, Spring Modulith, Lombok and ShedLock. Package `kyc.review.evaluation`
and domain package `kyc.review.domain` are placeholders: rename to your packages.

## What is in the foundation

```
kyc/review/evaluation
├── context        ReviewContext, ReviewContextService, PartyTieringLookup, ports (documents, blocks, tiering)
├── rule           ReviewRule (template), RuleOutcome, RuleType, 4 empty rules (@Order 1..4)
├── command        ReviewCommand (+ fallback task), CommandResult, handler interface, dispatcher, 3 handlers
├── task           TaskType (subjects), KycReviewTaskListener (Salesforce upsert), SalesforceTaskPort
├── event          KycReviewTaskRequested, ReviewStatusChanged, ReviewBlocked, UnblockingRequested,
│                  ReviewBackToClientCommunication, ReviewRemediated
├── history        ReviewStatusHistoryRecorder (synchronous, same transaction)
└── orchestration  ReviewEvaluationService (phase 1), ReviewOutcomeApplier (phase 2), EvaluationReport,
                   ReviewEvaluationJob (cron + ShedLock), ReviewSelector, ReviewEvaluationProperties
```

Plus `review-aggregate-additions.java.txt`: the methods to add to your existing `Review` entity.

## What stays for the specific tickets

| Ticket | To implement |
|---|---|
| 1 Documents evaluation | `ReviewDocumentsEvaluator`: members not removed, FTKYP-646 per member, consolidation, persisted `newValidation` marker |
| 2 Review Context | `BlockStatusPort` and `PartyTieringPort` adapters |
| 3 Task event | `SalesforceTaskPort` adapter, real descriptions / queues / priorities in `TaskType` |
| 5 Unblocking action | `UNBLOCKING_ACCOUNT` type, init, backfill migration |
| 6 Unblocking execution | listener on `UnblockingRequested`, outbox entry, handler calling the adapter, then `unblockingSucceeded()` / `unblockingFailed()` |
| 7 Blocking execution | listener on `ReviewBlocked`, outbox entry, handler calling the adapter, then `blockingSucceeded()` / `blockingFailed()` |
| 8 FR 0.0 | `DocumentsCompletedRule.isEligible` |
| 9 FR 0.A | `BlockingRule.isEligible`, `canAutomate` (tiering asked last) |
| 10 FR 0.B | `UnblockingRule.isEligible`, `canAutomate` |
| 11 FR 0.C | `StpValidationRule.isEligible`, `canAutomate` |
| 13 Cron | `ReviewSelector` query, ShedLock table, metrics |

## Configuration

```yaml
kyc:
  review-evaluation:
    enabled: false
    cron: "0 0 * * * MON-FRI"   # to define with the business
    batch-size: 200
    dry-run: true
```

Enable `@EnableScheduling`, `@EnableSchedulerLock(defaultLockAtMostFor = "PT2H")` and `@ConfigurationPropertiesScan`.
