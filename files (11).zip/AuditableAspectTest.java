package com.crok4it.audit;

import com.crok4it.audit.annotation.Auditable;
import com.crok4it.audit.entity.AuditEntry;
import com.crok4it.audit.repository.AuditEntryRepository;
import com.crok4it.audit.service.AuditService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

/**
 * Tests d'intégration pour @Auditable.
 *
 * Couvre :
 *   - SpEL par nom de paramètre (#payload.reviewId)
 *   - SpEL par index (#root[0].id)
 *   - SpEL expression invalide (doit être silencieuse, pas de crash)
 *   - Capture d'exception (status=ERROR, errorClass, stacktrace)
 *   - Succès (status=SUCCESS)
 *   - REQUIRES_NEW : l'audit ERROR est sauvegardé même si TX métier rollback
 *   - Self-invocation : l'aspect NE doit PAS être déclenché
 */
@SpringBootTest
@ActiveProfiles("test")
class AuditableAspectTest {

    @Autowired
    private AuditEntryRepository repository;

    @Autowired
    private TestAuditableService service;

    @BeforeEach
    void cleanUp() {
        repository.deleteAll();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SCENARIO 1 — SpEL par nom de paramètre
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("SpEL expressions")
    class SpelTests {

        @Test
        @DisplayName("SpEL #param.field résout correctement l'entityId")
        void spelByParamName_resolvesEntityId() {
            service.syncReview(new ReviewPayload("review-42", "member-7"));

            List<AuditEntry> entries = repository.findAll();
            assertThat(entries).hasSize(1);
            AuditEntry entry = entries.get(0);

            assertThat(entry.getAction()).isEqualTo("REVIEW_SYNC");
            assertThat(entry.getEntityId()).isEqualTo("review-42");
            assertThat(entry.getCorrelationId()).isEqualTo("member-7");
            assertThat(entry.getStatus()).isEqualTo(AuditEntry.AuditStatus.SUCCESS);
        }

        @Test
        @DisplayName("SpEL #root[0] résout le premier argument par index")
        void spelByIndex_resolvesFirstArg() {
            service.blockMember("member-99", "corr-123");

            List<AuditEntry> entries = repository.findAll();
            assertThat(entries).hasSize(1);
            assertThat(entries.get(0).getEntityId()).isEqualTo("member-99");
            assertThat(entries.get(0).getCorrelationId()).isEqualTo("corr-123");
        }

        @Test
        @DisplayName("SpEL expression invalide ne plante pas — entityId est null")
        void spelInvalidExpression_doesNotCrash_entityIdIsNull() {
            // "#payload.nonExistentField" — champ inexistant
            assertThatNoException()
                    .isThrownBy(() -> service.withBadSpel(new ReviewPayload("r-1", "m-1")));

            List<AuditEntry> entries = repository.findAll();
            assertThat(entries).hasSize(1);
            assertThat(entries.get(0).getEntityId()).isNull(); // SpEL fail → null
            assertThat(entries.get(0).getStatus()).isEqualTo(AuditEntry.AuditStatus.SUCCESS);
        }

        @Test
        @DisplayName("SpEL module statique ('salesforce') retourne la valeur littérale")
        void spelStaticModule_returnsLiteral() {
            service.syncReview(new ReviewPayload("r-1", "m-1"));

            AuditEntry entry = repository.findAll().get(0);
            assertThat(entry.getModule()).isEqualTo("salesforce");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SCENARIO 2 — Gestion des erreurs
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Gestion des erreurs")
    class ErrorHandlingTests {

        @Test
        @DisplayName("Exception capturée → status=ERROR avec errorClass et message")
        void exception_capturedWithStatusError() {
            assertThatThrownBy(() -> service.failingMethod("entity-1"))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessage("Erreur métier simulée");

            List<AuditEntry> entries = repository.findAll();
            assertThat(entries).hasSize(1);
            AuditEntry entry = entries.get(0);

            assertThat(entry.getStatus()).isEqualTo(AuditEntry.AuditStatus.ERROR);
            assertThat(entry.getErrorClass()).isEqualTo("java.lang.IllegalStateException");
            assertThat(entry.getErrorMessage()).isEqualTo("Erreur métier simulée");
            assertThat(entry.getStacktrace()).isNotBlank();
            assertThat(entry.getEntityId()).isEqualTo("entity-1");
        }

        @Test
        @DisplayName("REQUIRES_NEW : audit ERROR sauvegardé même si TX principale rollback")
        void requiresNew_auditSavedEvenIfBusinessTxRollback() {
            // La méthode lance une exception → TX métier rollback
            // Mais l'audit DOIT être persisté (REQUIRES_NEW)
            assertThatThrownBy(() -> service.failingWithTransaction("entity-tx"))
                    .isInstanceOf(RuntimeException.class);

            // L'entrée d'audit doit exister malgré le rollback
            List<AuditEntry> entries = repository.findAll();
            assertThat(entries)
                    .hasSize(1)
                    .first()
                    .satisfies(e -> {
                        assertThat(e.getStatus()).isEqualTo(AuditEntry.AuditStatus.ERROR);
                        assertThat(e.getEntityId()).isEqualTo("entity-tx");
                    });
        }

        @Test
        @DisplayName("rethrowException=false avale l'exception sans la propager")
        void rethrowFalse_exceptionSwallowed() {
            assertThatNoException()
                    .isThrownBy(() -> service.failingSilently("silent-entity"));

            AuditEntry entry = repository.findAll().get(0);
            assertThat(entry.getStatus()).isEqualTo(AuditEntry.AuditStatus.ERROR);
            assertThat(entry.getEntityId()).isEqualTo("silent-entity");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SCENARIO 3 — Succès + captureArgs
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Succès et capture")
    class SuccessTests {

        @Test
        @DisplayName("Succès → status=SUCCESS, durationMs >= 0")
        void success_statusSuccessAndDuration() {
            service.syncReview(new ReviewPayload("r-1", "m-1"));

            AuditEntry entry = repository.findAll().get(0);
            assertThat(entry.getStatus()).isEqualTo(AuditEntry.AuditStatus.SUCCESS);
            assertThat(entry.getDurationMs()).isNotNull().isGreaterThanOrEqualTo(0L);
            assertThat(entry.getTraceId()).isNotNull(); // traceId Micrometer présent
            assertThat(entry.getCreatedAt()).isNotNull();
            assertThat(entry.getMethodSignature()).contains("syncReview");
        }

        @Test
        @DisplayName("captureArgs=true → inputPayload JSON non vide")
        void captureArgs_inputPayloadIsJson() {
            service.withCapturedArgs(new ReviewPayload("r-capture", "m-capture"));

            AuditEntry entry = repository.findAll().get(0);
            assertThat(entry.getInputPayload())
                    .isNotBlank()
                    .contains("r-capture");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SCENARIO 4 — Limitation AOP self-invocation
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Limitations AOP")
    class AopLimitationTests {

        @Test
        @DisplayName("Self-invocation (this.xxx()) : l'aspect n'est PAS déclenché")
        void selfInvocation_aspectNotTriggered() {
            // callsInternalMethod() appelle this.syncReview() en interne
            // L'aspect @Auditable sur syncReview NE sera PAS déclenché
            service.callsInternalMethod();

            // Aucune entrée d'audit ne doit être créée
            assertThat(repository.findAll())
                    .isEmpty(); // ← COMPORTEMENT ATTENDU, pas un bug
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Service de test avec tous les patterns
    // ═══════════════════════════════════════════════════════════════════════

    @Service
    static class TestAuditableService {

        @Auditable(
            action        = "REVIEW_SYNC",
            entityType    = "Review",
            entityId      = "#payload.reviewId",
            correlationId = "#payload.memberId",
            module        = "'salesforce'"
        )
        public void syncReview(ReviewPayload payload) {
            // succès
        }

        @Auditable(
            action        = "MEMBER_BLOCK",
            entityType    = "Member",
            entityId      = "#root[0]",
            correlationId = "#root[1]"
        )
        public void blockMember(String memberId, String correlationId) {
            // succès
        }

        @Auditable(
            action   = "BAD_SPEL",
            entityId = "#payload.nonExistentField" // champ inexistant → null
        )
        public void withBadSpel(ReviewPayload payload) {
            // succès
        }

        @Auditable(
            action        = "FAILING_METHOD",
            entityType    = "Entity",
            entityId      = "#root[0]",
            captureStacktrace = true
        )
        public void failingMethod(String entityId) {
            throw new IllegalStateException("Erreur métier simulée");
        }

        @Auditable(
            action   = "FAILING_WITH_TX",
            entityId = "#root[0]"
        )
        @Transactional
        public void failingWithTransaction(String entityId) {
            throw new RuntimeException("TX rollback simulé");
        }

        @Auditable(
            action          = "FAILING_SILENT",
            entityId        = "#root[0]",
            rethrowException = false  // avale l'exception
        )
        public void failingSilently(String entityId) {
            throw new RuntimeException("Exception avalée");
        }

        @Auditable(
            action      = "WITH_ARGS",
            entityId    = "#payload.reviewId",
            captureArgs = true
        )
        public void withCapturedArgs(ReviewPayload payload) {
            // succès
        }

        /**
         * Appel interne — l'aspect @Auditable sur syncReview NE sera PAS déclenché.
         * C'est la limitation fondamentale du proxy Spring AOP.
         */
        public void callsInternalMethod() {
            // this.syncReview() → bypasse le proxy → pas d'audit
            this.syncReview(new ReviewPayload("internal-r", "internal-m"));
        }
    }

    record ReviewPayload(String reviewId, String memberId) {}

    // Configuration de test minimale
    @Configuration
    static class TestConfig {
        // Spring Boot auto-configure tout ce dont on a besoin
        // (DataSource H2, JPA, Jackson, Micrometer, AOP)
    }
}
