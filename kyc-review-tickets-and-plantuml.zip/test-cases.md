# Test cases - Automatic evaluation of KYC reviews

Two levels:
- **Unit tests**: one class at a time, no Spring context, no database. Rules, Review aggregate, consolidation, dispatcher, job logic.
- **Integration tests**: Spring Boot context, real database (Testcontainers), external systems stubbed (WireMock), events checked with the Spring Modulith `Scenario` API. One test per business use case, from the cron to the side effects.

## 1. Test setup

| Element | Tool | Notes |
|---|---|---|
| Database | Testcontainers (same engine as production) | Liquibase / Flyway migrations applied, including the `UNBLOCKING_ACCOUNT` backfill |
| iHub adapter (FTKYP-643) | WireMock | `GET /v1/bil-parties/{partyId}/completeness-status`, one stub per document situation |
| Block status service (KYC data, KYT, non i-Hub) | WireMock | |
| Tiering API | WireMock | lets us assert "called" or "not called" |
| Posting restriction adapter | WireMock | PUT / REMOVE, success, error, timeout |
| Salesforce | WireMock or stub of the task client | assert create / update / reopen |
| Events | Spring Modulith `Scenario`, `PublishedEvents` | assert published events and their order |
| Time | fixed `Clock` bean | blocking planned date "passed" or "not passed" |
| Test data | builders: `aReview()`, `aMember()`, `anIhubBlock()` | readable Given sections |

Naming: `should_<expected>_when_<situation>`.

---

## 2. Unit tests

### 2.1 Review documents evaluation (ticket 1)

| ID | Given (members, FTKYP-646 mocked) | Then |
|---|---|---|
| U1-01 | A compliant + just validated, B already compliant | `newValidation=true`, `allBlocksCompliant=true`, `pending=false`, `rejected=false` |
| U1-02 | A and B already compliant | `newValidation=false`, `allBlocksCompliant=true` |
| U1-03 | A just validated, B one pending document | `newValidation=true`, `allBlocksCompliant=false`, `pending=true` |
| U1-04 | A one rejected, B one pending | `allBlocksCompliant=false`, `pending=true`, `rejected=true` |
| U1-05 | A no change not compliant, B compliant | `newValidation=false`, `allBlocksCompliant=false`, `pending=false`, `rejected=false` |
| U1-06 | member with status `removed` | FTKYP-646 never called for it |
| U1-07 | member without i-Hub block | FTKYP-646 never called for it |
| U1-08 | member with only `DOCS_IHUB_SPECIFIC` | FTKYP-646 called with that block type only |
| U1-09 | no eligible member | `allBlocksCompliant=true`, others false, warning logged |
| U1-10 | FTKYP-646 throws for B | exception propagated with review id and party id |

### 2.2 Review context and tiering lookup (ticket 2)

| ID | Given | Then |
|---|---|---|
| U2-01 | review in CCO | context built with the loaded `Review` |
| U2-02 | review in Remediated or unknown | no context |
| U2-03 | one non i-Hub block amber | `nonIhubBlocksOk=false` |
| U2-04 | KYT KO on the main party | `kycDataAndKytOk=false` |
| U2-05 | context built | tiering API not called |
| U2-06 | `partyTiering.get()` called twice | tiering API called once |
| U2-07 | tiering API in error | `partyTiering.get()` empty |

### 2.3 Rules (tickets 8 to 11)

Each rule is tested with a context built by hand. Expected outcome: `NA` (not applicable), `AUTO(command)` or `TASK(type)`.

**FR 0.0 Documents completed**

| ID | Status | allBlocksCompliant | newValidation | non i-Hub amber | Expected |
|---|---|---|---|---|---|
| U8-01 | CCO | yes | yes | yes | TASK(FR_0_0) |
| U8-02 | Prepare com | yes | yes | yes | TASK(FR_0_0) |
| U8-03 | Blocked | yes | yes | yes | TASK(FR_0_0) |
| U8-04 | CCO | yes | yes | no | NA |
| U8-05 | CCO | yes | no | yes | NA |
| U8-06 | CCO | no | yes | yes | NA |
| U8-07 | Remediated | yes | yes | yes | NA |
| U8-08 | CCO, date passed | yes | yes | yes | TASK(FR_0_0) |

**FR 0.A Blocking** (date passed unless stated)

| ID | Status | Docs compliant | KYC/KYT OK | Pending | Rejected | Retail + Low | Tiering | Expected | Tiering called |
|---|---|---|---|---|---|---|---|---|---|
| U9-01 | CCO | no | yes | no | no | yes | 4 | AUTO(BlockReview) | yes |
| U9-02 | CCO | no | yes | no | no | yes | 5 | AUTO(BlockReview) | yes |
| U9-03 | CCO | no | yes | no | no | yes | 2 | TASK(FR_0_A) | yes |
| U9-04 | CCO | no | yes | no | no | no | - | TASK(FR_0_A) | no |
| U9-05 | CCO | no | yes | no | yes | yes | - | TASK(FR_0_A) | no |
| U9-06 | CCO | yes | no | no | no | yes | 4 | AUTO(BlockReview) | yes |
| U9-07 | CCO | no | yes | yes | no | yes | - | NA | no |
| U9-08 | CCO, date not passed | no | yes | no | no | yes | - | NA | no |
| U9-09 | Blocked | no | yes | no | no | yes | - | NA | no |
| U9-10 | Prepare com | no | yes | no | no | yes | 4 | AUTO(BlockReview) | yes |
| U9-11 | CCO | no | yes | no | no | yes | API down | TASK(FR_0_A) | yes |
| U9-12 | CCO | yes | yes | no | no | yes | - | NA | no |

**FR 0.B Unblocking**

| ID | Status | Docs compliant | non i-Hub OK | Unblocking action | Retail + Low | Expected |
|---|---|---|---|---|---|---|
| U10-01 | Blocked | yes | yes | TO_BE_PROCESSED | yes | AUTO(UnblockAccount) |
| U10-02 | Blocked | yes | yes | TO_BE_PROCESSED | yes (831) | AUTO(UnblockAccount) |
| U10-03 | Blocked | yes | yes | TO_BE_PROCESSED | no | TASK(FR_0_B) |
| U10-04 | Blocked | yes | no | TO_BE_PROCESSED | yes | NA |
| U10-05 | Blocked | no | yes | TO_BE_PROCESSED | yes | NA |
| U10-06 | Blocked | yes | yes | INIT | yes | NA |
| U10-07 | Blocked | yes | yes | IN_PROGRESS | yes | NA |
| U10-08 | Blocked | yes | yes | PROCESSED | yes | NA |
| U10-09 | Blocked | yes | yes | ERROR | yes | NA |
| U10-10 | CCO | yes | yes | TO_BE_PROCESSED | yes | NA |

**FR 0.C Validation STP**

| ID | Status | Date passed | Docs compliant | non i-Hub OK | Retail + Low | Main DAO | Expected |
|---|---|---|---|---|---|---|---|
| U11-01 | CCO | yes | yes | yes | yes | not 831 | AUTO(Remediate) |
| U11-02 | CCO | yes | yes | yes | yes | 831 | TASK(FR_0_C) |
| U11-03 | CCO | yes | yes | yes | no | not 831 | TASK(FR_0_C) |
| U11-04 | CCO | no | yes | yes | yes | not 831 | NA |
| U11-05 | CCO | yes | no | yes | yes | not 831 | NA |
| U11-06 | CCO | yes | yes | no | yes | not 831 | NA |
| U11-07 | Blocked | yes | yes | yes | yes | not 831 | NA |
| U11-08 | Prepare com | yes | yes | yes | yes | not 831 | NA |

### 2.4 Review aggregate (ticket 4)

| ID | Given | When | Then |
|---|---|---|---|
| U4-01 | review CCO | `block(SYSTEM)` | status Blocked, `BLOCKING` to be processed, events `ReviewStatusChanged(CCO->BLOCKED, AUTOMATIC)` + `ReviewBlocked` |
| U4-02 | review Blocked | `block()` | refused, no event |
| U4-03 | Blocked, unblocking `TO_BE_PROCESSED` | `requestUnblock()` | action `IN_PROGRESS`, event `UnblockingRequested`, **no** `ReviewStatusChanged` |
| U4-04 | Blocked, unblocking `INIT` | `requestUnblock()` | refused |
| U4-05 | review CCO | `remediate(SYSTEM)` | status Remediated, `ReviewStatusChanged` + `ReviewRemediated` |
| U4-06 | review Blocked | `remediate()` | refused |
| U4-07 | `BLOCKING` to be processed | `blockingSucceeded()` | `BLOCKING` processed, unblocking `TO_BE_PROCESSED` |
| U4-08 | `BLOCKING` to be processed | `blockingFailed()` | `BLOCKING` error, `KycReviewTaskRequested(FR_0_A)` |
| U4-09 | unblocking `IN_PROGRESS` | `unblockingSucceeded()` | action processed, status CCO, `ReviewStatusChanged(BLOCKED->CCO)` + `ReviewBackToClientCommunication` |
| U4-10 | unblocking `IN_PROGRESS` | `unblockingFailed()` | action error, status Blocked, `KycReviewTaskRequested(FR_0_B)` |
| U4-11 | review CCO | `block(KYCO user)` | `ReviewStatusChanged` with mode `MANUAL` and the user |

### 2.5 Rule template, dispatcher and fallback (ticket 4)

| ID | Given | Then |
|---|---|---|
| U4-20 | rule not eligible | `NotApplicable`, `canAutomate` not called |
| U4-21 | rule eligible and automatic | `AutomaticAction` with the rule's command |
| U4-22 | rule eligible and manual | `TaskRequested` with the rule's task type |
| U4-23 | `BlockReview` refused by the Review | fallback `KycReviewTaskRequested(FR_0_A)` |
| U4-24 | `UnblockAccount` refused | fallback FR_0_B |
| U4-25 | `Remediate` refused | fallback FR_0_C |
| U4-26 | each command type | dispatched to its own handler only |

### 2.6 Task event and handlers (tickets 3, 6, 7)

| ID | Given | Then |
|---|---|---|
| U3-01 | each `TaskType` | subject, description, queue and priority filled |
| U3-02 | no existing task | Salesforce client `create` |
| U3-03 | open task same type | `update`, no `create` |
| U3-04 | closed task same type | `reopen` + `update` |
| U6-01 | adapter REMOVE OK | `review.unblockingSucceeded()` called |
| U6-02 | adapter REMOVE KO, last retry | `review.unblockingFailed()` called |
| U6-03 | action already `PROCESSED` | adapter not called |
| U7-01 | adapter PUT OK | `review.blockingSucceeded()` called |
| U7-02 | adapter PUT KO, last retry | `review.blockingFailed()` called |

### 2.7 Orchestrator and cron (tickets 12, 13)

| ID | Given | Then |
|---|---|---|
| U12-01 | version changed between phase 1 and 2 | nothing applied, report skipped |
| U12-02 | outcomes FR 0.0 task + FR 0.A auto | both applied in the same phase 2 |
| U12-03 | dry-run | rules evaluated, phase 2 not called |
| U13-01 | job disabled | selector not called |
| U13-02 | 3 reviews, the 2nd throws | 1st and 3rd evaluated, 2nd counted failed |
| U13-03 | 2 pages of ids | all ids evaluated in order |

---

## 3. Integration tests (business use cases)

Each use case starts from the database state and the stubs, runs the **cron once or several times**, then checks the database (status, actions, history), the published events and the stub calls.

Legend of the checks: **S** status, **A** process actions, **H** status history, **T** Salesforce task, **P** posting restriction adapter calls, **E** events.

### 3.1 Nominal use cases

| ID | Use case | Given | When | Then |
|---|---|---|---|---|
| IT-01 | STP, never blocked | CCO, date passed, all members compliant, non i-Hub OK, Retail, Low, not 831 | 1 run | **S** Remediated · **H** CCO->REMEDIATED AUTOMATIC · **T** none · **E** `ReviewRemediated` |
| IT-02 | Manual finalization 831 | same as IT-01 with main DAO 831 | 1 run | **S** CCO · **T** FR_0_C created · **H** none |
| IT-03 | Documents completed, non i-Hub work remains | CCO, last block validated by iHub, one non i-Hub block amber | 1 run | **T** FR_0_0 created · **S** unchanged |
| IT-04 | Full automatic path | CCO, date passed, one document missing, Retail, Low, tiering 4 | run 1 | **S** Blocked · **A** BLOCKING processed, UNBLOCKING `TO_BE_PROCESSED` · **P** PUT called once · **H** CCO->BLOCKED |
| | | then iHub validates the document | run 2 | **A** UNBLOCKING processed · **P** REMOVE called once · **S** CCO · **H** BLOCKED->CCO |
| | | | run 3 | **S** Remediated · **H** CCO->REMEDIATED · **T** none |
| IT-05 | Full manual path | same as IT-04, not Retail | run 1 | **T** FR_0_A · **S** CCO |
| | | KYCO blocks (manual action) | | **S** Blocked · **H** MANUAL · **P** PUT |
| | | document validated | run 2 | **T** FR_0_B · **S** Blocked |
| | | KYCO unblocks (manual action) | | **P** REMOVE · **S** CCO · **H** MANUAL |
| | | | run 3 | **T** FR_0_C · **S** CCO |
| IT-06 | FR 0.0 and FR 0.A in the same run | CCO, date passed, documents just completed, non i-Hub amber, KYT KO, auto profile tiering 4 | 1 run | **T** FR_0_0 · **S** Blocked · **P** PUT |
| IT-07 | Pending document pauses the blocking | CCO, date passed, one document pending | run 1 | **S** CCO · **T** none · **P** none |
| | | back office rejects the document | run 2 | **T** FR_0_A (no auto because rejected) · **S** CCO |
| IT-08 | Rejected document at the date | CCO, date passed, one document rejected, auto profile | 1 run | **T** FR_0_A · **S** CCO · tiering API **not called** |
| IT-09 | Blocked, documents completed, non i-Hub amber | Blocked, last block validated, non i-Hub amber | 1 run | **T** FR_0_0 · no unblocking · **P** none |
| IT-10 | 831 blocked then complete | Blocked, 831, Retail, Low, all OK, unblocking `TO_BE_PROCESSED` | run 1 | **P** REMOVE · **S** CCO |
| | | | run 2 | **T** FR_0_C · **S** CCO |

### 3.2 Failures and fallbacks

| ID | Use case | Given | When | Then |
|---|---|---|---|---|
| IT-20 | Blocking adapter fails | as IT-04 run 1, adapter PUT returns 500 on every retry | run 1 + outbox retries | **A** BLOCKING error · **T** FR_0_A · **S** Blocked |
| IT-21 | Unblocking adapter fails | Blocked, all OK, auto profile, adapter REMOVE returns 500 | run 1 + retries | **A** UNBLOCKING error · **T** FR_0_B · **S** Blocked |
| IT-22 | Tiering API down | as IT-04, tiering stub returns 503 | 1 run | **T** FR_0_A · **S** CCO |
| IT-23 | FTKYP-646 fails for one member | iHub stub 500 for one party | 1 run | review not changed, error logged, **T** none |
| IT-24 | Block status service down | stub 503 | 1 run | review not changed, no task |
| IT-25 | Salesforce down | IT-02 with Salesforce 503 | 1 run, then Salesforce back + resubmission | event publication incomplete, then task created once |
| IT-26 | History save fails | IT-01 with the history table forced to fail | 1 run | **S** still CCO (rollback), **H** none, **T** none |
| IT-27 | Command refused | phase 1 decides `BlockReview`, review moved to Blocked by KYCO before phase 2 | 1 run | version changed: skipped, nothing applied |

### 3.3 Consistency and idempotency

| ID | Use case | Given | When | Then |
|---|---|---|---|---|
| IT-40 | newValidation not lost | IT-03, phase 2 forced to fail after FTKYP-646 validated the block | run 1 (fails) + run 2 | run 2 creates **T** FR_0_0 once |
| IT-41 | No duplicate task | IT-02 | 2 runs | one FR_0_C task, updated at run 2 (or untouched, per Q2) |
| IT-42 | Closed task reopened | IT-02, KYCO closes the task without finalizing | run 2 | task reopened (per Q3) |
| IT-43 | Unblock never relaunched | IT-04 after run 2 | run 3, run 4 | REMOVE called once in total |
| IT-44 | Same outbox entry twice | unblocking entry delivered twice | | adapter REMOVE called once |
| IT-45 | Concurrent KYCO action | review locked by a KYCO transaction during phase 2 | 1 run | phase 2 waits for the lock, then version check: skipped |

### 3.4 Cron

| ID | Use case | Given | When | Then |
|---|---|---|---|---|
| IT-60 | Selection | 1 review per status (CCO, Prepare com, Blocked, Remediated) | 1 run | 3 evaluated, Remediated ignored |
| IT-61 | Failure isolation | 3 reviews, the 2nd with FTKYP-646 failing | 1 run | 1st and 3rd processed, report: 1 failed |
| IT-62 | Two instances | two job triggers in parallel (ShedLock table) | | one run only |
| IT-63 | Dry-run | IT-04 data, `dry-run=true` | 1 run | outcomes logged, **S A H T P** unchanged |
| IT-64 | Disabled | `enabled=false` | 1 run | nothing evaluated |
| IT-65 | Metrics | IT-01 + IT-02 | 1 run | counters: 2 evaluated, FR 0.C 1 auto 1 task |

### 3.5 Waiting for business answers

| ID | Use case | Blocked by |
|---|---|---|
| IT-80 | Review blocked only for KYC/KYT KO, documents compliant: unblock or not | KYC/KYT check in FR 0.B and FR 0.C |
| IT-81 | Document invalid again after the return to CCO: second blocking (BLOCKING action already processed) | re-blocking policy and reset of the process actions |
| IT-82 | Task update policy on every run | task policy (Q2, Q3, Q4) |

---

## 4. Coverage per ticket

| Ticket | Unit | Integration |
|---|---|---|
| 1 Documents evaluation | U1-01 to U1-10 | IT-03, IT-23, IT-40 |
| 2 Review Context | U2-01 to U2-07 | IT-22, IT-24 |
| 3 Task event | U3-01 to U3-04 | IT-02, IT-25, IT-41, IT-42 |
| 4 Framework, commands, aggregate, history | U4-01 to U4-26 | IT-26, IT-27 |
| 5 Unblocking action | U4-03, U4-07 | IT-04, IT-43 |
| 6 Unblocking execution | U6-01 to U6-03 | IT-04, IT-10, IT-21, IT-44 |
| 7 Blocking execution | U7-01, U7-02 | IT-04, IT-20 |
| 8 FR 0.0 | U8-01 to U8-08 | IT-03, IT-06, IT-09 |
| 9 FR 0.A | U9-01 to U9-12 | IT-04 to IT-08, IT-22 |
| 10 FR 0.B | U10-01 to U10-10 | IT-04, IT-05, IT-10, IT-21 |
| 11 FR 0.C | U11-01 to U11-08 | IT-01, IT-02, IT-04, IT-05, IT-10 |
| 12 Orchestrator | U12-01 to U12-03 | IT-06, IT-27, IT-45 |
| 13 Cron | U13-01 to U13-03 | IT-60 to IT-65 |
