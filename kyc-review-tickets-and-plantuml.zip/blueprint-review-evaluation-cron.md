# Blueprint - Automatic evaluation of KYC periodic reviews (i-Hub)

## 1. Purpose

A cron evaluates every open KYC periodic review. For each review it collects the facts (documents of every member, non i-Hub blocks, KYC data, KYT, profile, unblocking state), applies four business rules, and either acts automatically or creates a Salesforce task for KYCO.

| Rule | Business meaning | Automatic action | Automatic when | Otherwise |
|---|---|---|---|---|
| FR 0.0 | i-Hub documents completed, non i-Hub work remains | none | never | task FR 0.0 |
| FR 0.A | blocking planned date passed, review incomplete | review `Blocked` + posting restriction | Retail, AML Low, no rejected document, tiering 4 or 5 | task FR 0.A |
| FR 0.B | blocked review complete again | posting restriction removed, then review back to CCO | Retail, AML Low | task FR 0.B |
| FR 0.C | review complete, ready to close | review `Remediated` | Retail, AML Low, main DAO not 831 | task FR 0.C |

**Decisions taken with the business**
- After the unblocking of the account, the review goes back to Client Communication Ongoing, then FR 0.C finalizes it.
- Two separate tasks: FR 0.B (lift restrictions) and FR 0.C (finalize).
- An automatic action that cannot be done falls back to the task of its rule.
- FR 0.0 has no condition on the blocking planned date.
- A pending document (under back-office validation) pauses the blocking.

## 2. Full flow

```plantuml
@startuml
title KYC review automatic evaluation - full process

skinparam shadowing false
skinparam ActivityBorderColor #666666
skinparam ActivityBackgroundColor #FFFFFF
skinparam SwimlaneBorderColor #999999

|#F5F5F5|Scheduler|
start
:@Scheduled cron + ShedLock\n(one instance only, ticket 13);
if (job enabled?) then (yes)
else (no)
  stop
endif
:Select review ids in CCO,\nPrepare com or Blocked\n(keyset pagination);
:For each review id:\nevaluate in isolation\n(a failure is logged, the run continues);

|#DAE8FC|Phase 1 - Review Context|
:Load the Review from the database\n(status, blocking planned date, profile,\nprocess actions, @Version);
:For each member not removed\nwith an i-Hub block:\nFTKYP-646 refreshes the documents\n(ticket 1);
:Consolidate at review level\nallBlocksCompliant (AND), pending (OR),\nrejected (OR), newValidation (persisted marker);
:Block status service\nKYC data, KYT, non i-Hub blocks;
:Read UNBLOCKING_ACCOUNT state;
:ReviewContext = facts only\n(tiering lazy, not called yet)\n(ticket 2);

|#FFF2CC|Phase 1 - Rules|
partition "FR 0.0 Documents completed (ticket 8)" {
  if (CCO, Prepare com or Blocked\nand allBlocksCompliant and newValidation\nand one non i-Hub block amber?) then (eligible)
    :Task FR_0_0\n(never automatic);
  endif
}
partition "FR 0.A Blocking (ticket 9)" {
  if (CCO or Prepare com\nand blocking planned date passed\nand no pending document\nand (documents not compliant or KYC/KYT KO)?) then (eligible)
    if (Retail and AML Low\nand no rejected document\nand tiering 4 or 5 (lazy API call)?) then (automatic)
      :Command BlockReview;
    else (manual)
      :Task FR_0_A;
    endif
  endif
}
partition "FR 0.B Unblocking (ticket 10)" {
  if (Blocked and documents compliant\nand non i-Hub blocks OK\nand UNBLOCKING_ACCOUNT TO_BE_PROCESSED?) then (eligible)
    if (Retail and AML Low?) then (automatic)
      :Command UnblockAccount;
    else (manual)
      :Task FR_0_B;
    endif
  endif
}
partition "FR 0.C Validation STP (ticket 11)" {
  if (CCO and blocking planned date passed\nand documents compliant\nand non i-Hub blocks OK?) then (eligible)
    if (Retail and AML Low\nand main DAO not 831?) then (automatic)
      :Command Remediate;
    else (manual)
      :Task FR_0_C;
    endif
  endif
}

|#D5E8D4|Phase 2 - Review aggregate|
if (dry-run?) then (yes)
  :Log the outcomes, apply nothing;
  stop
endif
:findByIdForUpdate (pessimistic lock)\nREQUIRES_NEW transaction;
if (Review unchanged since phase 1\n(version)?) then (yes)
  :Dispatcher runs each command on the Review (ticket 4)\nreview.block() / requestUnblock() / remediate()\nrefused by the state machine -> fallback task;
  :Register KycReviewTaskRequested for each task;
  :Reset the newValidation marker;
  :Save the Review: status + process actions\n+ events, one short transaction;
:ReviewStatusChanged -> synchronous listener\nsaves the status history\n(same transaction);
else (no)
  :Skip, the next evaluation decides again;
  stop
endif

|#E1D5E7|After commit - listeners|
fork
  :KycReviewTaskRequested\n-> task listener (ticket 3);
  |#FFE6CC|External systems|
  :Salesforce: upsert task\n(review + task type);
fork again
  |#E1D5E7|After commit - listeners|
  :ReviewBlocked\n-> outbox (ticket 7);
  |#FFE6CC|External systems|
  :Posting restriction adapter: PUT;
  |#E1D5E7|After commit - listeners|
  if (adapter OK?) then (yes)
    :review.blockingSucceeded()\nBLOCKING PROCESSED\nUNBLOCKING_ACCOUNT TO_BE_PROCESSED;
  else (no, after retries)
    :review.blockingFailed()\nBLOCKING ERROR + task FR_0_A;
  endif
fork again
  :UnblockingRequested\n-> outbox (ticket 6);
  |#FFE6CC|External systems|
  :Posting restriction adapter: REMOVE;
  |#E1D5E7|After commit - listeners|
  if (adapter OK?) then (yes)
    :review.unblockingSucceeded()\nUNBLOCKING_ACCOUNT PROCESSED\nstatus Blocked -> CCO\n(next evaluation: FR 0.C);
  else (no, after retries)
    :review.unblockingFailed()\nUNBLOCKING_ACCOUNT ERROR + task FR_0_B;
  endif
fork again
  :ReviewRemediated\n-> audit, other modules;
end fork
stop
@enduml
```

## 3. Step by step

| # | Step | Component | Transaction | Ticket |
|---|---|---|---|---|
| 1 | Cron triggers, one instance only (ShedLock) | `ReviewEvaluationJob` | none | 13 |
| 2 | Select review ids in CCO, Prepare com, Blocked, page by page | `ReviewSelector` | read only | 13 |
| 3 | For each review: load the Review (status, date, profile, process actions, version) | `ReviewContextService` | read only | 2 |
| 4 | Refresh the i-Hub documents of each active member and consolidate | `ReviewDocumentsEvaluator` + FTKYP-646 | FTKYP-646 local transactions | 1 |
| 5 | Read KYC data, KYT, non i-Hub blocks, unblocking state | block status service | read only | 2 |
| 6 | Evaluate FR 0.0, FR 0.A, FR 0.B, FR 0.C (tiering fetched lazily by FR 0.A) | 4 rule classes | none | 8 to 11 |
| 7 | Dry-run: log the outcomes and stop | `ReviewEvaluationService` | none | 13 |
| 8 | Lock the review (`findByIdForUpdate`), check the version | `ReviewEvaluationService` | **phase 2 starts** (`REQUIRES_NEW`) | 12 |
| 9 | Run the commands on the Review, fallback task if refused; register tasks | `ReviewCommandDispatcher` + `Review` | phase 2 | 4 |
| 10 | Save the Review; synchronous listener saves the status history | `ReviewRepository`, `ReviewStatusHistoryRecorder` | phase 2, **commit** | 4 |
| 11 | After commit: task listener upserts the Salesforce task | `KycReviewTaskListener` | own | 3 |
| 12 | After commit: blocking listener, outbox, adapter PUT, then success or task FR 0.A | blocking outbox handler | own | 7 |
| 13 | After commit: unblocking listener, outbox, adapter REMOVE, then back to CCO or task FR 0.B | unblocking outbox handler | own | 6 |

## 4. Transactions and consistency

| Concern | Solution |
|---|---|
| No transaction open during remote calls | phase 1 (collect and decide) has no global transaction; phase 2 only touches the local database |
| Two changes on the same review at the same time | `findByIdForUpdate` in phase 2 + version check against phase 1, otherwise skipped |
| Status, actions, events and history consistent | one `save` of the Review aggregate; events registered in the aggregate; history written by a synchronous listener in the same transaction |
| Task or adapter call never lost | Spring Modulith event publication registry (tasks), outbox (adapter), both stored in the phase 2 transaction |
| Same validation notified twice or lost | `newValidation` read from a persisted marker, reset in phase 2 |
| Same task created twice | Salesforce upsert on the key review + task type |
| Two cron instances | ShedLock |

## 5. Events

| Event | Published by | Listener | Mode | Effect |
|---|---|---|---|---|
| `ReviewStatusChanged` | `Review.transitionTo()` | `ReviewStatusHistoryRecorder` | synchronous, same transaction | status history line |
| `ReviewBlocked` | `Review.block()` | blocking listener | after commit | outbox, adapter PUT |
| `UnblockingRequested` | `Review.requestUnblock()` | unblocking listener | after commit | outbox, adapter REMOVE |
| `ReviewBackToClientCommunication` | `Review.unblockingSucceeded()` | orchestrator (optional) | after commit | evaluate again for FR 0.C |
| `ReviewRemediated` | `Review.remediate()` | audit, other modules | after commit | information |
| `KycReviewTaskRequested` | rules, fallback, adapter failures | `KycReviewTaskListener` | after commit | Salesforce task upsert |

## 6. Failures and fallbacks

| Situation | Result |
|---|---|
| FTKYP-646, block status service down | no decision for this review, logged, next run |
| Tiering API down | no automatic blocking, task FR 0.A |
| Command refused by the Review (status changed) | fallback task of the rule |
| Adapter PUT fails after retries | `BLOCKING` in error, task FR 0.A |
| Adapter REMOVE fails after retries | `UNBLOCKING_ACCOUNT` in error, task FR 0.B |
| History save fails | status change rolled back, review evaluated again next run |
| Salesforce down | publication kept, resubmitted later |
| Technical error in phase 2 | rollback, no task, next run |
| One review fails | logged and counted, the cron continues |

## 7. Status and unblocking action

```plantuml
@startuml
title Review status and UNBLOCKING_ACCOUNT action
skinparam shadowing false

state "Review status" as RS {
  state "CCO / Prepare com" as CCO
  state BLOCKED
  state REMEDIATED
  [*] --> CCO
  CCO --> BLOCKED : FR 0.A auto: review.block()\nor KYCO after task FR 0.A
  BLOCKED --> CCO : unblocking PROCESSED\nreview.unblockingSucceeded()
  CCO --> REMEDIATED : FR 0.C auto: review.remediate()\nor KYCO after task FR 0.C
  REMEDIATED --> [*]
}

state "UNBLOCKING_ACCOUNT action" as UA {
  state INIT
  state TO_BE_PROCESSED
  state IN_PROGRESS
  state PROCESSED
  state ERROR
  [*] --> INIT : created with the review
  INIT --> TO_BE_PROCESSED : blocking PROCESSED
  TO_BE_PROCESSED --> IN_PROGRESS : FR 0.B auto: review.requestUnblock()\nor KYCO after task FR 0.B
  IN_PROGRESS --> PROCESSED : adapter OK
  IN_PROGRESS --> ERROR : adapter KO after retries\n-> task FR 0.B
  PROCESSED --> [*]
}
@enduml
```

## 8. Configuration

| Property | Meaning | Proposal |
|---|---|---|
| `kyc.review-evaluation.enabled` | job on or off | `false` until go-live |
| `kyc.review-evaluation.cron` | frequency | to define with the business |
| `kyc.review-evaluation.batch-size` | selection page size | 200 |
| `kyc.review-evaluation.dry-run` | log the outcomes without applying them | `true` for the first production runs |

## 9. Monitoring

- Counters: evaluated, skipped, failed reviews; outcomes per rule; fallback tasks.
- Timers: run duration, evaluation duration.
- End-of-run log with the totals and the failed review ids.

## 10. Open points

- Frequency and hours of the cron, dry-run period.
- Persisted marker for `newValidation`: flag set by FTKYP-646, or validation timestamp of the blocks.
- KYC data / KYT check in FR 0.B and FR 0.C.
- Why wait for the blocking planned date to finalize a review complete before.
- Task policy: update on every run or only on change, reopen a closed task, reminder after X days.
- Pending document: back-office delay after which KYCO is alerted.
- Contracts of the block status service and of the tiering API.
