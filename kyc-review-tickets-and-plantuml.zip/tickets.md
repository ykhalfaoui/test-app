# Epic - Automatic evaluation of KYC periodic reviews (i-Hub)

## Business context of the epic

During a KYC periodic review, the bank asks the customer (and its related parties) for documents through i-Hub. While the review is in **Client Communication Ongoing (CCO)** or **Prepare Client Communication**, KYCO follows each review by hand: checks whether documents arrived, decides when to block the customer, unblocks the account, then finalizes the review.

Each review has a **blocking planned date** (communication planned date + 95 days, or NIGO-GO + 45 days). Once it is passed and the review is still incomplete, the customer must be blocked (posting restriction on the account).

This epic automates that follow-up. For each review, the system builds a consolidated view (`ReviewContext`), then applies four business rules:

| Rule | Business meaning | Automatic action | Otherwise |
|---|---|---|---|
| FR 0.0 | i-Hub documents are complete, but non i-Hub blocks still need KYCO | none | task FR 0.0 |
| FR 0.A | Blocking planned date passed and the review is incomplete | review set to `Blocked` | task FR 0.A |
| FR 0.B | Blocked review is complete again | account unblocked, then review back to Client Communication Ongoing | task FR 0.B |
| FR 0.C | Review complete and ready to close | review set to `Remediated` | task FR 0.C |

Low-risk retail customers are processed automatically. The other profiles produce a Salesforce task so that KYCO keeps control.

**Already in place:** i-Hub document update service per party (FTKYP-646, FTKYP-643), process actions on the review, outbox, Spring Modulith.
**In progress in another ticket:** posting restriction adapter (put and remove posting restrictions on an account).

## Decisions taken with the business

- After the unblocking of the account, the review goes back to **Client Communication Ongoing**, then FR 0.C finalizes it.
- Two separate tasks: FR 0.B (lift restrictions) and FR 0.C (finalize).
- An automatic action that cannot be done falls back to the task of its rule: KYCO is always told.
- FR 0.0 has no condition on the blocking planned date.
- A pending document (under back-office validation) pauses the blocking.

**Full process:** see `puml/0-full-process.puml`.

## Ticket overview

| # | Block | Ticket | Depends on |
|---|---|---|---|
| 1 | Data | Review documents evaluation | none |
| 2 | Data | Review Context (facts only, rules decide) | 1, 5 |
| 3 | Foundation | KYC review task: Spring Modulith event and Salesforce listener | none |
| 4 | Foundation | Rule framework, review commands and Review aggregate | 3, 5 |
| 5 | Unblocking | Process action `UNBLOCKING_ACCOUNT`: type, init, lifecycle, backfill | none |
| 6 | Unblocking | Unblocking account execution: listener, outbox, adapter call | 5, adapter ticket |
| 7 | Blocking | Blocking execution: migrate to the posting restriction adapter | adapter ticket |
| 8 | Rules | FR 0.0 Documents completed | 2, 4 |
| 9 | Rules | FR 0.A Blocking | 2, 4 |
| 10 | Rules | FR 0.B Unblocking | 2, 4, 5 |
| 11 | Rules | FR 0.C Validation STP | 2, 4 |
| 12 | Assembly | Rule orchestrator and end-to-end tests | 8 to 11 |
| 13 | Assembly | Evaluation cron: selection, scheduling, isolation, monitoring | 12 |

```
Day 1, in parallel:  [1 Documents]   [3 Task event]   [5 Unblock action]   [7 Blocking migration]
                          |               |                |      \
                     [2 Context]   [4 Framework + Executor] [6 Unblock execution]
                            \            /
              [8 FR 0.0] [9 FR 0.A] [10 FR 0.B] [11 FR 0.C]      (in parallel)
                                  |
                          [12 Orchestrator]
                                  |
                          [13 Cron]
```

---

## Ticket 1 - Review documents evaluation

**Type:** Technical story
**Reuses:** FTKYP-646 (i-Hub document update service per party), FTKYP-643 (iHub adapter `GET /v1/bil-parties/{partyId}/completeness-status`)

### Business context
A review can only move forward when **all** i-Hub documents of **all** its members (main party and related parties) are validated. Today KYCO checks every member one by one in i-Hub. This service does it for the whole review in one call: it refreshes the documents of each member and gives one answer for the review.

### Technical description
Input: the `Review` (loaded by the caller, ticket 2).

1. **Get the members of the review**
   - Main party and related parties with status **different from `removed`**.
   - Keep only members that have at least one i-Hub document block on the review (`DOCS_IHUB_COMMON` or `DOCS_IHUB_SPECIFIC`).
2. **Call FTKYP-646 for each member**
   - Input: `partyId` and the i-Hub block types of the member on the review.
   - FTKYP-646 calls i-Hub, updates the documents and the blocks, and returns:

```json
{ "newValidation": true, "allBlocksCompliant": false, "rejected": true, "pending": true }
```

3. **Consolidate at review level**

| Indicator | Calculation | Meaning |
|---|---|---|
| `newValidation` | OR of all members | at least one block validated during this execution |
| `allBlocksCompliant` | AND of all members | every i-Hub block of every member validated (by system or by user) |
| `pending` | OR of all members | at least one document under back-office validation |
| `rejected` | OR of all members | at least one document rejected |

```java
public record ReviewDocumentResult(
    boolean newValidation,
    boolean allBlocksCompliant,
    boolean pending,
    boolean rejected
) {}
```

### Examples (review with two members)

| Member A | Member B | `newValidation` | `allBlocksCompliant` | `pending` | `rejected` |
|---|---|---|---|---|---|
| block just validated, compliant | already compliant | true | true | false | false |
| already compliant | already compliant | false | true | false | false |
| block just validated, compliant | one document pending | true | false | true | false |
| one document rejected | one document pending | false | false | true | true |
| no change, not compliant | already compliant | false | false | false | false |

### Edge cases
- **No member with an i-Hub block:** `allBlocksCompliant = true`, other indicators false, warning logged. To confirm within the team.
- **FTKYP-646 fails for one member:** the service fails, error logged with review id and party id.
- **Loss of `newValidation`:** FTKYP-646 compares the block before and after **its own call**. If the block was validated and committed at run N but the evaluation failed, run N+1 sees the block already valid and `newValidation = false`: the movement is lost. The detection must rely on a persisted state, not on the last call. Two options, to decide within the team:
  - **A. Flag set by FTKYP-646:** when a block passes to `VALIDATED_BY_SYSTEM`, FTKYP-646 sets `documentsValidatedToEvaluate = true` on the review in the same commit. The evaluation resets it only in its final transaction.
  - **B. Timestamp (no change to FTKYP-646):** `newValidation = at least one block with validatedAt > review.documentsLastEvaluatedAt`. The evaluation updates `documentsLastEvaluatedAt` in its final transaction. Requires a reliable validation date on the blocks.

### Acceptance criteria
- Given a member with status `removed`, then FTKYP-646 is not called for it.
- Given a member without i-Hub block on the review, then FTKYP-646 is not called for it.
- Given a member with only `DOCS_IHUB_SPECIFIC`, then FTKYP-646 is called with that block type only.
- Given two members compliant, then `allBlocksCompliant = true`; one not compliant, then `false`.
- Given one member with `newValidation`, `pending` or `rejected` true, then the review indicator is true.
- Given FTKYP-646 fails, then the error is logged with review id and party id.
- Every line of the examples table returns the expected indicators.

---

## Ticket 2 - Review Context: entry point of the review evaluation

**Type:** Technical story
**Uses:** ticket 1, ticket 5 (unblocking process action), existing service exposing KYC data, KYT and non i-Hub blocks (name to complete), party tiering API

### Business context
To decide what to do with a review (notify, block, unblock, finalize), the bank needs a complete and up-to-date picture of it: status, blocking planned date, documents of every member, KYC data, KYT, non i-Hub blocks, customer profile, state of the unblocking. Today KYCO gathers this by hand from several screens.

The Review Context gathers these **facts** once. It does **not** decide anything: the eligibility and the automation conditions of each action live in the rules (tickets 8 to 11), each rule owning its own conditions.

### Why the Review Context is the entry point
- Every evaluation starts by collecting the facts, in one place, before any decision.
- All rules read the same facts, collected at the same moment.
- Rules contain only business conditions: no service call, no repository.

### Technical description
Input: `reviewId`.

1. **Load the review:** get the `Review` from the database and put it in the context.
   - Review not found, or status not in (`CCO`, `PREPARE_COM`, `BLOCKED`): no context, logged.
2. **Documents:** call ticket 1 with the `Review`. It returns `ReviewDocumentResult`.
3. **Other blocks:** call the block status service.
   - `nonIhubBlocksOk`: false as soon as one non i-Hub block is **amber**.
   - `kycDataAndKytOk`: false as soon as KYC data or KYT is KO, for the main party or the review.
4. **Unblocking action state:** read the status of the `UNBLOCKING_ACCOUNT` process action of the review (ticket 5).
5. **Party tiering, lazy:** the tiering comes from an API and is only needed by FR 0.A when a blocking could be automatic. The context does **not** call it: it exposes a lazy, memoized lookup. The API is called only the first time a rule asks for it, and at most once per evaluation.

```java
public record ReviewContext(
    Review review,                          // status, blocking planned date, pool, AML score, main DAO
    ReviewDocumentResult documents,         // ticket 1
    boolean nonIhubBlocksOk,
    boolean kycDataAndKytOk,
    ProcessActionStatus unblockingAction,   // ticket 5: INIT, TO_BE_PROCESSED, IN_PROGRESS, PROCESSED, ERROR
    PartyTieringLookup partyTiering         // lazy: calls the tiering API on first get(), then cached
) {}

public final class PartyTieringLookup {
    private final Supplier<Optional<Integer>> loader;   // wraps the tiering API call for the main party
    private Optional<Integer> value;
    public Optional<Integer> get() { if (value == null) value = loader.get(); return value; }
}
```

The `Review` is read only for the rules: they never modify it.

### What the context contains, and what it does not

| In the context (facts) | In the rules (conditions) |
|---|---|
| status, blocking planned date, pool, AML score, main DAO | eligibility of each action |
| `newValidation`, `allBlocksCompliant`, `pending`, `rejected` | automation conditions (Retail, Low, tiering, 831...) |
| `nonIhubBlocksOk`, `kycDataAndKytOk` | which action or which task |
| unblocking action state | |
| tiering, on demand | |

### Edge cases
- **Ticket 1 or the block status service fails:** no context, error logged with the review id, no rule runs.
- **Tiering API fails:** `partyTiering.get()` returns empty, logged. FR 0.A then creates a task, so KYCO decides.
- **Missing KYC data or KYT:** `kycDataAndKytOk = false`, logged.
- **No `UNBLOCKING_ACCOUNT` action on the review** (should not happen after ticket 5 backfill): logged as error.

### Acceptance criteria
- Given a `reviewId`, then the `Review` is loaded from the database and put in the context.
- Given an unknown review, or a review not in CCO, Prepare com or Blocked, then no context is built.
- Given ticket 1 returns its indicators, then they are in `context.documents()` unchanged.
- Given one non i-Hub block amber, then `nonIhubBlocksOk = false`.
- Given KYT KO on the main party, then `kycDataAndKytOk = false`.
- Given the unblocking action in `TO_BE_PROCESSED`, then `unblockingAction = TO_BE_PROCESSED`.
- Given the context is built, then the tiering API is not called.
- Given `partyTiering.get()` called twice, then the tiering API is called once.
- Given the tiering API in error, then `partyTiering.get()` returns empty.

### Open points for the team
- Name and contract of the block status service and of the tiering API.

---

## Ticket 3 - KYC review task: Spring Modulith event and Salesforce listener

**Type:** Technical story

### Business context
When a rule cannot act automatically, KYCO must receive a **Salesforce task** telling what to do on the review. There are four kinds of tasks, one per rule. KYCO must never receive the same task twice for the same review: an existing task is reopened and updated, not duplicated. A task must never be lost, even if Salesforce is unavailable.

### Technical description
Tasks are **Spring Modulith application events**. The event publication registry stores the publication in the same transaction as the rule result, and the listener runs after commit. Incomplete publications are resubmitted, so no task is lost.

```java
public record KycReviewTaskRequested(
    String reviewId,
    TaskType taskType,
    Instant occurredAt
) {}

public enum TaskType {
    FR_0_0("KYC REVIEW - i-HUB documents complete. Ready for follow-up",
           "<description>", "<queue>", Priority.NORMAL),
    FR_0_A("KYC REVIEW - The customer eligible for blocking",
           "<description>", "<queue>", Priority.HIGH),
    FR_0_B("KYC REVIEW - Restrictions of the customer to be manually lifted",
           "<description>", "<queue>", Priority.HIGH),
    FR_0_C("KYC REVIEW - The review meets the criteria for a finalization",
           "<description>", "<queue>", Priority.NORMAL);

    private final String subject;
    private final String description;
    private final String queue;
    private final Priority priority;
}
```

1. **Publisher** `KycReviewTaskPublisher`: `applicationEventPublisher.publishEvent(new KycReviewTaskRequested(...))`, called inside the transaction of the evaluation.
2. **Listener** `KycReviewTaskListener` with `@ApplicationModuleListener`:
   - reads subject, description, queue and priority from `TaskType`,
   - looks for an existing Salesforce task with the key `reviewId + taskType`,
   - absent: create. Open: update. Closed: reopen and update.
3. **Resubmission** of incomplete publications (Salesforce down): use the Spring Modulith mechanism already configured in the project (resubmit on restart or scheduled resubmission).

Descriptions, queues and priorities are placeholders, to be provided by the business. Changing a value requires a release.

### Acceptance criteria
- Given the evaluation transaction commits, then the event publication is stored and the listener is called after commit.
- Given the evaluation transaction rolls back, then no event is published and no task is created.
- Given no existing task for this review and type, then one task is created with the values of its `TaskType`.
- Given an open task of the same type, then it is updated, no duplicate.
- Given a closed task of the same type, then it is reopened and updated.
- Given Salesforce unavailable, then the publication stays incomplete and the task is created once it is resubmitted.

### Open questions for the business
- Uniqueness key `review + task type`: correct on the Salesforce side?
- Open task and nothing changed: update on every evaluation or only on change?
- Task closed by KYCO without doing the action: reopen it?
- Task open for a long time: reminder after X days?

---

## Ticket 4 - Rule framework, review commands and Review aggregate

**Type:** Technical story

### Business context
Each of the four rules answers the same three questions: is the review **eligible**, can the action be done **automatically**, and **which action**. If it cannot be automatic, KYCO gets a task. And if an automatic action turns out to be impossible when it is executed, KYCO must also get a task: an action never fails silently.

All changes go through the **review**: blocking, unblocking, return to client communication, remediation. The review checks that the change is allowed, updates its status and its process actions together, and publishes the matching event.

### Technical description

**1. Template of a rule**

```java
public abstract class ReviewRule {

    public final RuleOutcome evaluate(ReviewContext ctx) {
        if (!isEligible(ctx)) return new NotApplicable(type());
        if (canAutomate(ctx)) return new AutomaticAction(type(), command(ctx));
        return new TaskRequested(type(), taskType());
    }

    protected abstract RuleType type();
    protected abstract boolean isEligible(ReviewContext ctx);
    protected abstract boolean canAutomate(ReviewContext ctx);
    protected abstract ReviewCommand command(ReviewContext ctx);
    protected abstract TaskType taskType();
}

public sealed interface RuleOutcome {
    record NotApplicable(RuleType rule) implements RuleOutcome {}
    record AutomaticAction(RuleType rule, ReviewCommand command) implements RuleOutcome {}
    record TaskRequested(RuleType rule, TaskType taskType) implements RuleOutcome {}
}
```

**2. Commands (Command pattern), each with its fallback task**

```java
public sealed interface ReviewCommand {
    String reviewId();
    TaskType fallbackTask();

    record BlockReview(String reviewId)    implements ReviewCommand { public TaskType fallbackTask() { return TaskType.FR_0_A; } }
    record UnblockAccount(String reviewId) implements ReviewCommand { public TaskType fallbackTask() { return TaskType.FR_0_B; } }
    record Remediate(String reviewId)      implements ReviewCommand { public TaskType fallbackTask() { return TaskType.FR_0_C; } }
}
```

**3. One handler per command, called by a dispatcher (Command Handler pattern)**

```java
public interface ReviewCommandHandler<C extends ReviewCommand> {
    Class<C> supports();
    CommandResult handle(Review review, C command);
}

public sealed interface CommandResult {
    record Done() implements CommandResult {}
    record Refused(String reason) implements CommandResult {}
}

@Component
class ReviewCommandDispatcher {
    CommandResult dispatch(Review review, ReviewCommand command) {
        CommandResult result = handler(command).handle(review, command);
        if (result instanceof Refused r) {
            log.warn("{} refused for {}: {}", command, review.getId(), r.reason());
            review.requestTask(command.fallbackTask());          // fallback: KYCO decides
        }
        return result;
    }
}
```

| Command | Handler | Review method | Refused when |
|---|---|---|---|
| `BlockReview` | `BlockReviewHandler` | `review.block()` | status not CCO or Prepare com |
| `UnblockAccount` | `UnblockAccountHandler` | `review.requestUnblock()` | not Blocked, or unblocking action not `TO_BE_PROCESSED` |
| `Remediate` | `RemediateHandler` | `review.remediate()` | status not CCO |

**4. The Review aggregate (state machine + process actions + events)**

The process actions (`BLOCKING`, `UNBLOCKING_ACCOUNT`) belong to the `Review` aggregate. Each method changes the status and the actions together and registers its event. Events are published by Spring Modulith when the review is saved, in the same transaction.

```java
public class Review extends AbstractAggregateRoot<Review> {
    @Version private long version;

    public void block(Actor actor)     { require(CCO, PREPARE_COM); transitionTo(BLOCKED, actor); action(BLOCKING).toBeProcessed(); registerEvent(new ReviewBlocked(id)); }
    public void requestUnblock()       { require(BLOCKED); action(UNBLOCKING_ACCOUNT).start(); registerEvent(new UnblockingRequested(id)); }
    public void remediate(Actor actor) { require(CCO); transitionTo(REMEDIATED, actor); registerEvent(new ReviewRemediated(id)); }

    // single entry point for every status change -> history never forgotten
    private void transitionTo(ReviewStatus target, Actor actor) {
        ReviewStatus from = status;
        status = target;
        registerEvent(new ReviewStatusChanged(id, from, target, actor.mode(), actor.name(), Instant.now()));
    }
    public void requestTask(TaskType t) { registerEvent(new KycReviewTaskRequested(id, t, now())); }

    // called by the outbox handlers (tickets 6 and 7)
    public void blockingSucceeded()   { action(BLOCKING).processed(); action(UNBLOCKING_ACCOUNT).toBeProcessed(); }
    public void blockingFailed()      { action(BLOCKING).error(); requestTask(FR_0_A); }
    public void unblockingSucceeded() { action(UNBLOCKING_ACCOUNT).processed(); transitionTo(CCO, Actor.system("FR_0_B")); registerEvent(new ReviewBackToClientCommunication(id)); }
    public void unblockingFailed()    { action(UNBLOCKING_ACCOUNT).error(); requestTask(FR_0_B); }
}
```

**5. Events published by the Review**

| Event | Published by | Listened by | Effect |
|---|---|---|---|
| `ReviewBlocked` | `block()` | blocking listener (ticket 7) | outbox, then adapter PUT posting restriction |
| `UnblockingRequested` | `requestUnblock()` | unblocking listener (ticket 6) | outbox, then adapter REMOVE posting restriction |
| `ReviewBackToClientCommunication` | `unblockingSucceeded()` | orchestrator (optional) | evaluate the review again for FR 0.C |
| `ReviewRemediated` | `remediate()` | audit, other modules | information |
| `KycReviewTaskRequested` | `requestTask()` | task listener (ticket 3) | Salesforce task upsert |
| `ReviewStatusChanged` | `transitionTo()` (every status change) | `ReviewStatusHistoryRecorder` | status history saved, **same transaction** |

KYCO manual actions use the same `Review` methods: same checks, same events, same history.

**6. Status history (separate aggregate, same transaction)**

The status history has its own aggregate and repository. The `Review` never calls it: it publishes `ReviewStatusChanged`, and a **synchronous** listener saves the history right after the review update, in the same transaction.

```java
@Component
@RequiredArgsConstructor
class ReviewStatusHistoryRecorder {

    private final ReviewStatusHistoryService reviewStatusHistoryService;

    @EventListener                       // synchronous: runs inside the transaction of reviewRepository.save()
    void on(ReviewStatusChanged e) {
        reviewStatusHistoryService.createHistoryFor(e.reviewId(), e.mode(), e.from(), e.to(), e.actor(), e.at());
    }
}
```

- Synchronous `@EventListener` (not `@ApplicationModuleListener`): the review and its history are committed together, or rolled back together.
- `TransitionMode`: `AUTOMATIC` for the rules and the adapter callbacks, `MANUAL` for KYCO.
- No status change: no event, no history line.

### Acceptance criteria
- Given a rule not eligible, then `NotApplicable` and `canAutomate` is not called.
- Given a rule eligible and automatic, then `AutomaticAction` with the rule's command.
- Given a rule eligible and not automatic, then `TaskRequested` with the rule's task type.
- Given `BlockReview` on a review in CCO, then status `Blocked`, `BLOCKING` to be processed, `ReviewBlocked` published.
- Given `BlockReview` on a review already Blocked, then `Refused` and `KycReviewTaskRequested(FR_0_A)` published.
- Given `UnblockAccount` with the unblocking action not `TO_BE_PROCESSED`, then `Refused` and task FR_0_B.
- Given `Remediate` on a review not in CCO, then `Refused` and task FR_0_C.
- Given the save fails, then no event is published (same transaction).
- Given a KYCO manual blocking, then the same `review.block()` is used and `ReviewBlocked` is published.
- Given any status change, then one history line is saved with from, to, mode and actor, in the same transaction.
- Given the history save fails, then the status change is rolled back.
- Given a command that does not change the status (`requestUnblock`), then no history line.

---

## Ticket 5 - Process action `UNBLOCKING_ACCOUNT`: type, init, lifecycle and backfill

**Type:** Technical story

### Business context
Unblocking a customer means **removing the posting restriction** from the account. Like the blocking, it must go through a **process action** on the review: it is traceable, it is executed once, and it is never relaunched once processed. Today there is no such action for the unblocking. It must exist on every review, become ready as soon as the customer is blocked, and be added to the reviews already in progress.

### Technical description

**1. New process action type** `UNBLOCKING_ACCOUNT`, next to the existing blocking action.

**2. Lifecycle**

| Status | When |
|---|---|
| `INIT` | created with the review (same place as the other process actions) |
| `TO_BE_PROCESSED` | when the blocking action of the review is processed (account blocked) |
| `IN_PROGRESS` | triggered by FR 0.B (automatic) or by KYCO (manual, after task FR 0.B) |
| `PROCESSED` | posting restriction removed by the adapter (ticket 6) |
| `ERROR` | adapter call failed (ticket 6) |

Status names to align with the existing process action statuses.

**3. Init:** create the `UNBLOCKING_ACCOUNT` action in `INIT` for every new review, in the same place where the other process actions are initialized.

**4. Transition to `TO_BE_PROCESSED`:** when the blocking action passes to processed, move the unblocking action of the same review to `TO_BE_PROCESSED`. Same transaction as the blocking update.

**5. Backfill of the reviews in progress** (database migration):

| Review today | `UNBLOCKING_ACCOUNT` created in |
|---|---|
| CCO or Prepare com, not blocked | `INIT` |
| Blocked, blocking action processed | `TO_BE_PROCESSED` |
| Remediated or closed | not created |

The migration is idempotent: a review that already has the action is not touched.

**6. Manual trigger:** KYCO can trigger the action from the review after a task FR 0.B. Use the existing way process actions are triggered by users, if any. To confirm.

### Acceptance criteria
- Given a new review, then an `UNBLOCKING_ACCOUNT` action exists in `INIT`.
- Given the blocking action passes to processed, then the unblocking action of the same review passes to `TO_BE_PROCESSED`.
- Given the blocking action fails, then the unblocking action stays in `INIT`.
- Given the migration runs, then each review in progress gets the action with the status of the table above.
- Given the migration runs twice, then no duplicate action is created.
- Given the action in `PROCESSED`, then it can never be triggered again.

---

## Ticket 6 - Unblocking account execution: listener, outbox and adapter call

**Type:** Technical story
**Depends on:** posting restriction adapter (other ticket, in progress)

### Business context
Once the unblocking is decided (automatically by FR 0.B or by KYCO), the posting restriction must really be removed from the customer account in the core banking system. Only then does the review go back to **Client Communication Ongoing** (business decision), so that it can be finalized. If the unblocking cannot be done, KYCO must be told with a task.

### Technical description
1. **Listener** on `UnblockingRequested` (published by `review.requestUnblock()`, action `IN_PROGRESS`): saves an outbox entry.
2. **Outbox handler:** calls the **posting restriction adapter**, operation "remove posting restriction", for the account(s) of the review.
3. **Result**, in one transaction on the review:
   - success: `review.unblockingSucceeded()`: action `PROCESSED`, status `Blocked` to `CCO`, event `ReviewBackToClientCommunication`,
   - failure after the maximum retries: `review.unblockingFailed()`: action `ERROR` and task FR_0_B, KYCO unblocks by hand.
4. **Idempotency:** an action already `PROCESSED` is ignored by the handler.

```
FR 0.B or KYCO -> review.requestUnblock() -> IN_PROGRESS + UnblockingRequested
  -> listener -> outbox entry
     -> outbox handler -> adapter: remove restriction
        -> success : PROCESSED, review back to CCO  (next evaluation: FR 0.C)
        -> failure : retries, then ERROR + task FR_0_B
```

### Acceptance criteria
- Given `UnblockingRequested`, then one outbox entry is stored.
- Given the adapter succeeds, then the action is `PROCESSED`, the review is in CCO and `ReviewBackToClientCommunication` is published.
- Given the adapter fails, then the outbox retries; after the maximum, the action is `ERROR` and a task FR_0_B is published.
- Given the same entry handled twice, then the adapter is called only once.

---

## Ticket 7 - Blocking execution: migrate to the posting restriction adapter

**Type:** Technical story
**Depends on:** posting restriction adapter (other ticket, in progress)

### Business context
Blocking and unblocking are two sides of the same operation on the customer account: put a posting restriction, remove it. Using the same adapter for both guarantees that what one puts, the other can remove. If the blocking cannot be done, KYCO must be told with a task.

### Technical description
- **Listener** on `ReviewBlocked` (published by `review.block()`): saves an outbox entry.
- **Outbox handler:** calls the posting restriction adapter, operation "put posting restriction", for the account(s) of the review. It replaces the current integration of the blocking process action.
- **Result**, in one transaction on the review:
  - success: `review.blockingSucceeded()`: `BLOCKING` processed, `UNBLOCKING_ACCOUNT` to `TO_BE_PROCESSED` (ticket 5),
  - failure after the maximum retries: `review.blockingFailed()`: `BLOCKING` in error and task FR_0_A.
- Keep the existing audit and error handling of the blocking action. Remove the old integration once validated (or feature flag during the transition, to decide within the team).

### Acceptance criteria
- Given `ReviewBlocked`, then the adapter is called with "put posting restriction".
- Given the adapter succeeds, then `BLOCKING` is processed and `UNBLOCKING_ACCOUNT` is `TO_BE_PROCESSED`.
- Given the adapter fails after the retries, then `BLOCKING` is in error and a task FR_0_A is published.
- Given a customer blocked through the adapter, then the unblocking through the same adapter removes the restriction (integration test).
- Non-regression: the existing blocking tests still pass.

---

## Ticket 8 - Rule FR 0.0: documents completed

**Type:** Technical story

### Business context
When the last i-Hub document of a review is validated, the i-Hub part is done. If KYCO still has **manual analysis** to do on non i-Hub blocks (at least one amber), KYCO must be told that the i-Hub documents are complete and that the review can be followed up.
- This rule **never changes the review**: there is no automatic action, it only creates a task for KYCO.
- It has **no condition on the blocking planned date** (decision D1): it can fire before or after the date, and in the same evaluation as FR 0.A.
- It also applies to a **Blocked** review: documents can be completed while the customer is blocked.
- If all non i-Hub blocks are already OK, there is nothing to tell KYCO: FR 0.B or FR 0.C take over.

### Rule
```
eligible   : status in (CCO, PREPARE_COM, BLOCKED)
             and allBlocksCompliant
             and newValidation
             and not nonIhubBlocksOk
automatic  : never                       -> canAutomate() always returns false, no command
otherwise  : task FR 0.0                 -> "KYC REVIEW - i-HUB documents complete. Ready for follow-up"
```

### Technical description
- `DocumentsCompletedRule extends ReviewRule` (ticket 4).
  - `isEligible`: the four conditions above, all read from the context.
  - `canAutomate`: always `false`.
  - `command`: never called.
  - `taskType`: `TaskType.FR_0_0`.
- `newValidation` must come from the **persisted** marker of ticket 1 (option A flag or option B timestamp), not from the in-memory result of the last FTKYP-646 call. Otherwise a failed evaluation loses the notification.
- The marker is reset by the orchestrator in phase 2 (ticket 12), whether FR 0.0 created a task or not. So the same validation never produces two tasks.
- The task is idempotent anyway (ticket 3): if a FR 0.0 task already exists for the review, it is updated, not duplicated.

### Acceptance criteria
- Given status CCO, documents compliant, a block just validated, one non i-Hub block amber, then `TaskRequested(FR_0_0)`.
- Given the same with status Prepare com or Blocked, then `TaskRequested(FR_0_0)`.
- Given the blocking planned date passed, then the rule still applies.
- Given all non i-Hub blocks green or grey, then `NotApplicable`.
- Given no block just validated, then `NotApplicable`.
- Given documents not all compliant, then `NotApplicable`.
- Given status Remediated, then `NotApplicable`.
- Given the evaluation failed after a block was validated, then the next evaluation still returns `TaskRequested(FR_0_0)` (persisted marker).
- The rule never returns `AutomaticAction`.

---

## Ticket 9 - Rule FR 0.A: blocking

**Type:** Technical story

### Business context
The customer had until the **blocking planned date** to provide what was asked. Once it is passed and the review is still incomplete (documents not compliant, or KYC data / KYT KO), the customer must be **blocked**.
- Low-risk customers (tiering 4 or 5, Retail, AML Low) are blocked automatically, unless a document was **rejected**: a rejection needs a human look.
- Other customers: KYCO receives a task.
- A **pending** document (provided by the customer, under back-office validation) pauses the blocking: the customer did the job.

### Rule
```
eligible   : status in (CCO, PREPARE_COM) and blockingPlannedDate < today and not pending
             and (not allBlocksCompliant or not kycDataAndKytOk)
automatic  : pool = Retail and amlScore = Low and not rejected
             and partyTiering in (4, 5)              -> command BlockReview
otherwise  : task FR 0.A
```

In `canAutomate`, check pool, AML score and `rejected` first, and ask `partyTiering.get()` last: the tiering API is then called only when a blocking could really be automatic.

The command `BlockReview` calls `review.block()` (ticket 4): status `Blocked`, `BLOCKING` to be processed, event `ReviewBlocked`, then the adapter (ticket 7). "today" comes from an injected `Clock`.

### Acceptance criteria
- Given eligible, Retail, Low, no rejected document, tiering 4 or 5, then `AutomaticAction(BlockReview)`.
- Given eligible, Retail, Low, no rejected document, tiering 2, then `TaskRequested(FR_0_A)`.
- Given eligible, not Retail or not Low, then `TaskRequested(FR_0_A)` and the tiering is not requested.
- Given eligible with a rejected document, then `TaskRequested(FR_0_A)` and the tiering is not requested.
- Given not eligible, then the tiering is not requested.
- Given the tiering unavailable, then `TaskRequested(FR_0_A)`.
- Given documents compliant but KYC data / KYT KO, then the rule applies.
- Given a pending document, then `NotApplicable`.
- Given the date not passed, or status Blocked, then `NotApplicable`.

### Open questions for the business
- Pending document: is there a back-office delay after which KYCO is alerted?
- Only non i-Hub blocks KO (documents and KYC OK): no blocking, intended?
- Tiering "4 and 5" means "4 or 5"?

---

## Ticket 10 - Rule FR 0.B: unblocking

**Type:** Technical story

### Business context
A blocked customer who provided everything must get access to the account again. FR 0.B decides the unblocking. The account is unblocked through the `UNBLOCKING_ACCOUNT` process action, and once the restriction is really removed, the review goes back to **Client Communication Ongoing** (business decision, ticket 6). FR 0.C then finalizes it.
- Retail, AML Low (831 included): automatic unblocking.
- Other customers: task FR 0.B, KYCO unblocks by hand (same process action, same return to CCO).
- No unblocking while a non i-Hub block is still amber.

### Rule
```
eligible   : status = BLOCKED and allBlocksCompliant and nonIhubBlocksOk
             and unblockingAction = TO_BE_PROCESSED
automatic  : pool = Retail and amlScore = Low   -> command UnblockAccount
otherwise  : task FR 0.B
```

The status stays `Blocked` until the adapter confirms the unblocking (ticket 6).

### Acceptance criteria
- Given eligible, Retail, Low (831 or not), then `AutomaticAction(UnblockAccount)`.
- Given eligible, not Retail or not Low, then `TaskRequested(FR_0_B)`.
- Given the unblocking action `INIT`, `IN_PROGRESS`, `PROCESSED` or `ERROR`, then `NotApplicable`.
- Given one non i-Hub block amber, then `NotApplicable`.
- Given status CCO, then `NotApplicable`.

### Open question for the business
- Should the unblocking also require KYC data / KYT OK? Without it, a review blocked only for KYC would be unblocked with KYC still KO.

---

## Ticket 11 - Rule FR 0.C: validation / finalization (STP)

**Type:** Technical story

### Business context
A review is ready to close when every document is compliant and every non i-Hub block is OK, the review is in **Client Communication Ongoing** and the blocking planned date is passed. A blocked review first goes back to CCO after its unblocking (ticket 6), then follows the same path.

Low-risk retail customers outside Retail International (831) are finalized automatically (`Remediated`). For the others, KYCO receives task FR 0.C.

### Rule
```
eligible   : status = CCO and blockingPlannedDate < today
             and allBlocksCompliant and nonIhubBlocksOk
automatic  : pool = Retail and amlScore = Low and mainDao != 831   -> command Remediate
otherwise  : task FR 0.C
```

### Acceptance criteria
- Given CCO, date passed, all OK, auto profile, then `AutomaticAction(Remediate)`.
- Given the same with main DAO 831, then `TaskRequested(FR_0_C)`.
- Given the same with AML score not Low, then `TaskRequested(FR_0_C)`.
- Given a review back in CCO after an unblocking, all OK, auto profile, then `AutomaticAction(Remediate)`.
- Given status Blocked, then `NotApplicable`.
- Given CCO, date not passed, then `NotApplicable`.
- Given one non i-Hub block amber, then `NotApplicable`.

### Open questions for the business
- Why wait for the blocking planned date to finalize a review complete before?
- Should finalization also require KYC data / KYT OK?

---

## Ticket 12 - Rule orchestrator and end-to-end tests

**Type:** Technical story

### Business context
For a given review, the four rules must be applied in a fixed and predictable order, so that KYCO never receives contradictory tasks and the review never ends in an inconsistent state.

### Technical description
The evaluation runs in **two phases**, so that no database transaction stays open during the calls to other services (iHub, block status service, tiering API).

```java
public EvaluationReport evaluate(String reviewId) {
    // Phase 1 - collect and decide, no global transaction
    ReviewContext ctx = contextService.build(reviewId);              // ticket 2 (remote calls)
    List<RuleOutcome> outcomes = rules.stream()                      // @Order: FR 0.0, 0.A, 0.B, 0.C
        .map(rule -> rule.evaluate(ctx))                             // pure, tiering fetched lazily if needed
        .toList();

    // Phase 2 - apply, one short transaction
    return applier.apply(ctx.review().getId(), ctx.review().getVersion(), outcomes);
}

@Transactional(propagation = Propagation.REQUIRES_NEW)             // one transaction per review
public EvaluationReport apply(ReviewId reviewId, long expectedVersion, List<RuleOutcome> outcomes) {
    Review review = repository.findByIdForUpdate(reviewId).orElseThrow();   // pessimistic lock
    if (review.getVersion() != expectedVersion) return EvaluationReport.skipped(reviewId);
    for (RuleOutcome o : outcomes) {
        switch (o) {
            case NotApplicable n   -> { }
            case AutomaticAction a -> dispatcher.dispatch(review, a.command());   // refused -> fallback task
            case TaskRequested t   -> review.requestTask(t.taskType());
        }
    }
    review.markDocumentsEvaluated();                                 // newValidation marker reset
    repository.save(review);                                         // status + actions + events + history together
    return EvaluationReport.of(reviewId, outcomes);
}
```

- **Phase 1** has no global transaction: FTKYP-646 uses its own short local transactions, the other calls are read only.
- **Phase 2** only touches the local database and lasts milliseconds.
- **Lock and check**: phase 2 reloads the review with `findByIdForUpdate` (nobody else can change it during the transition) and compares the version read in phase 1. If the review changed meanwhile (KYCO action, adapter callback), nothing is applied and the next evaluation decides again.
- **History**: written by the synchronous `ReviewStatusChanged` listener (ticket 4), inside this transaction.
- Status changes are taken into account at the **next** evaluation. Example: a review blocked by FR 0.A is not unblocked in the same evaluation.
- The unblocking is asynchronous (ticket 6): the review goes back to CCO when the adapter confirms, then FR 0.C applies at the next evaluation (or immediately on `ReviewBackToClientCommunication`, optional).
- `EvaluationReport`: review id and outcome of each rule, logged for audit.

### Acceptance criteria
- Given documents just completed, a non i-Hub block amber and KYC KO after the date, then both FR 0.0 and FR 0.A outcomes are produced.
- Given a review blocked by FR 0.A, then FR 0.B does not apply in the same evaluation.
- Given a blocked low-risk review now complete, then the unblocking is requested; after the adapter succeeds the review is in CCO; the next evaluation sets `Remediated`.
- Given a command refused by the review, then the fallback task is published in the same transaction.
- Given a failure while saving, then nothing is stored and the `newValidation` marker is kept.
- Given the review modified between phase 1 and phase 2, then nothing is applied and the report is marked skipped.
- Given phase 1, then no database transaction is open during the remote calls.
- One integration test per business scenario agreed with the business.

---

## Ticket 13 - Evaluation cron: selection, scheduling, isolation and monitoring

**Type:** Technical story

### Business context
Every open review must be re-evaluated regularly, so that a validated document, a passed blocking date, an unblocked account or a KYCO action is taken into account without anyone having to trigger it. The run must never block the application, never evaluate the same review twice at the same time, and one problem on a review must never stop the others.

### Technical description

**1. Scheduling**
```java
@Component
@RequiredArgsConstructor
class ReviewEvaluationJob {

    @Scheduled(cron = "${kyc.review-evaluation.cron}")
    @SchedulerLock(name = "kyc-review-evaluation", lockAtMostFor = "PT2H")     // one instance only
    void run() {
        if (!properties.enabled()) return;
        JobReport report = new JobReport();
        for (List<ReviewId> page : selector.eligibleReviewIds(properties.batchSize())) {
            for (ReviewId id : page) {
                try {
                    report.add(evaluationService.evaluate(id));               // ticket 12
                } catch (Exception e) {
                    log.error("Evaluation failed for review {}", id, e);
                    report.failed(id);                                        // next review continues
                }
            }
        }
        log.info("KYC review evaluation done: {}", report);
    }
}
```

**2. Selection**
- Review ids only (not the full entity), statuses `CCO`, `PREPARE_COM`, `BLOCKED`.
- Keyset pagination on the id, page size `kyc.review-evaluation.batch-size`.
- Each review is then loaded by the evaluation itself (ticket 2), so the data is always fresh.

**3. Isolation**
- One evaluation = one review = its own phase 2 transaction (`REQUIRES_NEW`, ticket 12).
- A failing review is logged and counted, the run continues.
- Two instances (OpenShift pods): ShedLock (`@SchedulerLock`) guarantees one run at a time. If ShedLock is not in the project yet, add `shedlock-spring` + JDBC provider and its table.
- Concurrency with KYCO or adapter callbacks: handled by `findByIdForUpdate` and the version check (ticket 12).

**4. Configuration**

| Property | Meaning | Proposal |
|---|---|---|
| `kyc.review-evaluation.enabled` | switch the job on or off | `false` until go-live |
| `kyc.review-evaluation.cron` | frequency | to define with the business (for example every hour on working days) |
| `kyc.review-evaluation.batch-size` | page size of the selection | 200 |
| `kyc.review-evaluation.dry-run` | evaluate and log the outcomes without applying them | `true` for the first runs in production |

The **dry-run** mode runs phase 1 and the rules, logs what would be done (block, unblock, remediate, tasks) and skips phase 2. It lets the business check the decisions on real data before switching to real actions.

**5. Monitoring (Micrometer)**
- Counters: reviews evaluated, skipped, failed; outcomes per rule (not applicable, automatic, task); fallback tasks.
- Timer: duration of the run and of one evaluation.
- End-of-run log: totals per rule and list of failed review ids.

### Acceptance criteria
- Given the job disabled, then no review is evaluated.
- Given 3 reviews in CCO, Prepare com and Blocked and 1 in Remediated, then only the 3 are evaluated.
- Given one review whose evaluation throws, then the error is logged with its id and the other reviews are evaluated.
- Given two instances triggered at the same time, then only one run executes.
- Given dry-run, then outcomes are logged and nothing is changed (no status, no action, no task).
- Given a run, then the metrics and the end-of-run log are produced.

### Open questions for the business
- Frequency of the run, and hours (working days only?).
- Duration of the dry-run period before real actions.
