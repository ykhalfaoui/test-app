@integration @failures
Feature: Failures and fallbacks
  An automatic action that cannot be done falls back to the task of its rule.
  A technical problem never produces a wrong decision: the review is evaluated again at the next run.

  Background:
    Given today is "2026-11-19"
    And the evaluation job is enabled and not in dry-run
    And Salesforce is available

  @IT-20
  Scenario: The blocking fails at the adapter
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And member "A" of review "R1" has a missing i-Hub document
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100", tiering "4"
    And the posting restriction adapter fails on "PUT" for every retry
    When the evaluation job runs
    And the blocking outbox retries are exhausted
    Then the process action "BLOCKING" of review "R1" is "ERROR"
    And a Salesforce task "FR_0_A" is created for review "R1"
    And the review "R1" is in status "BLOCKED"

  @IT-21
  Scenario: The unblocking fails at the adapter
    Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "TO_BE_PROCESSED"
    And all members of review "R1" have compliant i-Hub documents
    And all non i-Hub blocks of review "R1" are OK
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100"
    And the posting restriction adapter fails on "REMOVE" for every retry
    When the evaluation job runs
    And the unblocking outbox retries are exhausted
    Then the process action "UNBLOCKING_ACCOUNT" of review "R1" is "ERROR"
    And a Salesforce task "FR_0_B" is created for review "R1"
    And the review "R1" is in status "BLOCKED"

  @IT-22
  Scenario: The tiering API is down
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And member "A" of review "R1" has a missing i-Hub document
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100"
    And the tiering API is unavailable
    When the evaluation job runs
    Then a Salesforce task "FR_0_A" is created for review "R1"
    And the review "R1" is in status "CCO"

  @IT-23
  Scenario: FTKYP-646 fails for one member
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And the iHub adapter fails for member "B" of review "R1"
    When the evaluation job runs
    Then the review "R1" is unchanged
    And no Salesforce task exists for review "R1"
    And an error is logged for review "R1" and party "B"

  @IT-24
  Scenario: The block status service is down
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And the block status service is unavailable
    When the evaluation job runs
    Then the review "R1" is unchanged
    And no Salesforce task exists for review "R1"

  @IT-25
  Scenario: Salesforce is down
    Given a review "R1" eligible for a task "FR_0_C"
    And Salesforce is unavailable
    When the evaluation job runs
    Then the publication of "KycReviewTaskRequested(FR_0_C)" for review "R1" is incomplete
    When Salesforce is available again
    And the incomplete publications are resubmitted
    Then a Salesforce task "FR_0_C" is created once for review "R1"

  @IT-26
  Scenario: The status history cannot be saved
    Given a review "R1" eligible for an automatic remediation
    And the status history cannot be saved
    When the evaluation job runs
    Then the review "R1" is in status "CCO"
    And no status history line exists for review "R1"
    And no Salesforce task exists for review "R1"

  @IT-27
  Scenario: The review changed between phase 1 and phase 2
    Given a review "R1" eligible for an automatic blocking
    And KYCO blocks review "R1" after phase 1 and before phase 2
    When the evaluation job runs
    Then the evaluation report of review "R1" is "SKIPPED"
    And the posting restriction adapter received "PUT" once for review "R1"
    And only one status history line "CCO -> BLOCKED, MANUAL" exists for review "R1"
