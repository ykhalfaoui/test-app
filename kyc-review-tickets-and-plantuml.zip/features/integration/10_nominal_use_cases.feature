@integration @nominal
Feature: Automatic evaluation of KYC reviews - nominal use cases
  The cron evaluates the open reviews and acts automatically for low-risk retail customers,
  or creates a Salesforce task for KYCO.

  Background:
    Given today is "2026-11-19"
    And the evaluation job is enabled and not in dry-run
    And the posting restriction adapter accepts "PUT" and "REMOVE"
    And Salesforce is available

  @IT-01
  Scenario: Straight-through processing of a review never blocked
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And all members of review "R1" have compliant i-Hub documents
    And all non i-Hub blocks of review "R1" are OK
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100"
    When the evaluation job runs
    Then the review "R1" is in status "REMEDIATED"
    And a status history line "CCO -> REMEDIATED, AUTOMATIC" exists for review "R1"
    And no Salesforce task exists for review "R1"
    And the event "ReviewRemediated" is published for review "R1"

  @IT-02
  Scenario: Manual finalization for Retail International 831
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And all members of review "R1" have compliant i-Hub documents
    And all non i-Hub blocks of review "R1" are OK
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "831"
    When the evaluation job runs
    Then the review "R1" is in status "CCO"
    And a Salesforce task "FR_0_C" is created for review "R1"
    And no status history line exists for review "R1"

  @IT-03
  Scenario: Documents completed while non i-Hub work remains
    Given a review "R1" in status "CCO" with blocking planned date "2026-12-31"
    And iHub validates the last document of member "A" of review "R1"
    And the non i-Hub block "Manual analysis" of review "R1" is "AMBER"
    When the evaluation job runs
    Then a Salesforce task "FR_0_0" is created for review "R1"
    And the review "R1" is in status "CCO"

  @IT-04
  Scenario: Full automatic path: block, unblock, back to CCO, remediate
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And member "A" of review "R1" has a missing i-Hub document
    And all non i-Hub blocks of review "R1" are OK
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100", tiering "4"
    When the evaluation job runs
    Then the review "R1" is in status "BLOCKED"
    And the posting restriction adapter received "PUT" once for review "R1"
    And the process action "BLOCKING" of review "R1" is "PROCESSED"
    And the process action "UNBLOCKING_ACCOUNT" of review "R1" is "TO_BE_PROCESSED"
    And a status history line "CCO -> BLOCKED, AUTOMATIC" exists for review "R1"
    When iHub validates the missing document of member "A" of review "R1"
    And the evaluation job runs
    Then the posting restriction adapter received "REMOVE" once for review "R1"
    And the process action "UNBLOCKING_ACCOUNT" of review "R1" is "PROCESSED"
    And the review "R1" is in status "CCO"
    And a status history line "BLOCKED -> CCO, AUTOMATIC" exists for review "R1"
    When the evaluation job runs
    Then the review "R1" is in status "REMEDIATED"
    And a status history line "CCO -> REMEDIATED, AUTOMATIC" exists for review "R1"
    And no Salesforce task exists for review "R1"

  @IT-05
  Scenario: Full manual path: tasks FR 0.A, FR 0.B, FR 0.C
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And member "A" of review "R1" has a missing i-Hub document
    And all non i-Hub blocks of review "R1" are OK
    And the main party of review "R1" is pool "Wealth", AML score "Medium", main DAO "100"
    When the evaluation job runs
    Then a Salesforce task "FR_0_A" is created for review "R1"
    And the review "R1" is in status "CCO"
    When KYCO user "jdoe" blocks review "R1"
    Then the review "R1" is in status "BLOCKED"
    And a status history line "CCO -> BLOCKED, MANUAL, jdoe" exists for review "R1"
    When iHub validates the missing document of member "A" of review "R1"
    And the evaluation job runs
    Then a Salesforce task "FR_0_B" is created for review "R1"
    And the review "R1" is in status "BLOCKED"
    When KYCO user "jdoe" unblocks review "R1"
    Then the posting restriction adapter received "REMOVE" once for review "R1"
    And the review "R1" is in status "CCO"
    When the evaluation job runs
    Then a Salesforce task "FR_0_C" is created for review "R1"

  @IT-06
  Scenario: FR 0.0 and FR 0.A in the same evaluation
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And iHub validates the last document of member "A" of review "R1"
    And the non i-Hub block "Manual analysis" of review "R1" is "AMBER"
    And the KYT assessment of the main party of review "R1" is "KO"
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100", tiering "4"
    When the evaluation job runs
    Then a Salesforce task "FR_0_0" is created for review "R1"
    And the review "R1" is in status "BLOCKED"
    And the posting restriction adapter received "PUT" once for review "R1"

  @IT-07
  Scenario: A pending document pauses the blocking
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And member "A" of review "R1" has a pending i-Hub document
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100", tiering "4"
    When the evaluation job runs
    Then the review "R1" is in status "CCO"
    And no Salesforce task exists for review "R1"
    And the posting restriction adapter was not called
    When the back office rejects the pending document of member "A" of review "R1"
    And the evaluation job runs
    Then a Salesforce task "FR_0_A" is created for review "R1"
    And the review "R1" is in status "CCO"

  @IT-08
  Scenario: A rejected document prevents the automatic blocking
    Given a review "R1" in status "CCO" with blocking planned date "2026-11-18"
    And member "A" of review "R1" has a rejected i-Hub document
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100", tiering "4"
    When the evaluation job runs
    Then a Salesforce task "FR_0_A" is created for review "R1"
    And the review "R1" is in status "CCO"
    And the tiering API was not called

  @IT-09
  Scenario: Blocked review, documents completed, non i-Hub work remains
    Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "TO_BE_PROCESSED"
    And iHub validates the last document of member "A" of review "R1"
    And the non i-Hub block "Manual analysis" of review "R1" is "AMBER"
    When the evaluation job runs
    Then a Salesforce task "FR_0_0" is created for review "R1"
    And the review "R1" is in status "BLOCKED"
    And the posting restriction adapter was not called

  @IT-10
  Scenario: Retail International 831 blocked then complete
    Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "TO_BE_PROCESSED"
    And all members of review "R1" have compliant i-Hub documents
    And all non i-Hub blocks of review "R1" are OK
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "831"
    When the evaluation job runs
    Then the posting restriction adapter received "REMOVE" once for review "R1"
    And the review "R1" is in status "CCO"
    When the evaluation job runs
    Then a Salesforce task "FR_0_C" is created for review "R1"
    And the review "R1" is in status "CCO"
