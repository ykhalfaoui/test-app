@integration @wip @business-question
Feature: Use cases waiting for a business answer
  These scenarios describe the open questions. They are tagged @wip and excluded from the build
  until the business has answered. The expected result is written as the current proposal.

  Background:
    Given today is "2026-11-19"
    And the evaluation job is enabled and not in dry-run

  @IT-80
  Scenario: Review blocked only because KYC data or KYT is KO
    Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "TO_BE_PROCESSED"
    And all members of review "R1" have compliant i-Hub documents
    And all non i-Hub blocks of review "R1" are OK
    And the KYT assessment of the main party of review "R1" is "KO"
    And the main party of review "R1" is pool "Retail", AML score "Low", main DAO "100"
    When the evaluation job runs
    # Proposal: FR 0.B also requires KYC data / KYT OK
    Then the posting restriction adapter was not called
    And the review "R1" is in status "BLOCKED"

  @IT-81
  Scenario: Document invalid again after the return to client communication
    Given the review "R1" went through the full automatic path up to the return to "CCO"
    And the blocking planned date of review "R1" is passed
    And member "A" of review "R1" has a missing i-Hub document again
    When the evaluation job runs
    # To decide: reset of the BLOCKING and UNBLOCKING_ACCOUNT actions for a second cycle
    Then the review "R1" is in status "BLOCKED"
    And the posting restriction adapter received "PUT" 2 times in total for review "R1"

  @IT-82
  Scenario: Open task and nothing changed
    Given a review "R1" eligible for a task "FR_0_C"
    And the evaluation job has run once
    When the evaluation job runs
    # To decide: update on every run, or only when something changes
    Then the Salesforce task "FR_0_C" of review "R1" is not updated
