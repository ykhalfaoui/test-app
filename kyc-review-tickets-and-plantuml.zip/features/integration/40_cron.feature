@integration @cron @ticket-13
Feature: Evaluation cron
  The cron evaluates every open review, one instance at a time,
  and a problem on one review never stops the others.

  Background:
    Given today is "2026-11-19"
    And the evaluation job is enabled

  @IT-60
  Scenario: Only open reviews are evaluated
    Given the reviews:
      | review | status      |
      | R1     | CCO         |
      | R2     | PREPARE_COM |
      | R3     | BLOCKED     |
      | R4     | REMEDIATED  |
    When the evaluation job runs
    Then reviews "R1, R2, R3" are evaluated
    And review "R4" is not evaluated

  @IT-61
  Scenario: A failing review does not stop the run
    Given the reviews "R1, R2, R3" in status "CCO"
    And the iHub adapter fails for review "R2"
    When the evaluation job runs
    Then reviews "R1" and "R3" are evaluated
    And the job report counts 2 evaluated and 1 failed
    And the failed review ids "R2" are logged

  @IT-62
  Scenario: Two instances triggered at the same time
    Given two application instances
    When both trigger the evaluation job at the same time
    Then only one run executes

  @IT-63
  Scenario: Dry-run logs the decisions without applying them
    Given the evaluation job is in dry-run
    And a review "R1" eligible for an automatic blocking
    When the evaluation job runs
    Then the outcome "AUTO(BlockReview)" is logged for review "R1"
    And the review "R1" is unchanged
    And no process action of review "R1" changed
    And no status history line exists for review "R1"
    And no Salesforce task exists for review "R1"
    And the posting restriction adapter was not called

  @IT-64
  Scenario: Disabled job
    Given the evaluation job is disabled
    And a review "R1" eligible for an automatic remediation
    When the evaluation job runs
    Then no review is evaluated

  @IT-65
  Scenario: Metrics of the run
    Given a review "R1" eligible for an automatic remediation
    And a review "R2" eligible for a task "FR_0_C"
    When the evaluation job runs
    Then the metric "kyc.review.evaluated" is 2
    And the metric "kyc.review.outcome" for rule "FR_0_C" is 1 "automatic" and 1 "task"
