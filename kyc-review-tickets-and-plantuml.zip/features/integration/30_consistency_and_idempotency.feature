@integration @consistency
Feature: Consistency and idempotency
  A run that fails, a run repeated, or an event delivered twice
  never loses a decision and never does an action twice.

  Background:
    Given today is "2026-11-19"
    And the evaluation job is enabled and not in dry-run
    And the posting restriction adapter accepts "PUT" and "REMOVE"
    And Salesforce is available

  @IT-40
  Scenario: A document validation is not lost when the evaluation fails
    Given a review "R1" in status "CCO" with blocking planned date "2026-12-31"
    And iHub validates the last document of member "A" of review "R1"
    And the non i-Hub block "Manual analysis" of review "R1" is "AMBER"
    And phase 2 of review "R1" fails once
    When the evaluation job runs
    Then no Salesforce task exists for review "R1"
    When the evaluation job runs
    Then a Salesforce task "FR_0_0" is created once for review "R1"

  @IT-41
  Scenario: No duplicate task over several runs
    Given a review "R1" eligible for a task "FR_0_C"
    When the evaluation job runs 2 times
    Then exactly one Salesforce task "FR_0_C" exists for review "R1"

  @IT-42
  Scenario: A task closed without action is reopened
    Given a review "R1" eligible for a task "FR_0_C"
    And the evaluation job has run once
    And KYCO closes the Salesforce task "FR_0_C" of review "R1" without finalizing
    When the evaluation job runs
    Then the Salesforce task "FR_0_C" of review "R1" is open again

  @IT-43
  Scenario: The unblocking is never relaunched
    Given the review "R1" went through the full automatic path up to the return to "CCO"
    When the evaluation job runs 2 times
    Then the posting restriction adapter received "REMOVE" once in total for review "R1"

  @IT-44
  Scenario: The same outbox entry delivered twice
    Given an unblocking outbox entry for review "R1"
    When the unblocking outbox entry is delivered 2 times
    Then the posting restriction adapter received "REMOVE" once for review "R1"

  @IT-45
  Scenario: A KYCO action locks the review during phase 2
    Given a review "R1" eligible for an automatic remediation
    And KYCO holds a lock on review "R1" and changes its status
    When the evaluation job runs
    Then phase 2 of review "R1" waits for the lock
    And the evaluation report of review "R1" is "SKIPPED"
