@unit
Feature: Salesforce tasks and posting restriction handlers

  @ticket-3
  Scenario Outline: Every task type is fully configured
    When the configuration of task type "<type>" is read
    Then it has a subject, a description, a queue and a priority

    Examples:
      | type   |
      | FR_0_0 |
      | FR_0_A |
      | FR_0_B |
      | FR_0_C |

  @ticket-3
  Scenario Outline: Task upsert on the key review + task type
    Given for review "R1" the Salesforce task "FR_0_C" is "<existing>"
    When the event "KycReviewTaskRequested(R1, FR_0_C)" is handled
    Then the Salesforce client is called with "<call>"

    Examples:
      | existing | call            |
      | absent   | create          |
      | open     | update          |
      | closed   | reopen + update |

  @ticket-6
  Scenario: Unblocking adapter call succeeds
    Given an unblocking outbox entry for review "R1"
    And the posting restriction adapter accepts "REMOVE"
    When the unblocking outbox entry is handled
    Then the unblocking of review "R1" is marked succeeded

  @ticket-6
  Scenario: Unblocking adapter call fails on the last retry
    Given an unblocking outbox entry for review "R1" on its last retry
    And the posting restriction adapter fails on "REMOVE"
    When the unblocking outbox entry is handled
    Then the unblocking of review "R1" is marked failed

  @ticket-6
  Scenario: Unblocking already processed
    Given an unblocking outbox entry for review "R1"
    And the process action "UNBLOCKING_ACCOUNT" of review "R1" is "PROCESSED"
    When the unblocking outbox entry is handled
    Then the posting restriction adapter is not called

  @ticket-7
  Scenario: Blocking adapter call succeeds
    Given a blocking outbox entry for review "R1"
    And the posting restriction adapter accepts "PUT"
    When the blocking outbox entry is handled
    Then the blocking of review "R1" is marked succeeded

  @ticket-7
  Scenario: Blocking adapter call fails on the last retry
    Given a blocking outbox entry for review "R1" on its last retry
    And the posting restriction adapter fails on "PUT"
    When the blocking outbox entry is handled
    Then the blocking of review "R1" is marked failed
