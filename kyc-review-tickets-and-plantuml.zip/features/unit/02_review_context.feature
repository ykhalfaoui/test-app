@unit @ticket-2
Feature: Review context
  As the review evaluation
  I want all the facts of a review collected once, without any decision
  So that every rule reads the same, up-to-date picture

  Scenario: Context built for an open review
    Given a review "R1" in status "CCO"
    When the context of review "R1" is built
    Then the context contains the review "R1" loaded from the database

  Scenario Outline: No context for a review that cannot be evaluated
    Given a review "R1" in status "<status>"
    When the context of review "R1" is built
    Then no context is built

    Examples:
      | status     |
      | REMEDIATED |
      | UNKNOWN    |

  Scenario: A non i-Hub block in amber
    Given a review "R1" in status "CCO"
    And the non i-Hub block "Manual analysis" of review "R1" is "AMBER"
    When the context of review "R1" is built
    Then nonIhubBlocksOk is false

  Scenario: KYT KO on the main party
    Given a review "R1" in status "CCO"
    And the KYT assessment of the main party of review "R1" is "KO"
    When the context of review "R1" is built
    Then kycDataAndKytOk is false

  Scenario: The tiering is not fetched when the context is built
    Given a review "R1" in status "CCO"
    When the context of review "R1" is built
    Then the tiering API is not called

  Scenario: The tiering is fetched once on demand
    Given the context of review "R1" is built
    When the party tiering is requested twice
    Then the tiering API is called once

  Scenario: Tiering API in error
    Given the context of review "R1" is built
    And the tiering API is unavailable
    When the party tiering is requested
    Then no tiering is returned
