@unit @rules
Feature: Review rules
  Each rule answers three questions on the review context:
  is the review eligible, can the action be automatic, and which command or which task.
  Expected outcome: NOT_APPLICABLE, AUTO(<command>) or TASK(<task type>).

  Background:
    Given today is "2026-11-19"

  @ticket-8
  Scenario Outline: FR 0.0 Documents completed
    Given a review context with status "<status>"
    And blocking planned date "<date>"
    And allBlocksCompliant <ok>, newValidation <new>
    And a non i-Hub block in amber <amber>
    When rule "FR 0.0" is evaluated
    Then the outcome is "<outcome>"

    Examples:
      | status      | date       | ok    | new   | amber | outcome       |
      | CCO         | 2026-12-31 | true  | true  | true  | TASK(FR_0_0)  |
      | PREPARE_COM | 2026-12-31 | true  | true  | true  | TASK(FR_0_0)  |
      | BLOCKED     | 2026-11-01 | true  | true  | true  | TASK(FR_0_0)  |
      | CCO         | 2026-11-01 | true  | true  | true  | TASK(FR_0_0)  |
      | CCO         | 2026-12-31 | true  | true  | false | NOT_APPLICABLE |
      | CCO         | 2026-12-31 | true  | false | true  | NOT_APPLICABLE |
      | CCO         | 2026-12-31 | false | true  | true  | NOT_APPLICABLE |
      | REMEDIATED  | 2026-11-01 | true  | true  | true  | NOT_APPLICABLE |

  @ticket-8
  Scenario: FR 0.0 is never automatic
    Given a review context eligible for rule "FR 0.0"
    When rule "FR 0.0" is evaluated
    Then the outcome is never automatic

  @ticket-9
  Scenario Outline: FR 0.A Blocking
    Given a review context with status "<status>"
    And blocking planned date "<date>"
    And allBlocksCompliant <docsOk>, kycDataAndKytOk <kycOk>, pending <pending>, rejected <rejected>
    And pool "<pool>", AML score "<aml>"
    And the tiering API returns "<tiering>"
    When rule "FR 0.A" is evaluated
    Then the outcome is "<outcome>"
    And the tiering API is called <called>

    Examples:
      | status      | date       | docsOk | kycOk | pending | rejected | pool   | aml    | tiering | outcome           | called |
      | CCO         | 2026-11-01 | false  | true  | false   | false    | Retail | Low    | 4       | AUTO(BlockReview) | true   |
      | CCO         | 2026-11-01 | false  | true  | false   | false    | Retail | Low    | 5       | AUTO(BlockReview) | true   |
      | CCO         | 2026-11-01 | false  | true  | false   | false    | Retail | Low    | 2       | TASK(FR_0_A)      | true   |
      | CCO         | 2026-11-01 | false  | true  | false   | false    | Wealth | Low    | 4       | TASK(FR_0_A)      | false  |
      | CCO         | 2026-11-01 | false  | true  | false   | false    | Retail | Medium | 4       | TASK(FR_0_A)      | false  |
      | CCO         | 2026-11-01 | false  | true  | false   | true     | Retail | Low    | 4       | TASK(FR_0_A)      | false  |
      | CCO         | 2026-11-01 | true   | false | false   | false    | Retail | Low    | 4       | AUTO(BlockReview) | true   |
      | CCO         | 2026-11-01 | false  | true  | true    | false    | Retail | Low    | 4       | NOT_APPLICABLE    | false  |
      | CCO         | 2026-12-31 | false  | true  | false   | false    | Retail | Low    | 4       | NOT_APPLICABLE    | false  |
      | BLOCKED     | 2026-11-01 | false  | true  | false   | false    | Retail | Low    | 4       | NOT_APPLICABLE    | false  |
      | PREPARE_COM | 2026-11-01 | false  | true  | false   | false    | Retail | Low    | 4       | AUTO(BlockReview) | true   |
      | CCO         | 2026-11-01 | true   | true  | false   | false    | Retail | Low    | 4       | NOT_APPLICABLE    | false  |
      | CCO         | 2026-11-01 | false  | true  | false   | false    | Retail | Low    | ERROR   | TASK(FR_0_A)      | true   |

  @ticket-10
  Scenario Outline: FR 0.B Unblocking
    Given a review context with status "<status>"
    And allBlocksCompliant <docsOk>, nonIhubBlocksOk <nonIhubOk>
    And the unblocking action is "<action>"
    And pool "<pool>", AML score "<aml>", main DAO "<dao>"
    When rule "FR 0.B" is evaluated
    Then the outcome is "<outcome>"

    Examples:
      | status  | docsOk | nonIhubOk | action          | pool   | aml    | dao | outcome              |
      | BLOCKED | true   | true      | TO_BE_PROCESSED | Retail | Low    | 100 | AUTO(UnblockAccount) |
      | BLOCKED | true   | true      | TO_BE_PROCESSED | Retail | Low    | 831 | AUTO(UnblockAccount) |
      | BLOCKED | true   | true      | TO_BE_PROCESSED | Wealth | Low    | 100 | TASK(FR_0_B)         |
      | BLOCKED | true   | true      | TO_BE_PROCESSED | Retail | Medium | 100 | TASK(FR_0_B)         |
      | BLOCKED | true   | false     | TO_BE_PROCESSED | Retail | Low    | 100 | NOT_APPLICABLE       |
      | BLOCKED | false  | true      | TO_BE_PROCESSED | Retail | Low    | 100 | NOT_APPLICABLE       |
      | BLOCKED | true   | true      | INIT            | Retail | Low    | 100 | NOT_APPLICABLE       |
      | BLOCKED | true   | true      | IN_PROGRESS     | Retail | Low    | 100 | NOT_APPLICABLE       |
      | BLOCKED | true   | true      | PROCESSED       | Retail | Low    | 100 | NOT_APPLICABLE       |
      | BLOCKED | true   | true      | ERROR           | Retail | Low    | 100 | NOT_APPLICABLE       |
      | CCO     | true   | true      | TO_BE_PROCESSED | Retail | Low    | 100 | NOT_APPLICABLE       |

  @ticket-11
  Scenario Outline: FR 0.C Validation STP
    Given a review context with status "<status>"
    And blocking planned date "<date>"
    And allBlocksCompliant <docsOk>, nonIhubBlocksOk <nonIhubOk>
    And pool "<pool>", AML score "<aml>", main DAO "<dao>"
    When rule "FR 0.C" is evaluated
    Then the outcome is "<outcome>"

    Examples:
      | status      | date       | docsOk | nonIhubOk | pool   | aml    | dao | outcome          |
      | CCO         | 2026-11-01 | true   | true      | Retail | Low    | 100 | AUTO(Remediate)  |
      | CCO         | 2026-11-01 | true   | true      | Retail | Low    | 831 | TASK(FR_0_C)     |
      | CCO         | 2026-11-01 | true   | true      | Wealth | Low    | 100 | TASK(FR_0_C)     |
      | CCO         | 2026-11-01 | true   | true      | Retail | Medium | 100 | TASK(FR_0_C)     |
      | CCO         | 2026-12-31 | true   | true      | Retail | Low    | 100 | NOT_APPLICABLE   |
      | CCO         | 2026-11-01 | false  | true      | Retail | Low    | 100 | NOT_APPLICABLE   |
      | CCO         | 2026-11-01 | true   | false     | Retail | Low    | 100 | NOT_APPLICABLE   |
      | BLOCKED     | 2026-11-01 | true   | true      | Retail | Low    | 100 | NOT_APPLICABLE   |
      | PREPARE_COM | 2026-11-01 | true   | true      | Retail | Low    | 100 | NOT_APPLICABLE   |
