@unit @ticket-4
Feature: Review aggregate, commands and fallback
  All changes go through the review: it checks the transition,
  updates its status and process actions together, and registers the events.
  A command refused by the review falls back to the task of its rule.

  Rule: Blocking

    Scenario: Block a review in client communication
      Given a review "R1" in status "CCO"
      When the review "R1" is blocked by "SYSTEM FR_0_A"
      Then the review "R1" is in status "BLOCKED"
      And the process action "BLOCKING" is "TO_BE_PROCESSED"
      And the events "ReviewStatusChanged(CCO -> BLOCKED, AUTOMATIC), ReviewBlocked" are registered

    Scenario: Block a review already blocked
      Given a review "R1" in status "BLOCKED"
      When the command "BlockReview" is dispatched for review "R1"
      Then the command is refused
      And the event "KycReviewTaskRequested(FR_0_A)" is registered
      And no "ReviewStatusChanged" event is registered

    Scenario: Blocking succeeded at the adapter
      Given a review "R1" in status "BLOCKED" with process action "BLOCKING" "TO_BE_PROCESSED"
      When the blocking of review "R1" succeeds
      Then the process action "BLOCKING" is "PROCESSED"
      And the process action "UNBLOCKING_ACCOUNT" is "TO_BE_PROCESSED"

    Scenario: Blocking failed at the adapter
      Given a review "R1" in status "BLOCKED" with process action "BLOCKING" "TO_BE_PROCESSED"
      When the blocking of review "R1" fails
      Then the process action "BLOCKING" is "ERROR"
      And the event "KycReviewTaskRequested(FR_0_A)" is registered

  Rule: Unblocking

    Scenario: Request the unblocking
      Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "TO_BE_PROCESSED"
      When the unblocking of review "R1" is requested
      Then the process action "UNBLOCKING_ACCOUNT" is "IN_PROGRESS"
      And the event "UnblockingRequested" is registered
      And the review "R1" is in status "BLOCKED"
      And no "ReviewStatusChanged" event is registered

    Scenario Outline: Unblocking refused when the action is not ready
      Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "<action>"
      When the command "UnblockAccount" is dispatched for review "R1"
      Then the command is refused
      And the event "KycReviewTaskRequested(FR_0_B)" is registered

      Examples:
        | action      |
        | INIT        |
        | IN_PROGRESS |
        | PROCESSED   |
        | ERROR       |

    Scenario: Unblocking succeeded: back to client communication
      Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "IN_PROGRESS"
      When the unblocking of review "R1" succeeds
      Then the process action "UNBLOCKING_ACCOUNT" is "PROCESSED"
      And the review "R1" is in status "CCO"
      And the events "ReviewStatusChanged(BLOCKED -> CCO, AUTOMATIC), ReviewBackToClientCommunication" are registered

    Scenario: Unblocking failed
      Given a review "R1" in status "BLOCKED" with process action "UNBLOCKING_ACCOUNT" "IN_PROGRESS"
      When the unblocking of review "R1" fails
      Then the process action "UNBLOCKING_ACCOUNT" is "ERROR"
      And the review "R1" is in status "BLOCKED"
      And the event "KycReviewTaskRequested(FR_0_B)" is registered

  Rule: Remediation

    Scenario: Remediate a review in client communication
      Given a review "R1" in status "CCO"
      When the review "R1" is remediated by "SYSTEM FR_0_C"
      Then the review "R1" is in status "REMEDIATED"
      And the events "ReviewStatusChanged(CCO -> REMEDIATED, AUTOMATIC), ReviewRemediated" are registered

    Scenario: Remediate a blocked review
      Given a review "R1" in status "BLOCKED"
      When the command "Remediate" is dispatched for review "R1"
      Then the command is refused
      And the event "KycReviewTaskRequested(FR_0_C)" is registered

  Rule: Status history

    Scenario: Manual transition by KYCO
      Given a review "R1" in status "CCO"
      When the review "R1" is blocked by KYCO user "jdoe"
      Then the event "ReviewStatusChanged(CCO -> BLOCKED, MANUAL, jdoe)" is registered

    Scenario: History saved in the same transaction
      Given a review "R1" in status "CCO"
      When the review "R1" is remediated by "SYSTEM FR_0_C" and saved
      Then one status history line "CCO -> REMEDIATED, AUTOMATIC" exists for review "R1"

    Scenario: History failure rolls back the transition
      Given a review "R1" in status "CCO"
      And the status history cannot be saved
      When the review "R1" is remediated by "SYSTEM FR_0_C" and saved
      Then the review "R1" is in status "CCO" in the database
      And no status history line exists for review "R1"

  Rule: Rule template

    Scenario: A rule not eligible does not check the automation
      Given a rule that is not eligible for the context
      When the rule is evaluated
      Then the outcome is "NOT_APPLICABLE"
      And the automation condition is not checked
