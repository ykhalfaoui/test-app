@unit @ticket-1
Feature: Review documents evaluation
  As the review evaluation
  I want one consolidated document result for the whole review
  So that the rules know whether all i-Hub documents of all members are compliant

  Background:
    Given a review "R1" in status "CCO"

  Scenario Outline: Consolidation of the members results
    Given member "A" of review "R1" returns newValidation <A_new>, allBlocksCompliant <A_ok>, pending <A_pending>, rejected <A_rejected>
    And member "B" of review "R1" returns newValidation <B_new>, allBlocksCompliant <B_ok>, pending <B_pending>, rejected <B_rejected>
    When the documents of review "R1" are evaluated
    Then the review document result is newValidation <new>, allBlocksCompliant <ok>, pending <pending>, rejected <rejected>

    Examples:
      | case                                    | A_new | A_ok  | A_pending | A_rejected | B_new | B_ok  | B_pending | B_rejected | new   | ok    | pending | rejected |
      | A just validated, B already compliant   | true  | true  | false     | false      | false | true  | false     | false      | true  | true  | false   | false    |
      | A and B already compliant               | false | true  | false     | false      | false | true  | false     | false      | false | true  | false   | false    |
      | A just validated, B pending             | true  | true  | false     | false      | false | false | true      | false      | true  | false | true    | false    |
      | A rejected, B pending                   | false | false | false     | true       | false | false | true      | false      | false | false | true    | true     |
      | A not compliant, B compliant            | false | false | false     | false      | false | true  | false     | false      | false | false | false   | false    |

  Scenario: A removed member is ignored
    Given member "A" of review "R1" has status "removed" and an invalid i-Hub document
    And member "B" of review "R1" is compliant
    When the documents of review "R1" are evaluated
    Then FTKYP-646 is not called for member "A"
    And the review document result is allBlocksCompliant true

  Scenario: A member without i-Hub block is ignored
    Given member "A" of review "R1" has no i-Hub document block on the review
    When the documents of review "R1" are evaluated
    Then FTKYP-646 is not called for member "A"

  Scenario: Only the block types of the member are sent
    Given member "A" of review "R1" has only the block type "DOCS_IHUB_SPECIFIC"
    When the documents of review "R1" are evaluated
    Then FTKYP-646 is called for member "A" with block types "DOCS_IHUB_SPECIFIC"

  Scenario: No eligible member
    Given review "R1" has no active member with an i-Hub block
    When the documents of review "R1" are evaluated
    Then the review document result is newValidation false, allBlocksCompliant true, pending false, rejected false
    And a warning is logged for review "R1"

  Scenario: FTKYP-646 fails for one member
    Given FTKYP-646 fails for member "B" of review "R1"
    When the documents of review "R1" are evaluated
    Then the evaluation fails with review id "R1" and party id "B"
