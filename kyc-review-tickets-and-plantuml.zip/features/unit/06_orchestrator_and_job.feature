@unit
Feature: Orchestrator and cron logic

  @ticket-12
  Scenario: Review changed between phase 1 and phase 2
    Given phase 1 of review "R1" decided "AUTO(BlockReview)" on version 3
    And review "R1" is now on version 4
    When phase 2 of review "R1" runs
    Then nothing is applied
    And the evaluation report of review "R1" is "SKIPPED"

  @ticket-12
  Scenario: Several outcomes applied together
    Given phase 1 of review "R1" decided "TASK(FR_0_0)" and "AUTO(BlockReview)"
    When phase 2 of review "R1" runs
    Then the task "FR_0_0" and the blocking are applied in the same transaction

  @ticket-12 @ticket-13
  Scenario: Dry-run
    Given the evaluation runs in dry-run mode
    And phase 1 of review "R1" decided "AUTO(Remediate)"
    When review "R1" is evaluated
    Then the outcome "AUTO(Remediate)" is logged
    And phase 2 is not called

  @ticket-13
  Scenario: Job disabled
    Given the evaluation job is disabled
    When the evaluation job runs
    Then no review is selected

  @ticket-13
  Scenario: One failing review does not stop the run
    Given the reviews "R1, R2, R3" are selected
    And the evaluation of review "R2" throws an error
    When the evaluation job runs
    Then reviews "R1" and "R3" are evaluated
    And the job report counts 2 evaluated and 1 failed

  @ticket-13
  Scenario: Selection page by page
    Given 450 eligible reviews and a batch size of 200
    When the evaluation job runs
    Then 3 pages are read and 450 reviews are evaluated
