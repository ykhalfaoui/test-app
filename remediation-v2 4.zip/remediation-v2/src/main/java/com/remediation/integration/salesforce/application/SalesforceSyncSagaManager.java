package com.remediation.integration.salesforce.application;

import com.remediation.block.api.BlockReadyForReviewEvent;
import com.remediation.integration.salesforce.api.event.*;
import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.integration.salesforce.domain.SalesforceSyncSagaRepository;
import com.remediation.member.api.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.ReviewInstanceStartedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * SalesforceSyncSagaManager orchestrates the Salesforce synchronization process.
 *
 * Responsibilities:
 * 1. Creates saga when review starts
 * 2. Enqueues members and blocks as they're identified
 * 3. Requests batch processing when ready
 * 4. Handles batch completion/failure responses
 * 5. Finalizes review status when all data synced
 * 6. Manages retry logic for failures
 *
 * Flow orchestration:
 * - ReviewStarted → Create SF review (DRAFT)
 * - SF Review Created → Start member batching
 * - Members arrive → Enqueue and request batches
 * - Member batches complete → Start block batching
 * - Block batches complete → Update SF review (ONGOING)
 * - Status updated → Saga complete
 */
@Service
@Slf4j
public class SalesforceSyncSagaManager {

    private final SalesforceSyncSagaRepository sagaRepository;
    private final ApplicationEventPublisher eventPublisher;
    private final int batchSize;

    public SalesforceSyncSagaManager(
        SalesforceSyncSagaRepository sagaRepository,
        ApplicationEventPublisher eventPublisher,
        @Value("${salesforce.batch-size:100}") int batchSize
    ) {
        this.sagaRepository = sagaRepository;
        this.eventPublisher = eventPublisher;
        this.batchSize = batchSize;
    }

    // ========== Saga Initialization ==========

    /**
     * Creates saga and initiates Salesforce review creation when internal review starts.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(ReviewInstanceStartedEvent event) {
        log.info("Creating Salesforce sync saga for review {} [TraceId: {}]",
            event.reviewId().value(), event.traceId().value());

        // Create saga
        SalesforceSyncSaga saga = new SalesforceSyncSaga(event.reviewId(), event.traceId());
        saga.reviewCreationStarted();
        sagaRepository.save(saga);

        log.info("Saga {} created, requesting Salesforce review creation", saga.getId());

        // Request Salesforce review creation
        SalesforceReviewDraftRequested requestEvent = new SalesforceReviewDraftRequested(
            event.traceId(),
            event.reviewId(),
            event.triggerType()
        );
        eventPublisher.publishEvent(requestEvent);
    }

    // ========== Review Creation Response ==========

    /**
     * Handles Salesforce review creation response.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceReviewCreated event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresentOrElse(
            saga -> {
                if (event.success()) {
                    saga.reviewCreated(event.salesforceReviewId());
                    sagaRepository.save(saga);

                    log.info("Saga {} review created in Salesforce: {}",
                        saga.getId(), event.salesforceReviewId());

                    // Start processing any pending members
                    requestNextMemberBatch(saga);
                } else {
                    saga.fail("Review creation failed: " + event.failureMessage());
                    sagaRepository.save(saga);

                    log.error("Saga {} review creation failed: {}",
                        saga.getId(), event.failureMessage());

                    scheduleRetry(saga);
                }
            },
            () -> log.warn("Saga not found for review {}", event.reviewId().value())
        );
    }

    // ========== Member Enqueueing ==========

    /**
     * Enqueues members as they're identified.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(ReviewMemberIdentifiedEvent event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresentOrElse(
            saga -> {
                saga.enqueueMember(event.customerId().value());
                sagaRepository.save(saga);

                log.debug("Saga {} enqueued member {} [TraceId: {}]",
                    saga.getId(), event.customerId().value(), event.traceId().value());

                // Request batch if we're ready to sync members
                requestNextMemberBatch(saga);
            },
            () -> log.warn("Saga not found for review {}", event.reviewId().value())
        );
    }

    /**
     * Handles member batch completion.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceMembersBatchProcessed event) {
        sagaRepository.findById(event.sagaId()).ifPresentOrElse(
            saga -> {
                if (event.success()) {
                    saga.markMemberBatchCompleted(event.batchNumber());
                    sagaRepository.save(saga);

                    log.info("Saga {} member batch {} completed", saga.getId(), event.batchNumber());

                    // Request next batch or move to blocks
                    requestNextMemberBatch(saga);
                    maybeRequestBlockSync(saga);
                    maybeRequestStatusUpdate(saga);
                } else {
                    saga.markMemberBatchFailed(event.batchNumber(), event.memberIds(), event.failureMessage());
                    sagaRepository.save(saga);

                    log.error("Saga {} member batch {} failed: {}",
                        saga.getId(), event.batchNumber(), event.failureMessage());

                    scheduleRetry(saga);
                }
            },
            () -> log.warn("Saga not found: {}", event.sagaId())
        );
    }

    // ========== Block Enqueueing ==========

    /**
     * Enqueues blocks as they become ready.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(BlockReadyForReviewEvent event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresentOrElse(
            saga -> {
                saga.enqueueBlock(event.blockId().value().toString());
                sagaRepository.save(saga);

                log.debug("Saga {} enqueued block {} [TraceId: {}]",
                    saga.getId(), event.blockId().value(), event.traceId().value());

                // Request batch if we're ready to sync blocks
                maybeRequestBlockSync(saga);
            },
            () -> log.warn("Saga not found for review {}", event.reviewId().value())
        );
    }

    /**
     * Handles block batch completion.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceBlocksBatchProcessed event) {
        sagaRepository.findById(event.sagaId()).ifPresentOrElse(
            saga -> {
                if (event.success()) {
                    saga.markBlockBatchCompleted(event.batchNumber());
                    sagaRepository.save(saga);

                    log.info("Saga {} block batch {} completed", saga.getId(), event.batchNumber());

                    // Request next batch or finalize
                    maybeRequestBlockSync(saga);
                    maybeRequestStatusUpdate(saga);
                } else {
                    saga.markBlockBatchFailed(event.batchNumber(), event.blockIds(), event.failureMessage());
                    sagaRepository.save(saga);

                    log.error("Saga {} block batch {} failed: {}",
                        saga.getId(), event.batchNumber(), event.failureMessage());

                    scheduleRetry(saga);
                }
            },
            () -> log.warn("Saga not found: {}", event.sagaId())
        );
    }

    // ========== Status Finalization ==========

    /**
     * Handles review status update response.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceReviewStatusUpdated event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresentOrElse(
            saga -> {
                if (event.success()) {
                    saga.complete();
                    sagaRepository.save(saga);

                    log.info("Saga {} completed successfully [TraceId: {}]",
                        saga.getId(), event.traceId().value());
                } else {
                    saga.fail("Status update failed: " + event.failureMessage());
                    sagaRepository.save(saga);

                    log.error("Saga {} status update failed: {}",
                        saga.getId(), event.failureMessage());

                    scheduleRetry(saga);
                }
            },
            () -> log.warn("Saga not found for review {}", event.reviewId().value())
        );
    }

    // ========== Retry Logic ==========

    /**
     * Handles saga retry requests.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceSagaRetryRequested event) {
        sagaRepository.findById(event.sagaId()).ifPresentOrElse(
            saga -> {
                saga.retry();
                sagaRepository.save(saga);

                log.info("Saga {} retrying from status {}", saga.getId(), saga.getStatus());

                // Resume processing based on current state
                requestNextMemberBatch(saga);
                maybeRequestBlockSync(saga);
                maybeRequestStatusUpdate(saga);
            },
            () -> log.warn("Saga not found: {}", event.sagaId())
        );
    }

    // ========== Helper Methods ==========

    /**
     * Requests the next member batch if saga is ready.
     */
    private void requestNextMemberBatch(SalesforceSyncSaga saga) {
        if (saga.getSalesforceReviewId() == null ||
            saga.getStatus() != SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS) {
            return;
        }

        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextMemberBatch(batchSize);
        if (batch.isPresent()) {
            sagaRepository.save(saga);

            SalesforceSyncSaga.BatchProgress progress = batch.get();
            log.info("Saga {} requesting member batch {} ({} items)",
                saga.getId(), progress.batchNumber(), progress.items().size());

            SalesforceMembersBatchRequested requestEvent = new SalesforceMembersBatchRequested(
                saga.getTraceId(),
                saga.getId(),
                progress.batchNumber(),
                progress.items(),
                saga.getSalesforceReviewId()
            );
            eventPublisher.publishEvent(requestEvent);
        }
    }

    /**
     * Requests block batch if saga is ready.
     */
    private void maybeRequestBlockSync(SalesforceSyncSaga saga) {
        if (saga.getSalesforceReviewId() == null ||
            saga.getStatus() != SalesforceSyncSaga.SyncStatus.SYNCING_BLOCKS) {
            return;
        }

        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextBlockBatch(batchSize);
        if (batch.isPresent()) {
            sagaRepository.save(saga);

            SalesforceSyncSaga.BatchProgress progress = batch.get();
            log.info("Saga {} requesting block batch {} ({} items)",
                saga.getId(), progress.batchNumber(), progress.items().size());

            SalesforceBlocksBatchRequested requestEvent = new SalesforceBlocksBatchRequested(
                saga.getTraceId(),
                saga.getId(),
                progress.batchNumber(),
                progress.items(),
                saga.getSalesforceReviewId()
            );
            eventPublisher.publishEvent(requestEvent);
        }
    }

    /**
     * Requests status update if all data is synced.
     */
    private void maybeRequestStatusUpdate(SalesforceSyncSaga saga) {
        if (saga.getSalesforceReviewId() == null ||
            saga.getStatus() != SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS) {
            return;
        }

        log.info("Saga {} requesting review status update to ONGOING", saga.getId());

        SalesforceReviewStatusUpdateRequested requestEvent = new SalesforceReviewStatusUpdateRequested(
            saga.getTraceId(),
            saga.getReviewId(),
            saga.getSalesforceReviewId(),
            "ONGOING"
        );
        eventPublisher.publishEvent(requestEvent);
    }

    /**
     * Schedules a retry for a failed saga.
     */
    private void scheduleRetry(SalesforceSyncSaga saga) {
        log.info("Scheduling retry for saga {}", saga.getId());

        // In production, this could use Spring's @Async with delay or a scheduler
        // For now, publish retry event immediately (will be picked up by outbox forwarder)
        SalesforceSagaRetryRequested retryEvent = new SalesforceSagaRetryRequested(
            saga.getTraceId(),
            saga.getId()
        );
        eventPublisher.publishEvent(retryEvent);
    }
}
