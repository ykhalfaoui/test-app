package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Response event when a review is created in Salesforce.
 */
public record SalesforceReviewCreated(
    TraceId traceId,
    ReviewId reviewId,
    boolean success,
    String salesforceReviewId,
    String failureMessage
) {
    public SalesforceReviewCreated {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
        if (success && (salesforceReviewId == null || salesforceReviewId.isBlank())) {
            throw new IllegalArgumentException("salesforceReviewId required when success=true");
        }
    }
}
