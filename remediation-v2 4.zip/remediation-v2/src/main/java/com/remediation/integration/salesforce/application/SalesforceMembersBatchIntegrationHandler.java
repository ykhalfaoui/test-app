package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchRequested;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Handles Salesforce member batch sync requests.
 */
@Component
@Slf4j
public class SalesforceMembersBatchIntegrationHandler {

    private final SalesforceClient salesforceClient;
    private final ApplicationEventPublisher eventPublisher;

    public SalesforceMembersBatchIntegrationHandler(
        SalesforceClient salesforceClient,
        ApplicationEventPublisher eventPublisher
    ) {
        this.salesforceClient = salesforceClient;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Handles request to sync a batch of members to Salesforce.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceMembersBatchRequested event) {
        log.info("Syncing member batch {} ({} items) to Salesforce review {} [TraceId: {}]",
            event.batchNumber(), event.memberIds().size(),
            event.salesforceReviewId(), event.traceId().value());

        try {
            // Call Salesforce API
            salesforceClient.bulkUpsertMembers(
                event.salesforceReviewId(),
                event.memberIds()
            );

            // Publish success event
            SalesforceMembersBatchProcessed responseEvent = new SalesforceMembersBatchProcessed(
                event.traceId(),
                event.sagaId(),
                event.batchNumber(),
                event.memberIds(),
                true,
                null
            );
            eventPublisher.publishEvent(responseEvent);

            log.info("Member batch {} synced successfully [TraceId: {}]",
                event.batchNumber(), event.traceId().value());

        } catch (Exception ex) {
            log.error("Failed to sync member batch {} [TraceId: {}]: {}",
                event.batchNumber(), event.traceId().value(), ex.getMessage(), ex);

            // Publish failure event
            SalesforceMembersBatchProcessed responseEvent = new SalesforceMembersBatchProcessed(
                event.traceId(),
                event.sagaId(),
                event.batchNumber(),
                event.memberIds(),
                false,
                ex.getMessage()
            );
            eventPublisher.publishEvent(responseEvent);
        }
    }
}
