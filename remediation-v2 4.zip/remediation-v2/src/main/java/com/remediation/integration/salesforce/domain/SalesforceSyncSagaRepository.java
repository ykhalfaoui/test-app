package com.remediation.integration.salesforce.domain;

import com.remediation.sharedkernel.ReviewId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for SalesforceSyncSaga entities.
 */
@Repository
public interface SalesforceSyncSagaRepository extends JpaRepository<SalesforceSyncSaga, UUID> {

    /**
     * Find a saga by its associated review ID.
     */
    Optional<SalesforceSyncSaga> findByReviewId(ReviewId reviewId);

    /**
     * Find all sagas in a specific status.
     */
    List<SalesforceSyncSaga> findByStatus(SalesforceSyncSaga.SyncStatus status);
}
