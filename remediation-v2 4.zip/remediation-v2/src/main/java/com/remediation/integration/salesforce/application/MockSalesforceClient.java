package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.sharedkernel.ReviewId;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

/**
 * Mock implementation of SalesforceClient for development and testing.
 * Simulates Salesforce API calls with logging.
 *
 * Enable with: salesforce.enabled=false (default)
 */
@Component
@ConditionalOnProperty(name = "salesforce.enabled", havingValue = "false", matchIfMissing = true)
@Slf4j
public class MockSalesforceClient implements SalesforceClient {

    @Override
    public String createReviewDraft(ReviewId reviewId, String triggerType) {
        // Simulate API call delay
        simulateApiCall("createReviewDraft");

        String salesforceReviewId = "SF-" + UUID.randomUUID().toString().substring(0, 8);

        log.info("[MOCK SF] Created review draft: {} for internal review {} (trigger: {})",
            salesforceReviewId, reviewId.value(), triggerType);

        return salesforceReviewId;
    }

    @Override
    public void bulkUpsertMembers(String salesforceReviewId, List<String> memberIds) {
        // Simulate API call delay
        simulateApiCall("bulkUpsertMembers");

        log.info("[MOCK SF] Bulk upserted {} members to review {}",
            memberIds.size(), salesforceReviewId);

        // Log each member
        memberIds.forEach(memberId ->
            log.debug("[MOCK SF]   - Member: {}", memberId)
        );
    }

    @Override
    public void bulkUpsertBlocks(String salesforceReviewId, List<String> blockIds) {
        // Simulate API call delay
        simulateApiCall("bulkUpsertBlocks");

        log.info("[MOCK SF] Bulk upserted {} blocks to review {}",
            blockIds.size(), salesforceReviewId);

        // Log each block
        blockIds.forEach(blockId ->
            log.debug("[MOCK SF]   - Block: {}", blockId)
        );
    }

    @Override
    public void updateReviewStatus(String salesforceReviewId, String status) {
        // Simulate API call delay
        simulateApiCall("updateReviewStatus");

        log.info("[MOCK SF] Updated review {} status to: {}", salesforceReviewId, status);
    }

    /**
     * Simulates API call latency.
     */
    private void simulateApiCall(String operation) {
        try {
            // Simulate 100-300ms latency
            int delay = 100 + (int) (Math.random() * 200);
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("[MOCK SF] {} interrupted", operation);
        }
    }
}
