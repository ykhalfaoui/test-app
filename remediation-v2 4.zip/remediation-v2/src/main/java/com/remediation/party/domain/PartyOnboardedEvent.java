package com.remediation.party.domain;

import java.util.UUID;

/**
 * Domain event published when a new Party (customer) is successfully onboarded.
 *
 * This event triggers the initial provisioning of information blocks for the Party.
 *
 * Expected Actions:
 * - BlockProvisioningService creates 4 initial blocks (KYC, KYT, STATIC_DATA, DOCUMENT)
 * - Other systems may react (e.g., notifications, external systems sync)
 *
 * @param partyId ID of the newly onboarded Party
 */
public record PartyOnboardedEvent(UUID partyId) {
    public PartyOnboardedEvent {
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }
    }
}
