package com.remediation.party.domain;

import java.util.UUID;

/**
 * Domain event published when a Party (customer) is updated.
 *
 * This event can trigger partial block provisioning depending on the relation type.
 *
 * Use Case:
 * When a ReviewMember is created with relationType = "SECONDARY" (or similar),
 * this event triggers creation of STATIC_DATA and DOCUMENT blocks only.
 *
 * Expected Actions:
 * - BlockProvisioningService provisions partial block set (STATIC_DATA, DOCUMENT)
 * - Archives old STATIC_DATA and DOCUMENT blocks
 * - KYC and KYT blocks remain unchanged
 *
 * @param partyId ID of the updated Party
 * @param relationType Type of relation (e.g., "SECONDARY", "PRINCIPAL")
 */
public record PartyUpdatedEvent(UUID partyId, String relationType) {
    public PartyUpdatedEvent {
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }
    }
}
