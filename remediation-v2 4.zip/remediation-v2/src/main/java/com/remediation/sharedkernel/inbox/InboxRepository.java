package com.remediation.sharedkernel.inbox;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * Repository for managing inbox entries.
 */
@Repository
public interface InboxRepository extends JpaRepository<InboxEntry, UUID> {

    /**
     * Check if a message with the given event ID has already been received.
     * Used for idempotency checks.
     */
    boolean existsByEventId(UUID eventId);

    /**
     * Find inbox entries ready for retry.
     * These are RECEIVED entries with retryCount > 0 and nextRetryAt <= now.
     *
     * @param now Current timestamp
     * @param pageable Pagination info (limit batch size)
     * @return List of entries ready for retry
     */
    @Query("SELECT e FROM InboxEntry e WHERE e.status = 'RECEIVED' " +
           "AND e.retryCount > 0 " +
           "AND e.nextRetryAt IS NOT NULL " +
           "AND e.nextRetryAt <= :now " +
           "ORDER BY e.nextRetryAt ASC")
    List<InboxEntry> findReadyForRetry(@Param("now") Instant now, Pageable pageable);

    /**
     * Find orphaned inbox entries (RECEIVED for too long without processing).
     * Safety net to catch entries that were missed due to crashes or errors.
     *
     * @param threshold Timestamp threshold (e.g., 1 minute ago)
     * @param pageable Pagination info (limit batch size)
     * @return List of orphaned entries
     */
    @Query("SELECT e FROM InboxEntry e WHERE e.status = 'RECEIVED' " +
           "AND e.retryCount = 0 " +
           "AND e.receivedAt < :threshold " +
           "ORDER BY e.receivedAt ASC")
    List<InboxEntry> findOrphaned(@Param("threshold") Instant threshold, Pageable pageable);

    /**
     * Count entries by status.
     * Used for monitoring and metrics.
     */
    long countByStatus(InboxEntry.Status status);

    /**
     * Find DLQ entries for monitoring/manual intervention.
     */
    List<InboxEntry> findByStatusOrderByLastUpdatedAtDesc(InboxEntry.Status status, Pageable pageable);
}
