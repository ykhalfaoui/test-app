package com.remediation.sharedkernel.block;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/**
 * Service for provisioning (creating) and managing information blocks for Parties.
 *
 * Business Rules:
 * 1. Only ONE active block per type per Party
 * 2. Blocks never deleted (audit trail)
 * 3. When new block created, old active block automatically archived
 *
 * Three Provisioning Scenarios:
 *
 * A. Initial Onboarding:
 *    - Triggered by PartyOnboardedEvent
 *    - Creates 4 blocks: KYC, KYT, STATIC_DATA, DOCUMENT
 *    - No archiving needed (new Party)
 *
 * B. Review - Principal Actor:
 *    - Triggered by ReviewStartedEvent (for customer principal)
 *    - Archives existing 4 blocks
 *    - Creates 4 new blocks: KYC, KYT, STATIC_DATA, DOCUMENT
 *
 * C. Review - Secondary Member:
 *    - Triggered by PartyUpdatedEvent (with relationType = SECONDARY)
 *    - Archives existing 2 blocks (STATIC_DATA, DOCUMENT)
 *    - Creates 2 new blocks: STATIC_DATA, DOCUMENT
 *    - KYC and KYT blocks remain unchanged
 */
@Service
@Slf4j
public class BlockProvisioningService {

    private static final EnumSet<BlockType> FULL_BLOCK_SET =
        EnumSet.of(BlockType.KYC, BlockType.KYT, BlockType.STATIC_DATA, BlockType.DOCUMENT);

    private static final EnumSet<BlockType> PARTIAL_BLOCK_SET =
        EnumSet.of(BlockType.STATIC_DATA, BlockType.DOCUMENT);

    private final BlockRepository blockRepository;
    private final ApplicationEventPublisher eventPublisher;

    public BlockProvisioningService(BlockRepository blockRepository,
                                   ApplicationEventPublisher eventPublisher) {
        this.blockRepository = blockRepository;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Provision initial blocks for a newly onboarded Party.
     *
     * Use Case: Onboarding (Cas A)
     * Creates: KYC, KYT, STATIC_DATA, DOCUMENT (all version 1, all ACTIVE)
     *
     * Business Rule: No archiving needed since Party is new.
     *
     * @param partyId ID of the newly onboarded Party
     * @throws IllegalArgumentException if partyId is null
     * @throws IllegalStateException if Party already has active blocks
     */
    @Transactional
    public void provisionInitialBlocks(UUID partyId) {
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }

        log.info("Provisioning initial blocks for Party [partyId: {}]", partyId);

        // Safety check: Party should not have any active blocks yet
        long existingActiveBlocks = blockRepository.countByPartyIdAndStatus(partyId, BlockStatus.ACTIVE);
        if (existingActiveBlocks > 0) {
            log.warn("Party already has {} active blocks, skipping initial provisioning [partyId: {}]",
                existingActiveBlocks, partyId);
            return;
        }

        // Create all 4 block types
        List<Block> blocks = createBlockSet(partyId, FULL_BLOCK_SET);

        log.info("Successfully provisioned {} initial blocks for Party [partyId: {}]",
            blocks.size(), partyId);
    }

    /**
     * Provision full block set for a Party undergoing review with Principal Actor.
     *
     * Use Case: Review - Principal Actor (Cas B1)
     * Archives: KYC, KYT, STATIC_DATA, DOCUMENT (existing active blocks)
     * Creates: KYC, KYT, STATIC_DATA, DOCUMENT (new blocks, versions incremented)
     *
     * Business Rule 3: Old active blocks automatically archived before creating new ones.
     *
     * @param partyId ID of the Party under review
     * @throws IllegalArgumentException if partyId is null
     */
    @Transactional
    public void provisionFullBlockSet(UUID partyId) {
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }

        log.info("Provisioning full block set for Party [partyId: {}]", partyId);

        // Archive existing active blocks
        int archivedCount = archiveActiveBlocks(partyId, FULL_BLOCK_SET);
        log.info("Archived {} active blocks for Party [partyId: {}]", archivedCount, partyId);

        // Create new block set
        List<Block> blocks = createBlockSet(partyId, FULL_BLOCK_SET);

        log.info("Successfully provisioned {} new blocks for Party [partyId: {}]",
            blocks.size(), partyId);
    }

    /**
     * Provision partial block set for a Party undergoing review with Secondary Member.
     *
     * Use Case: Review - Secondary Member (Cas B2)
     * Archives: STATIC_DATA, DOCUMENT (existing active blocks only)
     * Creates: STATIC_DATA, DOCUMENT (new blocks, versions incremented)
     * Unchanged: KYC, KYT (remain active)
     *
     * Business Rule 3: Only affected block types are archived.
     *
     * @param partyId ID of the Party under review
     * @throws IllegalArgumentException if partyId is null
     */
    @Transactional
    public void provisionPartialBlockSet(UUID partyId) {
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }

        log.info("Provisioning partial block set for Party [partyId: {}]", partyId);

        // Archive only STATIC_DATA and DOCUMENT blocks
        int archivedCount = archiveActiveBlocks(partyId, PARTIAL_BLOCK_SET);
        log.info("Archived {} active blocks (STATIC_DATA, DOCUMENT) for Party [partyId: {}]",
            archivedCount, partyId);

        // Create new STATIC_DATA and DOCUMENT blocks
        List<Block> blocks = createBlockSet(partyId, PARTIAL_BLOCK_SET);

        log.info("Successfully provisioned {} new blocks (STATIC_DATA, DOCUMENT) for Party [partyId: {}]",
            blocks.size(), partyId);
    }

    /**
     * Archive active blocks of specified types for a Party.
     *
     * Business Rule 3: When new block created, old active block automatically archived.
     *
     * @param partyId Party ID
     * @param blockTypes Types of blocks to archive
     * @return Number of blocks archived
     */
    private int archiveActiveBlocks(UUID partyId, EnumSet<BlockType> blockTypes) {
        int archivedCount = 0;

        for (BlockType type : blockTypes) {
            blockRepository.findByPartyIdAndTypeAndStatus(partyId, type, BlockStatus.ACTIVE)
                .ifPresent(block -> {
                    log.debug("Archiving block [id: {}, type: {}, version: {}]",
                        block.getId(), block.getType(), block.getBlockVersion());

                    block.archive();
                    blockRepository.save(block);

                    // Publish domain event
                    eventPublisher.publishEvent(new BlockArchivedEvent(
                        block.getId(),
                        block.getPartyId(),
                        block.getType(),
                        block.getBlockVersion()
                    ));

                    log.info("Archived block [id: {}, partyId: {}, type: {}, version: {}]",
                        block.getId(), partyId, type, block.getBlockVersion());
                });

            if (blockRepository.existsByPartyIdAndTypeAndStatus(partyId, type, BlockStatus.ARCHIVED)) {
                archivedCount++;
            }
        }

        return archivedCount;
    }

    /**
     * Create a set of blocks for a Party.
     *
     * For each block type:
     * 1. Calculate next version number (max existing version + 1, or 1 if none exist)
     * 2. Create block with ACTIVE status and empty payload
     * 3. Save to database
     * 4. Publish BlockProvisionedEvent
     *
     * @param partyId Party ID
     * @param blockTypes Types of blocks to create
     * @return List of created blocks
     */
    private List<Block> createBlockSet(UUID partyId, EnumSet<BlockType> blockTypes) {
        List<Block> createdBlocks = new ArrayList<>();

        for (BlockType type : blockTypes) {
            // Calculate next version
            int nextVersion = getNextBlockVersion(partyId, type);

            // Create block with empty payload (can be populated later)
            Block block = Block.createActive(partyId, type, nextVersion, "{}");
            blockRepository.save(block);

            createdBlocks.add(block);

            // Publish domain event
            eventPublisher.publishEvent(new BlockProvisionedEvent(
                block.getId(),
                block.getPartyId(),
                block.getType(),
                block.getBlockVersion(),
                block.getStatus()
            ));

            log.info("Created block [id: {}, partyId: {}, type: {}, version: {}, status: {}]",
                block.getId(), partyId, type, nextVersion, block.getStatus());
        }

        return createdBlocks;
    }

    /**
     * Calculate the next version number for a block type.
     *
     * Logic:
     * - Find max existing version for this Party and block type
     * - If max is null (no existing blocks), return 1
     * - Otherwise, return max + 1
     *
     * Examples:
     * - No KYC blocks exist → next version = 1
     * - Max KYC version is 3 → next version = 4
     *
     * @param partyId Party ID
     * @param type Block type
     * @return Next version number (always >= 1)
     */
    private int getNextBlockVersion(UUID partyId, BlockType type) {
        Integer maxVersion = blockRepository.findMaxBlockVersionByPartyIdAndType(partyId, type);
        return maxVersion == null ? 1 : maxVersion + 1;
    }
}
