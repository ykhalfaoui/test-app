package com.remediation.sharedkernel.block;

import java.util.UUID;

/**
 * Domain event published when a new Block is provisioned (created) for a Party.
 *
 * This event is published after successful creation of a block, regardless of the trigger:
 * - Onboarding (initial 4 blocks)
 * - Review with Principal Actor (full refresh of 4 blocks)
 * - Review with Secondary Member (partial refresh of 2 blocks)
 *
 * Use Cases:
 * - Audit trail
 * - Triggering downstream processes (e.g., Salesforce sync)
 * - Metrics and monitoring
 * - Notifications
 *
 * @param blockId ID of the newly created block
 * @param partyId Party this block belongs to
 * @param type Type of block (KYC, KYT, STATIC_DATA, DOCUMENT)
 * @param blockVersion Business version number of the block
 * @param status Status of the block (should always be ACTIVE for new blocks)
 */
public record BlockProvisionedEvent(
    UUID blockId,
    UUID partyId,
    BlockType type,
    int blockVersion,
    BlockStatus status
) {
    public BlockProvisionedEvent {
        if (blockId == null) {
            throw new IllegalArgumentException("blockId cannot be null");
        }
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }
        if (type == null) {
            throw new IllegalArgumentException("type cannot be null");
        }
        if (blockVersion <= 0) {
            throw new IllegalArgumentException("blockVersion must be positive");
        }
        if (status == null) {
            throw new IllegalArgumentException("status cannot be null");
        }
    }
}
