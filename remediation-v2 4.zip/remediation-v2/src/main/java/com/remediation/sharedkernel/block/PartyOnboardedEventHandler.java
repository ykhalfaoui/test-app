package com.remediation.sharedkernel.block;

import com.remediation.party.domain.PartyOnboardedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Event handler for Party onboarding.
 *
 * Listens to PartyOnboardedEvent and triggers initial block provisioning.
 *
 * Use Case: Cas A - Onboarding
 * Action: Create 4 initial blocks (KYC, KYT, STATIC_DATA, DOCUMENT)
 *
 * Business Rule: New Party should have complete set of blocks from the start.
 */
@Component
@Slf4j
public class PartyOnboardedEventHandler {

    private final BlockProvisioningService blockProvisioningService;

    public PartyOnboardedEventHandler(BlockProvisioningService blockProvisioningService) {
        this.blockProvisioningService = blockProvisioningService;
    }

    /**
     * Handle Party onboarding event.
     *
     * Provisions initial blocks for the newly onboarded Party.
     *
     * @param event PartyOnboardedEvent containing Party ID
     */
    @EventListener
    public void onPartyOnboarded(PartyOnboardedEvent event) {
        log.info("Handling PartyOnboardedEvent [partyId: {}]", event.partyId());

        try {
            blockProvisioningService.provisionInitialBlocks(event.partyId());

            log.info("Successfully handled PartyOnboardedEvent [partyId: {}]", event.partyId());

        } catch (Exception ex) {
            log.error("Failed to provision initial blocks for Party [partyId: {}]: {}",
                event.partyId(), ex.getMessage(), ex);
            throw ex; // Re-throw to trigger transaction rollback
        }
    }
}
