package com.remediation.sharedkernel.inbox;

import java.util.UUID;

/**
 * Internal event published when an inbox entry is saved and ready for processing.
 * This triggers immediate async processing instead of waiting for scheduled polling.
 *
 * This event is NOT a domain event - it's an internal infrastructure event
 * for coordinating async processing.
 */
public record InboxEntryReceivedEvent(UUID eventId) {
    public InboxEntryReceivedEvent {
        if (eventId == null) {
            throw new IllegalArgumentException("eventId cannot be null");
        }
    }
}
