package com.remediation.sharedkernel.block;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for managing Block entities.
 *
 * Provides queries for:
 * - Finding active blocks
 * - Finding historical blocks
 * - Calculating next version numbers
 * - Archiving operations
 */
@Repository
public interface BlockRepository extends JpaRepository<Block, UUID> {

    /**
     * Find the active block for a given Party and block type.
     *
     * Business Rule: There should be at most ONE active block per type per Party.
     *
     * @param partyId Party ID
     * @param type Block type
     * @param status Block status (should be ACTIVE)
     * @return Optional containing the active block, or empty if none exists
     */
    Optional<Block> findByPartyIdAndTypeAndStatus(UUID partyId, BlockType type, BlockStatus status);

    /**
     * Find all blocks (active + archived) for a given Party and block type.
     * Ordered by version descending (newest first).
     *
     * Use case: View complete history of a block type for a Party.
     *
     * @param partyId Party ID
     * @param type Block type
     * @return List of all blocks ordered by version desc
     */
    List<Block> findAllByPartyIdAndTypeOrderByBlockVersionDesc(UUID partyId, BlockType type);

    /**
     * Find all active blocks for a given Party.
     *
     * Use case: Get current snapshot of all Party information.
     *
     * Expected result: 4 blocks (KYC, KYT, STATIC_DATA, DOCUMENT) if fully provisioned.
     *
     * @param partyId Party ID
     * @param status Block status (should be ACTIVE)
     * @return List of all active blocks for the Party
     */
    List<Block> findAllByPartyIdAndStatus(UUID partyId, BlockStatus status);

    /**
     * Find the maximum block version for a given Party and block type.
     *
     * Used to calculate the next version number when creating a new block.
     *
     * Example:
     * - If max version is 3, next version will be 4
     * - If no blocks exist, returns null, so next version will be 1
     *
     * @param partyId Party ID
     * @param type Block type
     * @return Maximum block version, or null if no blocks exist
     */
    @Query("SELECT MAX(b.blockVersion) FROM Block b WHERE b.partyId = :partyId AND b.type = :type")
    Integer findMaxBlockVersionByPartyIdAndType(@Param("partyId") UUID partyId, @Param("type") BlockType type);

    /**
     * Check if an active block exists for a given Party and block type.
     *
     * Use case: Validate business rule (only one active block per type).
     *
     * @param partyId Party ID
     * @param type Block type
     * @param status Block status (should be ACTIVE)
     * @return true if active block exists, false otherwise
     */
    boolean existsByPartyIdAndTypeAndStatus(UUID partyId, BlockType type, BlockStatus status);

    /**
     * Count active blocks for a given Party.
     *
     * Use case: Verify Party has complete block set (should be 4 for fully provisioned Party).
     *
     * @param partyId Party ID
     * @param status Block status (should be ACTIVE)
     * @return Count of active blocks
     */
    long countByPartyIdAndStatus(UUID partyId, BlockStatus status);

    /**
     * Find all archived blocks for a given Party and block type.
     *
     * Use case: View archived history excluding current active block.
     *
     * @param partyId Party ID
     * @param type Block type
     * @param status Block status (should be ARCHIVED)
     * @return List of archived blocks ordered by version desc
     */
    List<Block> findAllByPartyIdAndTypeAndStatusOrderByBlockVersionDesc(
        UUID partyId,
        BlockType type,
        BlockStatus status
    );
}
