package com.remediation.sharedkernel.block;

import java.util.UUID;

/**
 * Domain event published when a Block is archived.
 *
 * Archiving happens automatically when a new block of the same type is created for the same Party.
 * This is part of the versioning strategy (Business Rule 3).
 *
 * Timeline Example:
 * 1. Party has KYC Block v1 (ACTIVE)
 * 2. Review triggers creation of new KYC block
 * 3. KYC Block v1 is archived → BlockArchivedEvent published
 * 4. KYC Block v2 is created (ACTIVE) → BlockProvisionedEvent published
 *
 * Use Cases:
 * - Audit trail (track when information became historical)
 * - Compliance reporting
 * - Metrics (block lifecycle tracking)
 * - Cleanup processes (if needed)
 *
 * @param blockId ID of the archived block
 * @param partyId Party this block belongs to
 * @param type Type of block (KYC, KYT, STATIC_DATA, DOCUMENT)
 * @param blockVersion Business version number of the archived block
 */
public record BlockArchivedEvent(
    UUID blockId,
    UUID partyId,
    BlockType type,
    int blockVersion
) {
    public BlockArchivedEvent {
        if (blockId == null) {
            throw new IllegalArgumentException("blockId cannot be null");
        }
        if (partyId == null) {
            throw new IllegalArgumentException("partyId cannot be null");
        }
        if (type == null) {
            throw new IllegalArgumentException("type cannot be null");
        }
        if (blockVersion <= 0) {
            throw new IllegalArgumentException("blockVersion must be positive");
        }
    }
}
