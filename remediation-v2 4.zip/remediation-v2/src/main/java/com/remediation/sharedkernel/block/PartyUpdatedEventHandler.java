package com.remediation.sharedkernel.block;

import com.remediation.party.domain.PartyUpdatedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Event handler for Party updates.
 *
 * Listens to PartyUpdatedEvent and triggers partial block provisioning
 * when a Secondary Member is added to a Party.
 *
 * Use Case: Cas B2 - Review with Secondary Member
 * Action: Create 2 new blocks (STATIC_DATA, DOCUMENT), archive old ones
 *
 * Business Rule:
 * - For Secondary Members: Only STATIC_DATA and DOCUMENT blocks are refreshed
 * - KYC and KYT blocks remain unchanged
 */
@Component
@Slf4j
public class PartyUpdatedEventHandler {

    private static final String SECONDARY_RELATION_TYPE = "SECONDARY";

    private final BlockProvisioningService blockProvisioningService;

    public PartyUpdatedEventHandler(BlockProvisioningService blockProvisioningService) {
        this.blockProvisioningService = blockProvisioningService;
    }

    /**
     * Handle Party update event.
     *
     * Checks the relation type:
     * - If SECONDARY: Provisions partial block set (STATIC_DATA, DOCUMENT)
     * - Otherwise: No action (other relation types handled elsewhere)
     *
     * @param event PartyUpdatedEvent containing Party ID and relation type
     */
    @EventListener
    public void onPartyUpdated(PartyUpdatedEvent event) {
        log.info("Handling PartyUpdatedEvent [partyId: {}, relationType: {}]",
            event.partyId(), event.relationType());

        // Only handle SECONDARY member updates
        if (!SECONDARY_RELATION_TYPE.equalsIgnoreCase(event.relationType())) {
            log.debug("Ignoring PartyUpdatedEvent with relationType '{}' [partyId: {}]",
                event.relationType(), event.partyId());
            return;
        }

        try {
            blockProvisioningService.provisionPartialBlockSet(event.partyId());

            log.info("Successfully handled PartyUpdatedEvent for SECONDARY member [partyId: {}]",
                event.partyId());

        } catch (Exception ex) {
            log.error("Failed to provision partial blocks for Party [partyId: {}]: {}",
                event.partyId(), ex.getMessage(), ex);
            throw ex; // Re-throw to trigger transaction rollback
        }
    }
}
