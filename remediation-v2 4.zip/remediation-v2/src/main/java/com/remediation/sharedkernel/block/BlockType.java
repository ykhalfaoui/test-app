package com.remediation.sharedkernel.block;

/**
 * Types of information blocks that can be associated with a Party.
 *
 * Each Party can have multiple blocks of different types to track
 * different aspects of their compliance and customer information.
 *
 * Business Rules:
 * - Only ONE active block per type per Party
 * - Historical versions are archived but never deleted
 */
public enum BlockType {
    /**
     * Know Your Customer block.
     * Contains customer identification and verification information.
     */
    KYC,

    /**
     * Know Your Transaction block.
     * Contains transaction monitoring and analysis information.
     */
    KYT,

    /**
     * Static Data block.
     * Contains customer static information (name, address, contact details, etc.).
     */
    STATIC_DATA,

    /**
     * Document block.
     * Contains references to customer documents and attachments.
     */
    DOCUMENT
}
