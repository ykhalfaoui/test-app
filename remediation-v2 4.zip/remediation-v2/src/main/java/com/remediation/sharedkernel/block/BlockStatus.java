package com.remediation.sharedkernel.block;

/**
 * Status of an information block.
 *
 * Lifecycle:
 * 1. Block is created with ACTIVE status
 * 2. When a new block of same type is created, old block becomes ARCHIVED
 * 3. Archived blocks are kept forever for audit trail
 *
 * Business Rules:
 * - Only ONE ACTIVE block per type per Party
 * - ARCHIVED blocks cannot become ACTIVE again
 * - Blocks are never deleted (soft-delete only if required)
 */
public enum BlockStatus {
    /**
     * Active status - This is the current/latest version of this block type.
     * Only one block per type can be ACTIVE for a given Party.
     */
    ACTIVE,

    /**
     * Archived status - This is a historical version of this block type.
     * Archived when a newer version is created.
     * Kept for audit trail and compliance.
     */
    ARCHIVED
}
