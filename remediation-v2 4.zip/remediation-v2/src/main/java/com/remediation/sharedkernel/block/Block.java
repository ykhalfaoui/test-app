package com.remediation.sharedkernel.block;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Block entity - Versioned information blocks for Party compliance data.
 *
 * Business Context:
 * Each Party (customer) has multiple types of information blocks (KYC, KYT, Static Data, Documents).
 * These blocks are versioned to maintain a complete audit trail of changes over time.
 *
 * Versioning Strategy:
 * - blockVersion: Business version number (1, 2, 3...) for user-facing version tracking
 * - entityVersion: Technical version for Hibernate optimistic locking (concurrency control)
 *
 * Status Lifecycle:
 * 1. Block created with ACTIVE status
 * 2. When new block of same type created, old block marked ARCHIVED
 * 3. Archived blocks kept forever for audit trail
 *
 * Business Rules (CRITICAL):
 * - Rule 1: Only ONE ACTIVE block per type per Party
 * - Rule 2: Blocks never deleted (soft-delete only)
 * - Rule 3: When new block created, old ACTIVE block automatically ARCHIVED
 *
 * Example Timeline:
 * Day 1:  Party onboarding → KYC Block v1 (ACTIVE)
 * Day 30: Review (Principal) → KYC Block v1 (ARCHIVED), KYC Block v2 (ACTIVE)
 * Day 60: Review (Principal) → KYC Block v2 (ARCHIVED), KYC Block v3 (ACTIVE)
 */
@Entity
@Table(name = "block", indexes = {
    @Index(name = "idx_block_party_type_status", columnList = "party_id,type,status"),
    @Index(name = "idx_block_party_type_version", columnList = "party_id,type,block_version")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Block {

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    /**
     * Reference to the Party (customer) this block belongs to.
     */
    @Column(name = "party_id", nullable = false, updatable = false)
    private UUID partyId;

    /**
     * Type of information this block represents.
     * See {@link BlockType} for available types.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, updatable = false, length = 20)
    private BlockType type;

    /**
     * Business version number for this block type.
     * Incremented each time a new block of this type is created for the same Party.
     *
     * Examples:
     * - First KYC block for Party X: blockVersion = 1
     * - Second KYC block for Party X: blockVersion = 2
     * - First STATIC_DATA block for Party X: blockVersion = 1 (independent counter per type)
     *
     * Note: This is separate from entityVersion (Hibernate @Version).
     */
    @Column(name = "block_version", nullable = false, updatable = false)
    private Integer blockVersion;

    /**
     * Hibernate optimistic locking version.
     * Automatically incremented by Hibernate on each update.
     * Used to prevent lost updates in concurrent scenarios.
     *
     * Note: This is separate from blockVersion (business version).
     */
    @Version
    @Column(name = "entity_version")
    private Long entityVersion;

    /**
     * Current status of this block.
     * See {@link BlockStatus} for lifecycle.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private BlockStatus status;

    /**
     * Business data payload stored as JSON.
     * Contains the actual KYC data, document references, static data, etc.
     *
     * Structure depends on block type:
     * - KYC: { "identificationType": "...", "identificationNumber": "...", ... }
     * - STATIC_DATA: { "firstName": "...", "lastName": "...", "address": "...", ... }
     * - DOCUMENT: { "documentIds": [...], "documentTypes": [...], ... }
     * - KYT: { "riskScore": "...", "transactionPatterns": [...], ... }
     */
    @Lob
    @Column(name = "payload")
    private String payload;

    /**
     * When this block was created.
     * Immutable after creation.
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    /**
     * When this block was archived.
     * Null if status is ACTIVE.
     * Set when status transitions from ACTIVE to ARCHIVED.
     */
    @Column(name = "archived_at")
    private Instant archivedAt;

    /**
     * Factory method to create a new ACTIVE block.
     *
     * @param partyId Party this block belongs to
     * @param type Type of block
     * @param blockVersion Business version number
     * @param payload JSON payload with business data
     * @return New Block instance with ACTIVE status
     */
    public static Block createActive(UUID partyId, BlockType type, int blockVersion, String payload) {
        Block block = new Block();
        block.id = UUID.randomUUID();
        block.partyId = partyId;
        block.type = type;
        block.blockVersion = blockVersion;
        block.status = BlockStatus.ACTIVE;
        block.payload = payload;
        block.createdAt = Instant.now();
        block.archivedAt = null;
        return block;
    }

    /**
     * Archives this block.
     * Transitions status from ACTIVE to ARCHIVED.
     *
     * Business Rule: This happens automatically when a new block of the same type is created.
     *
     * @throws IllegalStateException if block is already archived
     */
    public void archive() {
        if (status == BlockStatus.ARCHIVED) {
            throw new IllegalStateException(
                String.format("Block already archived [id=%s, type=%s, version=%d]",
                    id, type, blockVersion)
            );
        }
        this.status = BlockStatus.ARCHIVED;
        this.archivedAt = Instant.now();
    }

    /**
     * Checks if this block is currently active.
     */
    public boolean isActive() {
        return status == BlockStatus.ACTIVE;
    }

    /**
     * Checks if this block is archived.
     */
    public boolean isArchived() {
        return status == BlockStatus.ARCHIVED;
    }

    /**
     * Updates the payload of this block.
     * Only allowed for ACTIVE blocks.
     *
     * @param newPayload New JSON payload
     * @throws IllegalStateException if block is archived
     */
    public void updatePayload(String newPayload) {
        if (status == BlockStatus.ARCHIVED) {
            throw new IllegalStateException(
                String.format("Cannot update archived block [id=%s, type=%s, version=%d]",
                    id, type, blockVersion)
            );
        }
        this.payload = newPayload;
    }
}
