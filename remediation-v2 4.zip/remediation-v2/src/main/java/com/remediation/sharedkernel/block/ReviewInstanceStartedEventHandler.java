package com.remediation.sharedkernel.block;

import com.remediation.review.api.ReviewInstanceStartedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Event handler for Review Instance start.
 *
 * Listens to ReviewInstanceStartedEvent and triggers full block provisioning
 * for the principal customer under review.
 *
 * Use Case: Cas B1 - Review with Principal Actor
 * Action: Archive existing 4 blocks, create 4 new blocks (KYC, KYT, STATIC_DATA, DOCUMENT)
 *
 * Business Rule:
 * - For Principal Customer: All block types are refreshed
 * - This ensures compliance data is up-to-date for the review
 */
@Component
@Slf4j
public class ReviewInstanceStartedEventHandler {

    private final BlockProvisioningService blockProvisioningService;

    public ReviewInstanceStartedEventHandler(BlockProvisioningService blockProvisioningService) {
        this.blockProvisioningService = blockProvisioningService;
    }

    /**
     * Handle Review Instance start event.
     *
     * Provisions full block set for the principal customer under review.
     *
     * Flow:
     * 1. Extract customerId from event (principal customer)
     * 2. Archive existing 4 active blocks
     * 3. Create 4 new blocks with incremented versions
     *
     * @param event ReviewInstanceStartedEvent containing review details
     */
    @EventListener
    public void onReviewInstanceStarted(ReviewInstanceStartedEvent event) {
        log.info("Handling ReviewInstanceStartedEvent [reviewId: {}, customerId: {}, traceId: {}]",
            event.reviewId().value(), event.customerId().value(), event.traceId().value());

        try {
            // Convert CustomerId to UUID (partyId)
            UUID partyId = event.customerId().value();

            blockProvisioningService.provisionFullBlockSet(partyId);

            log.info("Successfully handled ReviewInstanceStartedEvent [reviewId: {}, partyId: {}, traceId: {}]",
                event.reviewId().value(), partyId, event.traceId().value());

        } catch (Exception ex) {
            log.error("Failed to provision full blocks for review [reviewId: {}, customerId: {}, traceId: {}]: {}",
                event.reviewId().value(), event.customerId().value(), event.traceId().value(),
                ex.getMessage(), ex);
            throw ex; // Re-throw to trigger transaction rollback
        }
    }
}
