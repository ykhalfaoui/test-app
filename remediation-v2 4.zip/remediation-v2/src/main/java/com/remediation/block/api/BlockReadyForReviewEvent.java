package com.remediation.block.api;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Domain event published when a block is ready to be included in a review.
 * This event is consumed by the ReviewSaga to track block collection progress.
 *
 * @param traceId Distributed trace identifier
 * @param blockId The block that is ready
 * @param reviewId The review this block belongs to
 */
public record BlockReadyForReviewEvent(
    TraceId traceId,
    BlockId blockId,
    ReviewId reviewId
) {
    public BlockReadyForReviewEvent {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (blockId == null) throw new IllegalArgumentException("blockId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
    }
}
