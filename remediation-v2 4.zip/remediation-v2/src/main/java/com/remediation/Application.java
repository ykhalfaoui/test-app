package com.remediation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for Remediation System V2.
 *
 * Features:
 * - Event-driven architecture with Spring Modulith
 * - Domain-Driven Design with bounded contexts
 * - Saga pattern for long-running processes
 * - Inbox/Outbox patterns for reliable messaging
 * - Comprehensive audit trail
 */
@SpringBootApplication
@EnableScheduling  // For outbox forwarder and scheduled tasks
@EnableAsync       // For asynchronous processing
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
