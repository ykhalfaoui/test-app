package com.remediation.review.domain;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Review Instance aggregate representing a remediation review process.
 * This is the main business entity that tracks the review lifecycle.
 */
@Entity
@Table(name = "review_instance", indexes = {
    @Index(name = "idx_review_customer", columnList = "customer_id"),
    @Index(name = "idx_review_status", columnList = "status")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class ReviewInstance {

    public enum ReviewStatus {
        STARTED,        // Review initiated
        IN_PROGRESS,    // Data collection in progress
        READY,          // All data collected, ready for analyst review
        COMPLETED,      // Review completed
        CANCELLED       // Review cancelled
    }

    @EmbeddedId
    @AttributeOverride(name = "value", column = @Column(name = "id"))
    private ReviewId id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "customer_id", nullable = false))
    private CustomerId customerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private ReviewStatus status;

    @Column(name = "trigger_type", nullable = false, length = 50)
    private String triggerType;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "last_updated_at", nullable = false)
    private Instant lastUpdatedAt;

    @Version
    @Column(name = "version")
    private Long version;

    public ReviewInstance(CustomerId customerId, String triggerType) {
        this.id = ReviewId.create();
        this.customerId = customerId;
        this.triggerType = triggerType;
        this.status = ReviewStatus.STARTED;
        Instant now = Instant.now();
        this.createdAt = now;
        this.lastUpdatedAt = now;
    }

    public void markInProgress() {
        if (this.status == ReviewStatus.STARTED) {
            this.status = ReviewStatus.IN_PROGRESS;
            this.lastUpdatedAt = Instant.now();
        }
    }

    public void markReady() {
        if (this.status == ReviewStatus.IN_PROGRESS) {
            this.status = ReviewStatus.READY;
            this.lastUpdatedAt = Instant.now();
        }
    }

    public void complete() {
        this.status = ReviewStatus.COMPLETED;
        this.lastUpdatedAt = Instant.now();
    }
}
