package com.remediation.review.application;

import com.remediation.review.api.ReviewInstanceStartedEvent;
import com.remediation.review.domain.ReviewInstance;
import com.remediation.review.domain.ReviewInstanceRepository;
import com.remediation.review.domain.ReviewSaga;
import com.remediation.review.domain.ReviewSagaRepository;
import com.remediation.trigger.api.HitQualifiedPositiveEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.annotation.Order;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * ReviewSagaManager orchestrates the review process by:
 * 1. Creating ReviewInstance and ReviewSaga when a positive hit is received
 * 2. Publishing ReviewInstanceStartedEvent to trigger downstream processes
 * 3. Managing saga state transitions based on family composition and block collection events
 *
 * Uses Spring Modulith's @ApplicationModuleListener for event-driven orchestration.
 */
@Service
@Slf4j
public class ReviewSagaManager {

    private final ReviewInstanceRepository reviewRepository;
    private final ReviewSagaRepository sagaRepository;
    private final ApplicationEventPublisher eventPublisher;

    public ReviewSagaManager(
        ReviewInstanceRepository reviewRepository,
        ReviewSagaRepository sagaRepository,
        ApplicationEventPublisher eventPublisher
    ) {
        this.reviewRepository = reviewRepository;
        this.sagaRepository = sagaRepository;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Initiates a review process when a positive hit is received.
     * This listener has @Order(1) to ensure it runs before other listeners.
     */
    @ApplicationModuleListener
    @Transactional
    @Order(1) // Run first to ensure saga exists before other listeners
    public void on(HitQualifiedPositiveEvent event) {
        log.info("Initiating review for positive hit [customerId: {}, TraceId: {}]",
            event.customerId().value(), event.traceId().value());

        // 1. Create the ReviewInstance aggregate
        ReviewInstance review = new ReviewInstance(event.customerId(), event.hitType());
        reviewRepository.save(review);

        log.info("Created review instance {} for customer {}",
            review.getId().value(), event.customerId().value());

        // 2. Create the ReviewSaga state machine
        ReviewSaga saga = new ReviewSaga(review.getId(), event.customerId());
        sagaRepository.save(saga);

        log.info("Created review saga {} for review {}",
            saga.getId(), review.getId().value());

        // 3. Publish ReviewInstanceStartedEvent to trigger downstream processes
        ReviewInstanceStartedEvent startedEvent = new ReviewInstanceStartedEvent(
            event.traceId(),
            review.getId(),
            event.customerId(),
            event.hitType()
        );

        eventPublisher.publishEvent(startedEvent);

        log.info("Published ReviewInstanceStartedEvent for review {} [TraceId: {}]",
            review.getId().value(), event.traceId().value());
    }

    /**
     * Updates saga expectations when family composition is complete.
     * This tells the saga how many blocks to expect.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(com.remediation.member.api.FamilyCompositionCompletedEvent event) {
        log.info("Family composition completed for review {} - {} members [TraceId: {}]",
            event.reviewId().value(), event.memberCount(), event.traceId().value());

        sagaRepository.findByReviewId(event.reviewId()).ifPresentOrElse(
            saga -> {
                saga.setExpectations(event.memberCount());
                sagaRepository.save(saga);

                log.info("Saga {} expectations set to {} members",
                    saga.getId(), event.memberCount());
            },
            () -> log.warn("Saga not found for review {}", event.reviewId().value())
        );
    }

    /**
     * Records block collection in the saga.
     * When all blocks are collected, saga automatically completes.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(com.remediation.block.api.BlockReadyForReviewEvent event) {
        log.debug("Block ready for review [blockId: {}, reviewId: {}, TraceId: {}]",
            event.blockId().value(), event.reviewId().value(), event.traceId().value());

        sagaRepository.findByReviewId(event.reviewId()).ifPresentOrElse(
            saga -> {
                boolean collected = saga.markBlockCollected(event.blockId());
                sagaRepository.save(saga);

                if (collected) {
                    log.info("Saga {} collected block {} [TraceId: {}]",
                        saga.getId(), event.blockId().value(), event.traceId().value());
                }

                // Update review instance status when saga completes
                if (saga.isCompleted()) {
                    reviewRepository.findById(saga.getReviewId()).ifPresent(review -> {
                        review.markReady();
                        reviewRepository.save(review);

                        log.info("Review {} marked as READY - all data collected [TraceId: {}]",
                            review.getId().value(), event.traceId().value());
                    });
                }
            },
            () -> log.warn("Saga not found for review {}", event.reviewId().value())
        );
    }
}
