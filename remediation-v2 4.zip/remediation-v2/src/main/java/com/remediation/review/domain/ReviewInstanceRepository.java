package com.remediation.review.domain;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for ReviewInstance aggregate.
 */
@Repository
public interface ReviewInstanceRepository extends JpaRepository<ReviewInstance, ReviewId> {

    /**
     * Find all reviews for a given customer.
     */
    List<ReviewInstance> findByCustomerId(CustomerId customerId);

    /**
     * Find reviews by status.
     */
    List<ReviewInstance> findByStatus(ReviewInstance.ReviewStatus status);
}
