package com.remediation.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Async configuration for inbox processing.
 *
 * Strategy: Dedicated ThreadPools per event type to prevent cross-contamination.
 *
 * Event Types:
 * - HIT events: Customer screening hits (medium volume, high priority)
 * - PARTY events: Party/customer updates (low volume, low latency required)
 * - DDR events: Data refresh requests (high volume, lower priority)
 *
 * Why separate pools?
 * - Prevent head-of-line blocking between event types
 * - Independent scaling per event type
 * - Isolated backpressure (DDR overload doesn't block HITs)
 * - Different priorities and SLAs per type
 *
 * Thread Budget Analysis (Tomcat embedded default 200 threads):
 *
 * Concurrent Load Estimation:
 * - HTTP requests: ~50-100 concurrent (API endpoints for UI, external integrations)
 * - Kafka consumers: ~3-6 threads (1-2 per topic: HIT, PARTY, DDR)
 * - Async processing: HIT, PARTY, DDR pools
 *
 * Conservative Allocation:
 * - Reserve for HTTP: 100 threads (peak load)
 * - Reserve for Kafka: 10 threads (consumers + overhead)
 * - Available for async: 90 threads
 *
 * Async Pool Sizing (total max: 45 threads, comfortable margin):
 * - Hit pool: 3-10 threads (core=3, max=10, queue=100)
 * - Party pool: 2-5 threads (core=2, max=5, queue=50)
 * - DDR pool: 5-30 threads (core=5, max=30, queue=300)
 * Total async: 3+2+5=10 cores, max 10+5+30=45 threads
 *
 * Final Budget:
 * - HTTP: 100 threads reserved
 * - Kafka: 10 threads reserved
 * - Async: 45 threads max (10 cores always active)
 * - Buffer: 45 threads remaining
 *
 * Backpressure Strategy:
 * - CallerRunsPolicy: When pool full, Kafka consumer executes task
 * - This naturally slows Kafka consumption for overloaded event types
 * - Large queues absorb traffic spikes before triggering backpressure
 * - Core threads always ready for immediate processing
 *
 * Note: @EnableAsync is already configured in Application.java
 */
@Configuration
@Slf4j
public class AsyncConfig {

    /**
     * ThreadPool for HIT event processing.
     *
     * Characteristics:
     * - Medium volume: 50-200 hits/sec
     * - High priority: Customer screening is critical
     * - Medium latency: Target < 500ms
     * - Complex processing: Saga orchestration, family composition
     *
     * Sizing (conservative for HTTP traffic):
     * - Core: 3 threads (always ready, minimal footprint)
     * - Max: 10 threads (sufficient burst capacity)
     * - Queue: 100 (buffer for traffic spikes)
     * - Total capacity: 110 concurrent tasks
     * - Backpressure: CallerRunsPolicy slows Kafka consumption when full
     */
    @Bean("hitProcessorExecutor")
    public Executor hitProcessorExecutor(
        @Value("${inbox.processor.hit.core-pool-size:3}") int corePoolSize,
        @Value("${inbox.processor.hit.max-pool-size:10}") int maxPoolSize,
        @Value("${inbox.processor.hit.queue-capacity:100}") int queueCapacity
    ) {
        return createThreadPoolExecutor(
            "hit-proc-",
            corePoolSize,
            maxPoolSize,
            queueCapacity
        );
    }

    /**
     * ThreadPool for PARTY event processing.
     *
     * Characteristics:
     * - Low volume: 10-50 updates/sec
     * - Medium priority: Updates should be timely
     * - Low latency required: Target < 200ms
     * - Simple processing: Update existing records
     *
     * Sizing (minimal for low volume):
     * - Core: 2 threads (low volume, minimal footprint)
     * - Max: 5 threads (adequate for bursts)
     * - Queue: 50 (small buffer sufficient)
     * - Total capacity: 55 concurrent tasks
     * - Backpressure: CallerRunsPolicy slows Kafka consumption when full
     */
    @Bean("partyProcessorExecutor")
    public Executor partyProcessorExecutor(
        @Value("${inbox.processor.party.core-pool-size:2}") int corePoolSize,
        @Value("${inbox.processor.party.max-pool-size:5}") int maxPoolSize,
        @Value("${inbox.processor.party.queue-capacity:50}") int queueCapacity
    ) {
        return createThreadPoolExecutor(
            "party-proc-",
            corePoolSize,
            maxPoolSize,
            queueCapacity
        );
    }

    /**
     * ThreadPool for DDR (Data Refresh) event processing.
     *
     * Characteristics:
     * - High volume: 200-1000 events/sec
     * - Lower priority: Batch processing acceptable
     * - Higher latency tolerance: Target < 2s
     * - Batch-friendly: Can process in bulk
     *
     * Sizing (largest pool for high volume, but controlled):
     * - Core: 5 threads (base capacity without monopolizing resources)
     * - Max: 30 threads (large burst capacity for traffic spikes)
     * - Queue: 300 (large buffer absorbs spikes before backpressure)
     * - Total capacity: 330 concurrent tasks
     * - Backpressure: CallerRunsPolicy slows Kafka consumption when full
     * - Note: Large max allows handling bursts without affecting HTTP traffic
     */
    @Bean("ddrProcessorExecutor")
    public Executor ddrProcessorExecutor(
        @Value("${inbox.processor.ddr.core-pool-size:5}") int corePoolSize,
        @Value("${inbox.processor.ddr.max-pool-size:30}") int maxPoolSize,
        @Value("${inbox.processor.ddr.queue-capacity:300}") int queueCapacity
    ) {
        return createThreadPoolExecutor(
            "ddr-proc-",
            corePoolSize,
            maxPoolSize,
            queueCapacity
        );
    }

    /**
     * Helper method to create configured ThreadPoolTaskExecutor.
     */
    private Executor createThreadPoolExecutor(
        String threadNamePrefix,
        int corePoolSize,
        int maxPoolSize,
        int queueCapacity
    ) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        // Thread pool sizing
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);

        // Thread naming for debugging/monitoring
        executor.setThreadNamePrefix(threadNamePrefix);

        // CRITICAL: CallerRunsPolicy for backpressure
        // When queue is full, the calling thread (Kafka consumer) executes the task
        // This naturally slows down Kafka consumption for this specific topic
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());

        // Graceful shutdown
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(60);

        // Thread lifecycle
        executor.setKeepAliveSeconds(60);
        executor.setAllowCoreThreadTimeOut(false); // Keep core threads alive

        executor.initialize();

        log.info("Initialized {}: core={}, max={}, queue={}, policy=CallerRunsPolicy",
            threadNamePrefix + "executor",
            executor.getCorePoolSize(),
            executor.getMaxPoolSize(),
            executor.getQueueCapacity());

        return executor;
    }
}
