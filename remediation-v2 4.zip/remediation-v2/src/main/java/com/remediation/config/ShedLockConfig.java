package com.remediation.config;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.sql.DataSource;

/**
 * ShedLock configuration for distributed scheduled task locking.
 *
 * Purpose:
 * When running multiple instances of the application (horizontal scaling),
 * scheduled tasks (@Scheduled) would execute on ALL instances simultaneously.
 * ShedLock ensures only ONE instance executes each scheduled task at a time.
 *
 * How it works:
 * 1. Before executing a @Scheduled task, acquire lock in database
 * 2. If lock acquired: Execute task
 * 3. If lock held by another instance: Skip execution
 * 4. Release lock after execution or on expiration
 *
 * Use Cases in Remediation:
 * - InboxProcessor.processRetries() - Only one instance should poll for retries
 * - InboxProcessor.recoverOrphans() - Only one instance should recover orphans
 * - OutboxForwarder.forwardEvents() - Only one instance should forward outbox events
 * - InboxProcessor.recordMetrics() - Metrics from one instance sufficient
 *
 * Database Table:
 * ShedLock requires a table named 'shedlock' with specific schema.
 * The table is created automatically via schema.sql on application startup.
 *
 * Configuration:
 * - defaultLockAtMostFor: Maximum duration a lock can be held (prevent deadlocks)
 * - defaultLockAtLeastFor: Minimum duration to hold lock (prevent rapid re-execution)
 *
 * Example Usage:
 * @Scheduled(fixedDelay = 5000)
 * @SchedulerLock(name = "processRetries", lockAtMostFor = "10s", lockAtLeastFor = "5s")
 * public void processRetries() {
 *     // Only executed by one instance at a time
 * }
 */
@Configuration
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "10m") // Max 10 minutes per lock
public class ShedLockConfig {

    /**
     * LockProvider using JDBC for distributed locking.
     *
     * Stores locks in 'shedlock' table in the database.
     * All application instances share the same database, enabling coordination.
     */
    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(JdbcTemplateLockProvider.Configuration.builder()
            .withJdbcTemplate(new JdbcTemplate(dataSource))
            .usingDbTime() // Use database time for consistency across instances
            .build()
        );
    }
}
