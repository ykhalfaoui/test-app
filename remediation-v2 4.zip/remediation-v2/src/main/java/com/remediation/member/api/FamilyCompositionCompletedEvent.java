package com.remediation.member.api;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Domain event published when family composition is complete.
 * Informs the saga how many members (blocks) to expect.
 *
 * @param traceId Distributed trace identifier
 * @param reviewId The review for which composition is complete
 * @param memberCount Total number of members including principal customer and all relations
 */
public record FamilyCompositionCompletedEvent(
    TraceId traceId,
    ReviewId reviewId,
    int memberCount
) {
    public FamilyCompositionCompletedEvent {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
        if (memberCount <= 0) {
            throw new IllegalArgumentException("memberCount must be positive");
        }
    }
}
