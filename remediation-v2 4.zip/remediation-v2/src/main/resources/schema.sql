-- ShedLock table for distributed scheduled task locking
-- This table is automatically created on application startup
-- Used to coordinate @Scheduled tasks across multiple application instances

CREATE TABLE IF NOT EXISTS shedlock (
    name VARCHAR(64) NOT NULL,           -- Unique name of the scheduled task
    lock_until TIMESTAMP NOT NULL,       -- Lock expiration time (lockAtMostFor)
    locked_at TIMESTAMP NOT NULL,        -- When the lock was acquired
    locked_by VARCHAR(255) NOT NULL,     -- Instance identifier (hostname + thread)
    PRIMARY KEY (name)
);

-- Index for efficient lock cleanup queries
CREATE INDEX IF NOT EXISTS idx_shedlock_lock_until ON shedlock(lock_until);

-- Note: JPA ddl-auto will still create other entities (InboxEntry, OutboxEntry, etc.)
-- This schema.sql is specifically for ShedLock which doesn't use JPA entities
