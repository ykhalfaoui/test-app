package com.remediation.sharedkernel.block;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("BlockProvisioningService Unit Tests")
class BlockProvisioningServiceTest {

    @Mock
    private BlockRepository blockRepository;

    @Mock
    private ApplicationEventPublisher eventPublisher;

    @Captor
    private ArgumentCaptor<Block> blockCaptor;

    @Captor
    private ArgumentCaptor<BlockProvisionedEvent> provisionedEventCaptor;

    @Captor
    private ArgumentCaptor<BlockArchivedEvent> archivedEventCaptor;

    private BlockProvisioningService service;

    @BeforeEach
    void setUp() {
        service = new BlockProvisioningService(blockRepository, eventPublisher);
    }

    @Test
    @DisplayName("provisionInitialBlocks - Should create 4 blocks for new Party")
    void provisionInitialBlocks_newParty_creates4Blocks() {
        // Given
        UUID partyId = UUID.randomUUID();
        when(blockRepository.countByPartyIdAndStatus(partyId, BlockStatus.ACTIVE)).thenReturn(0L);
        when(blockRepository.findMaxBlockVersionByPartyIdAndType(eq(partyId), any())).thenReturn(null);

        // When
        service.provisionInitialBlocks(partyId);

        // Then
        verify(blockRepository, times(4)).save(blockCaptor.capture());
        verify(eventPublisher, times(4)).publishEvent(provisionedEventCaptor.capture());

        // Verify 4 blocks created
        var blocks = blockCaptor.getAllValues();
        assertThat(blocks).hasSize(4);

        // Verify all block types present
        assertThat(blocks).extracting(Block::getType)
            .containsExactlyInAnyOrder(
                BlockType.KYC,
                BlockType.KYT,
                BlockType.STATIC_DATA,
                BlockType.DOCUMENT
            );

        // Verify all blocks are version 1 and ACTIVE
        assertThat(blocks).allMatch(block -> block.getBlockVersion() == 1);
        assertThat(blocks).allMatch(Block::isActive);
        assertThat(blocks).allMatch(block -> block.getPartyId().equals(partyId));

        // Verify events published
        var events = provisionedEventCaptor.getAllValues();
        assertThat(events).hasSize(4);
        assertThat(events).allMatch(event -> event.partyId().equals(partyId));
        assertThat(events).allMatch(event -> event.blockVersion() == 1);
        assertThat(events).allMatch(event -> event.status() == BlockStatus.ACTIVE);
    }

    @Test
    @DisplayName("provisionInitialBlocks - Should skip if Party already has active blocks")
    void provisionInitialBlocks_existingBlocks_skips() {
        // Given
        UUID partyId = UUID.randomUUID();
        when(blockRepository.countByPartyIdAndStatus(partyId, BlockStatus.ACTIVE)).thenReturn(4L);

        // When
        service.provisionInitialBlocks(partyId);

        // Then
        verify(blockRepository, never()).save(any());
        verify(eventPublisher, never()).publishEvent(any());
    }

    @Test
    @DisplayName("provisionFullBlockSet - Should archive existing blocks and create new ones")
    void provisionFullBlockSet_existingActiveBlocks_archivesAndCreatesNew() {
        // Given
        UUID partyId = UUID.randomUUID();

        // Existing active blocks (version 1)
        Block existingKyc = Block.createActive(partyId, BlockType.KYC, 1, "{}");
        Block existingKyt = Block.createActive(partyId, BlockType.KYT, 1, "{}");
        Block existingStaticData = Block.createActive(partyId, BlockType.STATIC_DATA, 1, "{}");
        Block existingDocument = Block.createActive(partyId, BlockType.DOCUMENT, 1, "{}");

        when(blockRepository.findByPartyIdAndTypeAndStatus(partyId, BlockType.KYC, BlockStatus.ACTIVE))
            .thenReturn(Optional.of(existingKyc));
        when(blockRepository.findByPartyIdAndTypeAndStatus(partyId, BlockType.KYT, BlockStatus.ACTIVE))
            .thenReturn(Optional.of(existingKyt));
        when(blockRepository.findByPartyIdAndTypeAndStatus(partyId, BlockType.STATIC_DATA, BlockStatus.ACTIVE))
            .thenReturn(Optional.of(existingStaticData));
        when(blockRepository.findByPartyIdAndTypeAndStatus(partyId, BlockType.DOCUMENT, BlockStatus.ACTIVE))
            .thenReturn(Optional.of(existingDocument));

        // Next versions will be 2
        when(blockRepository.findMaxBlockVersionByPartyIdAndType(eq(partyId), any())).thenReturn(1);

        // When
        service.provisionFullBlockSet(partyId);

        // Then
        // Verify archiving: 4 saves for archiving + 4 saves for new blocks = 8 total
        verify(blockRepository, times(8)).save(blockCaptor.capture());

        // Verify 4 archived events + 4 provisioned events
        verify(eventPublisher, times(4)).publishEvent(archivedEventCaptor.capture());
        verify(eventPublisher, times(4)).publishEvent(provisionedEventCaptor.capture());

        // Verify archived blocks
        assertThat(existingKyc.isArchived()).isTrue();
        assertThat(existingKyt.isArchived()).isTrue();
        assertThat(existingStaticData.isArchived()).isTrue();
        assertThat(existingDocument.isArchived()).isTrue();

        // Verify new blocks created with version 2
        var newBlocks = blockCaptor.getAllValues().subList(4, 8); // Last 4 saves
        assertThat(newBlocks).hasSize(4);
        assertThat(newBlocks).allMatch(block -> block.getBlockVersion() == 2);
        assertThat(newBlocks).allMatch(Block::isActive);
    }

    @Test
    @DisplayName("provisionPartialBlockSet - Should only archive and create STATIC_DATA and DOCUMENT")
    void provisionPartialBlockSet_existingBlocks_onlyRefreshesPartialSet() {
        // Given
        UUID partyId = UUID.randomUUID();

        // Existing active blocks
        Block existingStaticData = Block.createActive(partyId, BlockType.STATIC_DATA, 2, "{}");
        Block existingDocument = Block.createActive(partyId, BlockType.DOCUMENT, 1, "{}");

        when(blockRepository.findByPartyIdAndTypeAndStatus(partyId, BlockType.STATIC_DATA, BlockStatus.ACTIVE))
            .thenReturn(Optional.of(existingStaticData));
        when(blockRepository.findByPartyIdAndTypeAndStatus(partyId, BlockType.DOCUMENT, BlockStatus.ACTIVE))
            .thenReturn(Optional.of(existingDocument));

        // Next versions
        when(blockRepository.findMaxBlockVersionByPartyIdAndType(partyId, BlockType.STATIC_DATA)).thenReturn(2);
        when(blockRepository.findMaxBlockVersionByPartyIdAndType(partyId, BlockType.DOCUMENT)).thenReturn(1);

        // When
        service.provisionPartialBlockSet(partyId);

        // Then
        // Verify only 4 saves: 2 for archiving + 2 for new blocks
        verify(blockRepository, times(4)).save(blockCaptor.capture());

        // Verify 2 archived events + 2 provisioned events
        verify(eventPublisher, times(2)).publishEvent(archivedEventCaptor.capture());
        verify(eventPublisher, times(2)).publishEvent(provisionedEventCaptor.capture());

        // Verify archived blocks
        assertThat(existingStaticData.isArchived()).isTrue();
        assertThat(existingDocument.isArchived()).isTrue();

        // Verify new blocks
        var newBlocks = blockCaptor.getAllValues().subList(2, 4); // Last 2 saves
        assertThat(newBlocks).hasSize(2);
        assertThat(newBlocks).extracting(Block::getType)
            .containsExactlyInAnyOrder(BlockType.STATIC_DATA, BlockType.DOCUMENT);
        assertThat(newBlocks).allMatch(Block::isActive);

        // Verify versions incremented
        var staticDataBlock = newBlocks.stream()
            .filter(b -> b.getType() == BlockType.STATIC_DATA)
            .findFirst().orElseThrow();
        assertThat(staticDataBlock.getBlockVersion()).isEqualTo(3);

        var documentBlock = newBlocks.stream()
            .filter(b -> b.getType() == BlockType.DOCUMENT)
            .findFirst().orElseThrow();
        assertThat(documentBlock.getBlockVersion()).isEqualTo(2);

        // Verify KYC and KYT were NOT touched
        verify(blockRepository, never()).findByPartyIdAndTypeAndStatus(partyId, BlockType.KYC, BlockStatus.ACTIVE);
        verify(blockRepository, never()).findByPartyIdAndTypeAndStatus(partyId, BlockType.KYT, BlockStatus.ACTIVE);
    }

    @Test
    @DisplayName("provisionInitialBlocks - Should throw when partyId is null")
    void provisionInitialBlocks_nullPartyId_throws() {
        // When / Then
        assertThatThrownBy(() -> service.provisionInitialBlocks(null))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("partyId cannot be null");
    }

    @Test
    @DisplayName("provisionFullBlockSet - Should handle empty active blocks gracefully")
    void provisionFullBlockSet_noExistingBlocks_createsNew() {
        // Given
        UUID partyId = UUID.randomUUID();
        when(blockRepository.findByPartyIdAndTypeAndStatus(eq(partyId), any(), eq(BlockStatus.ACTIVE)))
            .thenReturn(Optional.empty());
        when(blockRepository.findMaxBlockVersionByPartyIdAndType(eq(partyId), any())).thenReturn(null);

        // When
        service.provisionFullBlockSet(partyId);

        // Then
        verify(blockRepository, times(4)).save(any());
        verify(eventPublisher, times(4)).publishEvent(any(BlockProvisionedEvent.class));
        verify(eventPublisher, never()).publishEvent(any(BlockArchivedEvent.class));
    }
}
