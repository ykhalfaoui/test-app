package com.remediation.member;

import com.remediation.TestBase;
import com.remediation.member.api.FamilyCompositionCompletedEvent;
import com.remediation.member.api.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.sharedkernel.outbox.OutboxEntry;
import com.remediation.sharedkernel.outbox.OutboxRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import java.util.concurrent.TimeUnit;

/**
 * Tests for Member composition logic.
 */
class MemberCompositionTest extends TestBase {

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Autowired
    private OutboxRepository outboxRepository;

    @Test
    void shouldIdentifyMultipleFamilyMembers() {
        // Given
        ReviewInstanceStartedEvent event = new ReviewInstanceStartedEvent(
            TraceId.create(),
            ReviewId.create(),
            CustomerId.of("CUST-001"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - should publish member identified events
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> {
            var outboxEntries = outboxRepository.findAll();
            long memberEventCount = outboxEntries.stream()
                .filter(entry -> entry.getEventType().contains("ReviewMemberIdentifiedEvent"))
                .count();

            // Should find principal + relations (3-5 members)
            assertThat(memberEventCount).isBetween(3L, 6L);
        });
    }

    @Test
    void shouldPublishFamilyCompositionCompleted() {
        // Given
        ReviewInstanceStartedEvent event = new ReviewInstanceStartedEvent(
            TraceId.create(),
            ReviewId.create(),
            CustomerId.of("CUST-002"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - should publish completion event
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> {
            var completionEvents = outboxRepository.findAll().stream()
                .filter(entry -> entry.getEventType().contains("FamilyCompositionCompletedEvent"))
                .toList();

            assertThat(completionEvents).isNotEmpty();
        });
    }

    @Test
    void shouldIncludePrincipalCustomerAsFirstMember() {
        // Given
        CustomerId principalCustomer = CustomerId.of("CUST-PRINCIPAL");
        ReviewInstanceStartedEvent event = new ReviewInstanceStartedEvent(
            TraceId.create(),
            ReviewId.create(),
            principalCustomer,
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - first member event should be for principal customer
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> {
            var memberEvents = outboxRepository.findAll().stream()
                .filter(entry -> entry.getEventType().contains("ReviewMemberIdentifiedEvent"))
                .toList();

            assertThat(memberEvents).isNotEmpty();
            // Principal customer should be in the members (payload contains customerId)
            boolean hasPrincipal = memberEvents.stream()
                .anyMatch(entry -> entry.getPayload().contains(principalCustomer.value()));
            assertThat(hasPrincipal).isTrue();
        });
    }
}
