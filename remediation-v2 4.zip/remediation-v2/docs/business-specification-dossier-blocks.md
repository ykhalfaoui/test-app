# Spécification Métier : Gestion des Dossiers & Blocs d'Information Client

## 1. Contexte & Objectif

Nous devons suivre et gérer différentes "briques" d'information (des **"blocs"**) pour chaque client tout au long de sa relation avec nous.

Un client peut avoir :
- Un bloc pour son **KYC** (Know Your Customer)
- Un bloc pour son **KYT** (Know Your Transaction)
- Un bloc pour ses **Données Statiques** (nom, adresse, etc.)
- Un bloc pour ses **Documents**

**Objectif** : S'assurer que nous créons le bon ensemble de blocs au bon moment et que nous gardons un historique complet et auditable de ces informations.

## 2. Le Concept Central : Le "Dossier"

Chaque client (Party) possède des blocs d'information directement attachés à lui.

```
Client (Party)
    ├── KYC Block (actif)
    ├── KYT Block (actif)
    ├── Static Data Block (actif)
    ├── Document Block (actif)
    └── Blocs Archivés
        ├── KYC Block v1 (archivé)
        ├── KYC Block v2 (archivé)
        └── Static Data Block v1 (archivé)
```

**Note** : Il n'y a pas d'entité "Dossier" séparée. Les blocs sont directement liés au client (Party).

## 3. Règle Fondamentale : Le Versioning (Archivage)

### C'est la règle la plus importante du système

#### Règle 1 : Un Seul Bloc Actif Par Type
Par exemple :
- **Un seul** KYC actif
- **Un seul** bloc Document actif
- **Un seul** bloc Static Data actif
- **Un seul** KYT actif

#### Règle 2 : Historique Complet
**On ne supprime JAMAIS un bloc.**

Tous les blocs restent en base pour l'audit et l'historique.

#### Règle 3 : Archivage Automatique
Lorsqu'un nouveau bloc (ex: un nouveau KYC) doit être ajouté au dossier :
1. L'**ancien bloc KYC actif** doit être automatiquement basculé en statut **"Archivé"**
2. Le **nouveau bloc** devient alors le seul **"Actif"**

**Garantie** :
- ✅ Information la plus à jour (les blocs actifs)
- ✅ Historique complet de toutes les versions précédentes (les blocs archivés)

### Exemples d'Archivage

#### Exemple 1 : Remplacement KYC
```
État Initial :
├── KYC Block v1 (ACTIF)
└── Static Data Block (ACTIF)

Action : Créer nouveau KYC
↓
État Final :
├── KYC Block v1 (ARCHIVÉ) ← automatiquement archivé
├── KYC Block v2 (ACTIF)   ← nouveau bloc actif
└── Static Data Block (ACTIF) ← inchangé
```

#### Exemple 2 : Remplacement Multiple
```
État Initial :
├── KYC Block v2 (ACTIF)
├── KYT Block v1 (ACTIF)
├── Static Data Block v1 (ACTIF)
└── Document Block v1 (ACTIF)

Action : Créer jeu complet de nouveaux blocs
↓
État Final :
├── KYC Block v2 (ARCHIVÉ)      ← archivé
├── KYC Block v3 (ACTIF)        ← nouveau
├── KYT Block v1 (ARCHIVÉ)      ← archivé
├── KYT Block v2 (ACTIF)        ← nouveau
├── Static Data Block v1 (ARCHIVÉ) ← archivé
├── Static Data Block v2 (ACTIF)   ← nouveau
├── Document Block v1 (ARCHIVÉ)    ← archivé
└── Document Block v2 (ACTIF)      ← nouveau
```

## 4. Cas de Création de Blocs

Il y a **deux moments clés** où le système doit créer des blocs.

### Cas A : L'Onboarding (Arrivée d'un nouveau client)

**Déclencheur** : Un nouveau client (Party) est validé dans le système.

**Action Requise** :

Générer et ajouter le **jeu complet de blocs initiaux** pour ce client :
- ✅ KYC BLOCK
- ✅ KYT BLOCK
- ✅ STATIC DATA BLOCK
- ✅ DOCUMENT BLOCK

**Note** : Puisque c'est un nouveau client, il n'y a rien à archiver.

**Exemple** :
```
Nouveau Client : "Jean Dupont" (Party ID: 12345)
↓
Action Système :
Créer 4 blocs ACTIFS liés au Party 12345 :
├── KYC Block (ID: KYC-001, Status: ACTIF)
├── KYT Block (ID: KYT-001, Status: ACTIF)
├── Static Data Block (ID: SD-001, Status: ACTIF)
└── Document Block (ID: DOC-001, Status: ACTIF)
```

### Cas B : Une Revue de Remédiation (Mise à jour d'un client existant)

**Déclencheur** : Un **"Membre de Revue" (ReviewMember)** est créé pour un client existant.

**Action Requise** :

La logique dépend du **type de membre** :

#### B1. Si le membre est un "Acteur Principal"

Le système doit générer un **nouveau jeu COMPLET de blocs** :
- ✅ KYC BLOCK (nouveau)
- ✅ KYT BLOCK (nouveau)
- ✅ STATIC DATA BLOCK (nouveau)
- ✅ DOCUMENT BLOCK (nouveau)

**La Règle d'Archivage (Règle 3) s'applique** :
- Tous les anciens blocs actifs de ces types doivent être archivés

**Exemple** :
```
Client Existant : "Marie Martin" (Party ID: 67890)
Dossier Actuel :
├── KYC Block v1 (ACTIF)
├── KYT Block v1 (ACTIF)
├── Static Data Block v1 (ACTIF)
└── Document Block v1 (ACTIF)

Déclencheur : ReviewMember créé avec type="ACTEUR_PRINCIPAL"
↓
Action Système :
1. Archiver tous les blocs actifs :
   ├── KYC Block v1 (ACTIF → ARCHIVÉ)
   ├── KYT Block v1 (ACTIF → ARCHIVÉ)
   ├── Static Data Block v1 (ACTIF → ARCHIVÉ)
   └── Document Block v1 (ACTIF → ARCHIVÉ)

2. Créer 4 nouveaux blocs ACTIFS :
   ├── KYC Block v2 (ACTIF)
   ├── KYT Block v2 (ACTIF)
   ├── Static Data Block v2 (ACTIF)
   └── Document Block v2 (ACTIF)

État Final :
├── KYC Block v1 (ARCHIVÉ)
├── KYC Block v2 (ACTIF)
├── KYT Block v1 (ARCHIVÉ)
├── KYT Block v2 (ACTIF)
├── Static Data Block v1 (ARCHIVÉ)
├── Static Data Block v2 (ACTIF)
├── Document Block v1 (ARCHIVÉ)
└── Document Block v2 (ACTIF)
```

#### B2. Si le membre est un "Membre Secondaire" (relation)

Le système ne doit générer qu'un **jeu PARTIEL de nouveaux blocs** :
- ✅ STATIC DATA BLOCK (nouveau)
- ✅ DOCUMENT BLOCK (nouveau)

**La Règle d'Archivage (Règle 3) s'applique UNIQUEMENT** :
- Pour les anciens blocs STATIC DATA et DOCUMENT actifs
- Les blocs KYC et KYT actifs existants **ne sont PAS touchés**

**Exemple** :
```
Client Existant : "Pierre Durand" (Party ID: 11111)
Dossier Actuel :
├── KYC Block v2 (ACTIF)
├── KYT Block v1 (ACTIF)
├── Static Data Block v1 (ACTIF)
└── Document Block v1 (ACTIF)

Déclencheur : ReviewMember créé avec type="MEMBRE_SECONDAIRE"
↓
Action Système :
1. Archiver SEULEMENT les blocs Static Data et Document :
   ├── Static Data Block v1 (ACTIF → ARCHIVÉ)
   └── Document Block v1 (ACTIF → ARCHIVÉ)

2. Créer SEULEMENT 2 nouveaux blocs ACTIFS :
   ├── Static Data Block v2 (ACTIF)
   └── Document Block v2 (ACTIF)

3. NE PAS toucher aux blocs KYC et KYT

État Final :
├── KYC Block v2 (ACTIF)           ← INCHANGÉ
├── KYT Block v1 (ACTIF)           ← INCHANGÉ
├── Static Data Block v1 (ARCHIVÉ)
├── Static Data Block v2 (ACTIF)
├── Document Block v1 (ARCHIVÉ)
└── Document Block v2 (ACTIF)
```

## 5. Résumé des Règles

### Tableau Récapitulatif

| Événement | Type Membre | Blocs à Créer | Blocs à Archiver |
|-----------|-------------|---------------|------------------|
| **Onboarding** | N/A | KYC + KYT + STATIC DATA + DOCUMENT | Aucun (nouveau dossier) |
| **Revue Remédiation** | Acteur Principal | KYC + KYT + STATIC DATA + DOCUMENT | Tous les blocs actifs de ces types |
| **Revue Remédiation** | Membre Secondaire | STATIC DATA + DOCUMENT | Seulement les blocs STATIC DATA et DOCUMENT actifs |

### Règles de Versioning

| Règle | Description |
|-------|-------------|
| **Règle 1** | Un seul bloc actif par type à tout moment |
| **Règle 2** | Jamais de suppression de blocs (historique complet) |
| **Règle 3** | Archivage automatique lors de l'ajout d'un nouveau bloc du même type |

## 6. Exemples Complets de Scénarios

### Scénario 1 : Onboarding Simple

```
Jour 1 : Nouveau client "Alice Leblanc" (Party ID: P-001)
└── Système crée Dossier D-001
    ├── KYC Block (ID: KYC-001, Version: 1, Status: ACTIF)
    ├── KYT Block (ID: KYT-001, Version: 1, Status: ACTIF)
    ├── Static Data Block (ID: SD-001, Version: 1, Status: ACTIF)
    └── Document Block (ID: DOC-001, Version: 1, Status: ACTIF)
```

### Scénario 2 : Revue Complète (Acteur Principal)

```
Jour 1 : Client existant "Bob Martin" (Party ID: P-002)
Dossier D-002 actuel :
├── KYC Block v1 (ACTIF)
├── KYT Block v1 (ACTIF)
├── Static Data Block v1 (ACTIF)
└── Document Block v1 (ACTIF)

Jour 30 : ReviewMember créé avec type="ACTEUR_PRINCIPAL"
└── Système met à jour Dossier D-002 :
    ├── KYC Block v1 (ARCHIVÉ)
    ├── KYC Block v2 (ACTIF) ← nouveau
    ├── KYT Block v1 (ARCHIVÉ)
    ├── KYT Block v2 (ACTIF) ← nouveau
    ├── Static Data Block v1 (ARCHIVÉ)
    ├── Static Data Block v2 (ACTIF) ← nouveau
    ├── Document Block v1 (ARCHIVÉ)
    └── Document Block v2 (ACTIF) ← nouveau

Jour 90 : Nouvelle ReviewMember créé avec type="ACTEUR_PRINCIPAL"
└── Système met à jour Dossier D-002 :
    ├── KYC Block v1 (ARCHIVÉ)
    ├── KYC Block v2 (ARCHIVÉ)
    ├── KYC Block v3 (ACTIF) ← nouveau
    ├── KYT Block v1 (ARCHIVÉ)
    ├── KYT Block v2 (ARCHIVÉ)
    ├── KYT Block v3 (ACTIF) ← nouveau
    ├── Static Data Block v1 (ARCHIVÉ)
    ├── Static Data Block v2 (ARCHIVÉ)
    ├── Static Data Block v3 (ACTIF) ← nouveau
    ├── Document Block v1 (ARCHIVÉ)
    ├── Document Block v2 (ARCHIVÉ)
    └── Document Block v3 (ACTIF) ← nouveau
```

### Scénario 3 : Revue Partielle (Membre Secondaire)

```
Jour 1 : Client existant "Claire Dubois" (Party ID: P-003)
Dossier D-003 actuel :
├── KYC Block v2 (ACTIF)
├── KYT Block v1 (ACTIF)
├── Static Data Block v3 (ACTIF)
└── Document Block v2 (ACTIF)

Jour 15 : ReviewMember créé avec type="MEMBRE_SECONDAIRE"
└── Système met à jour Dossier D-003 :
    ├── KYC Block v2 (ACTIF)           ← INCHANGÉ
    ├── KYT Block v1 (ACTIF)           ← INCHANGÉ
    ├── Static Data Block v3 (ARCHIVÉ)
    ├── Static Data Block v4 (ACTIF)   ← nouveau
    ├── Document Block v2 (ARCHIVÉ)
    └── Document Block v3 (ACTIF)      ← nouveau
```

### Scénario 4 : Mix Acteur Principal + Membre Secondaire

```
Jour 1 : Client "David Laurent" (Party ID: P-004)
Dossier D-004 initial :
├── KYC Block v1 (ACTIF)
├── KYT Block v1 (ACTIF)
├── Static Data Block v1 (ACTIF)
└── Document Block v1 (ACTIF)

Jour 30 : ReviewMember #1 créé avec type="MEMBRE_SECONDAIRE"
└── Dossier D-004 :
    ├── KYC Block v1 (ACTIF)           ← INCHANGÉ
    ├── KYT Block v1 (ACTIF)           ← INCHANGÉ
    ├── Static Data Block v1 (ARCHIVÉ)
    ├── Static Data Block v2 (ACTIF)   ← nouveau
    ├── Document Block v1 (ARCHIVÉ)
    └── Document Block v2 (ACTIF)      ← nouveau

Jour 60 : ReviewMember #2 créé avec type="ACTEUR_PRINCIPAL"
└── Dossier D-004 :
    ├── KYC Block v1 (ARCHIVÉ)
    ├── KYC Block v2 (ACTIF)           ← nouveau
    ├── KYT Block v1 (ARCHIVÉ)
    ├── KYT Block v2 (ACTIF)           ← nouveau
    ├── Static Data Block v1 (ARCHIVÉ)
    ├── Static Data Block v2 (ARCHIVÉ)
    ├── Static Data Block v3 (ACTIF)   ← nouveau
    ├── Document Block v1 (ARCHIVÉ)
    ├── Document Block v2 (ARCHIVÉ)
    └── Document Block v3 (ACTIF)      ← nouveau

Jour 90 : ReviewMember #3 créé avec type="MEMBRE_SECONDAIRE"
└── Dossier D-004 :
    ├── KYC Block v1 (ARCHIVÉ)
    ├── KYC Block v2 (ACTIF)           ← INCHANGÉ
    ├── KYT Block v1 (ARCHIVÉ)
    ├── KYT Block v2 (ACTIF)           ← INCHANGÉ
    ├── Static Data Block v1 (ARCHIVÉ)
    ├── Static Data Block v2 (ARCHIVÉ)
    ├── Static Data Block v3 (ARCHIVÉ)
    ├── Static Data Block v4 (ACTIF)   ← nouveau
    ├── Document Block v1 (ARCHIVÉ)
    ├── Document Block v2 (ARCHIVÉ)
    ├── Document Block v3 (ARCHIVÉ)
    └── Document Block v4 (ACTIF)      ← nouveau
```

## 7. Questions Fréquentes

### Q1 : Que se passe-t-il si on crée deux ReviewMembers en même temps ?

**Réponse** : Chaque ReviewMember déclenche son propre processus de création de blocs. Si deux ReviewMembers de type "ACTEUR_PRINCIPAL" sont créés simultanément, le système doit :
1. Traiter le premier : archiver blocs actifs, créer nouveaux blocs
2. Traiter le second : archiver les blocs créés à l'étape 1, créer de nouveaux blocs

Résultat : Deux jeux de blocs archivés, un seul jeu actif (le plus récent).

### Q2 : Peut-on archiver manuellement un bloc ?

**Réponse** : Non. L'archivage est **automatique** et déclenché uniquement par la création d'un nouveau bloc du même type. Cela garantit la cohérence et l'auditabilité.

### Q3 : Peut-on réactiver un bloc archivé ?

**Réponse** : Non. Une fois archivé, un bloc reste archivé. Pour "revenir" à un état antérieur, il faut créer un nouveau bloc avec les données de l'ancien bloc archivé.

### Q4 : Combien de temps conserve-t-on les blocs archivés ?

**Réponse** : Pour toujours (ou selon politique de rétention légale). Les blocs archivés sont critiques pour l'audit et la conformité réglementaire.

### Q5 : Que se passe-t-il si la création d'un nouveau bloc échoue ?

**Réponse** : L'archivage et la création du nouveau bloc doivent être **atomiques** (transaction). Si la création échoue, l'archivage doit être annulé. Les blocs existants restent ACTIFS.

## 8. Contraintes & Invariants du Système

### Invariants (Toujours Vrais)

1. **Unicité Active** : Pour un dossier donné, il existe au maximum 1 bloc ACTIF par type
2. **Complétude Initiale** : Un dossier créé lors de l'onboarding contient exactement 4 blocs ACTIFS (KYC, KYT, STATIC DATA, DOCUMENT)
3. **Historique Immuable** : Un bloc archivé ne peut jamais redevenir actif
4. **Pas de Suppression** : Un bloc créé ne peut jamais être supprimé (soft-delete uniquement si besoin)

### Contraintes Temporelles

1. **Ordre d'Archivage** : L'archivage doit se faire AVANT la création du nouveau bloc
2. **Atomicité** : Archivage + Création = Transaction unique (tout ou rien)
3. **Timestamp** : Chaque bloc doit avoir un timestamp de création et d'archivage

## 9. Glossaire

| Terme | Définition |
|-------|------------|
| **Party** | Client (personne physique ou morale) |
| **Dossier** | Container logique regroupant tous les blocs d'un client |
| **Bloc** | Unité d'information versionnée (KYC, KYT, Static Data, Document) |
| **Actif** | Statut d'un bloc indiquant qu'il représente l'information courante |
| **Archivé** | Statut d'un bloc indiquant qu'il représente une version historique |
| **ReviewMember** | Entité créée lors d'une revue de remédiation pour un client |
| **Acteur Principal** | Type de ReviewMember déclenchant une revue complète (4 blocs) |
| **Membre Secondaire** | Type de ReviewMember déclenchant une revue partielle (2 blocs) |
| **Onboarding** | Processus d'intégration d'un nouveau client dans le système |
| **Versioning** | Mécanisme permettant de conserver l'historique des blocs via l'archivage |
