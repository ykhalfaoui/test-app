# Inbox Multi-Event-Type Architecture

## Overview

This document describes the architecture for processing multiple Kafka event types (HIT, PARTY, DDR) with dedicated ThreadPools to prevent bottlenecks and cross-contamination.

## Problem Statement

**Initial Problem**: Head-of-line blocking where failed messages block subsequent messages during retries.

**New Challenge**: Multiple event types with different characteristics:
- **HIT events**: Medium volume (50-200/sec), high priority, complex processing
- **PARTY events**: Low volume (10-50/sec), medium priority, simple updates
- **DDR events**: High volume (200-1000/sec), lower priority, batch-friendly

**Risk**: Without isolation, high-volume DDR events could monopolize ThreadPool resources and starve critical HIT processing.

## Solution Architecture

### 1. Event Type Field

Each inbox entry includes an `event_type` field to identify the message type:

```java
@Column(name = "event_type", length = 50, nullable = false)
private String eventType;
```

Possible values: `"HIT"`, `"PARTY"`, `"DDR"`

### 2. Dedicated ThreadPools

Each event type gets its own ThreadPoolTaskExecutor with independent sizing:

```java
@Configuration
public class AsyncConfig {

    @Bean("hitProcessorExecutor")
    public Executor hitProcessorExecutor() {
        // Core: 5, Max: 20, Queue: 200
    }

    @Bean("partyProcessorExecutor")
    public Executor partyProcessorExecutor() {
        // Core: 3, Max: 10, Queue: 100
    }

    @Bean("ddrProcessorExecutor")
    public Executor ddrProcessorExecutor() {
        // Core: 10, Max: 30, Queue: 500
    }
}
```

**Thread Budget** (Spring Boot Tomcat embedded with ~200 default threads):

**IMPORTANT**: Application serves both HTTP API traffic and Kafka event processing!

Allocation breakdown:
- **HTTP traffic**: 100 threads reserved (API endpoints for UI, external integrations)
- **Kafka consumers**: 10 threads reserved (consumer threads + overhead)
- **Async processing**: 45 threads max
- **Buffer**: 45 threads remaining (safety margin)

Async ThreadPool sizing (conservative):
- HIT ThreadPool: 3-10 threads (core=3, max=10, queue=100)
- PARTY ThreadPool: 2-5 threads (core=2, max=5, queue=50)
- DDR ThreadPool: 5-30 threads (core=5, max=30, queue=300)
- **Total async threads**: 10 cores always active, 45 max during bursts

### 3. Dynamic Routing

The `InboxProcessor` routes events to the appropriate ThreadPool based on event type:

```java
@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
public void onInboxEntryReceived(InboxEntryReceivedEvent event) {
    InboxEntry entry = inboxRepository.findById(event.eventId()).orElse(null);

    switch (entry.getEventType()) {
        case "HIT" -> processHitEntryAsync(event.eventId());
        case "PARTY" -> processPartyEntryAsync(event.eventId());
        case "DDR" -> processDdrEntryAsync(event.eventId());
    }
}

@Async("hitProcessorExecutor")
public void processHitEntryAsync(UUID eventId) {
    processEntry(eventId);
}

@Async("partyProcessorExecutor")
public void processPartyEntryAsync(UUID eventId) {
    processEntry(eventId);
}

@Async("ddrProcessorExecutor")
public void processDdrEntryAsync(UUID eventId) {
    processEntry(eventId);
}
```

### 4. Independent Backpressure

Each ThreadPool uses `CallerRunsPolicy` for rejection handling:

```java
executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
```

**Behavior**: When a pool is full, the Kafka consumer thread executes the task directly, naturally slowing consumption for that specific topic without affecting other event types.

**Example Scenario**:
- DDR queue fills up (500 messages + 30 active threads)
- Next DDR message triggers CallerRunsPolicy
- DDR Kafka consumer thread processes the message directly
- DDR consumption slows down naturally
- **HIT and PARTY processing continues unaffected** ✅

## Processing Flow

### 1. Message Arrival (Fast Path)

```
Kafka Message → Consumer
  ↓
Check duplicate (idempotency)
  ↓
Save to inbox with event_type
  ↓
Publish InboxEntryReceivedEvent
  ↓
ACK Kafka (< 50ms)
```

### 2. Immediate Async Processing

```
InboxEntryReceivedEvent
  ↓
Load entry to determine event_type
  ↓
Route to appropriate ThreadPool:
  - HIT → hitProcessorExecutor
  - PARTY → partyProcessorExecutor
  - DDR → ddrProcessorExecutor
  ↓
Process in dedicated thread
  ↓
On success: Mark PROCESSED
On failure: Schedule retry with exponential backoff
```

### 3. Retry Processing (Scheduled)

Every 5 seconds, check for entries ready for retry:

```sql
SELECT * FROM inbox
WHERE status = 'RECEIVED'
  AND retry_count > 0
  AND next_retry_at <= NOW()
ORDER BY next_retry_at ASC
LIMIT 100
```

For each entry, publish `InboxEntryReceivedEvent` → routes to correct pool

### 4. Orphan Recovery (Scheduled)

Every 30 seconds, check for entries stuck in RECEIVED:

```sql
SELECT * FROM inbox
WHERE status = 'RECEIVED'
  AND retry_count = 0
  AND received_at < (NOW() - 1 minute)
ORDER BY received_at ASC
LIMIT 50
```

For each orphan, publish `InboxEntryReceivedEvent` → routes to correct pool

## Benefits

### 1. No Cross-Contamination
- DDR volume spikes don't affect HIT processing
- Each event type has guaranteed minimum capacity (core threads)
- Failed DDR retries don't block HIT processing

### 2. Independent Scaling
- Adjust thread counts per event type based on production metrics
- Scale DDR pool for high volume without overprovisioning HIT pool
- Configuration via `application.yml` without code changes

### 3. Isolated Backpressure
- CallerRunsPolicy slows consumption per topic independently
- DDR overload doesn't cause HIT message delays
- Natural flow control without external throttling

### 4. Resource Efficiency
- Total thread budget fits comfortably in Tomcat embedded (~63/200 threads)
- Core threads always ready for immediate processing
- Idle threads time out after 60 seconds (except core threads)

## Configuration

### application.yml

```yaml
inbox:
  processor:
    max-retries: 5
    retry-batch-size: 100
    orphan-batch-size: 50
    retry-delay: 5000
    retry-initial-delay: 10000
    orphan-delay: 30000
    orphan-initial-delay: 60000
    metrics-delay: 10000
    metrics-initial-delay: 30000

    # Event-type specific ThreadPool configuration
    # Conservative sizing to preserve threads for HTTP traffic (100+ threads reserved)
    hit:
      core-pool-size: 3    # Medium priority, always ready
      max-pool-size: 10    # Burst capacity
      queue-capacity: 100  # Buffer for spikes
    party:
      core-pool-size: 2    # Low volume, minimal footprint
      max-pool-size: 5     # Small burst capacity
      queue-capacity: 50   # Small buffer
    ddr:
      core-pool-size: 5    # High volume, controlled base
      max-pool-size: 30    # Large burst capacity
      queue-capacity: 300  # Large buffer for batch processing
```

### Tuning Guidelines

**HIT Events** (Medium volume, high priority):
- Core: 3 threads → Always ready, minimal footprint
- Max: 10 threads → Sufficient burst capacity
- Queue: 100 → Buffer traffic spikes
- Strategy: Conservative sizing preserves HTTP threads

**PARTY Events** (Low volume, simple):
- Core: 2 threads → Minimal base for low volume
- Max: 5 threads → Small burst capacity adequate
- Queue: 50 → Small buffer sufficient

**DDR Events** (High volume, batch-friendly):
- Core: 5 threads → Controlled base capacity
- Max: 30 threads → Large burst capacity for volume
- Queue: 300 → Large buffer absorbs spikes
- Strategy: CallerRunsPolicy prevents monopolizing resources during sustained overload

## Monitoring

The `InboxProcessor` logs metrics every 10 seconds:

```
Inbox metrics - RECEIVED: 45, PROCESSED: 12845, DLQ: 3
```

**Alerts**:
- DLQ > 100: Manual intervention required
- RECEIVED > 1000: System overload warning

**ThreadPool Metrics** (via Spring Actuator):
- `executor.active` - Currently executing tasks
- `executor.pool.size` - Current pool size
- `executor.queued` - Tasks in queue
- `executor.completed` - Total completed tasks

Monitor per executor: `hitProcessorExecutor`, `partyProcessorExecutor`, `ddrProcessorExecutor`

## Retry Strategy

**Exponential Backoff**:
- Retry 1: 1 second
- Retry 2: 2 seconds
- Retry 3: 4 seconds
- Retry 4: 8 seconds
- Retry 5: 16 seconds
- After 5 retries: Move to DLQ

**Status Transitions**:
```
RECEIVED → (processing) → PROCESSED ✅
         ↓ (error)
         RECEIVED (retry_count++, next_retry_at set)
         ↓ (after max retries)
         DLQ ❌
```

## Database Schema

```sql
CREATE TABLE inbox (
    event_id UUID PRIMARY KEY,
    status VARCHAR(20) NOT NULL,
    payload TEXT NOT NULL,
    source VARCHAR(100),
    trace_id VARCHAR(100),
    event_type VARCHAR(50) NOT NULL,  -- NEW: "HIT", "PARTY", "DDR"
    retry_count INT NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP,
    error_message VARCHAR(2000),
    received_at TIMESTAMP NOT NULL,
    last_updated_at TIMESTAMP NOT NULL,
    version BIGINT
);

CREATE INDEX idx_inbox_status ON inbox(status);
CREATE INDEX idx_inbox_received_at ON inbox(received_at);
CREATE INDEX idx_inbox_event_type ON inbox(event_type);  -- NEW
CREATE INDEX idx_inbox_retry ON inbox(status, retry_count, next_retry_at);  -- NEW
```

## Future Extensions

### 1. Additional Event Types
To add a new event type (e.g., "AUDIT"):

1. Add new ThreadPool to `AsyncConfig`:
   ```java
   @Bean("auditProcessorExecutor")
   public Executor auditProcessorExecutor(...) { ... }
   ```

2. Add routing case in `InboxProcessor`:
   ```java
   case "AUDIT" -> processAuditEntryAsync(event.eventId());
   ```

3. Create async method:
   ```java
   @Async("auditProcessorExecutor")
   public void processAuditEntryAsync(UUID eventId) {
       processEntry(eventId);
   }
   ```

4. Add configuration in `application.yml`:
   ```yaml
   inbox:
     processor:
       audit:
         core-pool-size: 2
         max-pool-size: 5
         queue-capacity: 50
   ```

### 2. Priority-Based Processing
Implement priority queues within each ThreadPool for critical vs. normal messages.

### 3. Dynamic Thread Scaling
Use Micrometer metrics to auto-adjust thread pool sizes based on load patterns.

### 4. Circuit Breaker
Add Resilience4j circuit breaker per event type to fast-fail during downstream outages.

## Related Documentation

- [Inbox/Outbox Pattern](./04-outbox-inbox-pattern.puml)
- [End-to-End Sequence](./01-end-to-end-sequence.puml)
- [Architecture Components](./05-architecture-components.puml)
