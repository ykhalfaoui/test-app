# Implémentation : Gestion des Blocs d'Information Client

## Vue d'Ensemble

Cette implémentation réalise la spécification métier définie dans `business-specification-dossier-blocks.md`.

**Objectif** : Gérer les blocs d'information versionnés (KYC, KYT, STATIC_DATA, DOCUMENT) pour chaque client (Party) avec historique complet et archivage automatique.

## Architecture

### Entités & Enums

#### `BlockType` enum
```java
public enum BlockType {
    KYC,           // Know Your Customer
    KYT,           // Know Your Transaction
    STATIC_DATA,   // Static customer data
    DOCUMENT       // Document references
}
```

#### `BlockStatus` enum
```java
public enum BlockStatus {
    ACTIVE,    // Current version
    ARCHIVED   // Historical version
}
```

#### `Block` entity
```java
@Entity
public class Block {
    private UUID id;
    private UUID partyId;
    private BlockType type;
    private Integer blockVersion;      // Business version (1, 2, 3...)
    private Long entityVersion;        // Hibernate @Version (optimistic locking)
    private BlockStatus status;
    private String payload;            // JSON data
    private Instant createdAt;
    private Instant archivedAt;
}
```

**Points clés** :
- `blockVersion` : Version métier pour l'utilisateur (1, 2, 3...)
- `entityVersion` : Version technique Hibernate (gestion concurrence)
- **Séparation claire** pour éviter confusion

### Repository

`BlockRepository` fournit des requêtes pour :
- Trouver bloc actif : `findByPartyIdAndTypeAndStatus()`
- Calculer prochaine version : `findMaxBlockVersionByPartyIdAndType()`
- Historique complet : `findAllByPartyIdAndTypeOrderByBlockVersionDesc()`
- Vérifications : `existsByPartyIdAndTypeAndStatus()`, `countByPartyIdAndStatus()`

### Service de Provisioning

`BlockProvisioningService` implémente 3 méthodes principales :

#### 1. `provisionInitialBlocks(UUID partyId)`
**Cas A : Onboarding**
- Crée 4 blocs : KYC, KYT, STATIC_DATA, DOCUMENT
- Tous version 1, tous ACTIVE
- Pas d'archivage (nouveau client)

#### 2. `provisionFullBlockSet(UUID partyId)`
**Cas B1 : Review avec Acteur Principal**
- Archive 4 blocs actifs existants
- Crée 4 nouveaux blocs (versions incrémentées)
- KYC v1 → ARCHIVED, KYC v2 → ACTIVE (idem pour les 3 autres types)

#### 3. `provisionPartialBlockSet(UUID partyId)`
**Cas B2 : Review avec Membre Secondaire**
- Archive 2 blocs actifs : STATIC_DATA, DOCUMENT
- Crée 2 nouveaux blocs (versions incrémentées)
- KYC et KYT restent INCHANGÉS

### Événements Domaine

#### `BlockProvisionedEvent`
```java
public record BlockProvisionedEvent(
    UUID blockId,
    UUID partyId,
    BlockType type,
    int blockVersion,
    BlockStatus status
) {}
```
Publié après création d'un nouveau bloc.

#### `BlockArchivedEvent`
```java
public record BlockArchivedEvent(
    UUID blockId,
    UUID partyId,
    BlockType type,
    int blockVersion
) {}
```
Publié après archivage d'un bloc actif.

### Event Handlers

#### `PartyOnboardedEventHandler`
- Écoute : `PartyOnboardedEvent`
- Action : `provisionInitialBlocks()`
- Cas : A (Onboarding)

#### `PartyUpdatedEventHandler`
- Écoute : `PartyUpdatedEvent`
- Action : Si `relationType == "SECONDARY"` → `provisionPartialBlockSet()`
- Cas : B2 (Membre Secondaire)

#### `ReviewInstanceStartedEventHandler`
- Écoute : `ReviewInstanceStartedEvent`
- Action : `provisionFullBlockSet()`
- Cas : B1 (Acteur Principal)

## Flux de Données

### Scénario 1 : Onboarding d'un Nouveau Client

```
1. Nouveau client créé
   ↓
2. PartyOnboardedEvent publié
   ↓
3. PartyOnboardedEventHandler écoute
   ↓
4. BlockProvisioningService.provisionInitialBlocks()
   ↓
5. Création de 4 blocs (version 1, ACTIVE)
   - KYC Block v1 (ACTIVE)
   - KYT Block v1 (ACTIVE)
   - STATIC_DATA Block v1 (ACTIVE)
   - DOCUMENT Block v1 (ACTIVE)
   ↓
6. Publication de 4 x BlockProvisionedEvent
   ↓
7. Transaction committée
```

### Scénario 2 : Review avec Acteur Principal

```
1. Review démarrée pour client existant
   ↓
2. ReviewInstanceStartedEvent publié
   ↓
3. ReviewInstanceStartedEventHandler écoute
   ↓
4. BlockProvisioningService.provisionFullBlockSet()
   ↓
5. Archivage des 4 blocs actifs
   - KYC Block v1 (ACTIVE → ARCHIVED)
   - KYT Block v1 (ACTIVE → ARCHIVED)
   - STATIC_DATA Block v1 (ACTIVE → ARCHIVED)
   - DOCUMENT Block v1 (ACTIVE → ARCHIVED)
   ↓
6. Publication de 4 x BlockArchivedEvent
   ↓
7. Création de 4 nouveaux blocs (version 2, ACTIVE)
   - KYC Block v2 (ACTIVE)
   - KYT Block v2 (ACTIVE)
   - STATIC_DATA Block v2 (ACTIVE)
   - DOCUMENT Block v2 (ACTIVE)
   ↓
8. Publication de 4 x BlockProvisionedEvent
   ↓
9. Transaction committée
```

### Scénario 3 : Review avec Membre Secondaire

```
1. Membre secondaire ajouté à client existant
   ↓
2. PartyUpdatedEvent(relationType="SECONDARY") publié
   ↓
3. PartyUpdatedEventHandler écoute
   ↓
4. BlockProvisioningService.provisionPartialBlockSet()
   ↓
5. Archivage de 2 blocs actifs seulement
   - STATIC_DATA Block v1 (ACTIVE → ARCHIVED)
   - DOCUMENT Block v1 (ACTIVE → ARCHIVED)
   ↓
6. Publication de 2 x BlockArchivedEvent
   ↓
7. Création de 2 nouveaux blocs (versions incrémentées, ACTIVE)
   - STATIC_DATA Block v2 (ACTIVE)
   - DOCUMENT Block v2 (ACTIVE)
   ↓
8. Publication de 2 x BlockProvisionedEvent
   ↓
9. KYC et KYT restent INCHANGÉS
   ↓
10. Transaction committée
```

## Règles Métier Implémentées

### ✅ Règle 1 : Un Seul Bloc Actif Par Type
**Implémentation** :
- Méthode `archiveActiveBlocks()` archive l'ancien bloc avant création du nouveau
- Repository query `findByPartyIdAndTypeAndStatus()` retourne au plus 1 bloc actif
- Index DB `idx_block_party_type_status` pour performance

**Garantie** : Le code garantit atomiquement (transaction) l'archivage puis la création.

### ✅ Règle 2 : Historique Complet
**Implémentation** :
- Aucune méthode de suppression dans le Repository
- Statut `ARCHIVED` pour blocs historiques
- Méthode `archive()` sur l'entité Block (transition ACTIVE → ARCHIVED)

**Garantie** : Les blocs archivés restent en base pour audit.

### ✅ Règle 3 : Archivage Automatique
**Implémentation** :
- Service `archiveActiveBlocks()` appelé AVANT `createBlockSet()`
- Ordre garanti par le code (séquentiel)
- Transaction garantit atomicité (tout ou rien)

**Garantie** : Impossible de créer nouveau bloc sans archiver l'ancien.

## Gestion des Versions

### Calcul de la Prochaine Version

```java
private int getNextBlockVersion(UUID partyId, BlockType type) {
    Integer maxVersion = blockRepository.findMaxBlockVersionByPartyIdAndType(partyId, type);
    return maxVersion == null ? 1 : maxVersion + 1;
}
```

**Exemples** :
- Pas de bloc KYC → version 1
- Max version KYC = 3 → version 4
- Compteur indépendant par type (KYC v5, STATIC_DATA v2 possible)

### Différence blockVersion vs entityVersion

| Aspect | blockVersion | entityVersion |
|--------|--------------|---------------|
| **But** | Version métier (utilisateur) | Optimistic locking (technique) |
| **Type** | Integer | Long |
| **Géré par** | Application (manuelle) | Hibernate (automatique) |
| **Incrémentation** | À chaque nouveau bloc du même type | À chaque UPDATE de l'entité |
| **Visibilité** | UI, logs, audit | Interne uniquement |
| **Exemple** | KYC v1, v2, v3 | 1 → 2 → 3 (lors de modifications) |

**Pourquoi deux versions ?**
- Éviter confusion avec `@Version` Hibernate
- `blockVersion` pour business (affichage, audit)
- `entityVersion` pour concurrence (prévenir lost updates)

## Transactions & Gestion d'Erreur

### Stratégie Transactionnelle

Toutes les méthodes du service sont `@Transactional` :
```java
@Transactional
public void provisionFullBlockSet(UUID partyId) {
    // Archive 4 blocs
    // Crée 4 nouveaux blocs
    // Atomique : tout ou rien
}
```

**Avantages** :
- ✅ Rollback automatique si erreur
- ✅ Pas d'état incohérent (archive sans création, ou inverse)
- ✅ Événements publiés seulement si commit réussi

### Gestion des Erreurs dans les Handlers

```java
@EventListener
public void onPartyOnboarded(PartyOnboardedEvent event) {
    try {
        blockProvisioningService.provisionInitialBlocks(event.partyId());
    } catch (Exception ex) {
        log.error("Failed to provision blocks: {}", ex.getMessage(), ex);
        throw ex; // Re-throw pour rollback transaction
    }
}
```

**Comportement** :
- Erreur → Exception propagée → Transaction rollback
- Blocs non créés, événements non publiés
- Log d'erreur pour investigation

## Tests

### Tests Unitaires (`BlockProvisioningServiceTest`)

Couvrent :
- ✅ `provisionInitialBlocks()` crée 4 blocs pour nouveau Party
- ✅ `provisionInitialBlocks()` skip si Party a déjà des blocs
- ✅ `provisionFullBlockSet()` archive et crée 4 nouveaux blocs
- ✅ `provisionPartialBlockSet()` archive et crée 2 blocs (STATIC_DATA, DOCUMENT)
- ✅ Validation partyId null → IllegalArgumentException
- ✅ Gestion cas où aucun bloc actif n'existe

**Couverture** : 100% des méthodes publiques du service

### Tests à Ajouter (Intégration)

```java
@SpringBootTest
@Transactional
class BlockProvisioningIntegrationTest {

    @Test
    void fullScenario_onboarding_then_review() {
        // 1. Onboarding → 4 blocs v1
        // 2. Review Principal → 4 blocs v2 (v1 archivés)
        // 3. Vérifier historique complet
    }

    @Test
    void partialScenario_onboarding_then_secondaryMember() {
        // 1. Onboarding → 4 blocs v1
        // 2. Secondary Member → STATIC_DATA v2, DOCUMENT v2
        // 3. Vérifier KYC et KYT inchangés
    }

    @Test
    void concurrency_multipleReviewsSimultaneous() {
        // Test optimistic locking avec entityVersion
    }
}
```

## Base de Données

### Schéma Table `block`

```sql
CREATE TABLE block (
    id UUID PRIMARY KEY,
    party_id UUID NOT NULL,
    type VARCHAR(20) NOT NULL,
    block_version INT NOT NULL,
    entity_version BIGINT,
    status VARCHAR(20) NOT NULL,
    payload TEXT,
    created_at TIMESTAMP NOT NULL,
    archived_at TIMESTAMP,

    -- Indexes for performance
    INDEX idx_block_party_type_status (party_id, type, status),
    INDEX idx_block_party_type_version (party_id, type, block_version)
);
```

### Requêtes Typiques

**1. Trouver bloc actif pour un Party et type**
```sql
SELECT * FROM block
WHERE party_id = ?
  AND type = 'KYC'
  AND status = 'ACTIVE'
LIMIT 1;
```

**2. Calculer prochaine version**
```sql
SELECT MAX(block_version) FROM block
WHERE party_id = ?
  AND type = 'KYC';
```

**3. Historique complet d'un type de bloc**
```sql
SELECT * FROM block
WHERE party_id = ?
  AND type = 'KYC'
ORDER BY block_version DESC;
```

**4. Snapshot actuel d'un Party (tous blocs actifs)**
```sql
SELECT * FROM block
WHERE party_id = ?
  AND status = 'ACTIVE';
```

## Monitoring & Observabilité

### Logs Importants

Le service log :
- ✅ Provisioning initial : `"Provisioning initial blocks for Party [partyId: {}]"`
- ✅ Nombre de blocs créés : `"Successfully provisioned {} initial blocks"`
- ✅ Archivage : `"Archived {} active blocks for Party"`
- ✅ Erreurs : `"Failed to provision blocks: {}"`

### Métriques à Ajouter

```java
@Component
public class BlockMetrics {
    private final MeterRegistry registry;

    public void recordBlockProvisioned(BlockType type) {
        registry.counter("blocks.provisioned", "type", type.name()).increment();
    }

    public void recordBlockArchived(BlockType type) {
        registry.counter("blocks.archived", "type", type.name()).increment();
    }

    public void recordProvisioningError(String reason) {
        registry.counter("blocks.provisioning.errors", "reason", reason).increment();
    }
}
```

**Dashboards** :
- Nombre de blocs créés par type par jour
- Nombre d'archivages par jour
- Taux d'erreur de provisioning
- Distribution des versions par type de bloc

## Évolutions Futures

### 1. Validation du Payload
Actuellement, payload est un simple String JSON. Évolutions possibles :
- Schémas JSON par type de bloc
- Validation à la création
- Migration de données entre versions

### 2. Soft Delete
Si besoin de "supprimer" un bloc :
```java
@Column(name = "deleted_at")
private Instant deletedAt;

public void softDelete() {
    this.deletedAt = Instant.now();
}
```

### 3. Audit Trail Enrichi
Ajouter champs :
- `createdBy` : Utilisateur ayant créé le bloc
- `archivedBy` : Utilisateur ayant déclenché l'archivage
- `reason` : Raison de l'archivage (Review, Manual, etc.)

### 4. Compression des Blocs Archivés
Pour blocs très anciens :
```java
@Scheduled(cron = "0 0 2 * * *") // 2am daily
public void compressOldArchivedBlocks() {
    Instant threshold = Instant.now().minus(Duration.ofDays(365));
    // Compress payload, move to cold storage, etc.
}
```

## Checklist de Déploiement

- [ ] Table `block` créée en base (via JPA ddl-auto ou migration)
- [ ] Indexes créés (`idx_block_party_type_status`, `idx_block_party_type_version`)
- [ ] Tests unitaires passent (BlockProvisioningServiceTest)
- [ ] Tests d'intégration écrits et passent
- [ ] Logs vérifiés en environnement de test
- [ ] Événements `PartyOnboardedEvent`, `PartyUpdatedEvent` publiés correctement
- [ ] Handlers enregistrés comme Spring beans (@Component)
- [ ] Métriques intégrées avec Prometheus/Grafana
- [ ] Documentation mise à jour
- [ ] Runbook pour opérations (comment débugger un bloc en erreur, etc.)

## Références

- [Spécification Métier](./business-specification-dossier-blocks.md)
- [Code Source](../src/main/java/com/remediation/sharedkernel/block/)
- [Tests](../src/test/java/com/remediation/sharedkernel/block/)
