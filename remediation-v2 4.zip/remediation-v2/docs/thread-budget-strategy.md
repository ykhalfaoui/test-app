# Thread Budget Strategy - HTTP + Kafka Processing

## Context

L'application remediation-v2 est déployée sur **Spring Boot avec Tomcat embedded** (default: 200 threads).

Elle doit gérer **deux types de charge** simultanément:
1. **Trafic HTTP**: API REST pour les utilisateurs, UI, intégrations externes
2. **Traitement Kafka**: Événements HIT, PARTY, DDR consommés depuis Kafka

## Le Problème

❌ **Risque**: Si les ThreadPools async monopolisent trop de threads, le trafic HTTP devient lent ou bloqué!

**Symptômes d'un mauvais dimensionnement**:
- Requêtes HTTP en timeout (503 Service Unavailable)
- Latence HTTP élevée même pour endpoints simples
- Tomcat rejette des connexions HTTP
- Logs: "All threads are busy, cannot serve HTTP request"

## La Solution: Budget Conservateur

### Allocation des 200 Threads Tomcat

```
┌─────────────────────────────────────────────────────────┐
│ Tomcat Thread Pool (200 threads total)                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ HTTP Traffic                  [100 threads reserved]   │
│ ├─ API endpoints (UI, external integrations)           │
│ ├─ Peak concurrent requests: ~50-100                   │
│ └─ Always available, never exhausted                   │
│                                                         │
│ Kafka Consumers               [10 threads reserved]    │
│ ├─ HitKafkaConsumer (1-2 threads)                      │
│ ├─ PartyKafkaConsumer (1-2 threads)                    │
│ ├─ DdrKafkaConsumer (1-2 threads)                      │
│ └─ Consumer overhead (poll, commit, etc.)              │
│                                                         │
│ Async Processing              [45 threads max]         │
│ ├─ hitProcessorExecutor: 3 cores, 10 max              │
│ ├─ partyProcessorExecutor: 2 cores, 5 max             │
│ └─ ddrProcessorExecutor: 5 cores, 30 max              │
│                                                         │
│ Buffer / Safety Margin        [45 threads]             │
│ └─ Handles unexpected spikes, scheduled tasks          │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Stratégie de Sizing

**Principe**: Async ThreadPools sont dimensionnés de manière **conservative** pour préserver le trafic HTTP.

#### 1. Core Threads (Toujours Actifs)

Total: **10 threads** (3 HIT + 2 PARTY + 5 DDR)

**Pourquoi minimal?**
- Ces threads sont **toujours vivants** (même quand idle)
- Ils consomment des ressources même sans charge Kafka
- On minimise l'empreinte pour préserver HTTP

**Avantage**:
- Toujours prêts pour traitement immédiat
- Latence < 100ms pour premiers messages

#### 2. Max Threads (Burst Capacity)

Total: **45 threads** (10 HIT + 5 PARTY + 30 DDR)

**Pourquoi limité?**
- En cas de burst, ThreadPools peuvent scale jusqu'à 45 threads
- Laisse 155 threads pour HTTP + Kafka + buffer
- HTTP traffic jamais impacté, même durant pics Kafka

**Mécanisme**:
```
Normal load:
├─ Core threads (10) handle events
├─ HTTP uses ~20-50 threads
└─ ~140 threads available

Burst load (Kafka spike):
├─ ThreadPools scale to max (45)
├─ HTTP still has 100+ threads available
└─ HTTP latency unchanged ✅
```

#### 3. Queue Capacity (Buffer Before Rejection)

- HIT: 100 messages
- PARTY: 50 messages
- DDR: 300 messages

**Rôle des queues**:
- Absorbent les pics de trafic **avant** de créer de nouveaux threads
- Évitent la création excessive de threads pour pics courts
- Retardent l'activation de CallerRunsPolicy

**Flux d'exécution**:
```
1. Message arrive → Core threads busy?
   ├─ Non → Thread exécute immédiatement
   └─ Oui → Va en queue

2. Queue pleine → Max threads atteints?
   ├─ Non → Crée nouveau thread (jusqu'à max)
   └─ Oui → CallerRunsPolicy (backpressure)

3. CallerRunsPolicy activé
   └─ Kafka consumer thread exécute la tâche
   └─ Ralentit naturellement la consommation Kafka
   └─ Protège HTTP traffic ✅
```

## CallerRunsPolicy: La Clé de la Protection HTTP

### Comment ça Fonctionne

```java
executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
```

**Comportement**:
- Quand ThreadPool est saturé (queue pleine + max threads)
- Le thread **qui soumet** la tâche l'exécute lui-même
- Pour nous: c'est le **Kafka consumer thread**

**Effet**:
```
DDR Overload Scenario:
├─ 300 messages in queue
├─ 30 threads processing
├─ New DDR message arrives
└─ CallerRunsPolicy triggered
    ├─ Kafka consumer thread processes message directly
    ├─ Consumer stops polling during processing
    ├─ DDR consumption slows naturally
    └─ HTTP traffic UNAFFECTED ✅

Meanwhile:
├─ HIT processing continues normally (dedicated pool)
├─ PARTY processing continues normally (dedicated pool)
└─ HTTP requests served normally (100+ threads available)
```

### Pourquoi CallerRunsPolicy > AbortPolicy

**AbortPolicy** (rejeter la tâche):
❌ Message perdu (pas acceptable)
❌ Kafka offset bloqué
❌ Besoin retry manuel

**CallerRunsPolicy** (exécuter dans caller):
✅ Message traité (pas de perte)
✅ Backpressure automatique
✅ Kafka offset avance
✅ HTTP traffic protégé

## Scénarios de Charge

### Scénario 1: Charge Normale

```
HTTP: 30 requêtes/sec (~30 threads actifs)
Kafka: 100 HIT/sec, 20 PARTY/sec, 500 DDR/sec

Thread Usage:
├─ HTTP: 30/100 threads (30%)
├─ Kafka consumers: 6/10 threads (60%)
├─ Async processing: 10/45 threads (cores, 22%)
└─ Available: 154/200 threads (77%)

Performance:
✅ HTTP latency: < 50ms (normal)
✅ Kafka processing: < 100ms (immediate async)
✅ No backpressure
```

### Scénario 2: Pic HTTP (Black Friday)

```
HTTP: 150 requêtes/sec (~80 threads actifs)
Kafka: 100 HIT/sec, 20 PARTY/sec, 500 DDR/sec

Thread Usage:
├─ HTTP: 80/100 threads (80%)  ⚠️ High
├─ Kafka consumers: 6/10 threads (60%)
├─ Async processing: 10/45 threads (cores, 22%)
└─ Available: 104/200 threads (52%)

Performance:
✅ HTTP latency: < 100ms (acceptable)
✅ Kafka processing: < 100ms (immediate async)
⚠️ HTTP threads under pressure but sufficient
✅ Async pools not scaling (preserving HTTP)
```

### Scénario 3: Pic Kafka DDR

```
HTTP: 30 requêtes/sec (~30 threads actifs)
Kafka: 100 HIT/sec, 20 PARTY/sec, 2000 DDR/sec  ⚠️ Spike!

Thread Usage:
├─ HTTP: 30/100 threads (30%)
├─ Kafka consumers: 6/10 threads (60%)
├─ Async processing: 42/45 threads (93%)  ⚠️ High
│   ├─ HIT: 8 threads
│   ├─ PARTY: 4 threads
│   └─ DDR: 30 threads (MAX!)  ⚠️
└─ Available: 122/200 threads (61%)

Performance:
✅ HTTP latency: < 50ms (unaffected)
✅ HIT processing: < 100ms (isolated)
✅ PARTY processing: < 100ms (isolated)
⚠️ DDR processing: Backpressure activated
   ├─ Queue full (300 messages)
   ├─ CallerRunsPolicy triggered
   ├─ DDR consumer slowed to ~500-800/sec
   └─ HTTP completely unaffected ✅
```

### Scénario 4: Pic Combiné (HTTP + Kafka)

```
HTTP: 150 requêtes/sec (~80 threads actifs)  ⚠️ High
Kafka: 200 HIT/sec, 50 PARTY/sec, 2000 DDR/sec  ⚠️ Spike!

Thread Usage:
├─ HTTP: 80/100 threads (80%)  ⚠️ High
├─ Kafka consumers: 8/10 threads (80%)
├─ Async processing: 45/45 threads (100%)  ⚠️ MAX!
│   ├─ HIT: 10 threads (MAX!)
│   ├─ PARTY: 5 threads (MAX!)
│   └─ DDR: 30 threads (MAX!)
└─ Available: 67/200 threads (34%)  ⚠️ Reduced

Performance:
✅ HTTP latency: < 150ms (acceptable, still served)
⚠️ HIT processing: CallerRunsPolicy (slowed to ~150/sec)
⚠️ PARTY processing: CallerRunsPolicy (slowed to ~30/sec)
⚠️ DDR processing: CallerRunsPolicy (slowed to ~500/sec)

Result:
✅ HTTP traffic continues (67 threads buffer remaining)
✅ No HTTP 503 errors
✅ Kafka processing slowed but not stopped
✅ System stable, no crash
⚠️ Increased latency acceptable during peak
✅ System recovers automatically when load decreases
```

## Monitoring & Alerting

### Métriques Critiques

**1. HTTP Thread Pool** (via Spring Actuator):
```
http.server.requests.active
tomcat.threads.busy
tomcat.threads.current
```

**Alertes**:
- `tomcat.threads.busy > 150` → Warning (75%)
- `tomcat.threads.busy > 180` → Critical (90%)
- `http.server.requests.active > 100` → Investigate

**2. Async ThreadPools**:
```
executor.active{name="hitProcessorExecutor"}
executor.queued{name="hitProcessorExecutor"}
executor.pool.size{name="hitProcessorExecutor"}
```

**Alertes**:
- `executor.active >= executor.pool.max` → Backpressure active
- `executor.queued > capacity * 0.8` → Queue nearly full
- `executor.completed` stagnant → Processing stuck

**3. Kafka Consumer Lag**:
```
kafka.consumer.lag{topic="remediation.hits"}
kafka.consumer.lag{topic="remediation.party"}
kafka.consumer.lag{topic="remediation.ddr"}
```

**Alertes**:
- Lag > 1000 messages → Backpressure active or processing slow
- Lag increasing continuously → Need scaling

## Tuning en Production

### Quand Augmenter les Threads Async?

**Signaux**:
1. Kafka consumer lag augmente continuellement
2. Inbox backlog (RECEIVED status) > 1000
3. HTTP latency < 50ms stable
4. `tomcat.threads.busy < 100` (50%)

**Action**: Augmenter progressivement core/max threads:
```yaml
# Before
ddr:
  core-pool-size: 5
  max-pool-size: 30

# After (if HTTP comfortable)
ddr:
  core-pool-size: 8
  max-pool-size: 40
```

### Quand Diminuer les Threads Async?

**Signaux**:
1. HTTP latency > 200ms durant charge normale
2. `tomcat.threads.busy > 150` fréquemment
3. HTTP 503 errors apparaissent
4. Kafka lag acceptable (< 100)

**Action**: Réduire max threads ou queues:
```yaml
# Before
ddr:
  max-pool-size: 30
  queue-capacity: 300

# After (preserve HTTP)
ddr:
  max-pool-size: 20
  queue-capacity: 200
```

### Scaling Horizontal vs Vertical

**Quand scaler horizontalement (plus d'instances)?**
- HTTP latency > 200ms + Kafka lag > 5000
- Tous les threads saturés (HTTP + async)
- Aucune marge de manœuvre avec tuning

**Avantages**:
- Double la capacité totale (HTTP + Kafka)
- Chaque instance reste responsive
- Résilience améliorée (HA)

**Configuration Kubernetes**:
```yaml
replicas: 3  # Scale from 1 to 3

# Each instance:
# - 200 threads
# - 100 for HTTP
# - 45 for async
# = 600 threads HTTP total
# = 135 threads async total
```

## Checklist de Validation

### Avant Déploiement

- [ ] Load test HTTP seul: 200 req/sec, latency < 100ms
- [ ] Load test Kafka seul: Lag < 500 messages
- [ ] Load test combiné: HTTP latency < 150ms + Lag < 1000
- [ ] Vérifier CallerRunsPolicy activé sur surcharge
- [ ] Vérifier pas de HTTP 503 durant pics Kafka
- [ ] Vérifier threads actifs < 180 durant pic combiné

### En Production

- [ ] Grafana dashboard avec métriques HTTP + async + Kafka
- [ ] Alertes configurées (threads busy, lag, latency)
- [ ] Logs structurés avec thread names (hit-proc-, party-proc-, ddr-proc-)
- [ ] Runbook pour scaling (horizontal/vertical)
- [ ] Baseline performance établie (normal load metrics)

## Références

- [Spring Boot Embedded Tomcat Configuration](https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html#application-properties.server)
- [ThreadPoolExecutor RejectedExecutionHandler](https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/ThreadPoolExecutor.html)
- [Inbox Multi-Event-Type Architecture](./inbox-multi-event-type-architecture.md)
