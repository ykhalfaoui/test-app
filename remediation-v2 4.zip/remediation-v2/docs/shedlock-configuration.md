# ShedLock Configuration - Distributed Scheduled Task Locking

## Pourquoi ShedLock ?

### Le Problème Sans ShedLock

Lorsque vous déployez **plusieurs instances** de l'application (horizontal scaling), chaque instance exécute ses propres `@Scheduled` tasks:

```
Instance 1                Instance 2                Instance 3
├─ @Scheduled             ├─ @Scheduled             ├─ @Scheduled
│  processRetries()       │  processRetries()       │  processRetries()
│  every 5s               │  every 5s               │  every 5s
│                         │                         │
├─ Query DB for retries   ├─ Query DB for retries   ├─ Query DB for retries
├─ Finds 100 entries      ├─ Finds 100 entries      ├─ Finds 100 entries
└─ Processes them         └─ Processes them         └─ Processes them
   ❌ DUPLICATE WORK!        ❌ DUPLICATE WORK!        ❌ DUPLICATE WORK!
```

**Conséquences**:
- ❌ Mêmes messages traités 3 fois (waste de CPU/DB)
- ❌ Logs dupliqués (metrics incorrects)
- ❌ Race conditions possibles
- ❌ Outbox entries forwarded multiple times

### La Solution Avec ShedLock

ShedLock garantit qu'**une seule instance** exécute chaque tâche scheduled:

```
Instance 1                Instance 2                Instance 3
├─ @Scheduled             ├─ @Scheduled             ├─ @Scheduled
│  + @SchedulerLock       │  + @SchedulerLock       │  + @SchedulerLock
│  processRetries()       │  processRetries()       │  processRetries()
│                         │                         │
├─ Acquires lock ✅       ├─ Tries lock ❌          ├─ Tries lock ❌
├─ Query DB for retries   ├─ Lock held, SKIP        ├─ Lock held, SKIP
├─ Finds 100 entries      │                         │
└─ Processes them         └─ Waits next cycle       └─ Waits next cycle
   ✅ ONE execution
```

**Avantages**:
- ✅ Pas de travail dupliqué
- ✅ Logs et métriques corrects
- ✅ Pas de race conditions
- ✅ Outbox forwarding safe

## Architecture ShedLock

### Base de Données Partagée

Toutes les instances partagent la même base de données:

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ Instance 1  │    │ Instance 2  │    │ Instance 3  │
└──────┬──────┘    └──────┬──────┘    └──────┬──────┘
       │                  │                  │
       └──────────────────┼──────────────────┘
                          │
                   ┌──────▼──────┐
                   │  Database   │
                   │             │
                   │ ┌─────────┐ │
                   │ │shedlock │ │ ← Lock coordination table
                   │ └─────────┘ │
                   │ ┌─────────┐ │
                   │ │  inbox  │ │
                   │ └─────────┘ │
                   │ ┌─────────┐ │
                   │ │ outbox  │ │
                   │ └─────────┘ │
                   └─────────────┘
```

### Table ShedLock

Créée automatiquement via `schema.sql`:

```sql
CREATE TABLE shedlock (
    name VARCHAR(64) NOT NULL,           -- Task name (unique)
    lock_until TIMESTAMP NOT NULL,       -- When lock expires
    locked_at TIMESTAMP NOT NULL,        -- When lock was acquired
    locked_by VARCHAR(255) NOT NULL,     -- Instance identifier
    PRIMARY KEY (name)
);
```

**Exemple de données**:
```
name                              | lock_until           | locked_at            | locked_by
----------------------------------|---------------------|---------------------|---------------------------
InboxProcessor_processRetries     | 2024-01-15 10:05:00 | 2024-01-15 10:01:00 | instance-1-thread-12
OutboxForwarder_forwardPending    | 2024-01-15 10:05:00 | 2024-01-15 10:01:00 | instance-2-thread-8
InboxProcessor_recoverOrphans     | 2024-01-15 10:10:00 | 2024-01-15 10:00:30 | instance-1-thread-5
InboxProcessor_recordMetrics      | 2024-01-15 10:02:00 | 2024-01-15 10:01:51 | instance-3-thread-3
```

## Configuration Automatique

### 1. Dépendances (pom.xml)

```xml
<!-- ShedLock for distributed scheduled task locking -->
<dependency>
    <groupId>net.javacrumbs.shedlock</groupId>
    <artifactId>shedlock-spring</artifactId>
    <version>5.10.0</version>
</dependency>

<dependency>
    <groupId>net.javacrumbs.shedlock</groupId>
    <artifactId>shedlock-provider-jdbc-template</artifactId>
    <version>5.10.0</version>
</dependency>
```

### 2. Création Automatique de la Table (schema.sql)

Spring Boot exécute automatiquement `src/main/resources/schema.sql` au démarrage:

```sql
CREATE TABLE IF NOT EXISTS shedlock (
    name VARCHAR(64) NOT NULL,
    lock_until TIMESTAMP NOT NULL,
    locked_at TIMESTAMP NOT NULL,
    locked_by VARCHAR(255) NOT NULL,
    PRIMARY KEY (name)
);
```

✅ **La table est créée automatiquement au démarrage de l'application**

### 3. Configuration Java (ShedLockConfig.java)

```java
@Configuration
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "10m")
public class ShedLockConfig {

    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(
            JdbcTemplateLockProvider.Configuration.builder()
                .withJdbcTemplate(new JdbcTemplate(dataSource))
                .usingDbTime() // Use DB time for consistency
                .build()
        );
    }
}
```

## Utilisation sur les @Scheduled Tasks

### Syntaxe

```java
@Scheduled(fixedDelay = 5000)
@SchedulerLock(
    name = "TaskName",              // Unique identifier
    lockAtMostFor = "4m",           // Max lock duration
    lockAtLeastFor = "4s"           // Min lock duration
)
public void myScheduledTask() {
    // Code executed by ONE instance only
}
```

### Paramètres Expliqués

**`name`**: Identifiant unique de la tâche
- Doit être unique par méthode
- Convention: `ClassName_methodName`
- Exemple: `InboxProcessor_processRetries`

**`lockAtMostFor`**: Durée maximale du lock
- Protège contre les deadlocks si l'instance crash
- Si l'instance crash, lock expire automatiquement
- Doit être > durée normale d'exécution
- Exemple: Si task prend 30s, mettre 2-4 minutes

**`lockAtLeastFor`**: Durée minimale du lock
- Empêche la ré-exécution immédiate
- Utile pour éviter la contention
- Généralement légèrement < `fixedDelay`
- Exemple: Si fixedDelay=5s, mettre 4s

### Exemples Réels

#### 1. InboxProcessor.processRetries()

```java
@Scheduled(
    fixedDelayString = "${inbox.processor.retry-delay:5000}",  // Every 5s
    initialDelayString = "${inbox.processor.retry-initial-delay:10000}",
    timeUnit = TimeUnit.MILLISECONDS
)
@SchedulerLock(
    name = "InboxProcessor_processRetries",
    lockAtMostFor = "4m",      // Max 4 minutes (safety)
    lockAtLeastFor = "4s"      // Min 4 seconds (prevent rapid re-exec)
)
public void processRetries() {
    // Query retries, trigger async processing
}
```

**Pourquoi ces valeurs?**
- `lockAtMostFor = 4m`: Traitement de 100 retries peut prendre 1-2 minutes max
- `lockAtLeastFor = 4s`: Légèrement moins que fixedDelay (5s)

#### 2. InboxProcessor.recoverOrphans()

```java
@Scheduled(
    fixedDelayString = "${inbox.processor.orphan-delay:30000}",  // Every 30s
    initialDelayString = "${inbox.processor.orphan-initial-delay:60000}",
    timeUnit = TimeUnit.MILLISECONDS
)
@SchedulerLock(
    name = "InboxProcessor_recoverOrphans",
    lockAtMostFor = "10m",     // Max 10 minutes (large batch possible)
    lockAtLeastFor = "29s"     // Min 29 seconds
)
public void recoverOrphans() {
    // Query orphans, trigger recovery
}
```

**Pourquoi ces valeurs?**
- `lockAtMostFor = 10m`: Orphan recovery peut traiter beaucoup d'entrées
- `lockAtLeastFor = 29s`: Légèrement moins que fixedDelay (30s)

#### 3. InboxProcessor.recordMetrics()

```java
@Scheduled(
    fixedDelayString = "${inbox.processor.metrics-delay:10000}",  // Every 10s
    initialDelayString = "${inbox.processor.metrics-initial-delay:30000}",
    timeUnit = TimeUnit.MILLISECONDS
)
@SchedulerLock(
    name = "InboxProcessor_recordMetrics",
    lockAtMostFor = "2m",      // Max 2 minutes
    lockAtLeastFor = "9s"      // Min 9 seconds
)
public void recordMetrics() {
    // Count inbox entries, log metrics
}
```

**Pourquoi ces valeurs?**
- `lockAtMostFor = 2m`: Metrics très rapides, 2 min largement suffisant
- `lockAtLeastFor = 9s`: Légèrement moins que fixedDelay (10s)

#### 4. OutboxForwarder.forwardPending()

```java
@Scheduled(
    fixedDelayString = "${outbox.forwarder.fixed-delay:5000}",  // Every 5s
    initialDelayString = "${outbox.forwarder.initial-delay:2000}",
    timeUnit = TimeUnit.MILLISECONDS
)
@SchedulerLock(
    name = "OutboxForwarder_forwardPending",
    lockAtMostFor = "4m",      // Max 4 minutes
    lockAtLeastFor = "4s"      // Min 4 seconds
)
@Transactional
public void forwardPending() {
    // Forward outbox entries to Kafka
}
```

**Pourquoi ces valeurs?**
- `lockAtMostFor = 4m`: Forwarding 100 events peut prendre 1-2 minutes
- `lockAtLeastFor = 4s`: Légèrement moins que fixedDelay (5s)

## Flux d'Exécution

### Scénario: 3 Instances Running

```
Time: 10:00:00.000
├─ Instance 1: @Scheduled trigger (processRetries)
│  ├─ Try acquire lock "InboxProcessor_processRetries"
│  ├─ Lock available ✅
│  ├─ INSERT INTO shedlock (name='InboxProcessor_processRetries',
│  │                          lock_until=10:04:00, locked_at=10:00:00,
│  │                          locked_by='instance-1-thread-12')
│  ├─ Execute processRetries()
│  └─ Release lock after 4s (lockAtLeastFor)
│
├─ Instance 2: @Scheduled trigger (processRetries)
│  ├─ Try acquire lock "InboxProcessor_processRetries"
│  ├─ Lock held by instance-1 ❌
│  ├─ SELECT * FROM shedlock WHERE name='...' AND lock_until > NOW()
│  └─ Skip execution, wait next cycle
│
└─ Instance 3: @Scheduled trigger (processRetries)
   ├─ Try acquire lock "InboxProcessor_processRetries"
   ├─ Lock held by instance-1 ❌
   └─ Skip execution, wait next cycle

Time: 10:00:05.000 (5 seconds later)
├─ Instance 1: @Scheduled trigger again
│  ├─ Try acquire lock
│  ├─ Lock available (lockAtLeastFor expired) ✅
│  └─ Execute again
│
├─ Instance 2: Skip (lock held)
└─ Instance 3: Skip (lock held)
```

### Scénario: Instance Crash

```
Time: 10:00:00.000
├─ Instance 1: Acquires lock, starts processing
│  ├─ lock_until = 10:04:00 (lockAtMostFor = 4m)
│  ├─ Processing...
│  └─ 💥 CRASH at 10:00:30 (lock NOT released!)

Time: 10:00:35.000
├─ Instance 2: @Scheduled trigger
│  ├─ Try acquire lock
│  ├─ SELECT * FROM shedlock WHERE name='...' AND lock_until > NOW()
│  ├─ lock_until = 10:04:00 (still in future)
│  └─ Skip execution ⏳ Wait for lock expiration

Time: 10:04:01.000 (lock expired!)
├─ Instance 2: @Scheduled trigger
│  ├─ Try acquire lock
│  ├─ lock_until = 10:04:00 (expired) ✅
│  ├─ UPDATE shedlock SET lock_until=10:08:00, locked_by='instance-2'
│  └─ Execute successfully (recovery from crash)
```

## Monitoring

### Logs ShedLock

Activer les logs ShedLock dans `application.yml`:

```yaml
logging:
  level:
    net.javacrumbs.shedlock: DEBUG
```

**Exemple de logs**:
```
2024-01-15 10:00:00.123 DEBUG [ShedLock] - Locked InboxProcessor_processRetries, locked_by=instance-1-thread-12
2024-01-15 10:00:05.456 DEBUG [ShedLock] - Lock InboxProcessor_processRetries not obtained, locked_by=instance-1-thread-12
2024-01-15 10:00:10.789 DEBUG [ShedLock] - Unlocked InboxProcessor_processRetries
```

### Monitoring SQL

Requêtes pour surveiller les locks:

**1. Locks actifs**:
```sql
SELECT name, locked_by, locked_at, lock_until
FROM shedlock
WHERE lock_until > NOW()
ORDER BY locked_at DESC;
```

**2. Locks expirés (possibles deadlocks)**:
```sql
SELECT name, locked_by, locked_at, lock_until,
       TIMESTAMPDIFF(MINUTE, lock_until, NOW()) as expired_minutes_ago
FROM shedlock
WHERE lock_until < NOW()
ORDER BY lock_until DESC;
```

**3. Historique par instance**:
```sql
SELECT locked_by, COUNT(*) as lock_count, MAX(locked_at) as last_lock
FROM shedlock
GROUP BY locked_by
ORDER BY lock_count DESC;
```

### Métriques Prometheus

Intégrer avec Micrometer pour exposer métriques:

```java
@Component
public class ShedLockMetrics {

    @Scheduled(fixedRate = 60000)
    public void recordLockMetrics() {
        // Count active locks
        // Count expired locks
        // Track lock acquisition success/failure
    }
}
```

## Troubleshooting

### Problème 1: Tâches Ne S'Exécutent Jamais

**Symptômes**:
- Aucun log de tâche scheduled
- Inbox backlog augmente
- Outbox entries PENDING ne sont pas forwarded

**Causes possibles**:
1. Toutes les instances ont crashé
2. Lock deadlock (lock_until dans le futur mais instance morte)
3. ShedLock mal configuré

**Solution**:
```sql
-- Vérifier locks actifs
SELECT * FROM shedlock WHERE lock_until > NOW();

-- Si locks orphelins, forcer expiration
DELETE FROM shedlock WHERE lock_until < NOW();

-- Redémarrer une instance
```

### Problème 2: Duplicate Execution

**Symptômes**:
- Logs dupliqués pour même tâche
- Metrics comptés 2x ou 3x

**Causes possibles**:
1. `@SchedulerLock` manquant sur certaines méthodes
2. Lock name non unique
3. ShedLock pas activé (`@EnableSchedulerLock`)

**Solution**:
```java
// ❌ BAD: Missing @SchedulerLock
@Scheduled(fixedDelay = 5000)
public void myTask() { }

// ✅ GOOD: Lock present
@Scheduled(fixedDelay = 5000)
@SchedulerLock(name = "MyTask", lockAtMostFor = "2m", lockAtLeastFor = "4s")
public void myTask() { }
```

### Problème 3: Locks Expirent Trop Vite

**Symptômes**:
- Task prend 5 minutes
- Lock expire après 2 minutes (lockAtMostFor)
- Autre instance prend le lock pendant exécution
- Duplicate work / race conditions

**Solution**:
```java
// ❌ BAD: lockAtMostFor trop court
@SchedulerLock(
    name = "LongTask",
    lockAtMostFor = "2m",  // Task takes 5min!
    lockAtLeastFor = "4s"
)

// ✅ GOOD: lockAtMostFor > execution time
@SchedulerLock(
    name = "LongTask",
    lockAtMostFor = "10m",  // Sufficient margin
    lockAtLeastFor = "4s"
)
```

## Checklist de Validation

### Développement

- [ ] Dépendances ShedLock ajoutées dans `pom.xml`
- [ ] `ShedLockConfig` créée avec `@EnableSchedulerLock`
- [ ] `schema.sql` créé avec table `shedlock`
- [ ] Tous les `@Scheduled` ont `@SchedulerLock`
- [ ] Lock names uniques (convention: `ClassName_methodName`)
- [ ] `lockAtMostFor` > durée d'exécution normale
- [ ] `lockAtLeastFor` < `fixedDelay` de la tâche

### Tests Locaux

- [ ] Application démarre sans erreur
- [ ] Table `shedlock` créée dans H2 console
- [ ] Logs montrent locks acquired/released
- [ ] Une seule instance exécute chaque tâche

### Tests Cluster (3 instances)

- [ ] Démarrer 3 instances avec même DB
- [ ] Vérifier qu'une seule exécute chaque `@Scheduled`
- [ ] Logs pas dupliqués (metrics correctes)
- [ ] Crash d'une instance → autre prend le relais
- [ ] Table `shedlock` montre différents `locked_by`

### Production

- [ ] Monitoring SQL sur locks actifs/expirés
- [ ] Alertes si locks deadlock (> 10min expired)
- [ ] Logs ShedLock en DEBUG pour investigation
- [ ] Runbook pour forcer unlock en urgence

## Références

- [ShedLock Documentation](https://github.com/lukas-krecan/ShedLock)
- [Spring Scheduling Documentation](https://docs.spring.io/spring-framework/docs/current/reference/html/integration.html#scheduling)
- [Inbox/Outbox Pattern](./inbox-multi-event-type-architecture.md)
