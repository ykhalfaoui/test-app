#!/bin/bash

echo "📊 Génération du rapport Allure en PDF..."
echo ""

# Step 1: Générer le rapport HTML
echo "1️⃣ Génération du rapport HTML Allure..."
allure generate target/allure-results --clean -o target/allure-report

if [ $? -ne 0 ]; then
    echo "❌ Erreur lors de la génération du rapport Allure"
    exit 1
fi

echo "✅ Rapport HTML généré dans: target/allure-report/"
echo ""

# Step 2: Ouvrir le rapport dans le navigateur pour impression PDF manuelle
echo "2️⃣ Ouverture du rapport dans le navigateur..."
echo ""
echo "📝 Instructions pour générer le PDF:"
echo "   1. Le rapport va s'ouvrir dans votre navigateur"
echo "   2. Utilisez la fonction d'impression du navigateur (Cmd+P / Ctrl+P)"
echo "   3. Sélectionnez 'Enregistrer en PDF' comme destination"
echo "   4. Ajustez les paramètres:"
echo "      - Orientation: Paysage (recommandé)"
echo "      - Marges: Aucune ou Minimales"
echo "      - Échelle: 80-90% (pour que tout rentre)"
echo "   5. Cliquez sur 'Enregistrer'"
echo ""

# Ouvrir le rapport
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    open target/allure-report/index.html
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    xdg-open target/allure-report/index.html
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    start target/allure-report/index.html
fi

echo ""
echo "════════════════════════════════════════════════════════════"
echo "💡 Alternative: Utiliser un outil automatique"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "Si vous voulez automatiser la conversion HTML → PDF:"
echo ""
echo "Option 1 - wkhtmltopdf (recommandé):"
echo "  brew install wkhtmltopdf  # Mac"
echo "  sudo apt-get install wkhtmltopdf  # Linux"
echo "  wkhtmltopdf -O Landscape target/allure-report/index.html allure-report.pdf"
echo ""
echo "Option 2 - Playwright (headless browser):"
echo "  npm install -g playwright"
echo "  npx playwright pdf target/allure-report/index.html allure-report.pdf"
echo ""
echo "Option 3 - Allure PDF Plugin:"
echo "  Installez: https://github.com/viclovsky/allure-pdf-plugin"
echo ""
