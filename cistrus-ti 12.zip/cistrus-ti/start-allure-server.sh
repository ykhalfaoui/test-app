#!/bin/bash
# Lance le serveur Allure pour visualiser le rapport
echo "🚀 Lancement du serveur Allure..."
./mvnw allure:serve
