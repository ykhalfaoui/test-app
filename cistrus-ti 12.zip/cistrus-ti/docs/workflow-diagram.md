# 🎯 KYC Workflow - Diagramme de Flux

## Vue d'ensemble du Workflow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         KYC COMPLETE WORKFLOW                                │
│                         (End-to-End avec état partagé)                       │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Création Review (DDR Hit)                    @workflow-step-1       │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  Input:                                                                       │
│  ┌──────────────────────────────────────────┐                               │
│  │  • Principal Actor: CLIENT-A (digital)    │                               │
│  │  • ecStaticData: true                     │                               │
│  │  • Relations: 4 (SPOUSE, CHILD×2, PARTNER)│                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Action: DDR Hit Trigger                                                      │
│  ┌──────────────────────────────────────────┐                               │
│  │  🎯 DDR Hit → Review Creation             │                               │
│  │  📋 Review ID: REV-001                    │                               │
│  │  📦 Blocks Created:                       │                               │
│  │    • IDENTITY → UNDER_REVIEW_BY_IHUB      │                               │
│  │    • ADDRESS → UNDER_REVIEW_BY_IHUB       │                               │
│  │    • FINANCIAL_SITUATION → UNDER_REVIEW   │                               │
│  │    • RISK_ASSESSMENT → UNDER_REVIEW       │                               │
│  │  👥 Related Members: 4 × 4 blocks = 16    │                               │
│  │  ☁️  Salesforce: Synced                    │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Output (État persisté):                                                     │
│  ┌──────────────────────────────────────────┐                               │
│  │  workflowContext = {                      │                               │
│  │    reviewId: "REV-001",                   │                               │
│  │    principalId: "CLIENT-A",               │                               │
│  │    reviewStatus: "ACTIVE",                │                               │
│  │    totalBlocks: 20 (4 + 16)               │                               │
│  │  }                                         │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
                                    ↓
                                    ↓ État préservé (pas de @Before reset)
                                    ↓
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 2: Notifications (85 & 126)                     @workflow-step-2       │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  Input (récupéré du contexte):                                               │
│  ┌──────────────────────────────────────────┐                               │
│  │  • Review ID: REV-001 (from Step 1)       │                               │
│  │  • Review Status: ACTIVE                  │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Action 1: Notification 85                                                    │
│  ┌──────────────────────────────────────────┐                               │
│  │  📨 iHub → Notification 85                │                               │
│  │     "Request customer documentation"      │                               │
│  │                                            │                               │
│  │  Review Status:                            │                               │
│  │    ACTIVE → WAITING_CUSTOMER_RESPONSE     │                               │
│  │                                            │                               │
│  │  📧 Email sent to client                  │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Action 2: Notification 126                                                   │
│  ┌──────────────────────────────────────────┐                               │
│  │  📨 iHub → Notification 126                │                               │
│  │     "Customer provided documentation"     │                               │
│  │                                            │                               │
│  │  Blocks Transition:                        │                               │
│  │    IDENTITY:  UNDER_REVIEW → VALIDATED_BY_CUSTOMER     │                 │
│  │    ADDRESS:   UNDER_REVIEW → VALIDATED_BY_CUSTOMER     │                 │
│  │                                            │                               │
│  │  Blocks Unchanged:                         │                               │
│  │    FINANCIAL_SITUATION → UNDER_REVIEW_BY_IHUB          │                 │
│  │    RISK_ASSESSMENT → UNDER_REVIEW_BY_IHUB              │                 │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Output (État mis à jour):                                                   │
│  ┌──────────────────────────────────────────┐                               │
│  │  workflowContext = {                      │                               │
│  │    reviewStatus: "WAITING_CUSTOMER_RESPONSE",          │                 │
│  │    notification85Sent: true,              │                               │
│  │    notification126Sent: true,             │                               │
│  │    blocksValidated: 2,                    │                               │
│  │    emailSentAt: "2024-02-09T10:30:00"     │                               │
│  │  }                                         │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
                                    ↓
                                    ↓ État préservé
                                    ↓
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP 3: Changements Manuels (KYC Officer)            @workflow-step-3       │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  Input (récupéré du contexte):                                               │
│  ┌──────────────────────────────────────────┐                               │
│  │  • Review ID: REV-001 (from Step 1/2)     │                               │
│  │  • Blocks:                                 │                               │
│  │    - IDENTITY: VALIDATED_BY_CUSTOMER      │                               │
│  │    - ADDRESS: VALIDATED_BY_CUSTOMER       │                               │
│  │    - FINANCIAL_SITUATION: UNDER_REVIEW    │                               │
│  │    - RISK_ASSESSMENT: UNDER_REVIEW        │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Authentication:                                                              │
│  ┌──────────────────────────────────────────┐                               │
│  │  👮 KYC Officer: officer.john.doe@bank.com│                               │
│  │  ✅ Permissions: MANUAL_UPDATE            │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Manual Update 1:                                                             │
│  ┌──────────────────────────────────────────┐                               │
│  │  ✏️  FINANCIAL_SITUATION                  │                               │
│  │     UNDER_REVIEW → ESCALATED_TO_COMPLIANCE│                               │
│  │                                            │                               │
│  │  📝 Event Logged:                         │                               │
│  │    • changedBy: officer.john.doe@bank.com │                               │
│  │    • reason: MANUAL_OVERRIDE              │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Manual Update 2:                                                             │
│  ┌──────────────────────────────────────────┐                               │
│  │  ✏️  RISK_ASSESSMENT                      │                               │
│  │     UNDER_REVIEW → VALIDATED              │                               │
│  │                                            │                               │
│  │  ✅ All blocks now in final statuses      │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
│  Final State:                                                                 │
│  ┌──────────────────────────────────────────┐                               │
│  │  📊 Review Status: COMPLETED              │                               │
│  │                                            │                               │
│  │  Block Summary:                            │                               │
│  │    ✅ IDENTITY: VALIDATED_BY_CUSTOMER     │                               │
│  │    ✅ ADDRESS: VALIDATED_BY_CUSTOMER      │                               │
│  │    🟠 FINANCIAL_SITUATION: ESCALATED      │                               │
│  │    ✅ RISK_ASSESSMENT: VALIDATED          │                               │
│  │                                            │                               │
│  │  🎉 Review COMPLETED                      │                               │
│  │  📅 Duration: 3 days                      │                               │
│  │  📨 Notifications sent: 2                 │                               │
│  │  👮 Manual changes: 2                     │                               │
│  └──────────────────────────────────────────┘                               │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Flux de Données entre Scénarios

```
┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
│   SCENARIO 1    │         │   SCENARIO 2    │         │   SCENARIO 3    │
│                 │         │                 │         │                 │
│ Create Review   │────────▶│ Send Notifs     │────────▶│ Manual Updates  │
│                 │         │                 │         │                 │
└─────────────────┘         └─────────────────┘         └─────────────────┘
        │                           │                           │
        │                           │                           │
        ▼                           ▼                           ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      workflowContext (Shared State)                     │
├────────────────────────────────────────────────────────────────────────┤
│  reviewId: "REV-001"                                                    │
│  principalId: "CLIENT-A"                                                │
│  reviewStatus: "ACTIVE" → "WAITING_RESPONSE" → "COMPLETED"            │
│  isDigital: true                                                        │
│  ecStaticData: true                                                     │
│  relatedMembersCount: 4                                                 │
│  salesforceSynced: true                                                 │
│  notification85Sent: true                                               │
│  notification126Sent: true                                              │
│  blocksValidated: 2                                                     │
│  currentOfficer: "officer.john.doe@bank.com"                           │
└────────────────────────────────────────────────────────────────────────┘
```

---

## Comparaison: Mode Standard vs Mode Workflow

### Mode Standard (Scénarios Isolés)

```
Scenario A          Scenario B          Scenario C
    ↓                   ↓                   ↓
  @Before             @Before             @Before
  (reset)             (reset)             (reset)
    ↓                   ↓                   ↓
┌─────────┐         ┌─────────┐         ┌─────────┐
│ State A │         │ State B │         │ State C │
│ (vide)  │         │ (vide)  │         │ (vide)  │
└─────────┘         └─────────┘         └─────────┘
    ↓                   ↓                   ↓
  Execute             Execute             Execute
    ↓                   ↓                   ↓
  @After              @After              @After

❌ Pas de partage d'état
✅ Scénarios indépendants
✅ Parallélisable
```

### Mode Workflow (Scénarios Enchaînés)

```
Scenario 1          Scenario 2          Scenario 3
    ↓                   ↓                   ↓
  @Before             @Before             @Before
  (NO reset)          (NO reset)          (NO reset)
    ↓                   ↓                   ↓
┌─────────┐         ┌─────────┐         ┌─────────┐
│ State 1 │────────▶│ State 2 │────────▶│ State 3 │
│ (vide)  │         │ (State1)│         │ (State2)│
└─────────┘         └─────────┘         └─────────┘
    ↓                   ↓                   ↓
  Execute             Execute             Execute
    ↓                   ↓                   ↓
  @After              @After              @After

✅ État partagé et cumulatif
✅ Workflow end-to-end
❌ Pas parallélisable (ordre requis)
```

---

## Configuration Technique

### Tag `@no-reset`

```gherkin
@kyc @workflow @end-to-end @no-reset  ← Active le mode workflow
Feature: KYC Complete Workflow
```

### Hooks Configuration

```java
// CucumberHooks.java

@Before(order = 0, value = "not @no-reset")
public void resetState(Scenario scenario) {
    kycSteps.reset();  // Reset pour scénarios normaux
}

@Before(order = 0, value = "@no-reset")
public void logWorkflowScenario(Scenario scenario) {
    // Pas de reset - état préservé
}
```

### Runner Configuration

```java
// RunWorkflowTest.java

@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@workflow")
@ConfigurationParameter(key = "cucumber.execution.order", value = "defined")
```

---

## Rapport Allure Généré

Le workflow génère un rapport riche avec:

### 📊 Step 1 - Review Creation

```html
┌────────────────────────────────────────────┐
│ 📋 GIVEN: Initialize blocks                │
├────────────────────────────────────────────┤
│ 📦 Initial Block States                    │
│ ┌──────────────────────┬─────────────────┐ │
│ │ Block                │ Status          │ │
│ ├──────────────────────┼─────────────────┤ │
│ │ IDENTITY             │ UNDER_REVIEW... │ │
│ │ ADDRESS              │ UNDER_REVIEW... │ │
│ │ FINANCIAL_SITUATION  │ UNDER_REVIEW... │ │
│ │ RISK_ASSESSMENT      │ UNDER_REVIEW... │ │
│ └──────────────────────┴─────────────────┘ │
└────────────────────────────────────────────┘
```

### 📨 Step 2 - Notifications

```html
┌────────────────────────────────────────────┐
│ 📨 Notification 85                         │
├────────────────────────────────────────────┤
│ Description: Request customer documentation│
│ Review: REV-001                            │
│ Sent at: 2024-02-09T10:30:00               │
└────────────────────────────────────────────┘

┌────────────────────────────────────────────┐
│ 🔄 Blocks Transitioned to                  │
│    VALIDATED_BY_CUSTOMER                   │
├────────────────────────────────────────────┤
│ ✅ IDENTITY                                │
│ ✅ ADDRESS                                 │
└────────────────────────────────────────────┘
```

### ✏️ Step 3 - Manual Updates

```html
┌────────────────────────────────────────────┐
│ ✏️ Manual Status Change                    │
├────────────────────────────────────────────┤
│ Block: FINANCIAL_SITUATION                 │
│ Old: 🔵 UNDER_REVIEW_BY_IHUB               │
│ New: 🟠 ESCALATED_TO_COMPLIANCE            │
│ Changed by: officer.john.doe@bank.com      │
└────────────────────────────────────────────┘
```

### 🎯 Final Summary

```html
┌────────────────────────────────────────────────────────┐
│      🎯 Workflow Complete - Summary Report             │
├────────────────────────────────────────────────────────┤
│ Metric                       │ Value                   │
├──────────────────────────────┼─────────────────────────┤
│ Total blocks                 │ 4                       │
│ Validated by customer        │ 2                       │
│ Escalated to compliance      │ 1                       │
│ Validated by officer         │ 1                       │
│ Review duration (days)       │ 3                       │
│ Notifications sent           │ 2                       │
└──────────────────────────────┴─────────────────────────┘

✅ Workflow Status: COMPLETED
📋 Review ID: REV-001
👤 Principal ID: CLIENT-A
👮 Last Officer: officer.john.doe@bank.com
```

---

## Exécution

```bash
# Lancer le workflow complet
mvn clean test -Dtest=RunWorkflowTest

# Générer et voir le rapport Allure
allure serve target/allure-results
```

Le rapport Allure montrera les 3 scénarios enchaînés avec l'état partagé visible à chaque étape!
