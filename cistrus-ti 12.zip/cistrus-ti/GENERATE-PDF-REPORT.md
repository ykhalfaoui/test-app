# 📄 How to Generate Allure Report in PDF

## Quick Start (3 steps)

### Step 1: Run the workflow tests
```bash
mvn clean test -Dtest=RunWorkflowTest
```

### Step 2: Generate the PDF using the script
```bash
chmod +x generate-allure-pdf.sh
./generate-allure-pdf.sh
```

This will:
- Generate the HTML Allure report
- Open it in your browser
- Show instructions for manual PDF export

### Step 3: Save as PDF from browser
When the report opens in your browser:
1. Press `Cmd+P` (Mac) or `Ctrl+P` (Windows/Linux)
2. Select "Save as PDF" as destination
3. Recommended settings:
   - Orientation: **Landscape**
   - Margins: **None** or **Minimal**
   - Scale: **80-90%**
4. Click **Save**

---

## Alternative: Automated PDF Generation

If you want to automate the PDF conversion without manual browser steps:

### Option 1: wkhtmltopdf (Recommended)

**Install:**
```bash
# Mac
brew install wkhtmltopdf

# Linux
sudo apt-get install wkhtmltopdf
```

**Generate PDF:**
```bash
# First generate HTML report
allure generate target/allure-results --clean -o target/allure-report

# Convert to PDF
wkhtmltopdf -O Landscape target/allure-report/index.html allure-report.pdf
```

### Option 2: Playwright (headless browser)

**Install:**
```bash
npm install -g playwright
npx playwright install chromium
```

**Generate PDF:**
```bash
# First generate HTML report
allure generate target/allure-results --clean -o target/allure-report

# Convert to PDF
npx playwright pdf target/allure-report/index.html allure-report.pdf --landscape
```

### Option 3: Allure PDF Plugin

Install the official Allure PDF plugin from:
https://github.com/viclovsky/allure-pdf-plugin

Add to your `pom.xml`:
```xml
<plugin>
    <groupId>io.qameta.allure</groupId>
    <artifactId>allure-maven</artifactId>
    <version>2.32.0</version>
    <configuration>
        <reportVersion>2.32.0</reportVersion>
        <resultsDirectory>${project.build.directory}/allure-results</resultsDirectory>
        <plugins>
            <plugin>
                <groupId>com.github.viclovsky.allure</groupId>
                <artifactId>allure-pdf-plugin</artifactId>
                <version>1.0.0</version>
            </plugin>
        </plugins>
    </configuration>
</plugin>
```

---

## Complete Workflow (Test → PDF)

Single command to run tests and open report:
```bash
mvn clean test -Dtest=RunWorkflowTest && allure serve target/allure-results
```

Then save as PDF from the browser (Cmd+P → Save as PDF).

---

## What's included in the report?

Your Allure report includes:
- ✅ Scenario summaries with pass/fail status
- 📊 Block state transitions with colored status icons
- 🏷️ Tags for each scenario (@workflow, @review-creation, etc.)
- 📝 Step-by-step execution details
- 🔍 Workflow context values (reviewId, principalId, etc.)
- 📈 Overall test statistics
- 🎨 Color-coded results (green=passed, red=failed, yellow=pending)

The report is business-readable with French terminology and visual indicators.

---

## Troubleshooting

**Problem:** Report is empty or missing scenarios
**Solution:** Make sure tests ran successfully first:
```bash
mvn clean test -Dtest=RunWorkflowTest
# Should see: BUILD SUCCESS
```

**Problem:** wkhtmltopdf crashes or produces blank PDF
**Solution:** Try adding these flags:
```bash
wkhtmltopdf -O Landscape --enable-local-file-access --javascript-delay 2000 \
  target/allure-report/index.html allure-report.pdf
```

**Problem:** PDF doesn't include all graphs/charts
**Solution:** Use Playwright instead (it has better JavaScript support):
```bash
npx playwright pdf target/allure-report/index.html allure-report.pdf \
  --landscape --wait-for-timeout 3000
```
