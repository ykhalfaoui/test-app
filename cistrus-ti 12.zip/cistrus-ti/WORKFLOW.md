# KYC Workflow - Guide d'utilisation

## 📋 Vue d'ensemble

Ce projet supporte **deux modes d'exécution** pour les tests Cucumber:

### 1. Mode Standard (Scénarios Isolés)
- Chaque scénario est **indépendant**
- État **réinitialisé** entre chaque scénario via `@Before` hook
- Utilisé par défaut pour tous les scénarios

### 2. Mode Workflow (Scénarios Enchaînés)
- Les scénarios sont **enchaînés** et partagent l'état
- **Pas de reset** entre les scénarios tagués `@no-reset`
- Permet de créer des workflows complexes end-to-end

---

## 🎯 Workflow End-to-End KYC

Le workflow `KycWorkflow.feature` démontre un flux complet:

```
Step 1: Création Review (DDR Hit)
    ↓
Step 2: Envoi Notifications (85 → 126)
    ↓
Step 3: Changements Manuels (KYC Officer)
    ↓
Résultat: Review Complète
```

### Structure du Workflow

```gherkin
@kyc @workflow @end-to-end @no-reset
Feature: KYC Complete Workflow - End to End

  @workflow-step-1 @review-creation
  Scenario: Step 1 - Create a KYC Review for digital client
    # Crée une review avec blocs pour client digital + 4 relations
    # État persisté: reviewId, principalId, blocks

  @workflow-step-2 @notifications
  Scenario: Step 2 - Send notification 85 and 126 for the review
    # Utilise la review créée en Step 1
    # Envoie notification 85 (demande docs)
    # Envoie notification 126 (validation client)
    # État persisté: notifications sent, blocks updated

  @workflow-step-3 @manual-update
  Scenario: Step 3 - KYC Officer manually changes block statuses
    # Utilise la review de Step 1/2
    # KYC Officer change statuts manuellement
    # Marque la review comme COMPLETED
```

---

## 🚀 Exécution

### Option 1: Tous les tests (standard + workflow)

```bash
mvn clean test
```

### Option 2: Uniquement les workflows

```bash
mvn clean test -Dtest=RunWorkflowTest
```

### Option 3: Filtrer par tags

```bash
# Seulement les scénarios critiques
mvn test -Dcucumber.filter.tags="@critical"

# Seulement les workflows
mvn test -Dcucumber.filter.tags="@workflow"

# Review creation uniquement
mvn test -Dcucumber.filter.tags="@review-creation"
```

---

## 📊 Rapport Allure

Après l'exécution:

```bash
# Générer et ouvrir le rapport
allure serve target/allure-results
```

Le rapport montrera:

- ✅ **Summary du workflow complet** avec métriques
- 📊 **État des blocs** à chaque étape
- 🔄 **Transitions de statut** avec couleurs
- 📨 **Notifications envoyées**
- 👮 **Actions manuelles du KYC Officer**
- 📈 **Contexte workflow** persisté entre scénarios

---

## 🔧 Configuration Technique

### Tag `@no-reset`

Dans [CucumberHooks.java](src/test/java/com/monentreprise/steps/cucumber/CucumberHooks.java):

```java
@Before(order = 0, value = "not @no-reset")
public void resetState(Scenario scenario) {
    // Reset pour scénarios normaux
    kycSteps.reset();
}

@Before(order = 0, value = "@no-reset")
public void logWorkflowScenario(Scenario scenario) {
    // Pas de reset - état préservé
}
```

### Ordre d'exécution garanti

Dans [RunWorkflowTest.java](src/test/java/com/monentreprise/RunWorkflowTest.java):

```java
@ConfigurationParameter(key = "cucumber.execution.order", value = "defined")
```

Les scénarios s'exécutent **dans l'ordre défini** dans le fichier `.feature`.

---

## 📝 Créer votre propre Workflow

### Étape 1: Créer votre feature avec `@no-reset`

```gherkin
@my-workflow @no-reset
Feature: Mon Workflow Personnalisé

  @step-1
  Scenario: Première étape
    Given je crée des données
    Then le contexte contient "dataId"

  @step-2
  Scenario: Deuxième étape
    Given je récupère "dataId" du contexte
    When je modifie les données
    Then les données sont mises à jour
```

### Étape 2: Créer les step definitions avec état partagé

```java
public class MyWorkflowSteps {

    // État partagé entre scénarios (ne sera pas reset)
    private final Map<String, Object> workflowContext = new HashMap<>();

    @Given("je crée des données")
    public void jeCreerDesDonnees() {
        String dataId = "DATA-" + System.currentTimeMillis();
        workflowContext.put("dataId", dataId);
    }

    @Given("je récupère {string} du contexte")
    public void jeRecupereDuContexte(String key) {
        String dataId = (String) workflowContext.get(key);
        assertNotNull(dataId, "dataId should exist in context");
    }
}
```

### Étape 3: Créer un runner dédié (optionnel)

```java
@Suite
@SelectClasspathResource("com/monentreprise/features")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@my-workflow")
@ConfigurationParameter(key = "cucumber.execution.order", value = "defined")
public class RunMyWorkflowTest {
}
```

---

## ⚠️ Bonnes Pratiques

### ✅ À FAIRE

1. **Toujours tagger avec `@no-reset`** pour les workflows enchaînés
2. **Vérifier les prérequis** au début de chaque step (ex: review existe)
3. **Logger l'état** dans le contexte pour traçabilité
4. **Utiliser Allure attachments** pour visualiser les transitions
5. **Tester le workflow complet** en une seule exécution

### ❌ À ÉVITER

1. **Ne pas mélanger** scénarios `@no-reset` et scénarios normaux dans la même feature
2. **Ne pas supposer** l'ordre si pas configuré avec `cucumber.execution.order=defined`
3. **Ne pas oublier** de vérifier les prérequis (évite les NPE si step précédente fail)
4. **Ne pas hardcoder** les IDs - utiliser le contexte partagé

---

## 🎨 Exemple Complet: Workflow KYC

Voir:
- **Feature**: [KycWorkflow.feature](src/test/resources/com/monentreprise/features/KycWorkflow.feature)
- **Steps**: [KycWorkflowCucumberSteps.java](src/test/java/com/monentreprise/steps/cucumber/KycWorkflowCucumberSteps.java)
- **Runner**: [RunWorkflowTest.java](src/test/java/com/monentreprise/RunWorkflowTest.java)

Exécution:

```bash
mvn clean test -Dtest=RunWorkflowTest
allure serve target/allure-results
```

Vous verrez dans Allure:
- 📋 Review créée avec ID dynamique
- 📨 Notifications 85 et 126 envoyées
- 👮 KYC Officer modifie les statuts
- 🎉 Review marquée COMPLETED
- 📊 Summary final avec toutes les métriques

---

## 🆘 Troubleshooting

### Problème: État non partagé entre scénarios

**Cause**: Tag `@no-reset` manquant

**Solution**: Ajouter `@no-reset` au niveau Feature

```gherkin
@workflow @no-reset  ← IMPORTANT
Feature: Mon Workflow
```

### Problème: Scénarios s'exécutent dans le mauvais ordre

**Cause**: Ordre d'exécution non configuré

**Solution**: Ajouter dans le runner:

```java
@ConfigurationParameter(key = "cucumber.execution.order", value = "defined")
```

### Problème: NullPointerException dans Step 2/3

**Cause**: Step 1 a échoué, donc contexte vide

**Solution**: Toujours vérifier les prérequis:

```java
@Given("la review {string} existe")
public void laReviewExiste(String reviewId) {
    assertNotNull(reviewId, "Review ID requis");
    assertEquals(currentReviewId, reviewId, "Review doit exister");
}
```

---

## 📚 Ressources

- [Cucumber Documentation](https://cucumber.io/docs/cucumber/)
- [Cucumber Hooks](https://cucumber.io/docs/cucumber/api/#hooks)
- [Allure Cucumber Integration](https://docs.qameta.io/allure/#_cucumber_jvm)
- [JUnit Platform Suite](https://junit.org/junit5/docs/current/user-guide/#running-tests-junit-platform-runner)
