#!/bin/bash

# 🎯 KYC Workflow Test Execution with Allure Report
# This script executes the workflow tests and generates the Allure report

echo "════════════════════════════════════════════════════════════"
echo "🎯 KYC Workflow Test Execution"
echo "════════════════════════════════════════════════════════════"
echo ""

# Step 1: Clean previous results
echo "📋 Step 1: Cleaning previous test results..."
rm -rf target/allure-results
rm -rf target/surefire-reports
echo "✅ Cleanup complete"
echo ""

# Step 2: Execute workflow tests
echo "📋 Step 2: Executing workflow tests..."
echo "   Running: mvn clean test -Dtest=RunWorkflowTest"
echo ""

mvn clean test -Dtest=RunWorkflowTest

TEST_EXIT_CODE=$?

echo ""
echo "════════════════════════════════════════════════════════════"

if [ $TEST_EXIT_CODE -eq 0 ]; then
    echo "✅ Workflow tests PASSED"
else
    echo "❌ Workflow tests FAILED (exit code: $TEST_EXIT_CODE)"
fi

echo "════════════════════════════════════════════════════════════"
echo ""

# Step 3: Generate Allure report
echo "📋 Step 3: Generating Allure report..."

if command -v allure &> /dev/null; then
    echo "   Allure CLI found, generating report..."

    # Check if allure-results exists
    if [ -d "target/allure-results" ]; then
        echo "   Found test results in target/allure-results"
        echo ""
        echo "🚀 Opening Allure report in browser..."
        echo ""

        allure serve target/allure-results
    else
        echo "⚠️  No test results found in target/allure-results"
        echo "   Tests may not have generated Allure results"
    fi
else
    echo "⚠️  Allure CLI not found"
    echo ""
    echo "To install Allure:"
    echo "  Mac:     brew install allure"
    echo "  Windows: scoop install allure"
    echo ""
    echo "Or download from: https://github.com/allure-framework/allure2/releases"
    echo ""
    echo "Alternative: Use Maven plugin"
    echo "  mvn allure:serve"
fi

echo ""
echo "════════════════════════════════════════════════════════════"
echo "🎉 Script completed"
echo "════════════════════════════════════════════════════════════"
