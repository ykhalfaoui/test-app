# 🚀 Quick Start - Workflow KYC

## Exécution Rapide (1 commande)

### Mac/Linux

```bash
# Rendre le script exécutable (une seule fois)
chmod +x run-workflow-with-report.sh

# Lancer les tests + rapport Allure
./run-workflow-with-report.sh
```

### Windows

```cmd
# Double-cliquer sur le fichier ou exécuter dans cmd:
run-workflow-with-report.bat
```

---

## Exécution Manuel (étape par étape)

Si vous préférez lancer manuellement:

### Étape 1: Lancer les tests workflow

```bash
mvn clean test -Dtest=RunWorkflowTest
```

**Ce que fait cette commande:**
- ✅ Nettoie les anciens résultats
- ✅ Exécute uniquement les scénarios tagués `@workflow`
- ✅ Génère les résultats Allure dans `target/allure-results`

**Sortie attendue:**

```
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.monentreprise.RunWorkflowTest
════════════════════════════════════════════════════════════
▶ Starting scenario: Step 1 - Create a KYC Review for digital client
  Tags: [@workflow-step-1, @review-creation, ...]
  Mode: WORKFLOW (no reset - state preserved)
════════════════════════════════════════════════════════════

... (exécution des 3 scénarios) ...

[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
```

### Étape 2: Générer et ouvrir le rapport Allure

**Option A - Allure CLI (Recommandé):**

```bash
allure serve target/allure-results
```

Le rapport s'ouvre automatiquement dans votre navigateur à `http://localhost:random-port`

**Option B - Maven Plugin:**

```bash
mvn allure:serve
```

**Option C - Générer HTML statique:**

```bash
allure generate target/allure-results --clean -o target/allure-report
open target/allure-report/index.html    # Mac
start target/allure-report/index.html   # Windows
```

---

## 📊 Ce que vous verrez dans le rapport

### 1. Overview (Vue d'ensemble)

```
┌──────────────────────────────────────────┐
│ 📊 Test Results Overview                 │
├──────────────────────────────────────────┤
│ Total: 3                                  │
│ ✅ Passed: 3                             │
│ ❌ Failed: 0                             │
│ ⏭️  Skipped: 0                           │
│ Success Rate: 100%                        │
└──────────────────────────────────────────┘
```

### 2. Suites (Par runner)

```
com.monentreprise.RunWorkflowTest
  └── KYC Complete Workflow - End to End
      ├── ✅ Step 1 - Create a KYC Review for digital client
      ├── ✅ Step 2 - Send notification 85 and 126 for the review
      └── ✅ Step 3 - KYC Officer manually changes block statuses
```

### 3. Behaviors (Vue BDD)

```
@kyc
  └── @workflow
      └── @end-to-end
          ├── @workflow-step-1
          ├── @workflow-step-2
          └── @workflow-step-3
```

### 4. Packages (Par package Java)

```
com.monentreprise.steps.cucumber
  └── KycWorkflowCucumberSteps
      ├── 📋 GIVEN: Initialize blocks
      ├── 🧑 Setup principal actor
      ├── 🚩 Set ecStaticData flag
      ├── 👨‍👩‍👧‍👦 Add related parties
      ├── 🎯 Trigger DDR Hit
      ├── 📨 Send notification 85
      ├── 📨 Send notification 126
      ├── ✏️ Manual update
      └── 🎉 Review COMPLETED
```

### 5. Attachments (Par scénario)

Chaque scénario aura des attachments HTML riches:

**Step 1:**
- 📦 Initial Block States (tableau)
- 👥 Related Parties (tableau)
- 🎯 DDR Hit (card)
- ☁️ Salesforce Sync (card)
- 🔍 Workflow Context (tableau)

**Step 2:**
- 📨 Notification 85 (card avec description)
- 📨 Notification 126 (card avec description)
- 🔄 Blocks Transitioned (tableau coloré)
- ✓ Blocks Unchanged (tableau)
- 🔄 Context Updated (confirmation)

**Step 3:**
- 👮 Officer Authentication (card)
- ✏️ Manual Status Change × 2 (cards avec old/new status)
- 📝 Status Change Event (tableau)
- 📊 All Blocks - Final Statuses (tableau)
- 🎯 Final Workflow Summary (grand tableau avec métriques)

### 6. Timeline

Vous verrez l'exécution chronologique:

```
10:30:00 | Step 1 starts (WORKFLOW mode - no reset)
10:30:05 | Step 1 completes (5s)
10:30:05 | Step 2 starts (WORKFLOW mode - no reset)
10:30:08 | Step 2 completes (3s)
10:30:08 | Step 3 starts (WORKFLOW mode - no reset)
10:30:12 | Step 3 completes (4s)
```

---

## 🔍 Navigation dans le rapport

### Filtrer par tags

Utilisez les filtres en haut à droite:
- Tags: `@workflow`, `@review-creation`, `@notifications`, `@manual-update`
- Status: `passed`, `failed`, `broken`
- Severity: `blocker`, `critical`, `normal`

### Voir les détails d'un scénario

1. Cliquez sur le nom du scénario
2. Vous verrez:
   - ⏱️ Durée d'exécution
   - 🏷️ Tags
   - 📋 Steps détaillés (Given/When/Then)
   - 📎 Attachments HTML
   - 📊 Parameters
   - 🔗 Links (si configurés)

### Télécharger le rapport

En bas à droite du rapport Allure, cliquez sur "Export" pour:
- 📥 Télécharger le rapport complet (ZIP)
- 📄 Générer un PDF (avec plugin)

---

## ⚡ Commandes Utiles

### Tests uniquement (sans rapport)

```bash
mvn clean test -Dtest=RunWorkflowTest
```

### Tests + rapport en une commande

```bash
mvn clean test -Dtest=RunWorkflowTest && allure serve target/allure-results
```

### Tests en parallèle (plus rapide)

```bash
mvn clean test -Dtest=RunWorkflowTest -Djunit.jupiter.execution.parallel.enabled=true
```

**Note:** Les workflows ne peuvent PAS être parallélisés car ils partagent l'état!

### Tests avec logs détaillés

```bash
mvn clean test -Dtest=RunWorkflowTest -X
```

### Nettoyer tout et recommencer

```bash
mvn clean
rm -rf target/allure-results target/surefire-reports
mvn test -Dtest=RunWorkflowTest
```

---

## 🐛 Troubleshooting

### Problème: "Allure command not found"

**Solution:**

```bash
# Mac
brew install allure

# Windows (Scoop)
scoop install allure

# Windows (Manuel)
# Télécharger depuis https://github.com/allure-framework/allure2/releases
# Décompresser et ajouter bin/ au PATH
```

**Alternative:** Utiliser le plugin Maven

```bash
mvn allure:serve
```

### Problème: "No tests were found"

**Cause:** Le tag `@workflow` n'est pas trouvé

**Solution:** Vérifier que [KycWorkflow.feature](src/test/resources/com/monentreprise/features/KycWorkflow.feature) existe et contient `@workflow`

```bash
# Lister les features
ls -la src/test/resources/com/monentreprise/features/

# Vérifier le contenu
head -5 src/test/resources/com/monentreprise/features/KycWorkflow.feature
```

### Problème: "Tests failed"

**Solution:** Voir les logs détaillés

```bash
# Logs dans la console
mvn clean test -Dtest=RunWorkflowTest -X

# Logs dans le fichier
cat target/surefire-reports/*.txt
```

### Problème: "Port already in use" (Allure)

**Cause:** Un serveur Allure tourne déjà

**Solution:**

```bash
# Trouver le process
lsof -i :random-port

# Tuer le process
kill -9 <PID>

# Ou utiliser un port différent
allure serve target/allure-results -p 8081
```

---

## 📚 Ressources

- [WORKFLOW.md](WORKFLOW.md) - Guide complet du workflow
- [docs/workflow-diagram.md](docs/workflow-diagram.md) - Diagrammes détaillés
- [Allure Documentation](https://docs.qameta.io/allure/)
- [Cucumber Documentation](https://cucumber.io/docs/cucumber/)

---

**Dernière mise à jour:** Février 2026
