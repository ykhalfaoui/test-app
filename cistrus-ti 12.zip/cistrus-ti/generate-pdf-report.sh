#!/bin/bash
# Génère un rapport PDF à partir des résultats Allure
# Prérequis: Allure CLI et allure-pdf-plugin doivent être installés

echo "📄 Génération du rapport PDF..."

# Vérifie si la commande allure est disponible
if ! command -v allure &> /dev/null; then
    echo "❌ Erreur: Allure CLI n'est pas installé."
    echo "Veuillez installer Allure: brew install allure"
    exit 1
fi

# Génération du rapport standard
echo "Génération du rapport HTML..."
./mvnw allure:report

# Tentative de génération PDF (si le plugin est installé sur le CLI systeme)
# Note: Le plugin PDF n'est pas standard, c'est une extension
echo "Tentative de conversion PDF..."
if allure plugin list | grep -q "pdf"; then
    allure generate target/allure-results --clean -o target/allure-report
    # La commande exacte dépend de la version du plugin, souvent c'est automatique ou via une option
    echo "✅ Rapport généré dans target/allure-report"
else
    echo "⚠️ Plugin 'allure-pdf-plugin' non détecté."
    echo "Pour le PDF, veuillez installer le plugin via Allure CLI ou utiliser une image Docker."
    echo "Rapport HTML disponible dans target/site/allure-maven-plugin/index.html"
fi
