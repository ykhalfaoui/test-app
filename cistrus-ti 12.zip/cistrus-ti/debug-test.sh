#!/bin/bash

echo "🔍 Running workflow tests with debug logging..."
echo ""

./mvnw clean test -Dtest=RunWorkflowTest 2>&1 | tee test-debug.log

echo ""
echo "════════════════════════════════════════════════════════════"
echo "📊 Debug Output:"
echo "════════════════════════════════════════════════════════════"
echo ""

# Extract debug lines
grep "🔍 DEBUG" test-debug.log

echo ""
echo "════════════════════════════════════════════════════════════"

if grep -q "BUILD SUCCESS" test-debug.log; then
    echo "✅ Tests PASSED!"
else
    echo "❌ Tests FAILED!"
    echo ""
    echo "Error summary:"
    grep "AssertionFailedError" test-debug.log | head -5
fi

echo ""
echo "Full debug log saved to: test-debug.log"
