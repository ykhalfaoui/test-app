package com.monentreprise;

import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import static io.cucumber.junit.platform.engine.Constants.GLUE_PROPERTY_NAME;
import static io.cucumber.junit.platform.engine.Constants.PLUGIN_PROPERTY_NAME;
import static io.cucumber.junit.platform.engine.Constants.FILTER_TAGS_PROPERTY_NAME;

/**
 * Dedicated test runner for KYC Workflow end-to-end scenarios.
 *
 * This runner executes only workflow scenarios tagged with @workflow.
 * These scenarios share state across steps and build on each other
 * without reset between them (thanks to @no-reset tag).
 *
 * To run only workflow tests:
 * mvn test -Dtest=RunWorkflowTest
 *
 * To run and generate Allure report:
 * mvn clean test -Dtest=RunWorkflowTest
 * allure serve target/allure-results
 */
@Suite
@SelectClasspathResource("com/monentreprise/features")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.monentreprise.steps.cucumber")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "pretty, io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm")
@ConfigurationParameter(key = "cucumber.object-factory", value = "org.citrusframework.cucumber.backend.spring.CitrusSpringObjectFactory")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@workflow")
@ConfigurationParameter(key = "cucumber.execution.order", value = "defined")
public class RunWorkflowTest {
}
