package com.monentreprise.steps.cucumber;

import com.monentreprise.steps.kyc.KycSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.monentreprise.steps.cucumber.AllureReportHelper.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Cucumber steps for KycWorkflow feature.
 * Manages end-to-end workflow state across multiple scenarios without reset.
 */
public class KycWorkflowCucumberSteps {

    @Autowired
    private KycSteps kycSteps;

    // Use singleton instance instead of Spring bean to ensure persistence across scenarios
    private final WorkflowContext workflowContext = WorkflowContext.getInstance();

    private String currentReviewId;
    private String currentPrincipalId;
    private String currentOfficer;
    private final Map<String, String> blockStatusHistory = new HashMap<>();
    private int relatedMembersCount = 0;

    // ════════════════════════════════════════════════════════════
    // STEP 1: Review Creation
    // ════════════════════════════════════════════════════════════

    @Given("a principal actor who is {string}")
    public void aPrincipalActorWhoIs(String digitalStatus) {
        Allure.step("🧑 Setup principal actor - Digital: " + digitalStatus, () -> {
            boolean isDigital = "digital".equalsIgnoreCase(digitalStatus);
            currentPrincipalId = "CLIENT-" + System.currentTimeMillis();

            workflowContext.put("isDigital", isDigital);
            workflowContext.put("principalId", currentPrincipalId);

            String html = String.format(
                "<div style='background:#e3f2fd;padding:12px;border-left:4px solid #1976d2;'>" +
                "<b>🧑 Principal Actor Created</b><br/>" +
                "ID: <code>%s</code><br/>" +
                "Digital: <b>%s</b> %s" +
                "</div>",
                currentPrincipalId,
                isDigital ? "YES" : "NO",
                isDigital ? "✅" : "❌"
            );
            Allure.addAttachment("Principal Actor", "text/html", html, ".html");
        });
    }

    @Given("the principal actor has ecStaticData flag set to {string}")
    public void thePrincipalActorHasEcStaticDataFlagSetTo(String flag) {
        Allure.step("🚩 Set ecStaticData flag: " + flag, () -> {
            boolean ecStaticData = "true".equalsIgnoreCase(flag);
            workflowContext.put("ecStaticData", ecStaticData);

            // Note: Allure.parameter() causes UnsupportedOperationException with Citrus
            System.out.println("  ecStaticData flag set to: " + ecStaticData);
        });
    }

    @Given("the actor has the following related parties:")
    public void theActorHasTheFollowingRelatedParties(DataTable dataTable) {
        Allure.step("👨‍👩‍👧‍👦 Add related parties", () -> {
            List<Map<String, String>> relations = dataTable.asMaps(String.class, String.class);

            relatedMembersCount = 0;
            StringBuilder html = new StringBuilder();
            html.append("<table style='border-collapse:collapse;width:100%;'>");
            html.append("<tr style='background:#4caf50;color:white;'>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>Relation Type</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>Count</th>");
            html.append("</tr>");

            for (Map<String, String> relation : relations) {
                String relationType = relation.get("Relation");
                int count = Integer.parseInt(relation.get("Count"));
                relatedMembersCount += count;

                html.append("<tr style='background:#e8f5e9;'>");
                html.append("<td style='padding:8px;border:1px solid #ddd;'>").append(relationType).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;text-align:center;'><b>").append(count).append("</b></td>");
                html.append("</tr>");
            }

            html.append("<tr style='background:#c8e6c9;font-weight:bold;'>");
            html.append("<td style='padding:8px;border:1px solid #ddd;'>TOTAL</td>");
            html.append("<td style='padding:8px;border:1px solid #ddd;text-align:center;'>").append(relatedMembersCount).append("</td>");
            html.append("</tr>");
            html.append("</table>");

            workflowContext.put("relatedMembersCount", relatedMembersCount);
            Allure.addAttachment("Related Parties", "text/html", html.toString(), ".html");
        });
    }

    @When("a DDR hit is triggered for the principal actor")
    public void aDDRHitIsTriggeredForThePrincipalActor() {
        Allure.step("🎯 Trigger DDR Hit", () -> {
            currentReviewId = "REV-" + String.format("%03d", (int)(Math.random() * 1000));
            workflowContext.put("reviewId", currentReviewId);
            workflowContext.put("reviewStatus", "ACTIVE");
            workflowContext.put("hitTriggeredAt", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

            // DEBUG: Log context state
            System.out.println("🔍 DEBUG - After DDR hit:");
            System.out.println("  currentReviewId: " + currentReviewId);
            System.out.println("  workflowContext.reviewId: " + workflowContext.get("reviewId"));
            System.out.println("  workflowContext size: " + workflowContext.size());
            System.out.println("  workflowContext instance: " + System.identityHashCode(workflowContext));

            String html = String.format(
                "<div style='background:#fff3e0;padding:12px;border-left:4px solid #ff9800;'>" +
                "<b>🎯 DDR Hit Triggered</b><br/>" +
                "Review ID: <code style='background:#ffe0b2;padding:2px 6px;border-radius:3px;'>%s</code><br/>" +
                "Principal: <code>%s</code><br/>" +
                "Status: <span style='color:#2e7d32;'>✅ ACTIVE</span>" +
                "</div>",
                currentReviewId,
                currentPrincipalId
            );
            Allure.addAttachment("DDR Hit", "text/html", html, ".html");
        });
    }

    @Then("a new review should be created in version {int}")
    public void aNewReviewShouldBeCreatedInVersion(Integer version) {
        Allure.step("📋 Verify review creation - Version " + version, () -> {
            assertNotNull(currentReviewId, "Review ID should be set");
            workflowContext.put("reviewVersion", version);

            System.out.println("  Review Version: " + version);
            assertEquals("ACTIVE", workflowContext.get("reviewStatus"), "Review should be ACTIVE");
        });
    }

    @Then("the following blocks should be created for the principal actor:")
    public void theFollowingBlocksShouldBeCreatedForThePrincipalActor(DataTable dataTable) {
        Allure.step("📦 Create blocks for principal actor", () -> {
            List<Map<String, String>> blocks = dataTable.asMaps(String.class, String.class);

            for (Map<String, String> blockRow : blocks) {
                String block = blockRow.get("Block");
                String status = blockRow.get("Status");

                String blockKey = currentPrincipalId + ":" + block;
                kycSteps.setBlockStatus(blockKey, status);
                blockStatusHistory.put(blockKey, status);
            }

            String html = buildBlockStatusTable(
                "📦 Principal Actor Blocks",
                "#1976d2",
                blocks,
                "Block",
                "Status"
            );
            Allure.addAttachment("Principal Blocks Created", "text/html", html, ".html");
        });
    }

    @Then("the following blocks should be created for all {int} related members")
    public void theFollowingBlocksShouldBeCreatedForAllRelatedMembers(Integer count) {
        Allure.step("👥 Create blocks for " + count + " related members", () -> {
            assertEquals(relatedMembersCount, count, "Related members count mismatch");

            workflowContext.put("totalBlocksCreated", 4 + (relatedMembersCount * 4));

            String html = String.format(
                "<div style='background:#e8f5e9;padding:12px;border-left:4px solid #4caf50;'>" +
                "<b>👥 Related Members Blocks</b><br/>" +
                "Members: <b>%d</b><br/>" +
                "Blocks per member: <b>4</b><br/>" +
                "Total blocks: <b>%d</b> (Principal: 4 + Members: %d)" +
                "</div>",
                count,
                4 + (count * 4),
                count * 4
            );
            Allure.addAttachment("Related Members Blocks", "text/html", html, ".html");
        });
    }

    @Then("the review and blocks are synchronized in Salesforce")
    public void theReviewAndBlocksAreSynchronizedInSalesforce() {
        Allure.step("☁️ Salesforce synchronization", () -> {
            workflowContext.put("salesforceSynced", true);
            workflowContext.put("salesforceSyncedAt", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

            String html = "<div style='background:#e1f5fe;padding:12px;border-left:4px solid #0288d1;'>" +
                "<b>☁️ Salesforce Sync</b><br/>" +
                "Status: <span style='color:#2e7d32;'>✅ SUCCESS</span><br/>" +
                "Synced at: <code>" + workflowContext.get("salesforceSyncedAt") + "</code>" +
                "</div>";
            Allure.addAttachment("Salesforce Sync", "text/html", html, ".html");
        });
    }

    @Then("the workflow context should contain:")
    public void theWorkflowContextShouldContain(DataTable dataTable) {
        Allure.step("🔍 Verify workflow context", () -> {
            // Use asMaps to properly parse the table (avoids including headers as data)
            List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);

            // Convert list of maps to a single map
            Map<String, String> expectedContext = new HashMap<>();
            for (Map<String, String> row : rows) {
                String key = row.get("Key");
                String value = row.get("Value");
                if (key != null && value != null) {
                    expectedContext.put(key, value);
                }
            }

            // VERIFY context instead of overwriting it!
            for (Map.Entry<String, String> entry : expectedContext.entrySet()) {
                String key = entry.getKey();
                String expectedValue = entry.getValue();
                Object actualValue = workflowContext.get(key);

                // For placeholders like <any>, just verify the key exists
                if ("<any>".equals(expectedValue) || "*".equals(expectedValue)) {
                    assertNotNull(actualValue, key + " should exist in context (placeholder verification)");
                    System.out.println("  ✅ " + key + " exists in context: " + actualValue);
                } else {
                    // For specific values, verify they match
                    assertNotNull(actualValue, "Context should contain key: " + key);
                    assertEquals(expectedValue, String.valueOf(actualValue),
                        "Context value for " + key + " should match");
                    System.out.println("  ✅ " + key + " = " + actualValue + " (expected: " + expectedValue + ")");
                }
            }

            // Build HTML table with ACTUAL values from context
            StringBuilder html = new StringBuilder();
            html.append("<table style='border-collapse:collapse;width:100%;'>");
            html.append("<tr style='background:#673ab7;color:white;'>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>Context Key</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>Actual Value</th>");
            html.append("</tr>");

            for (Map.Entry<String, String> entry : expectedContext.entrySet()) {
                String key = entry.getKey();
                Object actualValue = workflowContext.get(key);
                html.append("<tr style='background:#ede7f6;'>");
                html.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>").append(key).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;'><code>")
                    .append(actualValue != null ? actualValue : "null").append("</code></td>");
                html.append("</tr>");
            }
            html.append("</table>");

            Allure.addAttachment("Workflow Context (Verified)", "text/html", html.toString(), ".html");
        });
    }

    // ════════════════════════════════════════════════════════════
    // STEP 2: Notifications
    // ════════════════════════════════════════════════════════════

    @Given("the review from workflow context exists and is {string}")
    public void theReviewFromWorkflowContextExistsAndIs(String status) {
        Allure.step("📋 Verify review from context exists - Status: " + status, () -> {
            // DEBUG: Log context state at Step 2
            System.out.println("🔍 DEBUG - Step 2 - Verify review from context:");
            System.out.println("  workflowContext size: " + workflowContext.size());
            System.out.println("  workflowContext keys: " + workflowContext.getAll().keySet());
            System.out.println("  workflowContext.reviewId: " + workflowContext.get("reviewId"));
            System.out.println("  workflowContext instance: " + System.identityHashCode(workflowContext));

            // Retrieve from context
            String contextReviewId = (String) workflowContext.get("reviewId");
            currentReviewId = contextReviewId; // Sync instance variable
            currentPrincipalId = (String) workflowContext.get("principalId"); // Also sync principal

            assertNotNull(contextReviewId, "Review ID should exist in workflow context");
            assertEquals(status, workflowContext.get("reviewStatus"), "Review status should match");

            System.out.println("  Review ID (from context): " + contextReviewId);
            System.out.println("  Principal ID (from context): " + currentPrincipalId);
            System.out.println("  Status: " + status);
        });
    }

    @Given("the review {string} exists and is {string}")
    public void theReviewExistsAndIs(String reviewId, String status) {
        Allure.step("📋 Verify review exists: " + reviewId + " - " + status, () -> {
            // DEBUG: Log context state at Step 2
            System.out.println("🔍 DEBUG - Step 2 - Verify review exists:");
            System.out.println("  Expected reviewId: " + reviewId);
            System.out.println("  workflowContext size: " + workflowContext.size());
            System.out.println("  workflowContext keys: " + workflowContext.getAll().keySet());
            System.out.println("  workflowContext.reviewId: " + workflowContext.get("reviewId"));
            System.out.println("  workflowContext instance: " + System.identityHashCode(workflowContext));

            // Retrieve from context to ensure persistence across scenarios
            String contextReviewId = (String) workflowContext.get("reviewId");
            currentReviewId = contextReviewId; // Sync instance variable

            assertEquals(reviewId, contextReviewId, "Review ID should match context");
            assertEquals(status, workflowContext.get("reviewStatus"), "Review status should match");

            System.out.println("  Review ID: " + reviewId);
            System.out.println("  Status: " + status);
        });
    }

    @When("iHub sends notification {string} for the review")
    public void iHubSendsNotificationForTheReview(String notificationCode) {
        Allure.step("📨 Send notification " + notificationCode, () -> {
            String notificationKey = "notification" + notificationCode + "Sent";
            workflowContext.put(notificationKey, true);
            workflowContext.put(notificationKey + "At", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

            String description = getNotificationDescription(notificationCode);

            String html = String.format(
                "<div style='background:#fff9c4;padding:12px;border-left:4px solid #fbc02d;'>" +
                "<b>📨 Notification %s</b><br/>" +
                "Description: %s<br/>" +
                "Review: <code>%s</code><br/>" +
                "Sent at: <code>%s</code>" +
                "</div>",
                notificationCode,
                description,
                currentReviewId,
                workflowContext.get(notificationKey + "At")
            );
            Allure.addAttachment("Notification " + notificationCode, "text/html", html, ".html");
        });
    }

    @Then("the notification {string} should be processed")
    public void theNotificationShouldBeProcessed(String notificationCode) {
        Allure.step("✅ Verify notification " + notificationCode + " processed", () -> {
            String notificationKey = "notification" + notificationCode + "Sent";
            assertTrue((Boolean) workflowContext.get(notificationKey), "Notification " + notificationCode + " should be sent");
        });
    }

    @Then("the review status should be updated to {string}")
    public void theReviewStatusShouldBeUpdatedTo(String newStatus) {
        Allure.step("🔄 Update review status to " + newStatus, () -> {
            String oldStatus = (String) workflowContext.get("reviewStatus");
            workflowContext.put("reviewStatus", newStatus);

            String html = String.format(
                "<div style='background:#e1bee7;padding:12px;border-left:4px solid #8e24aa;'>" +
                "<b>🔄 Status Transition</b><br/>" +
                "From: <code style='background:#f3e5f5;padding:2px 6px;'>%s</code><br/>" +
                "To: <code style='background:#ce93d8;padding:2px 6px;color:white;'>%s</code>" +
                "</div>",
                oldStatus,
                newStatus
            );
            Allure.addAttachment("Status Update", "text/html", html, ".html");
        });
    }

    @Then("an email should be sent to the client")
    public void anEmailShouldBeSentToTheClient() {
        Allure.step("📧 Send email to client", () -> {
            workflowContext.put("emailSentAt", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

            String html = "<div style='background:#e0f7fa;padding:12px;border-left:4px solid #00acc1;'>" +
                "<b>📧 Email Sent</b><br/>" +
                "To: <code>client@example.com</code><br/>" +
                "Subject: Action required for KYC review<br/>" +
                "Sent at: <code>" + workflowContext.get("emailSentAt") + "</code>" +
                "</div>";
            Allure.addAttachment("Email Notification", "text/html", html, ".html");
        });
    }

    @Then("the workflow context should be updated with:")
    public void theWorkflowContextShouldBeUpdatedWith(DataTable dataTable) {
        Allure.step("🔄 Update workflow context", () -> {
            Map<String, String> updates = dataTable.asMap(String.class, String.class);

            for (Map.Entry<String, String> entry : updates.entrySet()) {
                Object value = entry.getValue();
                // Try to convert to boolean if it looks like one
                if ("true".equalsIgnoreCase(entry.getValue()) || "false".equalsIgnoreCase(entry.getValue())) {
                    value = Boolean.parseBoolean(entry.getValue());
                }
                workflowContext.put(entry.getKey(), value);
            }

            Allure.addAttachment("Context Updated", "text/html",
                "<div style='background:#c8e6c9;padding:8px;'>✅ " + updates.size() + " context entries updated</div>", ".html");
        });
    }

    @Then("the following blocks should transition to {string}:")
    public void theFollowingBlocksShouldTransitionTo(String newStatus, DataTable dataTable) {
        Allure.step("🔄 Transition blocks to " + newStatus, () -> {
            List<Map<String, String>> blocks = dataTable.asMaps(String.class, String.class);

            int transitionCount = 0;
            for (Map<String, String> blockRow : blocks) {
                String block = blockRow.get("Block");
                String blockKey = currentPrincipalId + ":" + block;
                kycSteps.setBlockStatus(blockKey, newStatus);
                blockStatusHistory.put(blockKey, newStatus);
                transitionCount++;
            }

            workflowContext.put("blocksValidated", transitionCount);

            // Convert blocks to include Status column
            List<Map<String, String>> blocksWithStatus = blocks.stream()
                .map(row -> Map.of("Block", row.get("Block"), "Status", newStatus))
                .toList();

            String html = buildBlockStatusTable(
                "🔄 Blocks Transitioned to " + newStatus,
                "#2e7d32",
                blocksWithStatus,
                "Block",
                "Status"
            );
            Allure.addAttachment("Blocks Transitioned", "text/html", html, ".html");
        });
    }

    @Then("the following blocks should remain {string}:")
    public void theFollowingBlocksShouldRemain(String status, DataTable dataTable) {
        Allure.step("✓ Verify blocks remain in " + status, () -> {
            List<Map<String, String>> blocks = dataTable.asMaps(String.class, String.class);

            for (Map<String, String> blockRow : blocks) {
                String block = blockRow.get("Block");
                String blockKey = currentPrincipalId + ":" + block;
                String currentStatus = kycSteps.getBlockStates().get(blockKey);

                if (currentStatus == null) {
                    kycSteps.setBlockStatus(blockKey, status);
                }
            }

            // Convert blocks to include Status column
            List<Map<String, String>> blocksWithStatus = blocks.stream()
                .map(row -> Map.of("Block", row.get("Block"), "Status", status))
                .toList();

            String html = buildBlockStatusTable(
                "✓ Blocks Remaining in " + status,
                "#1976d2",
                blocksWithStatus,
                "Block",
                "Status"
            );
            Allure.addAttachment("Blocks Unchanged", "text/html", html, ".html");
        });
    }

    // ════════════════════════════════════════════════════════════
    // STEP 3: Manual Updates
    // ════════════════════════════════════════════════════════════

    @Given("the review from workflow context has blocks in various statuses")
    public void theReviewFromWorkflowContextHasBlocksInVariousStatuses() {
        Allure.step("📦 Verify review from context has blocks", () -> {
            // DEBUG: Log context state at Step 3
            System.out.println("🔍 DEBUG - Step 3 - Verify review from context has blocks:");
            System.out.println("  workflowContext size: " + workflowContext.size());
            System.out.println("  workflowContext keys: " + workflowContext.getAll().keySet());
            System.out.println("  workflowContext.reviewId: " + workflowContext.get("reviewId"));
            System.out.println("  workflowContext.principalId: " + workflowContext.get("principalId"));
            System.out.println("  workflowContext instance: " + System.identityHashCode(workflowContext));

            // Retrieve from context to ensure persistence
            String contextReviewId = (String) workflowContext.get("reviewId");
            currentReviewId = contextReviewId; // Sync instance variable
            currentPrincipalId = (String) workflowContext.get("principalId"); // Sync principal too

            assertNotNull(contextReviewId, "Review ID should exist in workflow context");
            assertNotNull(currentPrincipalId, "Principal ID should exist in workflow context");
            assertTrue(kycSteps.getBlockStates().size() > 0, "Review should have blocks");

            System.out.println("  Review ID (from context): " + contextReviewId);
            System.out.println("  Principal ID (from context): " + currentPrincipalId);
            System.out.println("  Blocks count: " + kycSteps.getBlockStates().size());
        });
    }

    @Given("the review {string} has blocks in various statuses")
    public void theReviewHasBlocksInVariousStatuses(String reviewId) {
        Allure.step("📦 Verify review has blocks", () -> {
            // DEBUG: Log context state at Step 3
            System.out.println("🔍 DEBUG - Step 3 - Verify review has blocks:");
            System.out.println("  Expected reviewId: " + reviewId);
            System.out.println("  workflowContext size: " + workflowContext.size());
            System.out.println("  workflowContext keys: " + workflowContext.getAll().keySet());
            System.out.println("  workflowContext.reviewId: " + workflowContext.get("reviewId"));
            System.out.println("  workflowContext.principalId: " + workflowContext.get("principalId"));
            System.out.println("  workflowContext instance: " + System.identityHashCode(workflowContext));

            // Retrieve from context to ensure persistence
            String contextReviewId = (String) workflowContext.get("reviewId");
            currentReviewId = contextReviewId; // Sync instance variable
            currentPrincipalId = (String) workflowContext.get("principalId"); // Sync principal too

            assertEquals(reviewId, contextReviewId, "Review ID should match context");
            assertTrue(kycSteps.getBlockStates().size() > 0, "Review should have blocks");

            System.out.println("  Blocks count: " + kycSteps.getBlockStates().size());
        });
    }

    @Given("the KYC Officer is authenticated as {string}")
    public void theKYCOfficerIsAuthenticatedAs(String officerEmail) {
        Allure.step("👮 Authenticate KYC Officer: " + officerEmail, () -> {
            currentOfficer = officerEmail;
            workflowContext.put("currentOfficer", officerEmail);

            String html = String.format(
                "<div style='background:#e8eaf6;padding:12px;border-left:4px solid #3f51b5;'>" +
                "<b>👮 KYC Officer</b><br/>" +
                "Email: <code>%s</code><br/>" +
                "Role: <b>KYC Officer</b><br/>" +
                "Permissions: <span style='color:#2e7d32;'>✅ MANUAL_UPDATE</span>" +
                "</div>",
                officerEmail
            );
            Allure.addAttachment("Officer Authentication", "text/html", html, ".html");
        });
    }

    @When("the KYC Officer manually updates the {string} block to {string}")
    public void theKYCOfficerManuallyUpdatesTheBlockTo(String block, String newStatus) {
        Allure.step("✏️ Manual update: " + block + " → " + newStatus, () -> {
            String blockKey = currentPrincipalId + ":" + block;
            String oldStatus = kycSteps.getBlockStates().getOrDefault(blockKey, "UNKNOWN");

            kycSteps.setBlockStatus(blockKey, newStatus);

            workflowContext.put("lastManualUpdate", Map.of(
                "block", block,
                "oldStatus", oldStatus,
                "newStatus", newStatus,
                "officer", currentOfficer
            ));

            String html = String.format(
                "<div style='background:#fff3e0;padding:12px;border-left:4px solid #ff9800;'>" +
                "<b>✏️ Manual Status Change</b><br/>" +
                "Block: <code>%s</code><br/>" +
                "Old Status: <span style='background:%s;padding:2px 8px;border-radius:3px;'>%s %s</span><br/>" +
                "New Status: <span style='background:%s;padding:2px 8px;border-radius:3px;'>%s %s</span><br/>" +
                "Changed by: <code>%s</code>" +
                "</div>",
                block,
                statusColor(oldStatus), statusIcon(oldStatus), oldStatus,
                statusColor(newStatus), statusIcon(newStatus), newStatus,
                currentOfficer
            );
            Allure.addAttachment("Manual Update - " + block, "text/html", html, ".html");
        });
    }

    @Then("the block status should be changed to {string}")
    public void theBlockStatusShouldBeChangedTo(String expectedStatus) {
        Allure.step("✅ Verify status change to " + expectedStatus, () -> {
            @SuppressWarnings("unchecked")
            Map<String, String> lastUpdate = (Map<String, String>) workflowContext.get("lastManualUpdate");
            assertEquals(expectedStatus, lastUpdate.get("newStatus"), "Block status should be updated");
        });
    }

    @Then("a status change event should be logged:")
    public void aStatusChangeEventShouldBeLogged(DataTable dataTable) {
        Allure.step("📝 Log status change event", () -> {
            Map<String, String> eventData = dataTable.asMap(String.class, String.class);

            StringBuilder html = new StringBuilder();
            html.append("<table style='border-collapse:collapse;width:100%;'>");
            html.append("<tr style='background:#37474f;color:white;'>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>Field</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>Value</th>");
            html.append("</tr>");

            for (Map.Entry<String, String> entry : eventData.entrySet()) {
                html.append("<tr style='background:#eceff1;'>");
                html.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>").append(entry.getKey()).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;'><code>").append(entry.getValue()).append("</code></td>");
                html.append("</tr>");
            }
            html.append("</table>");

            Allure.addAttachment("Status Change Event", "text/html", html.toString(), ".html");
        });
    }

    @Then("all blocks for the review should now be in final statuses")
    public void allBlocksForTheReviewShouldNowBeInFinalStatuses() {
        Allure.step("✅ Verify all blocks in final statuses", () -> {
            Map<String, String> allBlocks = kycSteps.getBlockStates();

            List<Map<String, String>> blocksList = allBlocks.entrySet().stream()
                .filter(e -> e.getKey().startsWith(currentPrincipalId))
                .map(e -> Map.of("Block", e.getKey().split(":")[1], "Status", e.getValue()))
                .toList();

            String html = buildBlockStatusTable(
                "📊 All Blocks - Final Statuses",
                "#2e7d32",
                blocksList,
                "Block",
                "Status"
            );
            Allure.addAttachment("Final Block Statuses", "text/html", html, ".html");
        });
    }

    @Then("the review should be marked as {string}")
    public void theReviewShouldBeMarkedAs(String finalStatus) {
        Allure.step("🎉 Mark review as " + finalStatus, () -> {
            workflowContext.put("reviewStatus", finalStatus);
            workflowContext.put("completedAt", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

            String html = String.format(
                "<div style='background:#c8e6c9;padding:16px;border-left:6px solid #2e7d32;'>" +
                "<h3 style='margin:0;color:#1b5e20;'>🎉 Review %s</h3>" +
                "Review ID: <code style='background:#a5d6a7;padding:2px 6px;'>%s</code><br/>" +
                "Status: <b style='color:#2e7d32;'>%s</b><br/>" +
                "Completed at: <code>%s</code>" +
                "</div>",
                finalStatus,
                currentReviewId,
                finalStatus,
                workflowContext.get("completedAt")
            );
            Allure.addAttachment("Review " + finalStatus, "text/html", html, ".html");
        });
    }

    @Then("the final workflow summary should show:")
    public void theFinalWorkflowSummaryShouldShow(DataTable dataTable) {
        Allure.step("📊 Generate final workflow summary", () -> {
            Map<String, String> metrics = dataTable.asMap(String.class, String.class);

            StringBuilder html = new StringBuilder();
            html.append("<div style='background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);padding:20px;color:white;border-radius:8px;'>");
            html.append("<h2 style='margin:0 0 16px 0;'>🎯 Workflow Complete - Summary Report</h2>");
            html.append("<table style='border-collapse:collapse;width:100%;background:white;color:#333;border-radius:4px;overflow:hidden;'>");
            html.append("<tr style='background:#5e35b1;color:white;'>");
            html.append("<th style='padding:12px;text-align:left;'>Metric</th>");
            html.append("<th style='padding:12px;text-align:center;'>Value</th>");
            html.append("</tr>");

            for (Map.Entry<String, String> entry : metrics.entrySet()) {
                html.append("<tr style='background:#f5f5f5;border-bottom:1px solid #ddd;'>");
                html.append("<td style='padding:10px;font-weight:bold;'>").append(entry.getKey()).append("</td>");
                html.append("<td style='padding:10px;text-align:center;'><code style='background:#ede7f6;padding:4px 12px;border-radius:4px;font-size:14px;'>")
                    .append(entry.getValue()).append("</code></td>");
                html.append("</tr>");
            }

            html.append("</table>");
            html.append("<div style='margin-top:16px;padding:12px;background:rgba(255,255,255,0.2);border-radius:4px;'>");
            html.append("✅ <b>Workflow Status:</b> COMPLETED<br/>");
            html.append("📋 <b>Review ID:</b> ").append(currentReviewId).append("<br/>");
            html.append("👤 <b>Principal ID:</b> ").append(currentPrincipalId).append("<br/>");
            html.append("👮 <b>Last Officer:</b> ").append(currentOfficer);
            html.append("</div>");
            html.append("</div>");

            Allure.addAttachment("🎯 Final Workflow Summary", "text/html", html.toString(), ".html");
        });
    }

    // ════════════════════════════════════════════════════════════
    // Helper Methods
    // ════════════════════════════════════════════════════════════

    private String getNotificationDescription(String code) {
        return switch (code) {
            case "85" -> "Request for customer documentation";
            case "126" -> "Customer has provided documentation (validation)";
            case "86" -> "Reminder - documentation still pending";
            case "87" -> "Automatic escalation due to timeout";
            default -> "Unknown notification";
        };
    }
}
