package com.monentreprise.steps.cucumber;

/**
 * Shared utility for Allure report styling.
 * Centralizes status-to-color and status-to-icon mapping
 * so it is defined in one place and reused by all step classes and hooks.
 */
public final class AllureReportHelper {

    private AllureReportHelper() {
    }

    public static String statusColor(String status) {
        return switch (status) {
            case "INIT" -> "#e8f5e9";
            case "OUT_OF_SCOPE", "NOT_IN_SCOPE" -> "#f3e5f5";
            case "UNDER_REVIEW_BY_IHUB" -> "#e3f2fd";
            case "UNDER_REVIEW_MANUAL" -> "#fff8e1";
            case "VALIDATED_BY_SYSTEM" -> "#e0f2f1";
            case "VALIDATED_BY_CUSTOMER" -> "#c8e6c9";
            case "NOT_VALIDATED_BY_CUSTOMER" -> "#ffebee";
            case "ESCALATED_TO_COMPLIANCE" -> "#fce4ec";
            case "NOT_PERMANENT" -> "#eeeeee";
            case "VALIDATED" -> "#e0f2f1";
            case "PENDING" -> "#fff8e1";
            case "REVIEW" -> "#e3f2fd";
            case "REJECTED" -> "#ffebee";
            default -> "#fafafa";
        };
    }

    public static String statusIcon(String status) {
        return switch (status) {
            case "INIT" -> "🟢";
            case "OUT_OF_SCOPE", "NOT_IN_SCOPE" -> "⚪";
            case "UNDER_REVIEW_BY_IHUB" -> "🔵";
            case "UNDER_REVIEW_MANUAL" -> "🟡";
            case "VALIDATED_BY_SYSTEM", "VALIDATED_BY_CUSTOMER", "VALIDATED" -> "✅";
            case "NOT_VALIDATED_BY_CUSTOMER", "REJECTED" -> "🔴";
            case "ESCALATED_TO_COMPLIANCE" -> "🟠";
            case "NOT_PERMANENT" -> "⚫";
            case "POSITIVE" -> "🟢";
            case "PENDING" -> "🟡";
            case "REVIEW" -> "🔵";
            default -> "⬜";
        };
    }

    /**
     * Builds an HTML table for a list of block/status pairs.
     *
     * @param title      Table title
     * @param headerColor CSS background color for the header row
     * @param rows       List of maps with "Block"/"Status" keys (or custom keys via blockKey/statusKey)
     */
    public static String buildBlockStatusTable(String title, String headerColor,
                                               java.util.List<java.util.Map<String, String>> rows,
                                               String blockKey, String statusKey) {
        StringBuilder html = new StringBuilder();
        html.append("<table style='border-collapse:collapse;width:100%;'>");
        html.append("<tr style='background:").append(headerColor).append(";color:white;'>");
        html.append("<th style='padding:8px;border:1px solid #ddd;'>📦 ").append(blockKey).append("</th>");
        html.append("<th style='padding:8px;border:1px solid #ddd;'>📊 ").append(statusKey).append("</th>");
        html.append("<th style='padding:8px;border:1px solid #ddd;'>✅ Result</th>");
        html.append("</tr>");

        for (java.util.Map<String, String> row : rows) {
            String block = row.get(blockKey);
            String status = row.get(statusKey);
            html.append("<tr style='background:").append(statusColor(status)).append(";'>");
            html.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>")
                    .append(block).append("</td>");
            html.append("<td style='padding:8px;border:1px solid #ddd;'>")
                    .append(statusIcon(status)).append(" ").append(status).append("</td>");
            html.append("<td style='padding:8px;border:1px solid #ddd;color:#2e7d32;'>✅ OK</td>");
            html.append("</tr>");
        }
        html.append("</table>");
        return html.toString();
    }
}
