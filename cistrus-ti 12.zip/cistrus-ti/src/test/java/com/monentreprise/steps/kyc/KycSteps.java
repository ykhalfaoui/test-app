package com.monentreprise.steps.kyc;

import io.qameta.allure.Allure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class KycSteps {

    private static final Logger log = LoggerFactory.getLogger(KycSteps.class);

    public void logStep(String stepName) {
        log.info("→ {}", stepName);
        Allure.step(stepName);
    }

    public void addParameter(String name, String value) {
        Allure.parameter(name, value);
    }

    private java.util.Map<String, String> blockStates = new java.util.HashMap<>();

    /**
     * Resets all in-memory state between scenarios.
     */
    public void reset() {
        blockStates.clear();
        log.info("🧹 KycSteps state reset");
    }

    /**
     * Returns a snapshot of current block states (for reporting).
     */
    public java.util.Map<String, String> getBlockStates() {
        return java.util.Collections.unmodifiableMap(blockStates);
    }

    public void setBlockStatus(String blockName, String status) {
        blockStates.put(blockName, status);
        logStep("GIVEN Bloc " + blockName + " est mis à l'état " + status);
    }

    public void verifyBlockStatus(String blockName, String expectedStatus) {
        String actual = blockStates.getOrDefault(blockName, "UNKNOWN");
        if (!expectedStatus.equals(actual)) {
            throw new AssertionError("Erreur Bloc " + blockName + ": Attendu=" + expectedStatus + ", Actuel=" + actual);
        }
        logStep("CHECK Bloc " + blockName + " est bien " + actual);
    }

    public void verifyBlockStatuses(java.util.Map<String, String> expectedStatuses) {
        logStep("THEN Vérification en masse des statuts des blocs");
        expectedStatuses.forEach(this::verifyBlockStatus);
    }

    public void simulateSystemAction() {
        logStep("WHEN System processes blocks...");
        // Simulation: change PENDING -> REVIEW
        blockStates.replaceAll((k, v) -> "PENDING".equals(v) ? "REVIEW" : v);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // EXPERT COMPLIANCE LOGIC
    // ═══════════════════════════════════════════════════════════════════════════

    // --- SANCTIONS FAST TRACK ---
    public void sanctionsHitDetected(String listName) {
        addParameter("List", listName);
        logStep("WHEN Hit Sanction détecté sur liste " + listName);
        logStep("  > CRITIQUE: Trigger FAST TRACK activé");
    }

    public void verifyFastTrackInjection() {
        logStep("THEN L'alerte Sanction est injectée PRIORITAIREMENT dans la version OPEN");
        logStep("  > Override règle unicité effectué");
    }

    public void verifyImmediateAssetFreeze() {
        logStep("AND Gel des avoirs immédiat (Asset Freeze) appliqué par sécurité");
    }

    // --- PEP SCREENING ---
    public void pepHitDetected(String listName) {
        addParameter("List", listName);
        logStep("WHEN Hit PEP détecté sur liste " + listName);
    }

    public void enhancedDueDiligenceTriggered() {
        logStep("THEN Enhanced Due Diligence (EDD) activée");
        logStep("  > Validation Senior Management requise");
    }

    public void verifyNoAssetFreeze() {
        logStep("AND Pas de gel des avoirs (Risque modéré)");
    }

    // --- MLRO / SAR ---
    public void agentFlagsSuspiciousActivity() {
        logStep("WHEN L'agent qualifie l'activité de suspecte (Money Laundering Suspicion)");
    }

    public void escalateToMlro() {
        logStep("THEN Le dossier est escaladé au MLRO (Reporting Officer)");
        logStep("  > Statut: ESCALATED_TO_MLRO");
    }

    public void mlroDecision(String decision) {
        addParameter("MLRO Decision", decision);
        logStep("WHEN Le MLRO rend sa décision: " + decision);
    }

    public void verifySarFiled() {
        logStep("THEN Déclaration de Soupçon (SAR) enregistrée auprès des autorités");
    }

    public void verifyNoSarFiled() {
        logStep("THEN Aucune déclaration n'est faite (Fausse Alerte)");
        logStep("  > Retour au process standard");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // VERSION / STATES
    // ═══════════════════════════════════════════════════════════════════════════
    public void verifyVersionState(String s) {
        logStep("CHECK Version State: " + s);
    }

    public void triggerNewVersionAttempt() {
        logStep("WHEN Trigger standard (ex: Adresse)");
    }

    public void verifyNoNewVersionCreated() {
        logStep("THEN Bloqué (Règle Unicité)");
    }

    public void finalizeVersion() {
        logStep("WHEN Version FINALIZED");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BLOCK LOGIC
    // ═══════════════════════════════════════════════════════════════════════════
    public void runKytAiAnalysis(String r) {
        logStep("WHEN KYT AI Run: " + r);
        if ("OUTLINE".equals(r))
            logStep(" > Result: OUTLINE");
    }

    public void blockIsInitialized(String b) {
        logStep("GIVEN Bloc " + b + " INITIALIZED");
    }

    public void systemStartsAutoValidation() {
        logStep("WHEN Start Auto");
    }

    public void systemValidatesBlock() {
        logStep("THEN Validated Auto");
    }

    public void systemFailsAutoValidation() {
        logStep("THEN Manual Review");
    }

    public void delegateToExternalSystem(String s) {
        logStep("WHEN Delegate to " + s);
    }

    public void externalSystemReturns(String r) {
        logStep("AND External Return: " + r);
    }

    public void callScreeningProvider() {
        logStep("WHEN Call Provider");
    }

    public void systemRejectsDocument(String reason) {
        addParameter("Reason", reason);
        logStep("AND Le système rejette le document: " + reason);
        logStep("  > Retour Agent pour analyse");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // COMMS
    // ═══════════════════════════════════════════════════════════════════════════
    public void agentNeedsClientInfo() {
    }

    public void sendInitialCommunication(String c) {
    }

    public void waitPeriod(int p) {
        logStep("WHEN Période " + p + " expirée");
    }

    public void sendReminder(int r) {
        logStep("THEN Envoi Rappel " + r);
    }

    public void agentReceivesNotificationBeforeDeadline() {
        logStep("AND Notif Agent T2");
    }

    public void agentManuallySetsStatusBlocked() {
        logStep("WHEN Agent sets BLOCKED manually");
    }

    public void freezeAccounts() {
        logStep("THEN Debit Freeze");
    }

    public void clientRespondsToReminder() {
        logStep("WHEN Le client répond et fournit les documents");
    }

    public void processResumes() {
        logStep("THEN Le processus reprend (Pas de blocage)");
    }

    public void triggerExitProcess() {
    }

    // Legacy
    public void customerProfile(String r) {
        addParameter("Risk", r);
        logStep("GIVEN Profil Risque: " + r);
    }

    public void timeElapsed(String d) {
        logStep("WHEN Temps écoulé: " + d);
    }

    public void periodicReviewTriggered() {
        logStep("THEN Revue Périodique déclenchée");
        verifyVersionState("OPEN");
    }

    public void identifyRelations() {
    }

    public void applyRestrictiveRole() {
    }

    public void customerNotOnboarded() {
    }

    public void customerOnboardedSuccessfully(String t) {
    }

    public void verifyRemediationBlocksCreated(int c) {
    }

    public void verifyBlocksForThirdParty() {
    }

    public void customerExists(String t, String s) {
    }

    public void customerSwitchType(String f, String t) {
    }

    public void verifyBlocksUpdated() {
    }

    public void verifyOtherBlocksOutOfScope() {
    }

    public void verifyAllBlocksInitialized() {
    }

    public void customerLeavesBank() {
    }

    public void customerReturnsToBank() {
    }

    public void verifyCustomerStatus(String s) {
    }

    public void clientNotInScopeDDR() {
    }

    public void clientInScopeDDR() {
    }

    public void reviewInProgress() {
        verifyVersionState("OPEN");
    }

    public void noReviewInProgress() {
    }

    public void ihubLaunchesDDR() {
    }

    public void verifyHitQualifiedAs(String q) {
    }

    public void verifyHitSyncedToSalesforce(String s) {
    }

    public void launchReviewOnCustomer() {
    }

    public void verifyBlocksAndReviewSynced() {
    }

    public void agentRequestsComplianceOpinion() {
    }

    public void complianceResponds() {
    }

    public void agentValidatesBlock() {
    }

    public void trigger4EyesCheck() {
    }

    public void blockIsLocked() {
    }
}
