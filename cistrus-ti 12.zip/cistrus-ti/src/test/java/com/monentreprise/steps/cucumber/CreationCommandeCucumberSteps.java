package com.monentreprise.steps.cucumber;

import com.monentreprise.citrus.core.config.CitrusTestConfig;
import com.monentreprise.steps.commandes.CommandeSteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.annotations.CitrusResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import static org.citrusframework.actions.EchoAction.Builder.echo;

@CucumberContextConfiguration
@ContextConfiguration(classes = CitrusTestConfig.class)
public class CreationCommandeCucumberSteps {

    @CitrusResource
    private TestCaseRunner runner;

    @Autowired
    private CommandeSteps commandeSteps; // Reuse existing steps logic

    @Given("Un client {string} authentifié")
    public void un_client_authentifie(String typeClient) {
        commandeSteps.init(runner);
        commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(typeClient);
    }

    @When("Le client crée une commande de {double} EUR")
    public void le_client_cree_une_commande_de_eur(Double montant) {
        commandeSteps.creerCommande(commandeSteps.getCurrentCustomer(), java.math.BigDecimal.valueOf(montant));
    }

    @Then("La commande est en statut {string}")
    public void la_commande_est_en_statut(String statut) {
        commandeSteps.verifierStatut(statut);
    }

    @When("Le système valide la commande")
    public void le_systeme_valide_la_commande() {
        commandeSteps.validerCommande();
    }

    @When("Le client effectue le paiement")
    public void le_client_effectue_le_paiement() {
        commandeSteps.effectuerPaiement();
    }
}
