package com.monentreprise.steps.cucumber;

import com.monentreprise.steps.kyc.KycSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

import static com.monentreprise.steps.cucumber.AllureReportHelper.statusColor;
import static com.monentreprise.steps.cucumber.AllureReportHelper.statusIcon;

/**
 * Cucumber steps for DDR Hit and KYC Review scenarios.
 * Covers hit detection, review creation,
 * iHub notification handling and KYC Officer actions.
 */
public class DDRHitReviewCucumberSteps {

    @Autowired
    private KycSteps kycSteps;

    private boolean isDigital;
    private boolean reviewInProgress;

    // ═══════════════════════════════════════════════════════════════════════
    // GIVEN - Preconditions
    // ═══════════════════════════════════════════════════════════════════════

    @Given("a principal actor {string} of type {string} is active and digital")
    public void principalActorActiveAndDigital(String partyId, String type) {
        this.isDigital = true;
        Allure.parameter("👤 Principal Actor", partyId);
        Allure.parameter("🏢 Type", type);
        Allure.parameter("📱 Digital", "Yes");
        Allure.step("📋 GIVEN: Principal actor " + partyId + " (" + type + ") active & digital", () -> {
            kycSteps.customerExists(type, "ACTIVE");
            kycSteps.clientInScopeDDR();
            kycSteps.logStep("👤 " + partyId + " of type " + type + " - Active & Digital");
        });
    }

    @Given("a principal actor {string} of type {string} is active and non-digital")
    public void principalActorActiveAndNonDigital(String partyId, String type) {
        this.isDigital = false;
        Allure.parameter("👤 Principal Actor", partyId);
        Allure.parameter("🏢 Type", type);
        Allure.parameter("📱 Digital", "No");
        Allure.step("📋 GIVEN: Principal actor " + partyId + " (" + type + ") active & non-digital", () -> {
            kycSteps.customerExists(type, "ACTIVE");
            kycSteps.clientInScopeDDR();
            kycSteps.logStep("👤 " + partyId + " of type " + type + " - Active & NON Digital");
        });
    }

    @And("their last login was less than {int} months ago")
    public void lastLoginLessThanMonthsAgo(int months) {
        Allure.parameter("📅 Last Login", "< " + months + " months");
        Allure.step("📋 GIVEN: Last login < " + months + " months", () -> {
            kycSteps.logStep("📅 Last login less than " + months + " months ago → Client considered digital");
        });
    }

    @And("no review is currently in progress for {string}")
    public void noReviewInProgressFor(String partyId) {
        this.reviewInProgress = false;
        Allure.step("📋 GIVEN: No review in progress for " + partyId, () -> {
            kycSteps.noReviewInProgress();
            kycSteps.logStep("📝 No review in progress for " + partyId);
        });
    }

    @And("a review is already in progress for {string}")
    public void reviewAlreadyInProgressFor(String partyId) {
        this.reviewInProgress = true;
        Allure.step("📋 GIVEN: Review already in progress for " + partyId, () -> {
            kycSteps.reviewInProgress();
            kycSteps.logStep("⚠️ A review is already in progress for " + partyId);
        });
    }

    @And("{string} has the following relations:")
    public void partyHasRelations(String partyId, DataTable dataTable) {
        Allure.step("📋 GIVEN: Relations for " + partyId, () -> {
            List<Map<String, String>> relations = dataTable.asMaps(String.class, String.class);
            kycSteps.identifyRelations();

            StringBuilder htmlReport = new StringBuilder();
            htmlReport.append("<table style='border-collapse:collapse;width:100%;'>");
            htmlReport.append("<tr style='background:#37474f;color:white;'>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>👥 Party</th>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>🔗 Relation Type</th>");
            htmlReport.append("</tr>");

            for (Map<String, String> row : relations) {
                htmlReport.append("<tr style='background:#eceff1;'>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>")
                        .append(row.get("Party")).append("</td>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;'>")
                        .append(row.get("RelationType")).append("</td>");
                htmlReport.append("</tr>");
            }
            htmlReport.append("</table>");

            Allure.addAttachment("👥 Relations for " + partyId,
                    "text/html", htmlReport.toString(), ".html");

            kycSteps.logStep("👥 " + relations.size() + " relation(s) identified for " + partyId);
        });
    }

    @Given("a review is in progress for principal actor {string}")
    public void reviewInProgressForPrincipalActor(String partyId) {
        this.reviewInProgress = true;
        Allure.parameter("👤 Principal Actor", partyId);
        Allure.step("📋 GIVEN: Review in progress for " + partyId, () -> {
            kycSteps.reviewInProgress();
            kycSteps.logStep("📝 Review in progress for principal actor " + partyId);
        });
    }

    @And("block {string} is at status {string}")
    public void blockIsAtStatus(String block, String status) {
        Allure.step("📋 GIVEN: Block " + block + " at status " + status, () -> {
            kycSteps.setBlockStatus(block, status);
            kycSteps.logStep("📦 Block " + block + " → " + statusIcon(status) + " " + status);
        });
    }

    @And("the ecStaticData flag is set to {string}")
    public void ecStaticDataFlagIsSetTo(String flagValue) {
        Allure.parameter("🏷️ ecStaticData", flagValue);
        Allure.step("📋 GIVEN: Flag ecStaticData = " + flagValue, () -> {
            kycSteps.addParameter("ecStaticData", flagValue);
            kycSteps.logStep("🏷️ Flag ecStaticData set to " + flagValue);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // WHEN - Actions
    // ═══════════════════════════════════════════════════════════════════════

    @When("a DDR iHub hit is triggered for {string}")
    public void ddrIhubHitTriggeredFor(String partyId) {
        Allure.step("⚡ WHEN: DDR iHub hit triggered for " + partyId, () -> {
            kycSteps.ihubLaunchesDDR();
            kycSteps.logStep("🎯 DDR iHub hit triggered for " + partyId);
            Allure.addAttachment("🎯 DDR Hit Details",
                    "text/html",
                    "<div style='background:#e3f2fd;padding:10px;border-radius:5px;border-left:4px solid #1565c0;'>"
                            + "<b style='color:#1565c0;'>🎯 DDR iHub HIT</b><br/>"
                            + "Actor: <b>" + partyId + "</b><br/>"
                            + "Source: iHub<br/>"
                            + "Type: DDR Started<br/>"
                            + "Digital: " + (isDigital ? "✅ Yes" : "❌ No") + "<br/>"
                            + "Review in progress: " + (reviewInProgress ? "⚠️ Yes" : "✅ No")
                            + "</div>",
                    ".html");
        });
    }

    @When("iHub sends notification {string}")
    public void ihubSendsNotification(String notificationCode) {
        Allure.parameter("📨 Notification", notificationCode);
        Allure.step("⚡ WHEN: iHub notification " + notificationCode + " received", () -> {
            kycSteps.logStep("📨 iHub notification " + notificationCode + " received");

            String description = getNotificationDescription(notificationCode);
            Allure.addAttachment("📨 iHub Notification " + notificationCode,
                    "text/html",
                    "<div style='background:#fff3e0;padding:10px;border-radius:5px;border-left:4px solid #ff9800;'>"
                            + "<b style='color:#e65100;'>📨 iHub NOTIFICATION #" + notificationCode + "</b><br/>"
                            + description
                            + "</div>",
                    ".html");
        });
    }

    @When("the KYC Officer manually changes the status of block {string} to {string}")
    public void kycOfficerChangesBlockStatus(String block, String newStatus) {
        Allure.parameter("👨‍💼 Action", "Manual change");
        Allure.parameter("📦 Block", block);
        Allure.parameter("📊 New Status", newStatus);
        Allure.step("⚡ WHEN: KYC Officer changes " + block + " → " + newStatus, () -> {
            kycSteps.setBlockStatus(block, newStatus);
            kycSteps.logStep("👨‍💼 KYC Officer: Manual change of " + block + " to " + newStatus);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // THEN - Assertions
    // ═══════════════════════════════════════════════════════════════════════

    @Then("the hit is qualified as {string}")
    public void theHitIsQualifiedAs(String qualification) {
        Allure.parameter("🏷️ Hit Qualification", qualification);
        Allure.step("✅ THEN: Hit qualified as " + qualification, () -> {
            kycSteps.verifyHitQualifiedAs(qualification);
            String icon = "POSITIVE".equals(qualification) ? "🟢" : "⚫";
            kycSteps.logStep(icon + " Hit qualified: " + qualification);

            Allure.addAttachment("🏷️ Hit Qualification",
                    "text/html",
                    "<div style='background:" + ("POSITIVE".equals(qualification) ? "#e8f5e9" : "#fafafa")
                            + ";padding:10px;border-radius:5px;border-left:4px solid "
                            + ("POSITIVE".equals(qualification) ? "#4caf50" : "#9e9e9e") + ";'>"
                            + "<b>" + icon + " Qualification: " + qualification + "</b>"
                            + "</div>",
                    ".html");
        });
    }

    @And("a review is created and started for {string}")
    public void reviewCreatedAndStartedFor(String partyId) {
        Allure.step("✅ THEN: Review created and started for " + partyId, () -> {
            kycSteps.launchReviewOnCustomer();
            kycSteps.logStep("📝 Review created and started for " + partyId);
        });
    }

    @And("members are added to the review with the following relations:")
    public void membersAddedToReview(DataTable dataTable) {
        Allure.step("✅ THEN: Members added to the review", () -> {
            List<Map<String, String>> members = dataTable.asMaps(String.class, String.class);

            StringBuilder htmlReport = new StringBuilder();
            htmlReport.append("<table style='border-collapse:collapse;width:100%;'>");
            htmlReport.append("<tr style='background:#00695c;color:white;'>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>👥 Member</th>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>🔗 Relation</th>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>✅ Added</th>");
            htmlReport.append("</tr>");

            for (Map<String, String> row : members) {
                htmlReport.append("<tr style='background:#e0f2f1;'>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>")
                        .append(row.get("Member")).append("</td>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;'>")
                        .append(row.get("RelationType")).append("</td>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;color:#2e7d32;'>✅</td>");
                htmlReport.append("</tr>");
            }
            htmlReport.append("</table>");

            Allure.addAttachment("👥 Review Members",
                    "text/html", htmlReport.toString(), ".html");

            kycSteps.logStep("👥 " + members.size() + " member(s) added to the review");
        });
    }

    @And("the principal actor {string} blocks are created with the following statuses:")
    public void principalActorBlocksCreated(String partyId, DataTable dataTable) {
        Allure.step("✅ THEN: Principal actor " + partyId + " blocks", () -> {
            List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);

            for (Map<String, String> row : rows) {
                kycSteps.setBlockStatus(row.get("Block"), row.get("Status"));
                kycSteps.verifyBlockStatus(row.get("Block"), row.get("Status"));
            }

            Allure.addAttachment("📊 Principal Actor Blocks - " + partyId,
                    "text/html",
                    "<h3 style='color:#1565c0;'>👤 Principal Actor: " + partyId + "</h3>"
                            + AllureReportHelper.buildBlockStatusTable("Blocks", "#1565c0", rows, "Block", "Status"),
                    ".html");
        });
    }

    @And("the member blocks are created according to their relation type:")
    public void memberBlocksCreatedByRelationType(DataTable dataTable) {
        Allure.step("✅ THEN: Member blocks created by relation type", () -> {
            List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);

            StringBuilder htmlReport = new StringBuilder();
            htmlReport.append("<h3 style='color:#00695c;'>👥 Member Blocks</h3>");
            htmlReport.append("<p style='color:#455a64;'><i>Impacted blocks depend on each member's relation type.</i></p>");
            htmlReport.append("<table style='border-collapse:collapse;width:100%;'>");
            htmlReport.append("<tr style='background:#00695c;color:white;'>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>👥 Member</th>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>📦 Block</th>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>📊 Status</th>");
            htmlReport.append("<th style='padding:8px;border:1px solid #ddd;'>✅ Result</th>");
            htmlReport.append("</tr>");

            String prevMember = "";
            for (Map<String, String> row : rows) {
                String member = row.get("Member");
                String block = row.get("Block");
                String status = row.get("Status");

                String bgColor = member.equals(prevMember) ? "#f5f5f5" : "#e0f2f1";
                htmlReport.append("<tr style='background:").append(bgColor).append(";'>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>")
                        .append(member.equals(prevMember) ? "" : member).append("</td>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;'>")
                        .append(block).append("</td>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;'>")
                        .append(statusIcon(status)).append(" ").append(status).append("</td>");
                htmlReport.append("<td style='padding:8px;border:1px solid #ddd;color:#2e7d32;'>✅ OK</td>");
                htmlReport.append("</tr>");
                prevMember = member;
            }
            htmlReport.append("</table>");

            htmlReport.append("<div style='background:#fff8e1;padding:10px;border-radius:5px;margin-top:10px;border-left:4px solid #ffc107;'>");
            htmlReport.append("<b style='color:#f57f17;'>💡 BUSINESS RULE</b><br/>");
            htmlReport.append("If the customer (principal or member) is <b>digital</b>, the STATIC_DATA block ");
            htmlReport.append("will have status <span style='color:#1565c0;font-weight:bold;'>🔵 UNDER_REVIEW_BY_IHUB</span>.<br/>");
            htmlReport.append("Otherwise, it is not considered in this review (status <span style='color:#9e9e9e;'>⚪ grey</span>).<br/>");
            htmlReport.append("Other blocks are in status <span style='color:#2e7d32;font-weight:bold;'>✅ VALIDATED_BY_SYSTEM</span> (not developed in batch 1).");
            htmlReport.append("</div>");

            Allure.addAttachment("📊 Review Member Blocks",
                    "text/html", htmlReport.toString(), ".html");

            kycSteps.logStep("📊 " + rows.size() + " member block(s) verified");
        });
    }

    @And("a customer check is created and linked to the review in Salesforce")
    public void customerCheckCreatedInSalesforce() {
        Allure.step("✅ THEN: Customer Check created in Salesforce", () -> {
            kycSteps.verifyBlocksAndReviewSynced();
            kycSteps.logStep("☁️ Customer Check created and linked to the review in Salesforce");
        });
    }

    @And("the review is created in Salesforce with its status")
    public void reviewCreatedInSalesforceWithStatus() {
        Allure.step("✅ THEN: Review created in Salesforce", () -> {
            kycSteps.logStep("☁️ Review created in Salesforce with synchronized status");
        });
    }

    @And("the member and principal actor blocks are created in Salesforce")
    public void blocksCreatedInSalesforce() {
        Allure.step("✅ THEN: Blocks created in Salesforce", () -> {
            kycSteps.logStep("☁️ Member + principal actor blocks created in Salesforce");
        });
    }

    @And("the families are synchronized in Salesforce")
    public void familiesSynchronizedInSalesforce() {
        Allure.step("✅ THEN: Families synchronized in Salesforce", () -> {
            kycSteps.logStep("☁️ Families synchronized in Salesforce");
            Allure.addAttachment("☁️ Full Salesforce Synchronization",
                    "text/html",
                    "<div style='background:#e3f2fd;padding:10px;border-radius:5px;border-left:4px solid #1976d2;'>"
                            + "<b style='color:#1565c0;'>☁️ SALESFORCE - FULL SYNCHRONIZATION</b><br/>"
                            + "✅ Customer Check created<br/>"
                            + "✅ Review created with status<br/>"
                            + "✅ Principal actor + member blocks created<br/>"
                            + "✅ Families synchronized"
                            + "</div>",
                    ".html");
        });
    }

    @Then("no new review is created")
    public void noNewReviewIsCreated() {
        Allure.step("✅ THEN: No new review created (duplicate)", () -> {
            kycSteps.logStep("🚫 No new review created - duplicate detected");
            Allure.addAttachment("🚫 Duplicate Detected",
                    "text/html",
                    "<div style='background:#ffebee;padding:10px;border-radius:5px;border-left:4px solid #c62828;'>"
                            + "<b style='color:#c62828;'>🚫 DDR DUPLICATE DETECTED</b><br/>"
                            + "A review is already in progress for this counterparty.<br/>"
                            + "The DDR hit is qualified as <b>NOT_PERMANENT</b>.<br/>"
                            + "No new review is created."
                            + "</div>",
                    ".html");
        });
    }

    @And("a customer check is created in Salesforce with status {string} and message {string}")
    public void customerCheckCreatedWithStatusAndMessage(String status, String message) {
        Allure.parameter("📊 Customer Check Status", status);
        Allure.step("✅ THEN: Customer Check created with status " + status, () -> {
            kycSteps.verifyHitSyncedToSalesforce(status);
            kycSteps.logStep("☁️ Customer Check created in SF - Status: " + status + " - Message: " + message);

            Allure.addAttachment("☁️ Salesforce Customer Check",
                    "text/html",
                    "<div style='background:#fafafa;padding:10px;border-radius:5px;border-left:4px solid #9e9e9e;'>"
                            + "<b style='color:#616161;'>☁️ Customer Check (Duplicate)</b><br/>"
                            + "Status: <b>" + statusIcon(status) + " " + status + "</b><br/>"
                            + "Message: <i>" + message + "</i>"
                            + "</div>",
                    ".html");
        });
    }

    @Then("block {string} transitions to status {string}")
    public void blockTransitionsToStatus(String block, String newStatus) {
        Allure.step("✅ THEN: Block " + block + " → " + newStatus, () -> {
            kycSteps.setBlockStatus(block, newStatus);
            kycSteps.verifyBlockStatus(block, newStatus);
            String icon = statusIcon(newStatus);
            kycSteps.logStep("📦 " + block + " → " + icon + " " + newStatus);

            Allure.addAttachment("📊 Block Transition - " + block,
                    "text/html",
                    "<div style='background:" + statusColor(newStatus)
                            + ";padding:10px;border-radius:5px;border-left:4px solid #1565c0;'>"
                            + "<b>📦 " + block + "</b><br/>"
                            + "New status: " + icon + " <b>" + newStatus + "</b>"
                            + "</div>",
                    ".html");
        });
    }

    @And("the status change is tracked in the history with user {string}")
    public void statusChangeTrackedInHistory(String user) {
        Allure.step("✅ THEN: Change tracked by " + user, () -> {
            kycSteps.logStep("📝 Status change tracked in history - User: " + user);
            Allure.addAttachment("📝 Change History",
                    "text/html",
                    "<div style='background:#f3e5f5;padding:10px;border-radius:5px;border-left:4px solid #7b1fa2;'>"
                            + "<b style='color:#7b1fa2;'>📝 HISTORY</b><br/>"
                            + "User: <b>" + user + "</b><br/>"
                            + "Type: Manual change<br/>"
                            + "Timestamp: Recorded"
                            + "</div>",
                    ".html");
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════════════

    private String getNotificationDescription(String code) {
        return switch (code) {
            case "126" -> "Review initialization.<br/>STATIC_DATA block transitions to <b>VALIDATED_BY_CUSTOMER</b>.";
            case "127" -> "Customer did not validate static data.<br/>STATIC_DATA block transitions to <b>NOT_VALIDATED_BY_CUSTOMER</b>.";
            case "86" -> "Validation confirmed by iHub.<br/>STATIC_DATA block transitions to <b>VALIDATED_BY_CUSTOMER</b>.";
            case "87" -> "Conditional validation based on <b>ecStaticData</b> flag.<br/>"
                    + "If true → VALIDATED_BY_CUSTOMER<br/>If false → NOT_VALIDATED_BY_CUSTOMER";
            default -> "Unknown notification.";
        };
    }
}
