package com.monentreprise.steps.cucumber;

import java.util.HashMap;
import java.util.Map;

/**
 * Thread-safe singleton to hold workflow context across multiple Cucumber scenarios.
 * This singleton is shared across all step definition classes and persists state
 * when scenarios are tagged with @no-reset.
 *
 * Uses static instance to ensure a single shared state across the entire test run,
 * regardless of Spring context reloads.
 */
public class WorkflowContext {

    private static final WorkflowContext INSTANCE = new WorkflowContext();

    private final Map<String, Object> context = new HashMap<>();

    private WorkflowContext() {
        // Private constructor to prevent external instantiation
    }

    public static WorkflowContext getInstance() {
        return INSTANCE;
    }

    public void put(String key, Object value) {
        context.put(key, value);
    }

    public Object get(String key) {
        return context.get(key);
    }

    public String getString(String key) {
        return (String) context.get(key);
    }

    public Boolean getBoolean(String key) {
        return (Boolean) context.get(key);
    }

    public Integer getInteger(String key) {
        return (Integer) context.get(key);
    }

    public void clear() {
        context.clear();
    }

    public Map<String, Object> getAll() {
        return new HashMap<>(context);
    }

    public boolean containsKey(String key) {
        return context.containsKey(key);
    }

    public int size() {
        return context.size();
    }

    @Override
    public String toString() {
        return "WorkflowContext{size=" + context.size() + ", keys=" + context.keySet() + "}";
    }
}
