package com.monentreprise.steps.cucumber;

import com.monentreprise.steps.kyc.KycSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.monentreprise.steps.cucumber.AllureReportHelper.*;

/**
 * Cucumber steps for KycBlocks feature (English).
 * Handles bulk validation of KYC block statuses.
 */
public class KycCucumberSteps {

    @Autowired
    private KycSteps kycSteps;

    @Given("the blocks are initialized with the following statuses:")
    public void theBlocksAreInitializedWithTheFollowingStatuses(DataTable dataTable) {
        Allure.step("📋 GIVEN: Initialize blocks", () -> {
            Map<String, String> blocks = dataTable.asMap(String.class, String.class);
            blocks.forEach((block, status) -> kycSteps.setBlockStatus(block, status));

            List<Map<String, String>> rows = blocks.entrySet().stream()
                .map(entry -> Map.of("Block", entry.getKey(), "Status", entry.getValue()))
                .collect(Collectors.toList());

            String html = buildBlockStatusTable(
                "📊 Initial Block States",
                "#1565c0",
                rows,
                "Block",
                "Status"
            );
            Allure.addAttachment("📊 Initial block states", "text/html", html, ".html");
        });
    }

    @When("the system performs a status update")
    public void theSystemPerformsAStatusUpdate() {
        Allure.step("⚡ WHEN: System status update", () -> {
            kycSteps.simulateSystemAction();
        });
    }

    @Then("I verify that the blocks are in the expected statuses:")
    public void iVerifyThatTheBlocksAreInTheExpectedStatuses(DataTable dataTable) {
        Allure.step("✅ THEN: Validate final statuses", () -> {
            Map<String, String> expectedStatuses = dataTable.asMap(String.class, String.class);
            kycSteps.verifyBlockStatuses(expectedStatuses);

            List<Map<String, String>> rows = expectedStatuses.entrySet().stream()
                .map(entry -> Map.of("Block", entry.getKey(), "Status", entry.getValue()))
                .collect(Collectors.toList());

            String html = buildBlockStatusTable(
                "📊 Final Status Validation",
                "#2e7d32",
                rows,
                "Block",
                "Status"
            );
            Allure.addAttachment("📊 Final status validation", "text/html", html, ".html");
        });
    }
}
