package com.monentreprise.scenarios.kyc;

import com.monentreprise.citrus.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("📅 Feature: Revues Périodiques")
@Feature("Periodic Review Triggers (Paramétrés)")
@Owner("equipe-review")
public class PeriodicReviewTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @ParameterizedTest(name = "Revue {0} après {1}")
    @CsvSource({
            "High Risk / Wealth, 1 An",
            "Medium Risk, 3 Ans",
            "Low Risk, 7 Ans"
    })
    @Story("Logic de Périodicité (Risk-Based)")
    @DisplayName("📅 Triggers de Revue Périodique")
    @Description("La périodicité dépend du niveau de risque du client.")
    @Tag("periodic")
    void periodicReviewParameterized(String riskProfile, String duration) {
        kycSteps.customerProfile(riskProfile);
        kycSteps.timeElapsed(duration);
        kycSteps.periodicReviewTriggered();

        if (riskProfile.contains("High")) {
            kycSteps.identifyRelations();
            kycSteps.applyRestrictiveRole(); // Vérif spécifique Wealth
        }
    }
}
