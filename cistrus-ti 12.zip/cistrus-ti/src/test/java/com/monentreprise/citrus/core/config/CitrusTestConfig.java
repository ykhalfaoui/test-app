package com.monentreprise.citrus.core.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.sql.DataSource;

/**
 * Configuration Spring pour les tests d'intégration.
 * 
 * <h2>Responsabilités</h2>
 * <ul>
 * <li>Configuration de la DataSource (H2 in-memory par défaut)</li>
 * <li>Initialisation du schéma de base de données</li>
 * <li>Scan des composants de test (steps, fixtures)</li>
 * </ul>
 * 
 * <h2>Personnalisation</h2>
 * Pour utiliser une vraie base (Oracle, PostgreSQL), modifiez les propriétés
 * dans le bean {@link #testDataSource()}.
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@Configuration
@PropertySource("classpath:application-${env:local}.properties")
@EnableConfigurationProperties(CitrusTestProperties.class)
@ComponentScan(basePackages = {
        "com.monentreprise.steps",
        "com.monentreprise.fixtures",
        "com.monentreprise.config"
})
public class CitrusTestConfig {

    /**
     * DataSource pour les tests.
     * 
     * Configuration H2 in-memory par défaut.
     * Pour Oracle/PostgreSQL, remplacez les paramètres.
     */
    @Bean(name = "testDataSource")
    public DataSource testDataSource(CitrusTestProperties properties) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();

        dataSource.setDriverClassName(properties.getInfra().getDatasource().getDriverClassName());
        dataSource.setUrl(properties.getInfra().getDatasource().getUrl());
        dataSource.setUsername(properties.getInfra().getDatasource().getUsername());
        dataSource.setPassword(properties.getInfra().getDatasource().getPassword());

        return dataSource;
    }

    /**
     * Initialise la base de données avec le schéma de test.
     * Exécute automatiquement les scripts SQL au démarrage.
     */
    @Bean
    public DataSourceInitializer dataSourceInitializer(DataSource testDataSource) {
        DataSourceInitializer initializer = new DataSourceInitializer();
        initializer.setDataSource(testDataSource);

        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        // Scripts d'initialisation (ordre important)
        populator.addScript(new ClassPathResource("sql/schema/01_create_tables.sql"));
        populator.addScript(new ClassPathResource("sql/schema/02_create_indexes.sql"));
        populator.addScript(new ClassPathResource("sql/data/reference_data.sql"));

        // Continue même si un script échoue (utile pour les tables existantes)
        populator.setContinueOnError(true);

        initializer.setDatabasePopulator(populator);
        return initializer;
    }

    @Bean
    public org.citrusframework.selenium.endpoint.SeleniumBrowser seleniumBrowser() {
        org.citrusframework.selenium.endpoint.SeleniumBrowser browser = new org.citrusframework.selenium.endpoint.SeleniumBrowser();
        browser.getEndpointConfiguration().setBrowserType("chrome");
        return browser;
    }
}
