# 📚 Spécifications des Tests (Living Documentation)

Ce document est généré à partir du code source des tests. Il décrit le comportement attendu du système sous forme de scénarios BDD (Behavior-Driven Development).

---

## 🛒 Epic: Gestion des Commandes

### Feature: Création de commande

#### 📖 Story: US-COM-001 - Création commande client standard
> **Description**: Le client standard doit pouvoir passer une commande simple qui sera mise en attente de validation.

*   **Scénario**: `clientStandard_creeCommande_statutEnAttente`
    *   **GIVEN** Un client standard authentifié
    *   **AND** Un panier validé de 150€
    *   **GIVEN** L'environnement est prêt
    *   **WHEN** Le client valide sa commande
    *   **THEN** La commande est créée en statut 'En attente de paiement'
    *   **AND** Le montant est correctement enregistré
    *   **AND** Le type de client est associé à la commande

#### 📖 Story: US-COM-003 - Gestion des clients VIP
> **Description**: Les clients VIP bénéficient de plafonds plus élevés et d'un traitement prioritaire.

*   **Scénario**: `clientVIP_creeCommande_montantEleve`
    *   **GIVEN** Un client VIP authentifié
    *   **AND** Un panier de 2500€ (au-dessus du plafond standard)
    *   **WHEN** Le client VIP valide sa commande
    *   **THEN** La commande est créée avec succès

#### 📖 Story: US-COM-004 - Commandes entreprise
> **Description**: Les clients B2B ont des workflows de validation et des conditions de paiement spécifiques.

*   **Scénario**: `clientEntreprise_creeCommande_B2B`
    *   **GIVEN** Un client entreprise authentifié
    *   **WHEN** Le client entreprise passe une commande
    *   **THEN** La commande B2B est créée en attente de validation

---

### Feature: Cycle de vie commande

#### 📖 Story: US-COM-010 - Cycle de vie complet
> **Description**: Validation du flux nominal complet de la commande, de la création à la livraison.

*   **Scénario**: `fluxNominal_creationJusquauPaiement`
    *   **GIVEN** Un client avec un panier validé
    *   **WHEN** Le client valide son panier
    *   **THEN** La commande est en statut PENDING
    *   **WHEN** Le système valide la commande (contrôles OK)
    *   **THEN** La commande passe en statut VALIDATED
    *   **WHEN** Le client effectue le paiement
    *   **THEN** La commande passe en statut PAID
    *   **AND** Le flux nominal est complété avec succès

#### 📖 Story: US-COM-011 - Annulation commande
> **Description**: Gestion des annulations par le client selon l'état de la commande.

*   **Scénario**: `annulationCommande_avantValidation`
    *   **GIVEN** Une commande en statut PENDING
    *   **WHEN** Le client annule sa commande
    *   **THEN** La commande passe en statut CANCELLED
    *   **AND** Le motif d'annulation est enregistré

*   **Scénario**: `annulationCommande_apresValidation`
    *   **GIVEN** Une commande en statut VALIDATED
    *   **WHEN** Le client demande l'annulation (dans le délai)
    *   **THEN** La commande est annulée avec succès
    *   **AND** Le motif est tracé pour le SAV

#### 📖 Story: US-COM-012 - Règles de transition
> **Description**: Validation des transitions d'état interdites par la machine à états.

*   **Scénario**: `paiementSurCommandeNonValidee_doitEtreRefuse`
    *   **GIVEN** Une commande en statut PENDING (non validée)
    *   **WHEN** Une tentative de paiement est effectuée
    *   **THEN** Le paiement est refusé
    *   **AND** Un message d'erreur explicite est retourné

---

### Feature: Gestion des erreurs - Création commande

#### 📖 Story: US-COM-002 - Validation des montants
> **Description**: Règles de validation strictes sur les montants des commandes.

*   **Scénario**: `commandeAvecMontantNegatif_doitEtreRejetee`
    *   **GIVEN** Un client standard authentifié
    *   **WHEN** Le client tente de créer une commande avec un montant négatif (-50€)
    *   **THEN** La commande n'est pas créée
    *   **AND** Un message d'erreur est retourné

*   **Scénario**: `commandeAvecMontantZero_doitEtreRejetee`
    *   **GIVEN** Un client standard authentifié
    *   **WHEN** Le client tente de créer une commande avec un montant de 0€
    *   **THEN** La commande est rejetée avec le bon message d'erreur

*   **Scénario**: `commandeDepassantPlafondStandard_doitEtreRejetee`
    *   **GIVEN** Un client STANDARD (plafond 1000€)
    *   **WHEN** Le client tente de créer une commande de 1500€
    *   **THEN** La commande est rejetée pour dépassement de plafond

#### 📖 Story: US-COM-005 - Gestion clients bloqués
> **Description**: Sécurité et prévention de la fraude pour les clients blacklistés.

*   **Scénario**: `clientBloque_commandeRejetee`
    *   **GIVEN** Un client avec statut BLOQUÉ (suspicion de fraude)
    *   **WHEN** Le client bloqué tente de créer une commande
    *   **THEN** La commande est rejetée
    *   **AND** Une alerte de sécurité est générée

#### 📖 Story: US-COM-006 - Détection doublons
> **Description**: Garantie d'idempotence pour éviter les doubles commandes.

*   **Scénario**: `commandeEnDoublon_doitEtreDetectee`
    *   **GIVEN** Une commande existante en base
    *   **WHEN** Une tentative de création avec la même référence est effectuée
    *   **THEN** Le système retourne la commande existante
    *   **AND** Aucune nouvelle entrée n'est créée
