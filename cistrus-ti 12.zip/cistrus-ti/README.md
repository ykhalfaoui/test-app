# 🧪 Suite de Tests d'Intégration - Module Commandes

> Tests BDD avec Citrus Framework + Allure Reporting
> Architecture Enterprise Grade pour rapports métier-friendly

---

## 📋 Table des matières

- [Vue d'ensemble](#vue-densemble)
- [Architecture](#architecture)
- [Installation](#installation)
- [Exécution](#exécution)
- [Rapports](#rapports)
- [Structure du projet](#structure-du-projet)
- [Guide de contribution](#guide-de-contribution)

---

## Vue d'ensemble

Cette suite de tests d'intégration couvre le domaine **Gestion des Commandes** avec une approche BDD (Behavior-Driven Development). Les tests sont conçus pour être :

- ✅ **Lisibles par le métier** : Vocabulaire fonctionnel, pas de jargon technique
- ✅ **Maintenables** : Architecture DRY, couche d'abstraction métier
- ✅ **Traçables** : Liens vers JIRA, User Stories, règles métier
- ✅ **Parallélisables** : Données dynamiques, isolation des tests

### Couverture fonctionnelle

| Epic | Feature | Scénarios | Criticité |
|------|---------|-----------|-----------|
| 🛒 Commandes | Création commande | 8 | BLOCKER |
| 🛒 Commandes | Cycle de vie | 4 | CRITICAL |
| 🛒 Commandes | Edge cases | 7 | NORMAL |

| 🛒 Commandes | Edge cases | 7 | NORMAL |

### 🧩 Scénarios de Test

> 📘 **Documentation Détaillée** : Pour voir le détail exact des Features, User Stories et étapes Given/When/Then, consultez le document **[Spécifications des Tests (REMEDIATION-SPEC.md)](REMEDIATION-SPEC.md)**.

Les tests sont conçus pour valider des règles métier précises selon le profil du client :

#### 1. Clients Standard
*   **Flux Nominal** : Création panier (150€) -> Validation -> Paiement -> Livraison.
*   **Règle Métier** : Un client standard **ne peut pas commander pour plus de 2000€**.
*   **Statut** : La commande passe en `PENDING` après validation.

#### 2. Clients VIP
*   **Privilège** : Autorisation de commandes avec montants élevés (ex: 2500€).
*   **Flux** : Création -> Validation immédiate.

#### 3. Clients B2B (Entreprise)
*   **Règle** : Les commandes B2B suivent un workflow spécifique (validation manager requise, simule un délai).
*   **Vérification** : Le statut initial est différent.

#### 4. Edge Cases (Cas Limites)
*   **Montant Négatif** : Rejet immédiat de la commande.
*   **Montant Zéro** : Rejet immédiat.
*   **Doublons** : Détection de tentative de double commande (même ID de transaction).
*   **Client Bloqué** : Rejet de toute commande provenant d'un client blacklisté.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        TESTS (BDD)                               │
│  CreationCommandeTest, CycleVieCommandeTest, EdgeCasesTest      │
├─────────────────────────────────────────────────────────────────┤
│                    STEPS MÉTIER                                  │
│  CommandeSteps, CommandeAssertions (Vocabulaire fonctionnel)    │
├─────────────────────────────────────────────────────────────────┤
│                    FIXTURES                                      │
│  CommandeFixture (Génération données de test)                   │
├─────────────────────────────────────────────────────────────────┤
│                    CORE                                          │
│  BaseCitrusTest (given/when/then), Config                       │
├─────────────────────────────────────────────────────────────────┤
│                    INFRASTRUCTURE                                │
│  Citrus Framework, Spring, H2/Oracle, Allure                    │
└─────────────────────────────────────────────────────────────────┘
```

---

---

## Installation

### Prérequis

- Java 17+
- Maven 3.8+
- (Optionnel) Allure CLI pour les rapports locaux

#### 🖥️ Installation sur Windows

**Option A (Recommandée - Manuel/ZIP) :**
1. Télécharger la dernière release de **Allure Commandline** (zip/tgz) depuis [Maven Central](https://repo.maven.apache.org/maven2/io/qameta/allure/allure-commandline/).
2. Décompresser l'archive (ex: `C:\Tools\allure-2.32.0`).
3. Ajouter le dossier `bin` à votre **PATH** Windows (`C:\Tools\allure-2.32.0\bin`).
4. Vérifier : ouvrir un nouveau terminal `cmd` et taper `allure --version`.

**Option B (Scoop) :**
```powershell
scoop install allure
```

### Cloner et construire

```bash
# Cloner le repository
git clone https://github.com/monentreprise/citrus-expert-tests.git
cd citrus-expert-tests

# Installer les dépendances
# Windows
mvnw.cmd clean install -DskipTests
# Mac/Linux
./mvnw clean install -DskipTests
```

---

## Exécution

### 🎯 Modes d'Exécution

Ce projet supporte **deux modes d'exécution**:

#### Mode Standard (Scénarios Isolés)
Chaque scénario est indépendant avec reset d'état:

```bash
# Tous les tests
mvn clean test

# Uniquement les tests KYC
mvn test -Dcucumber.filter.tags="@kyc"
```

#### Mode Workflow (Scénarios Enchaînés) 🆕
Les scénarios s'enchaînent et partagent l'état sans reset:

```bash
# Exécuter le workflow KYC end-to-end
mvn clean test -Dtest=RunWorkflowTest
```

📚 **Documentation complète**: Voir [WORKFLOW.md](WORKFLOW.md) pour le guide détaillé des workflows

---

### Tous les tests

```bash
mvn clean test
```

### Par Environnement

Le projet supporte l'exécution sur différents environnements via la propriété système `-Denv`.
Les configurations sont chargées depuis `src/test/resources/application-${env}.properties`.

| Environnement | Commande | Description |
|---------------|----------|-------------|
| **Local** (Défaut) | `mvn test` | Utilise H2 en mémoire. Pour le dév quotidien. |
| **Dev** | `mvn test -Denv=dev` | Environnement d'intégration partagé. |
| **QA** | `mvn test -Denv=qa` | Environnement de recette/validation. |


### Par profil

```bash
# Tests smoke (rapides, critiques)
mvn clean test -Psmoke

# Tests de régression complets
mvn clean test -Pregression

# Tests critiques uniquement
mvn clean test -Pcritical

# Exclure les tests lents
mvn clean test -Pfast
```

### Par tag JUnit 5

```bash
# Tests de création de commande uniquement
mvn test -Dgroups="creation"

# Tests VIP
mvn test -Dgroups="vip"

# Exclure les edge cases
mvn test -DexcludedGroups="edge-cases"
```

---

## Rapports

### Générer le rapport Allure

**Mac/Linux** :
```bash
./start-allure-server.sh
```

**Windows** :
```cmd
start-allure-server.bat
```
*Ou via Maven direct : `mvnw.cmd allure:serve`*

Le rapport s'ouvre automatiquement dans votre navigateur.

### Exporter en PDF

**Mac/Linux** :
```bash
./generate-pdf-report.sh
```

**Windows** :
```cmd
generate-pdf-report.bat
```
*(Nécessite le plugin `allure-pdf-plugin`)*

Le rapport s'ouvre automatiquement dans votre navigateur.

### Contenu du rapport

Le rapport Allure inclut :

- **📊 Overview** : Statistiques globales, taux de succès
- **🗂️ Behaviors** : Vue par Epic/Feature/Story (BDD)
- **📋 Suites** : Vue par classe de test
- **📈 Graphs** : Tendances, durées d'exécution
- **🐛 Categories** : Bugs, problèmes infra, tests instables

### Capture d'écran type

```
┌────────────────────────────────────────────────────────────────┐
│ 🛒 Gestion des Commandes                                        │
│   └── Création de commande                                      │
│       ├── ✅ Client standard crée une commande avec succès     │
│       ├── ✅ Client VIP crée une commande avec montant élevé   │
│       └── ❌ Rejet commande avec montant négatif               │
│   └── Cycle de vie commande                                     │
│       ├── ✅ Flux nominal : Commande de la création à la livraison │
│       └── ✅ Annulation commande en statut PENDING             │
└────────────────────────────────────────────────────────────────┘
```

---

## Structure du projet

```
src/test/
├── java/com/monentreprise/
│   ├── core/                          # Socle technique
│   │   └── BaseCitrusTest.java        # given/when/then helpers
│   ├── config/                        # Configuration Spring
│   │   └── CitrusTestConfig.java      # DataSource, beans
│   ├── steps/                         # 🌟 Vocabulaire métier
│   │   └── commandes/
│   │       ├── CommandeSteps.java     # Actions et préconditions
│   │       └── CommandeAssertions.java # Vérifications fluentes
│   ├── fixtures/                      # Données de test
│   │   └── CommandeFixture.java       # Builder pattern
│   └── scenarios/                     # 🧪 Tests BDD
│       └── commandes/
│           ├── CreationCommandeTest.java
│           ├── CycleVieCommandeTest.java
│           └── EdgeCasesCommandeTest.java
└── resources/
    ├── sql/
    │   ├── schema/                    # DDL
    │   │   ├── 01_create_tables.sql
    │   │   └── 02_create_indexes.sql
    │   └── data/                      # Données de référence
    │       └── reference_data.sql
    ├── allure/                        # Config rapport
    │   ├── categories.json
    │   └── environment.properties
    └── allure.properties
```

---

## Guide de contribution

### Ajouter un nouveau test

1. **Identifier la Feature** : À quelle Epic/Feature appartient le test ?
2. **Créer le test** avec les annotations requises :

```java
@Epic("🛒 Gestion des Commandes")
@Feature("Ma Feature")
@Story("US-XXX: Description")
@TmsLink("JIRA-XXX")
@Severity(SeverityLevel.NORMAL)
@Tags({@Tag("regression"), @Tag("mon-tag")})
@DisplayName("Description lisible du test")
@Description("Description détaillée pour le métier")
void monNouveauTest() {
    given("...", () -> { });
    when("...", () -> { });
    then("...", () -> { });
}
```

3. **Utiliser les Steps existants** ou en créer de nouveaux si nécessaire
4. **Exécuter localement** : `mvn test -Dtest=MaClasseTest`
5. **Vérifier le rapport** : `mvn allure:serve`

### Checklist de validation

- [ ] `@Story` lié à une US existante
- [ ] `@TmsLink` vers le ticket JIRA
- [ ] Description compréhensible par un non-technique
- [ ] Utilisation des Steps métier (pas de SQL direct)
- [ ] Tags appropriés (smoke, regression, etc.)
- [ ] Test exécutable en parallèle (données dynamiques)

---

## Contact

**Équipe QA** : equipe-qa@monentreprise.com
**Responsable** : equipe-commerce
**Documentation** : [Confluence](https://confluence.monentreprise.com/display/QA)

---

*Dernière mise à jour : Janvier 2026*
