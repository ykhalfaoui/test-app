package com.example.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * Configuration du module audit.
 *
 * Deux responsabilités :
 * 1. Expose le publisher natif Spring sous @Qualifier pour éviter la dépendance circulaire
 *    avec notre @Primary AuditAwareEventPublisher.
 *
 * 2. Configure Jackson pour la sérialisation correcte des AuditMetadata records
 *    dans event_publication (retry safety).
 */
@Configuration
public class AuditConfig {

    /**
     * Le publisher natif de Spring — utilisé comme delegate par AuditAwareEventPublisher.
     * ApplicationContext IS-A ApplicationEventPublisher nativement.
     */
    @Bean
    @Qualifier("originalEventPublisher")
    public ApplicationEventPublisher originalEventPublisher(ApplicationContext applicationContext) {
        return applicationContext::publishEvent;
    }

    /**
     * ObjectMapper configuré pour sérialiser/désérialiser les records Java
     * et les types java.time (Instant dans AuditMetadata).
     *
     * CRITIQUE pour le retry : Spring Modulith désérialise les events
     * depuis event_publication via Jackson — AuditMetadata doit survivre
     * à ce cycle de sérialisation intact.
     */
    @Bean
    @Primary
    public ObjectMapper auditObjectMapper() {
        return JsonMapper.builder()
                .addModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .build();
    }
}
