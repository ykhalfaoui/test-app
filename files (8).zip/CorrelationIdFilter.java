package com.example.audit.entrypoint;

import com.example.audit.AuditThreadContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

/**
 * Entry point HTTP — premier filtre de la chaîne.
 *
 * Responsabilité : poser AuditThreadContext avant tout traitement applicatif,
 * propager le correlationId depuis le header entrant (ou en générer un),
 * et garantir le clear en finally.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter extends OncePerRequestFilter {

    private static final String CORRELATION_HEADER = "X-Correlation-Id";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        try {
            String correlationId = Optional
                    .ofNullable(request.getHeader(CORRELATION_HEADER))
                    .filter(h -> !h.isBlank())
                    .orElse(UUID.randomUUID().toString());

            AuditThreadContext.set(correlationId, extractUserId(), "HTTP");

            // Propage dans la response pour que le client puisse tracer
            response.setHeader(CORRELATION_HEADER, correlationId);

            filterChain.doFilter(request, response);
        } finally {
            AuditThreadContext.clear();
        }
    }

    private String extractUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getPrincipal())) {
            return auth.getName();
        }
        return "anonymous";
    }
}
