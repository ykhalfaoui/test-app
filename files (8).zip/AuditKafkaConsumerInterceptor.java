package com.example.audit.entrypoint;

import com.example.audit.AuditThreadContext;
import org.apache.kafka.clients.consumer.ConsumerInterceptor;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Header;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;

/**
 * Entry point Kafka — pose le contexte d'audit depuis les headers du message.
 *
 * Configuration :
 * spring.kafka.consumer.properties.interceptor.classes=com.example.audit.entrypoint.AuditKafkaConsumerInterceptor
 *
 * Headers Kafka attendus :
 * - X-Correlation-Id : propagé depuis le producteur
 * - X-User-Id        : identité de l'initiateur original
 */
public class AuditKafkaConsumerInterceptor<K, V> implements ConsumerInterceptor<K, V> {

    @Override
    public ConsumerRecords<K, V> onConsume(ConsumerRecords<K, V> records) {
        // Pour chaque batch, on prend le premier record pour initialiser le contexte
        // (dans la pratique, un consumer traite un message à la fois avec Spring Kafka)
        records.forEach(record -> {
            String correlationId = extractHeader(record.headers().lastHeader("X-Correlation-Id"));
            String userId        = extractHeader(record.headers().lastHeader("X-User-Id"));

            AuditThreadContext.set(
                    correlationId != null ? correlationId : UUID.randomUUID().toString(),
                    userId        != null ? userId        : "system",
                    "KAFKA"
            );
        });
        return records;
    }

    @Override
    public void onCommit(Map<TopicPartition, OffsetAndMetadata> offsets) {
        AuditThreadContext.clear();
    }

    @Override
    public void close() {
        AuditThreadContext.clear();
    }

    @Override
    public void configure(Map<String, ?> configs) {}

    private String extractHeader(Header header) {
        if (header == null) return null;
        return new String(header.value(), StandardCharsets.UTF_8);
    }
}
