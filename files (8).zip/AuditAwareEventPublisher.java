package com.example.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.lang.reflect.Constructor;
import java.lang.reflect.RecordComponent;

/**
 * Publisher @Primary — intercepte TOUS les events Spring.
 *
 * Logique d'enrichissement :
 * ┌─────────────────────────────────────────────────────────────────┐
 * │ event non-AuditableEvent ?     → pass-through (events Spring)  │
 * │ auditMetadata != null ?        → pass-through (replay Modulith) │
 * │ sinon                          → injectMetadata() via reflection│
 * └─────────────────────────────────────────────────────────────────┘
 *
 * Retry safety :
 * - Spring Modulith désérialise l'event depuis event_publication (JSON)
 * - AuditMetadata est preserved dans le JSON → auditMetadata != null au retry
 * - Guard 2 assure le pass-through → correlationId original conservé ✓
 *
 * Dégradation gracieuse :
 * - Tout échec de reflection → event publié tel quel (jamais de crash)
 */
@Component
@Primary
public class AuditAwareEventPublisher implements ApplicationEventPublisher {

    private static final Logger log = LoggerFactory.getLogger(AuditAwareEventPublisher.class);

    private final ApplicationEventPublisher delegate;
    private final AuditContextHolder auditContextHolder;

    public AuditAwareEventPublisher(
            @Qualifier("originalEventPublisher") ApplicationEventPublisher delegate,
            AuditContextHolder auditContextHolder) {
        this.delegate = delegate;
        this.auditContextHolder = auditContextHolder;
    }

    @Override
    public void publishEvent(Object event) {
        delegate.publishEvent(enrich(event));
    }

    // ─────────────────────────────────────────────────────────────────────
    // Enrichissement
    // ─────────────────────────────────────────────────────────────────────

    private Object enrich(Object event) {
        // Guard 1 — events système Spring (ContextRefreshedEvent, etc.) → pas touche
        if (!(event instanceof AuditableEvent auditable)) {
            return event;
        }

        // Guard 2 — déjà enrichi : replay Modulith ou event cascadé depuis un listener retryé
        if (auditable.auditMetadata() != null) {
            log.debug("[AUDIT] Event {} déjà enrichi (correlationId={}), pass-through",
                    event.getClass().getSimpleName(),
                    auditable.auditMetadata().correlationId());
            return event;
        }

        // Premier publish — on injecte le contexte courant (ThreadLocal + Micrometer)
        try {
            AuditMetadata metadata = auditContextHolder.current();
            Object enriched = injectMetadata(event, metadata);
            log.debug("[AUDIT] Event {} enrichi (correlationId={}, source={})",
                    event.getClass().getSimpleName(),
                    metadata.correlationId(),
                    metadata.sourceSystem());
            return enriched;
        } catch (Exception e) {
            // Dégradation gracieuse — jamais de crash au démarrage Spring
            log.warn("[AUDIT] Impossible d'enrichir l'event {} : {}",
                    event.getClass().getSimpleName(), e.getMessage());
            return event;
        }
    }

    /**
     * Reconstruit le record en substituant le champ `auditMetadata`.
     *
     * Convention : le champ dans le record DOIT s'appeler exactement `auditMetadata`.
     * Tous les autres champs sont recopiés via les accesseurs du record.
     */
    private Object injectMetadata(Object event, AuditMetadata metadata) throws Exception {
        Class<?> clazz = event.getClass();

        if (!clazz.isRecord()) {
            throw new UnsupportedOperationException(
                    "AuditableEvent doit être un record Java : " + clazz.getSimpleName());
        }

        RecordComponent[] components = clazz.getRecordComponents();
        Object[] args  = new Object[components.length];
        Class<?>[] types = new Class<?>[components.length];

        boolean foundAuditMetadata = false;

        for (int i = 0; i < components.length; i++) {
            RecordComponent component = components[i];
            types[i] = component.getType();

            if ("auditMetadata".equals(component.getName())) {
                args[i] = metadata;
                foundAuditMetadata = true;
            } else {
                args[i] = component.getAccessor().invoke(event);
            }
        }

        if (!foundAuditMetadata) {
            throw new IllegalArgumentException(
                    "Record " + clazz.getSimpleName() + " implémente AuditableEvent " +
                    "mais n'a pas de champ 'auditMetadata'. Convention non respectée.");
        }

        Constructor<?> canonical = clazz.getDeclaredConstructor(types);
        canonical.setAccessible(true);
        return canonical.newInstance(args);
    }
}
