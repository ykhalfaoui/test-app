package com.example.audit;

/**
 * ThreadLocal dédié à l'audit context.
 * Posé UNE SEULE FOIS par les entry points (HTTP Filter, Kafka Interceptor, ShedLock Aspect).
 * Restauré automatiquement par AuditContextRestorerAspect lors des retries.
 *
 * Note : remplace cette implémentation par ton ThreadLocal existant si tu en as un.
 */
public final class AuditThreadContext {

    private AuditThreadContext() {}

    private static final ThreadLocal<String> CORRELATION_ID = new ThreadLocal<>();
    private static final ThreadLocal<String> USER_ID        = new ThreadLocal<>();
    private static final ThreadLocal<String> SOURCE_SYSTEM  = new ThreadLocal<>();

    /**
     * Posé par les entry points avant tout traitement applicatif.
     */
    public static void set(String correlationId, String userId, String sourceSystem) {
        CORRELATION_ID.set(correlationId);
        USER_ID.set(userId);
        SOURCE_SYSTEM.set(sourceSystem);
    }

    /**
     * Restaure le contexte depuis un AuditMetadata existant (cas retry/replay).
     * Marque la source comme REPLAY pour distinguer dans le trail.
     */
    public static void restoreFrom(AuditMetadata metadata) {
        CORRELATION_ID.set(metadata.correlationId());
        USER_ID.set(metadata.userId());
        SOURCE_SYSTEM.set("REPLAY");
    }

    public static String getCorrelationId() { return CORRELATION_ID.get(); }
    public static String getUserId()        { return USER_ID.get(); }
    public static String getSourceSystem()  { return SOURCE_SYSTEM.get(); }

    public static boolean isEmpty() {
        return CORRELATION_ID.get() == null;
    }

    /**
     * TOUJOURS appeler en finally dans les entry points — évite les fuites entre requêtes.
     */
    public static void clear() {
        CORRELATION_ID.remove();
        USER_ID.remove();
        SOURCE_SYSTEM.remove();
    }
}
