package com.example.audit;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.time.Instant;

/**
 * Embedded dans chaque domain event.
 * Survit aux crashs, replays, et changements de thread.
 *
 * Convention : toujours en DERNIER champ dans le record — simplifie la reflection.
 *
 * @JsonDeserialize garantit que Jackson reconstruit ce record lors d'un retry
 * via IncompleteEventPublications (désérialisation depuis event_publication table).
 */
@JsonDeserialize
public record AuditMetadata(
        String correlationId,
        String traceId,
        String spanId,
        String userId,
        String sourceSystem,   // HTTP | KAFKA | SHEDLOCK | REPLAY | INTERNAL
        Instant initiatedAt
) {}
