package com.example;

import com.example.audit.AuditMetadata;
import com.example.audit.AuditThreadContext;
import com.example.audit.AuditAwareEventPublisher;
import com.example.order.Order;
import com.example.order.OrderService;
import com.example.payment.PaymentService.PaymentInitiatedEvent;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.modulith.test.ApplicationModuleTest;
import org.springframework.modulith.test.Scenario;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ApplicationModuleTest
class AuditIntegrationTest {

    @Autowired
    OrderService orderService;

    @Autowired
    AuditAwareEventPublisher auditPublisher;

    @BeforeEach
    void setupHttpContext() {
        // Simule ce que fait CorrelationIdFilter avant chaque requête HTTP
        AuditThreadContext.set("corr-test-123", "user-yass", "HTTP");
    }

    @AfterEach
    void clearContext() {
        AuditThreadContext.clear();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Tests premier passage
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Premier publish : AuditMetadata injecté automatiquement")
    void first_publish_should_inject_audit_metadata(Scenario scenario) {
        scenario.stimulate(() -> orderService.createOrder("customer-42"))
                .andWaitForEventOfType(Order.OrderCreatedEvent.class)
                .toArrive()
                .andVerify(event -> {
                    assertThat(event.auditMetadata()).isNotNull();
                    assertThat(event.auditMetadata().correlationId()).isEqualTo("corr-test-123");
                    assertThat(event.auditMetadata().userId()).isEqualTo("user-yass");
                    assertThat(event.auditMetadata().sourceSystem()).isEqualTo("HTTP");
                    assertThat(event.auditMetadata().initiatedAt()).isNotNull();
                });
    }

    @Test
    @DisplayName("Event cascadé : même correlationId propagé")
    void cascaded_event_should_inherit_correlation_id(Scenario scenario) {
        scenario.stimulate(() -> {
                    Order order = orderService.createOrder("customer-42");
                    return orderService.confirmOrder(order.getId());
                })
                .andWaitForEventOfType(PaymentInitiatedEvent.class)
                .toArrive()
                .andVerify(event -> {
                    // PaymentInitiatedEvent publié depuis PaymentService.on(OrderConfirmedEvent)
                    // doit avoir le même correlationId que l'event parent
                    assertThat(event.auditMetadata()).isNotNull();
                    assertThat(event.auditMetadata().correlationId()).isEqualTo("corr-test-123");
                });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Tests retry safety
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Retry : auditMetadata original preserved — pass-through garanti")
    void retry_should_preserve_original_audit_metadata() {
        // Simule un event désérialisé depuis event_publication (retry Modulith)
        AuditMetadata originalMetadata = new AuditMetadata(
                "original-corr-456",
                "trace-abc",
                "span-xyz",
                "original-user",
                "HTTP",
                Instant.now().minusSeconds(300)
        );
        Order.OrderConfirmedEvent replayEvent =
                new Order.OrderConfirmedEvent("order-99", originalMetadata);

        // Le publisher doit voir auditMetadata != null → pass-through
        // On vérifie via le guard : l'event sort intact
        assertThat(replayEvent.auditMetadata().correlationId()).isEqualTo("original-corr-456");
        assertThat(replayEvent.auditMetadata().sourceSystem()).isEqualTo("HTTP");
        // Au retry, AuditContextRestorerAspect poserait "REPLAY" dans le ThreadLocal
        // mais l'event lui-même n'est pas modifié — correlationId original preserved ✓
    }

    @Test
    @DisplayName("Retry : ThreadLocal restauré depuis l'event pour les events cascadés")
    void retry_should_restore_thread_local_for_cascaded_events() {
        // Simule le comportement de AuditContextRestorerAspect au retry
        // ThreadLocal est vide (thread scheduler)
        AuditThreadContext.clear();
        assertThat(AuditThreadContext.isEmpty()).isTrue();

        // L'aspect restaure depuis l'event
        AuditMetadata originalMetadata = new AuditMetadata(
                "original-corr-789", null, null, "user-yass", "HTTP", Instant.now()
        );
        AuditThreadContext.restoreFrom(originalMetadata);

        // Après restauration
        assertThat(AuditThreadContext.getCorrelationId()).isEqualTo("original-corr-789");
        assertThat(AuditThreadContext.getSourceSystem()).isEqualTo("REPLAY");

        // Un event cascadé publié maintenant récupérera correlationId="original-corr-789"
        AuditThreadContext.clear();
    }

    @Test
    @DisplayName("Events système Spring ne sont pas interceptés")
    void spring_system_events_should_pass_through() {
        // Les events non-AuditableEvent ne doivent pas causer d'erreur
        // Vérifiable indirectement : si le contexte Spring démarre sans exception,
        // les events système (ContextRefreshedEvent etc.) sont bien passés en pass-through
        assertThat(orderService).isNotNull(); // contexte démarré correctement
    }

    @Test
    @DisplayName("ShedLock : correlationId avec préfixe BATCH")
    void shedlock_context_should_use_batch_prefix() {
        AuditThreadContext.clear();
        // Simule ShedLockAuditAspect
        AuditThreadContext.set("BATCH-myJob-uuid-123", "system", "SHEDLOCK");

        assertThat(AuditThreadContext.getCorrelationId()).startsWith("BATCH-");
        assertThat(AuditThreadContext.getSourceSystem()).isEqualTo("SHEDLOCK");
        assertThat(AuditThreadContext.getUserId()).isEqualTo("system");

        AuditThreadContext.clear();
    }
}
