package com.example.audit;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Aspect critique pour le retry safety.
 *
 * Problème qu'il résout :
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │ Au retry via IncompleteEventPublications :                         │
 * │  - thread scheduler → AuditThreadContext VIDE                      │
 * │  - l'event retryé a son auditMetadata preserved ✓                  │
 * │  - MAIS si le listener publie de nouveaux events en cascade        │
 * │    → ces events n'ont pas de correlationId → perte de traçabilité  │
 * └─────────────────────────────────────────────────────────────────────┘
 *
 * Solution :
 * Avant chaque @ApplicationModuleListener, restaure le ThreadLocal
 * depuis l'auditMetadata de l'event reçu → les events cascadés héritent
 * du même correlationId que l'event original.
 *
 * Fonctionne aussi en premier passage (idempotent — ThreadLocal déjà posé
 * par le HTTP Filter, mais on l'écrase avec la même valeur).
 */
@Aspect
@Component
public class AuditContextRestorerAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditContextRestorerAspect.class);

    @Around("@annotation(org.springframework.modulith.events.ApplicationModuleListener)")
    public Object restoreAuditContext(ProceedingJoinPoint pjp) throws Throwable {
        AuditMetadata metadata = extractMetadata(pjp.getArgs());

        if (metadata != null) {
            boolean isRetry = AuditThreadContext.isEmpty();

            if (isRetry) {
                // Retry : ThreadLocal vide → on restaure depuis l'event
                AuditThreadContext.restoreFrom(metadata);
                log.debug("[AUDIT] Contexte restauré pour retry (correlationId={}, originalSource={})",
                        metadata.correlationId(), metadata.sourceSystem());
            }
            // Premier passage : ThreadLocal déjà posé par l'entry point — on ne touche pas
        }

        try {
            return pjp.proceed();
        } finally {
            // Ne clear que si c'est nous qui avons posé le contexte (retry)
            // En premier passage, le Filter/Interceptor/Aspect entry point gère le clear
            if (metadata != null && "REPLAY".equals(AuditThreadContext.getSourceSystem())) {
                AuditThreadContext.clear();
            }
        }
    }

    private AuditMetadata extractMetadata(Object[] args) {
        for (Object arg : args) {
            if (arg instanceof AuditableEvent auditable && auditable.auditMetadata() != null) {
                return auditable.auditMetadata();
            }
        }
        return null;
    }
}
