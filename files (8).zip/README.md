# Audit Transparent — Spring Modulith v2
## Avec Retry Safety complète

---

## Architecture complète

```
┌──────────────────────────────────────────────────────────────────────────┐
│  ENTRY POINTS — posent AuditThreadContext UNE SEULE FOIS                │
│                                                                          │
│  CorrelationIdFilter        AuditKafkaConsumerInterceptor   ShedLockAspect│
│  (HTTP)                     (KAFKA)                         (SHEDLOCK)   │
│  ThreadLocal.set(           ThreadLocal.set(                ThreadLocal.set(
│    correlationId,             correlationId,                  BATCH-job,
│    userId, "HTTP")            userId, "KAFKA")                "system", "SHEDLOCK")
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │
                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  SERVICE APPLICATIF (aucune connaissance de l'audit)                    │
│  orderService.confirmOrder() → repository.save(order)                   │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ AbstractAggregateRoot publie @DomainEvents
                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  AuditAwareEventPublisher @Primary                                       │
│                                                                          │
│  Guard 1 : non-AuditableEvent ?      → pass-through (events Spring)     │
│  Guard 2 : auditMetadata != null ?   → pass-through (replay)            │
│  Sinon   : injectMetadata()          → reconstruction record via reflect │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ event enrichi (correlationId, traceId, userId...)
                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  LISTENERS @ApplicationModuleListener                                    │
│                                                                          │
│  AuditContextRestorerAspect  ←── intercepte AVANT chaque listener       │
│  → si ThreadLocal vide (retry) : ThreadLocal.restoreFrom(event.metadata) │
│  → si ThreadLocal présent (1er passage) : ne touche pas                 │
│                                                                          │
│  PaymentService.on(OrderConfirmedEvent)                                  │
│  → publie PaymentInitiatedEvent(null)                                    │
│  → AuditAwareEventPublisher injecte correlationId depuis ThreadLocal ✓  │
│                                                                          │
│  AuditTrailListener.on(AuditableEvent)                                   │
│  → persist dans audit_trail                                             │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## Flux Retry (IncompleteEventPublications)

```
1. CRASH pendant AuditTrailListener
   └── event_publication : status = INCOMPLETE
       payload JSON : { "orderId": "x", "auditMetadata": { "correlationId": "abc" } }

2. RETRY (thread scheduler ShedLock)
   └── Spring Modulith désérialise OrderConfirmedEvent depuis JSON
       └── auditMetadata.correlationId = "abc"  ← preserved ✓

3. AuditAwareEventPublisher.enrich()
   └── auditMetadata != null → pass-through ✓  (correlationId "abc" conservé)

4. AuditContextRestorerAspect (AVANT le listener)
   └── ThreadLocal vide (thread scheduler) → isEmpty() = true
   └── ThreadLocal.restoreFrom(event.auditMetadata)
       └── correlationId = "abc", sourceSystem = "REPLAY"

5. PaymentService.on() publie PaymentInitiatedEvent(null)
   └── AuditAwareEventPublisher injecte correlationId = "abc" ✓
   └── Même correlationId propagé sur tous les events cascadés ✓

6. AuditTrailListener reçoit les events
   └── trail enregistré avec correlationId = "abc" et sourceSystem = "REPLAY"
```

---

## Fichiers

```
audit/
├── AuditMetadata.java                   # Record — embedded dans chaque event
├── AuditableEvent.java                  # Interface marker (dépendance minimale)
├── AuditThreadContext.java              # ThreadLocal : correlationId, userId, sourceSystem
├── AuditContextHolder.java             # Construit AuditMetadata (ThreadLocal + Micrometer)
├── AuditAwareEventPublisher.java       # @Primary — enrichit via reflection + 2 guards
├── AuditContextRestorerAspect.java     # Restaure ThreadLocal au retry ← CLÉ DU RETRY
├── AuditConfig.java                    # @Qualifier publisher natif + Jackson ObjectMapper
└── entrypoint/
    ├── CorrelationIdFilter.java        # HTTP entry point
    ├── AuditKafkaConsumerInterceptor   # Kafka entry point
    └── ShedLockAuditAspect.java        # ShedLock entry point

order/
├── Order.java                          # AbstractAggregateRoot — 100% DDD, aucun audit
└── OrderService.java                   # Service — aucune mention d'audit

payment/
└── PaymentService.java                 # Exemple event cascadé avec propagation correlationId

trail/
└── AuditTrailListener.java             # @ApplicationModuleListener — seul module qui connaît l'audit
```

---

## Convention unique à respecter

Dans chaque `record` qui implémente `AuditableEvent` :

```java
public record MonEvent(
    String champMetier1,
    String champMetier2,
    AuditMetadata auditMetadata   // ← toujours en DERNIER, toujours null à la création
) implements AuditableEvent {}
```

L'entité ou le service crée l'event avec `null` — le publisher injecte le contexte.

---

## Retry Safety Checklist

| Point                                    | Mécanisme                              | Status |
|------------------------------------------|----------------------------------------|--------|
| AuditMetadata preserved en base          | `@JsonDeserialize` + JavaTimeModule    | ✓      |
| Pass-through au retry                    | Guard `auditMetadata != null`          | ✓      |
| ThreadLocal restauré au retry            | `AuditContextRestorerAspect`           | ✓      |
| Events cascadés dans listener retryé     | ThreadLocal restauré → publisher l'utilise | ✓  |
| Trail distingue retry vs premier passage | `sourceSystem = "REPLAY"`              | ✓      |
| Pas de fuite ThreadLocal                 | `clear()` en finally partout           | ✓      |
