package com.example.order;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Repository
interface OrderRepository extends JpaRepository<Order, String> {}

/**
 * Service applicatif — aucune mention d'audit.
 *
 * Flux complet :
 * 1. HTTP Filter pose AuditThreadContext (correlationId, userId, "HTTP")
 * 2. Service appelle repository.save()
 * 3. AbstractAggregateRoot publie les @DomainEvents
 * 4. AuditAwareEventPublisher (@Primary) intercepte et injecte AuditMetadata
 * 5. Les listeners reçoivent l'event enrichi
 */
@Service
public class OrderService {

    private final OrderRepository repository;

    public OrderService(OrderRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public Order createOrder(String customerId) {
        Order order = Order.create(customerId);
        return repository.save(order);
        // → publie OrderCreatedEvent enrichi automatiquement
    }

    @Transactional
    public Order confirmOrder(String orderId) {
        Order order = findById(orderId);
        order.confirm();
        return repository.save(order);
        // → publie OrderConfirmedEvent enrichi automatiquement
    }

    @Transactional
    public Order cancelOrder(String orderId, String reason) {
        Order order = findById(orderId);
        order.cancel(reason);
        return repository.save(order);
        // → publie OrderCancelledEvent enrichi automatiquement
    }

    private Order findById(String orderId) {
        return repository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + orderId));
    }
}
