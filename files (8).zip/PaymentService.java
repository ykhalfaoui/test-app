package com.example.payment;

import com.example.audit.AuditMetadata;
import com.example.audit.AuditableEvent;
import com.example.order.Order.OrderConfirmedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

/**
 * Module Payment — illustre la propagation du correlationId sur un event cascadé.
 *
 * Scénario :
 * OrderConfirmedEvent (correlationId=X)
 *   → PaymentService.on()
 *   → publie PaymentInitiatedEvent(null)   ← auditMetadata null
 *   → AuditAwareEventPublisher enrichit    ← ThreadLocal présent (posé par Filter ou Aspect)
 *   → PaymentInitiatedEvent (correlationId=X) ✓ même correlationId propagé
 *
 * Au RETRY :
 * OrderConfirmedEvent (correlationId=X) désérialisé depuis event_publication
 *   → AuditContextRestorerAspect restaure ThreadLocal (correlationId=X, source=REPLAY)
 *   → PaymentService.on()
 *   → publie PaymentInitiatedEvent(null)
 *   → AuditAwareEventPublisher enrichit avec correlationId=X ✓
 */
@Component
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final ApplicationEventPublisher eventPublisher;

    public PaymentService(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    @ApplicationModuleListener
    public void on(OrderConfirmedEvent event) {
        log.info("[PAYMENT] Initiation paiement pour order={} correlationId={}",
                event.orderId(),
                event.auditMetadata() != null ? event.auditMetadata().correlationId() : "N/A");

        // Simule la logique métier
        String paymentId = initiatePayment(event.orderId());

        // Event cascadé — auditMetadata null, sera enrichi par le publisher
        // avec le MÊME correlationId que l'event parent (ThreadLocal restauré par l'aspect)
        eventPublisher.publishEvent(new PaymentInitiatedEvent(paymentId, event.orderId(), null));
    }

    private String initiatePayment(String orderId) {
        return "PAY-" + orderId.substring(0, Math.min(8, orderId.length()));
    }

    // ─── Domain Event ────────────────────────────────────────────────────────

    public record PaymentInitiatedEvent(
            String paymentId,
            String orderId,
            AuditMetadata auditMetadata    // null à la création — enrichi par le publisher
    ) implements AuditableEvent {}
}
