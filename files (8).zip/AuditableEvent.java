package com.example.audit;

/**
 * Interface marker à implémenter par tous les domain events auditables.
 *
 * Les modules de domaine dépendent uniquement de cette interface légère.
 * L'enrichissement est entièrement géré par l'infrastructure (AuditAwareEventPublisher).
 */
public interface AuditableEvent {
    AuditMetadata auditMetadata();
}
