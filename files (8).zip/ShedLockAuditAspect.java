package com.example.audit.entrypoint;

import com.example.audit.AuditThreadContext;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Entry point ShedLock — pose le contexte d'audit pour les jobs batch clusterisés.
 *
 * Exécuté AVANT AuditContextRestorerAspect (order plus élevé) pour garantir
 * que le ThreadLocal est bien posé avant tout publish d'event dans le job.
 *
 * @Order(1) — priorité haute pour être exécuté en premier dans la chaîne AOP
 */
@Aspect
@Component
@Order(1)
public class ShedLockAuditAspect {

    @Around("@annotation(net.javacrumbs.shedlock.spring.annotation.SchedulerLock)")
    public Object aroundScheduledJob(ProceedingJoinPoint pjp) throws Throwable {
        String jobName = pjp.getSignature().getName();
        try {
            AuditThreadContext.set(
                    "BATCH-" + jobName + "-" + UUID.randomUUID(),
                    "system",
                    "SHEDLOCK"
            );
            return pjp.proceed();
        } finally {
            AuditThreadContext.clear();
        }
    }
}
