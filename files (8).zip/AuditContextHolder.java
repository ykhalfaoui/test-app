package com.example.audit;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

/**
 * Construit l'AuditMetadata courante en combinant :
 * - Ton ThreadLocal (correlationId, userId, sourceSystem) — posé par les entry points
 * - Micrometer Tracing (traceId, spanId) — propagation cross-thread automatique
 *
 * Appelé uniquement par AuditAwareEventPublisher lors du PREMIER publish.
 * Jamais appelé lors d'un retry (auditMetadata déjà présent dans l'event).
 */
@Component
public class AuditContextHolder {

    private final Tracer tracer;

    public AuditContextHolder(Tracer tracer) {
        this.tracer = tracer;
    }

    public AuditMetadata current() {
        // Micrometer Tracing — null-safe
        Span currentSpan = tracer.currentSpan();
        String traceId = currentSpan != null ? currentSpan.context().traceId() : null;
        String spanId  = currentSpan != null ? currentSpan.context().spanId()  : null;

        // ThreadLocal — posé par les entry points
        String correlationId = AuditThreadContext.getCorrelationId();
        String userId        = AuditThreadContext.getUserId();
        String sourceSystem  = AuditThreadContext.getSourceSystem();

        // Fallbacks défensifs — ne jamais laisser correlationId null
        if (correlationId == null) correlationId = UUID.randomUUID().toString();
        if (userId == null)        userId        = "system";
        if (sourceSystem == null)  sourceSystem  = "INTERNAL";

        return new AuditMetadata(correlationId, traceId, spanId, userId, sourceSystem, Instant.now());
    }
}
