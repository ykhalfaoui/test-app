package com.example.order;

import com.example.audit.AuditMetadata;
import com.example.audit.AuditableEvent;
import jakarta.persistence.*;
import org.springframework.data.domain.AbstractAggregateRoot;

/**
 * Agrégat Order — 100% DDD, aucune connaissance de l'infrastructure d'audit.
 *
 * Les events sont créés avec auditMetadata = null.
 * L'AuditAwareEventPublisher injecte le contexte au moment du repository.save().
 *
 * Convention : champ `auditMetadata` TOUJOURS en dernier dans chaque record.
 */
@Entity
@Table(name = "orders")
public class Order extends AbstractAggregateRoot<Order> {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    private String customerId;

    protected Order() {}

    // ─── Factory ────────────────────────────────────────────────────────────

    public static Order create(String customerId) {
        Order order = new Order();
        order.customerId = customerId;
        order.status = OrderStatus.PENDING;
        // auditMetadata = null — sera injecté par AuditAwareEventPublisher au save()
        order.registerEvent(new OrderCreatedEvent(order.id, customerId, null));
        return order;
    }

    // ─── Comportements ──────────────────────────────────────────────────────

    public Order confirm() {
        if (this.status != OrderStatus.PENDING) {
            throw new IllegalStateException(
                    "Order " + id + " cannot be confirmed from status " + status);
        }
        this.status = OrderStatus.CONFIRMED;
        registerEvent(new OrderConfirmedEvent(this.id, null));
        return this;
    }

    public Order cancel(String reason) {
        if (this.status == OrderStatus.CANCELLED) {
            throw new IllegalStateException("Order " + id + " already cancelled");
        }
        this.status = OrderStatus.CANCELLED;
        registerEvent(new OrderCancelledEvent(this.id, reason, null));
        return this;
    }

    // ─── Domain Events ──────────────────────────────────────────────────────

    public record OrderCreatedEvent(
            String orderId,
            String customerId,
            AuditMetadata auditMetadata      // null à la création — convention ← dernier champ
    ) implements AuditableEvent {}

    public record OrderConfirmedEvent(
            String orderId,
            AuditMetadata auditMetadata
    ) implements AuditableEvent {}

    public record OrderCancelledEvent(
            String orderId,
            String reason,
            AuditMetadata auditMetadata
    ) implements AuditableEvent {}

    // ─── Getters ────────────────────────────────────────────────────────────

    public String getId()          { return id; }
    public OrderStatus getStatus() { return status; }
    public String getCustomerId()  { return customerId; }

    public enum OrderStatus { PENDING, CONFIRMED, CANCELLED }
}
