package com.example.trail;

import com.example.audit.AuditMetadata;
import com.example.audit.AuditableEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.time.Instant;

/**
 * Module Trail — seul module qui connaît l'audit.
 * Écoute TOUS les AuditableEvent de tous les modules.
 *
 * @ApplicationModuleListener garantit :
 * - Exécution asynchrone dans une transaction séparée
 * - Retry automatique via IncompleteEventPublications en cas d'échec
 * - Au retry : AuditContextRestorerAspect restaure le correlationId original ✓
 */
@Component
public class AuditTrailListener {

    private static final Logger log = LoggerFactory.getLogger(AuditTrailListener.class);

    private final AuditTrailRepository repository;
    private final ObjectMapper objectMapper;

    public AuditTrailListener(AuditTrailRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    @ApplicationModuleListener
    public void on(AuditableEvent event) {
        AuditMetadata meta = event.auditMetadata();

        if (meta == null) {
            log.warn("[TRAIL] AuditableEvent {} reçu sans metadata — skipping",
                    event.getClass().getSimpleName());
            return;
        }

        AuditTrailEntry entry = new AuditTrailEntry(
                event.getClass().getSimpleName(),
                meta.correlationId(),
                meta.traceId(),
                meta.spanId(),
                meta.userId(),
                meta.sourceSystem(),
                meta.initiatedAt(),
                Instant.now(),
                serialize(event)
        );

        repository.save(entry);

        log.info("[TRAIL] {} | correlationId={} | user={} | source={}",
                entry.eventType(), meta.correlationId(), meta.userId(), meta.sourceSystem());
    }

    private String serialize(Object event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (JsonProcessingException e) {
            return "{\"error\":\"serialization_failed\",\"type\":\"" +
                    event.getClass().getSimpleName() + "\"}";
        }
    }
}

// ─── Entity ─────────────────────────────────────────────────────────────────

@Entity
@Table(name = "audit_trail", indexes = {
        @Index(name = "idx_audit_correlation", columnList = "correlation_id"),
        @Index(name = "idx_audit_trace",       columnList = "trace_id"),
        @Index(name = "idx_audit_user",        columnList = "user_id"),
        @Index(name = "idx_audit_occurred",    columnList = "occurred_at")
})
class AuditTrailEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "event_type",     nullable = false)
    private String eventType;

    @Column(name = "correlation_id", nullable = false, length = 128)
    private String correlationId;

    @Column(name = "trace_id",  length = 64)
    private String traceId;

    @Column(name = "span_id",   length = 64)
    private String spanId;

    @Column(name = "user_id",   length = 128)
    private String userId;

    @Column(name = "source_system", length = 50)
    private String sourceSystem;

    @Column(name = "initiated_at")
    private Instant initiatedAt;

    @Column(name = "occurred_at", nullable = false)
    private Instant occurredAt;

    @Column(name = "payload", columnDefinition = "TEXT")
    private String payload;

    protected AuditTrailEntry() {}

    AuditTrailEntry(String eventType, String correlationId, String traceId, String spanId,
                    String userId, String sourceSystem, Instant initiatedAt,
                    Instant occurredAt, String payload) {
        this.eventType     = eventType;
        this.correlationId = correlationId;
        this.traceId       = traceId;
        this.spanId        = spanId;
        this.userId        = userId;
        this.sourceSystem  = sourceSystem;
        this.initiatedAt   = initiatedAt;
        this.occurredAt    = occurredAt;
        this.payload       = payload;
    }

    String eventType()     { return eventType; }
    String correlationId() { return correlationId; }
}

@Repository
interface AuditTrailRepository extends JpaRepository<AuditTrailEntry, String> {}
