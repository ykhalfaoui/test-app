package com.example.inbox;

import com.example.shared.AuditMetadata;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

/**
 * Entité Inbox : représente un message Kafka reçu et persisté AVANT traitement.
 *
 * Pattern : le KafkaListener persiste l'InboxMessage en premier,
 * PUIS déclenche le traitement. En cas de crash, le message est rejoué
 * depuis l'inbox (ShedLock + polling ou Modulith IncompleteEventPublications).
 *
 * L'AuditMetadata est rempli depuis les headers Kafka (traceId, correlationId)
 * AVANT la persistance via InboxMessageFactory.
 */
@Entity
@Table(
    name = "inbox_message",
    indexes = {
        @Index(name = "idx_inbox_trace_id",       columnList = "trace_id"),
        @Index(name = "idx_inbox_correlation_id", columnList = "correlation_id"),
        @Index(name = "idx_inbox_status",         columnList = "status"),
        @Index(name = "idx_inbox_topic",          columnList = "topic, status"),
        @Index(name = "idx_inbox_created_at",     columnList = "created_at")
    }
)
public class InboxMessage {

    @Id
    @Column(name = "id", length = 36)
    private String id = UUID.randomUUID().toString();

    // ── Métadonnées Kafka ──────────────────────────────────────────────────────

    @Column(name = "topic", nullable = false, length = 200)
    private String topic;

    @Column(name = "partition_number")
    private Integer partition;

    @Column(name = "kafka_offset")
    private Long offset;

    @Column(name = "kafka_key", length = 200)
    private String kafkaKey;

    // ── Payload ───────────────────────────────────────────────────────────────

    @Column(name = "event_type", nullable = false, length = 100)
    private String eventType;

    @Column(name = "payload", nullable = false, columnDefinition = "TEXT")
    private String payload; // JSON sérialisé

    // ── Statut de traitement ──────────────────────────────────────────────────

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private InboxStatus status = InboxStatus.PENDING;

    @Column(name = "retry_count")
    private int retryCount = 0;

    @Column(name = "max_retries")
    private int maxRetries = 3;

    @Column(name = "last_error", columnDefinition = "TEXT")
    private String lastError;

    @Column(name = "processed_at")
    private Instant processedAt;

    @Column(name = "next_retry_at")
    private Instant nextRetryAt;

    // ── Corrélation avec Outbox ───────────────────────────────────────────────

    /**
     * ID du ou des OutboxMessage(s) générés par le traitement de cet InboxMessage.
     * Stocké en JSON array pour gérer le cas 1 inbox → N outbox (ex: review + member sync).
     */
    @Column(name = "outbox_message_ids", columnDefinition = "TEXT")
    private String outboxMessageIds;

    // ── AuditMetadata : traceId, spanId, correlationId, source, timestamps ────

    @Embedded
    private AuditMetadata auditMetadata;

    // ── Version pour optimistic locking ───────────────────────────────────────

    @Version
    @Column(name = "version")
    private Long version;

    // ── Constructeurs ─────────────────────────────────────────────────────────

    protected InboxMessage() {}

    public static InboxMessage create(String topic, String eventType, String payload,
                                       String kafkaKey, Integer partition, Long offset,
                                       AuditMetadata auditMetadata) {
        InboxMessage msg = new InboxMessage();
        msg.topic = topic;
        msg.eventType = eventType;
        msg.payload = payload;
        msg.kafkaKey = kafkaKey;
        msg.partition = partition;
        msg.offset = offset;
        msg.auditMetadata = auditMetadata;
        return msg;
    }

    // ── Transitions d'état ────────────────────────────────────────────────────

    public void markProcessing() {
        this.status = InboxStatus.PROCESSING;
    }

    public void markProcessed() {
        this.status = InboxStatus.PROCESSED;
        this.processedAt = Instant.now();
    }

    public void markFailed(String error, Instant nextRetryAt) {
        this.retryCount++;
        this.lastError = error;
        this.nextRetryAt = nextRetryAt;
        this.status = retryCount >= maxRetries ? InboxStatus.DEAD_LETTER : InboxStatus.FAILED;
    }

    public void markDeadLetter(String reason) {
        this.status = InboxStatus.DEAD_LETTER;
        this.lastError = reason;
    }

    public boolean canRetry() {
        return status == InboxStatus.FAILED && retryCount < maxRetries;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String getId()                   { return id; }
    public String getTopic()                { return topic; }
    public Integer getPartition()           { return partition; }
    public Long getOffset()                 { return offset; }
    public String getKafkaKey()             { return kafkaKey; }
    public String getEventType()            { return eventType; }
    public String getPayload()              { return payload; }
    public InboxStatus getStatus()          { return status; }
    public int getRetryCount()              { return retryCount; }
    public String getLastError()            { return lastError; }
    public Instant getProcessedAt()         { return processedAt; }
    public Instant getNextRetryAt()         { return nextRetryAt; }
    public String getOutboxMessageIds()     { return outboxMessageIds; }
    public AuditMetadata getAuditMetadata() { return auditMetadata; }
    public Long getVersion()               { return version; }

    public void setOutboxMessageIds(String ids) { this.outboxMessageIds = ids; }

    public enum InboxStatus {
        PENDING,      // Reçu, pas encore traité
        PROCESSING,   // En cours de traitement
        PROCESSED,    // Traité avec succès
        FAILED,       // Échec, retry planifié
        DEAD_LETTER   // Retry épuisé, intervention manuelle requise
    }
}
