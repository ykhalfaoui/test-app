package com.example.shared;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import io.micrometer.tracing.baggage.BaggageManager;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

/**
 * Pont entre Micrometer (TraceContext, Baggage) et AuditMetadata JPA.
 *
 * Appelé par :
 *  - InboxMessage (avant persist)
 *  - OutboxMessage (avant persist)
 *  - AuditLog (avant persist)
 *  - Tout code métier qui veut enrichir un AuditMetadata
 *
 * Lit dans cet ordre de priorité :
 *  1. Span courant Micrometer (le plus fiable)
 *  2. MDC (fallback si le span n'est pas injecté dans le thread courant)
 *  3. String vide (jamais null, pour éviter les NPE en base)
 */
@Component
public class TracingMetadataEnricher {

    private static final String MDC_TRACE_ID      = "traceId";
    private static final String MDC_SPAN_ID       = "spanId";
    private static final String BAGGAGE_CORR_ID   = "correlationId";

    private final Tracer tracer;

    public TracingMetadataEnricher(Tracer tracer) {
        this.tracer = tracer;
    }

    /**
     * Enrichit un AuditMetadata existant avec le contexte de tracing courant.
     * À appeler juste avant la persistance si l'AuditMetadata n'est pas encore rempli.
     */
    public void enrich(AuditMetadata metadata) {
        if (metadata.getTraceId() == null || metadata.getTraceId().isBlank()) {
            metadata.setTraceId(currentTraceId());
        }
        if (metadata.getSpanId() == null || metadata.getSpanId().isBlank()) {
            metadata.setSpanId(currentSpanId());
        }
        if (metadata.getCorrelationId() == null || metadata.getCorrelationId().isBlank()) {
            metadata.setCorrelationId(currentCorrelationId());
        }
    }

    /**
     * Crée un AuditMetadata complet depuis le contexte courant.
     */
    public AuditMetadata capture(String source) {
        return AuditMetadata.of(
                currentTraceId(),
                currentSpanId(),
                currentCorrelationId(),
                source
        );
    }

    /**
     * Crée un AuditMetadata pour un message Outbox lié à un message Inbox.
     */
    public AuditMetadata captureForOutbox(String source, String originatingInboxMessageId) {
        return capture(source).withOriginatingMessageId(originatingInboxMessageId);
    }

    // ── Accesseurs individuels ────────────────────────────────────────────────

    public String currentTraceId() {
        Span span = tracer.currentSpan();
        if (span != null) {
            return span.context().traceId();
        }
        // Fallback MDC (alimenté par Micrometer si logback-spring.xml configuré)
        String fromMdc = MDC.get(MDC_TRACE_ID);
        return fromMdc != null ? fromMdc : "";
    }

    public String currentSpanId() {
        Span span = tracer.currentSpan();
        if (span != null) {
            return span.context().spanId();
        }
        String fromMdc = MDC.get(MDC_SPAN_ID);
        return fromMdc != null ? fromMdc : "";
    }

    public String currentCorrelationId() {
        // Baggage Micrometer (propagé via HTTP header X-Correlation-Id)
        Span span = tracer.currentSpan();
        if (span != null) {
            // Micrometer 1.11+ : via BaggageManager ou span.context().baggageItems()
            // Le correlationId est propagé via Micrometer Baggage field "correlationId"
            String fromBaggage = io.micrometer.tracing.Tracer.class
                    .cast(tracer)
                    .getBaggage(BAGGAGE_CORR_ID) != null
                    ? tracer.getBaggage(BAGGAGE_CORR_ID).get()
                    : null;
            if (fromBaggage != null && !fromBaggage.isBlank()) {
                return fromBaggage;
            }
        }
        // Fallback MDC
        String fromMdc = MDC.get(BAGGAGE_CORR_ID);
        return fromMdc != null ? fromMdc : "";
    }
}
