package com.yourcompany.integration.blueprism.client;

import com.yourcompany.integration.blueprism.generated.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.oxm.UnmarshallingFailureException;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;

/**
 * Client SOAP BluePrism avec gestion d'erreurs robuste
 * 
 * @author Yass
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class BluePrismSoapClient {
    
    private final WebServiceTemplate webServiceTemplate;
    
    /**
     * ⭐ Bloquer un client avec gestion d'erreurs
     */
    public BlockClientResponse blockClient(BlockClient request) {
        log.debug("Calling BlockClient operation");
        
        try {
            BlockClientResponse response = (BlockClientResponse) webServiceTemplate
                .marshalSendAndReceive(request);
            
            log.debug("BlockClient response: success={}", response.isSuccess());
            return response;
            
        } catch (UnmarshallingFailureException e) {
            // ⭐ Erreur de décodage de la réponse
            log.error("❌ DECODING ERROR: Cannot unmarshal SOAP response", e);
            log.error("Check logs/error-response.xml for raw XML");
            
            // Retourner une réponse d'erreur
            BlockClientResponse errorResponse = new BlockClientResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Response decoding error: " + e.getMessage());
            return errorResponse;
            
        } catch (SoapFaultClientException e) {
            // SOAP Fault du serveur
            log.error("SOAP Fault received: {}", e.getMessage());
            log.error("Fault Code: {}", e.getFaultCode());
            log.error("Fault String: {}", e.getFaultStringOrReason());
            
            BlockClientResponse errorResponse = new BlockClientResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("SOAP Fault: " + e.getFaultStringOrReason());
            return errorResponse;
            
        } catch (Exception e) {
            log.error("Unexpected error calling BlockClient", e);
            
            BlockClientResponse errorResponse = new BlockClientResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Unexpected error: " + e.getMessage());
            return errorResponse;
        }
    }
    
    /**
     * Ping - Health check
     */
    public PingResponse ping(Ping request) {
        log.debug("Calling Ping operation");
        
        try {
            return (PingResponse) webServiceTemplate
                .marshalSendAndReceive(request);
        } catch (Exception e) {
            log.error("Ping failed", e);
            
            PingResponse errorResponse = new PingResponse();
            errorResponse.setSuccess(false);
            errorResponse.setCheck("Error: " + e.getMessage());
            return errorResponse;
        }
    }
    
    /**
     * Valider client World Check
     */
    public ValidateClientResponse validateClient(ValidateClientWorLdCheck request) {
        log.debug("Calling ValidateClientWorLdCheck operation");
        
        try {
            return (ValidateClientResponse) webServiceTemplate
                .marshalSendAndReceive(request);
        } catch (UnmarshallingFailureException e) {
            log.error("❌ DECODING ERROR in validateClient", e);
            
            ValidateClientResponse errorResponse = new ValidateClientResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Decoding error: " + e.getMessage());
            return errorResponse;
        } catch (Exception e) {
            log.error("ValidateClient failed", e);
            
            ValidateClientResponse errorResponse = new ValidateClientResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Error: " + e.getMessage());
            return errorResponse;
        }
    }
    
    /**
     * Créer mémo KYC
     */
    public CreateKYCMemoResponse createKYCMemo(CreateKYCMemo request) {
        log.debug("Calling CreateKYCMemo operation");
        
        try {
            return (CreateKYCMemoResponse) webServiceTemplate
                .marshalSendAndReceive(request);
        } catch (UnmarshallingFailureException e) {
            log.error("❌ DECODING ERROR in createKYCMemo", e);
            
            CreateKYCMemoResponse errorResponse = new CreateKYCMemoResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Decoding error: " + e.getMessage());
            return errorResponse;
        } catch (Exception e) {
            log.error("CreateKYCMemo failed", e);
            
            CreateKYCMemoResponse errorResponse = new CreateKYCMemoResponse();
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Error: " + e.getMessage());
            return errorResponse;
        }
    }
}
