package com.example.inbox;

import com.example.shared.AuditMetadata;
import com.example.shared.TracingMetadataEnricher;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Tracer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Point d'entrée Kafka → Inbox.
 *
 * Responsabilité UNIQUE : persister le message dans l'inbox avec son contexte
 * de tracing complet. Le traitement métier se fait dans InboxProcessor (séparé).
 *
 * Flux :
 *  ConsumerRecord → extrait headers (traceId, correlationId) → InboxMessage → persist → ACK Kafka
 *
 * Le traceId Micrometer est déjà restauré par le RecordInterceptor (KafkaTracingConfig)
 * donc tracer.currentSpan() != null ici.
 */
@Component
public class InboxKafkaListener {

    private static final Logger log = LoggerFactory.getLogger(InboxKafkaListener.class);

    private static final String HEADER_CORRELATION_ID = "X-Correlation-Id";
    private static final String HEADER_EVENT_TYPE     = "X-Event-Type";

    private final InboxMessageRepository repository;
    private final TracingMetadataEnricher enricher;
    private final ObservationRegistry observationRegistry;
    private final Tracer tracer;

    public InboxKafkaListener(InboxMessageRepository repository,
                               TracingMetadataEnricher enricher,
                               ObservationRegistry observationRegistry,
                               Tracer tracer) {
        this.repository = repository;
        this.enricher = enricher;
        this.observationRegistry = observationRegistry;
        this.tracer = tracer;
    }

    /**
     * Listener principal - adapte les topics à ta config.
     *
     * @Transactional : la persistance de l'InboxMessage et le ACK Kafka
     * sont dans la même transaction. Si le persist échoue → pas d'ACK → replay Kafka.
     */
    @KafkaListener(
        topics = {"${app.kafka.topics.reviews}", "${app.kafka.topics.members}"},
        groupId = "${spring.kafka.consumer.group-id}",
        containerFactory = "kafkaListenerContainerFactory" // celui avec RecordInterceptor
    )
    @Transactional
    public void onMessage(ConsumerRecord<String, String> record, Acknowledgment ack) {

        return Observation.createNotStarted("inbox.receive", observationRegistry)
            .lowCardinalityKeyValue("topic", record.topic())
            .lowCardinalityKeyValue("event_type", extractHeader(record, HEADER_EVENT_TYPE, "unknown"))
            .observe(() -> {

                String correlationId = extractHeader(record, HEADER_CORRELATION_ID, null);
                String eventType     = extractHeader(record, HEADER_EVENT_TYPE, "unknown");

                // AuditMetadata : traceId/spanId depuis Micrometer (déjà restauré par RecordInterceptor)
                // correlationId depuis le header Kafka (priorité sur le Baggage si présent)
                AuditMetadata metadata = enricher.capture("kafka:" + record.topic());
                if (correlationId != null) {
                    metadata.setCorrelationId(correlationId); // override Baggage si header explicite
                }

                // Idempotence : vérifie si ce message a déjà été reçu (même offset + partition)
                boolean alreadyExists = repository.existsByTopicAndPartitionAndOffset(
                    record.topic(), record.partition(), record.offset()
                );

                if (alreadyExists) {
                    log.warn("Message dupliqué ignoré: topic={} partition={} offset={} traceId={}",
                        record.topic(), record.partition(), record.offset(),
                        metadata.getTraceId());
                    ack.acknowledge();
                    return;
                }

                InboxMessage inbox = InboxMessage.create(
                    record.topic(),
                    eventType,
                    record.value(),
                    record.key(),
                    record.partition(),
                    record.offset(),
                    metadata
                );

                repository.save(inbox);

                log.info("Inbox persisted: id={} topic={} eventType={} traceId={} correlationId={}",
                    inbox.getId(), record.topic(), eventType,
                    metadata.getTraceId(), metadata.getCorrelationId());

                // ACK Kafka seulement si persist OK
                ack.acknowledge();
            });
    }

    private String extractHeader(ConsumerRecord<?, ?> record, String headerName, String defaultValue) {
        Header header = record.headers().lastHeader(headerName);
        if (header == null) return defaultValue;
        return new String(header.value(), StandardCharsets.UTF_8);
    }
}
