package com.example.audit;

import com.example.shared.AuditMetadata;
import com.example.shared.TracingMetadataEnricher;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;

/**
 * JPA EntityListener global : enrichit automatiquement l'AuditMetadata
 * de TOUTES les entités qui en ont un, SANS avoir à le faire manuellement.
 *
 * Déclaré via META-INF/orm.xml (pas via @EntityListeners sur chaque entité)
 * pour éviter la duplication et rester transparent.
 *
 * Fonctionnement :
 *  @PrePersist → si AuditMetadata.traceId est vide → enrichit depuis Micrometer
 *  @PreUpdate  → met à jour le spanId courant (le span a pu changer entre persist et update)
 *
 * Entités couvertes automatiquement : InboxMessage, OutboxMessage, AuditLog
 * (et toute future entité avec @Embedded AuditMetadata)
 *
 * ⚠️  Pour l'injection Spring dans un EntityListener, deux approches :
 *     1. SpringBeanAutowiringSupport (simple mais deprecated)
 *     2. ApplicationContext static holder (recommandé - voir AuditEntityListenerSupport)
 */
@Component
public class AuditTrailEntityListener {

    private static final Logger log = LoggerFactory.getLogger(AuditTrailEntityListener.class);

    // Static holder pour l'injection dans le contexte JPA (hors Spring proxy)
    private static TracingMetadataEnricher enricher;

    /**
     * Appelé par Spring au démarrage pour injecter l'enricher.
     * Déclaré dans AuditTrailConfig.
     */
    public static void setEnricher(TracingMetadataEnricher e) {
        enricher = e;
    }

    /**
     * Avant toute insertion : enrichit le AuditMetadata si traceId manquant.
     */
    @PrePersist
    public void onPrePersist(Object entity) {
        AuditMetadata metadata = extractMetadata(entity);
        if (metadata == null || enricher == null) return;

        enricher.enrich(metadata);

        log.debug("AuditMetadata enriched @PrePersist: entity={} traceId={} correlationId={}",
            entity.getClass().getSimpleName(),
            metadata.getTraceId(),
            metadata.getCorrelationId());
    }

    /**
     * Avant toute mise à jour : rafraîchit le spanId (le span courant a pu changer).
     * Ne touche PAS au traceId ni au correlationId (ils doivent rester stables).
     */
    @PreUpdate
    public void onPreUpdate(Object entity) {
        AuditMetadata metadata = extractMetadata(entity);
        if (metadata == null || enricher == null) return;

        // Rafraîchit uniquement le spanId
        String currentSpanId = enricher.currentSpanId();
        if (currentSpanId != null && !currentSpanId.isBlank()) {
            metadata.setSpanId(currentSpanId);
        }
    }

    /**
     * Extraction réflexive de l'AuditMetadata depuis l'entité.
     * Supporte : InboxMessage, OutboxMessage, AuditLog (et tout futur ajout).
     */
    private AuditMetadata extractMetadata(Object entity) {
        if (entity instanceof InboxMessage inbox) return inbox.getAuditMetadata();
        if (entity instanceof OutboxMessage outbox) return outbox.getAuditMetadata();
        if (entity instanceof AuditLog audit) return audit.getAuditMetadata();
        return null;
    }
}
