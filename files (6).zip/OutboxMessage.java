package com.example.outbox;

import com.example.shared.AuditMetadata;
import jakarta.persistence.*;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

/**
 * Entité Outbox : représente un message à envoyer vers Salesforce.
 *
 * Créé lors du traitement d'un InboxMessage (dans la même transaction).
 * Envoyé vers Salesforce par OutboxSalesforceProcessor (ShedLock).
 *
 * Tracking complet :
 *  - traceId original (depuis l'InboxMessage source)
 *  - originatingMessageId → lien direct avec l'InboxMessage
 *  - timestamps pour calcul de latence bout-en-bout
 *  - retry count + dead letter pour alerting
 *  - salesforceId pour audit du diff avant/après
 */
@Entity
@Table(
    name = "outbox_message",
    indexes = {
        @Index(name = "idx_outbox_trace_id",         columnList = "trace_id"),
        @Index(name = "idx_outbox_correlation_id",   columnList = "correlation_id"),
        @Index(name = "idx_outbox_status",           columnList = "status"),
        @Index(name = "idx_outbox_target",           columnList = "salesforce_object_type, status"),
        @Index(name = "idx_outbox_created_at",       columnList = "created_at"),
        @Index(name = "idx_outbox_next_retry",       columnList = "next_retry_at, status")
    }
)
public class OutboxMessage {

    @Id
    @Column(name = "id", length = 36)
    private String id = UUID.randomUUID().toString();

    // ── Cible Salesforce ──────────────────────────────────────────────────────

    @Column(name = "salesforce_object_type", nullable = false, length = 50)
    private String salesforceObjectType; // ex: "Review__c", "Member__c"

    @Column(name = "salesforce_id", length = 18)
    private String salesforceId; // rempli après sync réussie (pour audit diff)

    @Column(name = "operation", nullable = false, length = 20)
    private String operation; // CREATE, UPDATE, DELETE, UPSERT

    @Column(name = "payload", nullable = false, columnDefinition = "TEXT")
    private String payload; // JSON du record Salesforce à envoyer

    @Column(name = "payload_before", columnDefinition = "TEXT")
    private String payloadBefore; // Snapshot avant sync (pour diff audit)

    // ── Statut ────────────────────────────────────────────────────────────────

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private OutboxStatus status = OutboxStatus.PENDING;

    @Column(name = "retry_count")
    private int retryCount = 0;

    @Column(name = "max_retries")
    private int maxRetries = 5;

    @Column(name = "last_error", columnDefinition = "TEXT")
    private String lastError;

    @Column(name = "next_retry_at")
    private Instant nextRetryAt;

    // ── Timestamps pour mesure de latence ────────────────────────────────────

    /** Instant où l'OutboxMessage a été créé (= fin du traitement InboxMessage) */
    @Column(name = "enqueued_at")
    private Instant enqueuedAt = Instant.now();

    /** Instant où l'envoi Salesforce a démarré */
    @Column(name = "sending_started_at")
    private Instant sendingStartedAt;

    /** Instant où Salesforce a confirmé la réception */
    @Column(name = "sent_at")
    private Instant sentAt;

    // ── AuditMetadata : traceId original + lien inbox ─────────────────────────

    @Embedded
    private AuditMetadata auditMetadata;

    // ── Optimistic locking ────────────────────────────────────────────────────

    @Version
    @Column(name = "version")
    private Long version;

    // ── Constructeurs ─────────────────────────────────────────────────────────

    protected OutboxMessage() {}

    public static OutboxMessage create(String salesforceObjectType,
                                        String operation,
                                        String payload,
                                        String payloadBefore,
                                        AuditMetadata auditMetadata) {
        OutboxMessage msg = new OutboxMessage();
        msg.salesforceObjectType = salesforceObjectType;
        msg.operation = operation;
        msg.payload = payload;
        msg.payloadBefore = payloadBefore;
        msg.auditMetadata = auditMetadata;
        return msg;
    }

    // ── Transitions d'état ────────────────────────────────────────────────────

    public void markSending() {
        this.status = OutboxStatus.SENDING;
        this.sendingStartedAt = Instant.now();
    }

    public void markSent(String salesforceId) {
        this.status = OutboxStatus.SENT;
        this.salesforceId = salesforceId;
        this.sentAt = Instant.now();
    }

    public void markFailed(String error) {
        this.retryCount++;
        this.lastError = error;
        // Backoff exponentiel : 30s, 2min, 10min, 30min, 1h
        long backoffSeconds = (long) Math.min(3600, 30 * Math.pow(3, retryCount - 1));
        this.nextRetryAt = Instant.now().plusSeconds(backoffSeconds);
        this.status = retryCount >= maxRetries ? OutboxStatus.DEAD_LETTER : OutboxStatus.FAILED;
    }

    public void markDeadLetter(String reason) {
        this.status = OutboxStatus.DEAD_LETTER;
        this.lastError = reason;
    }

    /**
     * Calcule la latence bout-en-bout depuis la création jusqu'à l'envoi Salesforce.
     * Inclut le temps de traitement Inbox + le temps d'attente dans l'Outbox.
     */
    public Duration computeEndToEndLatency() {
        if (sentAt == null || auditMetadata == null || auditMetadata.getCreatedAt() == null) {
            return null;
        }
        // Latence depuis la création de l'InboxMessage (auditMetadata.createdAt)
        // jusqu'à la confirmation Salesforce (sentAt)
        return Duration.between(auditMetadata.getCreatedAt(), sentAt);
    }

    public boolean canRetry() {
        return status == OutboxStatus.FAILED && retryCount < maxRetries;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String getId()                       { return id; }
    public String getSalesforceObjectType()     { return salesforceObjectType; }
    public String getSalesforceId()             { return salesforceId; }
    public String getOperation()               { return operation; }
    public String getPayload()                 { return payload; }
    public String getPayloadBefore()           { return payloadBefore; }
    public OutboxStatus getStatus()            { return status; }
    public int getRetryCount()                 { return retryCount; }
    public int getMaxRetries()                 { return maxRetries; }
    public String getLastError()               { return lastError; }
    public Instant getNextRetryAt()            { return nextRetryAt; }
    public Instant getEnqueuedAt()             { return enqueuedAt; }
    public Instant getSendingStartedAt()       { return sendingStartedAt; }
    public Instant getSentAt()                 { return sentAt; }
    public AuditMetadata getAuditMetadata()    { return auditMetadata; }
    public Long getVersion()                   { return version; }

    public enum OutboxStatus {
        PENDING,     // En attente d'envoi
        SENDING,     // En cours d'envoi (lock acquis par le processor)
        SENT,        // Confirmé par Salesforce
        FAILED,      // Échec, retry planifié
        DEAD_LETTER  // Retry épuisé, alerte déclenchée
    }
}
