# BluePrism SOAP Client - Logs et Gestion d'Erreurs

## 🎯 Features

✅ **Logs détaillés** des requêtes/réponses SOAP  
✅ **Gestion erreurs de décodage** avec XML brut sauvegardé  
✅ **Authentification BASIC** via intercepteur  
✅ **SOAP Faults** gérés et loggés  
✅ **Fichiers de logs** pour analyse  

## 📋 Intercepteurs

Le client utilise **2 intercepteurs** (dans cet ordre) :

### 1. BasicAuthInterceptor
- Ajoute le header `Authorization: Basic xxx`
- S'exécute en premier

### 2. SoapLoggingInterceptor
- Logs des requêtes/réponses
- Détection des erreurs de décodage
- Sauvegarde du XML brut en cas d'erreur

## 🔍 Types d'Erreurs Gérées

### 1. Erreur de Décodage (UnmarshallingFailureException)

**Cause** : La réponse XML ne correspond pas au schéma attendu

**Logs** :
```
❌ DECODING ERROR: Cannot unmarshal SOAP response
Check logs/error-response.xml for raw XML
```

**Action** :
- Le XML brut est sauvegardé dans `logs/error-response.xml`
- Une réponse d'erreur est retournée
- L'application continue de fonctionner

**Exemple** :
```java
BlockClientResponse response = client.blockClient(request);

if (!response.isSuccess()) {
    log.error("Error: {}", response.getMessage());
    // Message: "Response decoding error: ..."
}
```

### 2. SOAP Fault

**Cause** : Le serveur retourne un SOAP Fault

**Logs** :
```
SOAP Fault received: Server error
Fault Code: soap:Server
Fault String: Invalid client ID
```

**Action** :
- Le fault est loggé
- Une réponse d'erreur est retournée

### 3. Erreur Réseau

**Cause** : Timeout, connexion refusée, etc.

**Logs** :
```
Unexpected error calling BlockClient
java.net.ConnectException: Connection refused
```

## 📁 Fichiers de Logs

### Structure

```
logs/
├── blueprism-client.log    # Logs applicatifs
└── error-response.xml       # XML brut en cas d'erreur de décodage
```

### blueprism-client.log

Contient tous les logs :
```
2025-02-01 10:30:15 [main] DEBUG BluePrismSoapClient - Calling BlockClient operation
2025-02-01 10:30:15 [main] DEBUG SoapLoggingInterceptor - SOAP REQUEST:
<?xml version="1.0"?>
<soapenv:Envelope>
  <soapenv:Body>
    <BlockClient>
      <bpInstance>PROD</bpInstance>
      <ClientID>12345</ClientID>
    </BlockClient>
  </soapenv:Body>
</soapenv:Envelope>

2025-02-01 10:30:16 [main] DEBUG SoapLoggingInterceptor - SOAP RESPONSE:
<?xml version="1.0"?>
<soapenv:Envelope>
  <soapenv:Body>
    <BlockClientResponse>
      <Success>true</Success>
      <Message>OK</Message>
    </BlockClientResponse>
  </soapenv:Body>
</soapenv:Envelope>
```

### error-response.xml

En cas d'erreur de décodage, contient le XML brut :
```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Body>
    <ns:UnexpectedResponse xmlns:ns="...">
      <!-- XML qui n'a pas pu être décodé -->
    </ns:UnexpectedResponse>
  </soapenv:Body>
</soapenv:Envelope>
```

## ⚙️ Configuration

### Activer/Désactiver les Logs Détaillés

**application.yml** :
```yaml
blueprism:
  soap:
    enable-detailed-logging: true  # false pour désactiver
```

**Logs désactivés** :
- Seules les erreurs sont loggées
- Pas de logs des requêtes/réponses

**Logs activés** :
- Toutes les requêtes SOAP
- Toutes les réponses SOAP
- SOAP Faults détaillés

### Niveau de Logs

```yaml
logging:
  level:
    # Logs de ton application
    com.yourcompany.integration.blueprism: DEBUG
    
    # Logs Spring-WS (détails framework)
    org.springframework.ws: INFO  # ou DEBUG pour plus de détails
    
    # Logs HTTP (requêtes réseau)
    org.apache.http: INFO  # ou DEBUG
```

## 🧪 Tester la Gestion d'Erreurs

### 1. Tester une Erreur de Décodage

Simuler une réponse inattendue :
```java
// Le serveur retourne un XML différent du schéma
// → UnmarshallingFailureException
// → XML sauvegardé dans logs/error-response.xml
```

### 2. Tester un SOAP Fault

```java
// Si le serveur retourne une erreur métier
// → SoapFaultClientException
// → Fault loggé avec code et message
```

### 3. Tester un Timeout

```yaml
blueprism:
  soap:
    socket-timeout: 1000  # 1 seconde (très court)
```

## 💡 Best Practices

### En Développement

```yaml
blueprism:
  soap:
    enable-detailed-logging: true

logging:
  level:
    com.yourcompany.integration.blueprism: DEBUG
    org.springframework.ws: DEBUG
```

**Résultat** : Tu vois TOUT (requêtes, réponses, erreurs)

### En Production

```yaml
blueprism:
  soap:
    enable-detailed-logging: false  # Performance !

logging:
  level:
    com.yourcompany.integration.blueprism: INFO
    org.springframework.ws: WARN
```

**Résultat** : Seules les erreurs sont loggées

### En Debug d'Erreur

Si tu as une erreur de décodage en production :

1. Active temporairement les logs :
```yaml
enable-detailed-logging: true
```

2. Reproduis l'erreur

3. Analyse `logs/error-response.xml`

4. Désactive les logs :
```yaml
enable-detailed-logging: false
```

## 🎯 Exemple Complet

```java
@Service
@RequiredArgsConstructor
public class MyService {
    
    private final BluePrismSoapClient client;
    private final ObjectFactory factory = new ObjectFactory();
    
    public void processClient(String clientId) {
        // 1. Créer requête
        BlockClient request = factory.createBlockClient();
        request.setClientID(clientId);
        request.setBlocking(true);
        
        // 2. Appeler SOAP (avec gestion d'erreurs automatique)
        BlockClientResponse response = client.blockClient(request);
        
        // 3. Vérifier le résultat
        if (response.isSuccess()) {
            log.info("✅ Client {} blocked successfully", clientId);
        } else {
            log.error("❌ Failed to block client {}: {}", 
                clientId, response.getMessage());
            
            // En cas d'erreur, check logs/error-response.xml
            // si le message contient "Decoding error"
        }
    }
}
```

## 🚨 Troubleshooting

### Erreur : "Cannot find logs/error-response.xml"

**Solution** : Le répertoire `logs/` n'existe pas
```bash
mkdir logs
```

### Les logs détaillés ne s'affichent pas

**Vérifier** :
1. `enable-detailed-logging: true` ✅
2. `logging.level.com.yourcompany...: DEBUG` ✅
3. Relancer l'application

### Le XML brut n'est pas sauvegardé

**Cause** : L'erreur n'est pas une erreur de décodage

**Vérifier** : Le log contient-il `❌ DECODING ERROR` ?

## 📊 Résumé

| Feature | Status | Fichier |
|---------|--------|---------|
| **Logs requêtes/réponses** | ✅ | Console + blueprism-client.log |
| **Erreurs de décodage** | ✅ | error-response.xml |
| **SOAP Faults** | ✅ | blueprism-client.log |
| **Auth BASIC** | ✅ | Intercepteur |
| **Gestion erreurs** | ✅ | Client robuste |

**Tout est loggé et géré ! 🎉**
