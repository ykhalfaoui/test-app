package com.example.audit;

import com.example.shared.AuditMetadata;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

/**
 * AuditLog : table JPA persistée + domain event Modulith publié.
 *
 * Chaque entrée représente une action métier significative :
 *  - Réception d'un message Kafka (inbox)
 *  - Traitement d'un event Modulith
 *  - Sync Salesforce réussie ou échouée
 *  - Retry / dead letter
 *
 * Le traceId dans AuditMetadata permet de corréler :
 *  - l'entrée AuditLog ↔ le span Zipkin/Jaeger
 *  - l'entrée AuditLog ↔ l'InboxMessage ↔ l'OutboxMessage
 *
 * Le diff avant/après (payloadBefore / payloadAfter) est stocké pour :
 *  - audit réglementaire
 *  - analyse des changements Salesforce
 *  - rollback manuel si besoin
 */
@Entity
@Table(
    name = "audit_log",
    indexes = {
        @Index(name = "idx_audit_trace_id",       columnList = "trace_id"),
        @Index(name = "idx_audit_correlation_id", columnList = "correlation_id"),
        @Index(name = "idx_audit_entity",         columnList = "entity_type, entity_id"),
        @Index(name = "idx_audit_action",         columnList = "action, created_at"),
        @Index(name = "idx_audit_created_at",     columnList = "created_at")
    }
)
public class AuditLog {

    @Id
    @Column(name = "id", length = 36)
    private String id = UUID.randomUUID().toString();

    // ── Qui / Quoi ────────────────────────────────────────────────────────────

    @Column(name = "action", nullable = false, length = 100)
    private String action; // ex: "SALESFORCE_SYNC", "INBOX_RECEIVED", "OUTBOX_DEAD_LETTER"

    @Column(name = "entity_type", length = 100)
    private String entityType; // ex: "Review__c", "Member__c", "InboxMessage"

    @Column(name = "entity_id", length = 36)
    private String entityId; // ID de l'entité concernée

    @Column(name = "actor", length = 100)
    private String actor; // "system", "kafka:topic-name", "shedlock:job-name"

    // ── Diff avant/après ─────────────────────────────────────────────────────

    @Column(name = "payload_before", columnDefinition = "TEXT")
    private String payloadBefore; // JSON snapshot avant modification

    @Column(name = "payload_after", columnDefinition = "TEXT")
    private String payloadAfter;  // JSON snapshot après modification

    // ── Résultat ──────────────────────────────────────────────────────────────

    @Enumerated(EnumType.STRING)
    @Column(name = "outcome", nullable = false, length = 20)
    private Outcome outcome;

    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    // ── Corrélation complète ──────────────────────────────────────────────────

    @Embedded
    private AuditMetadata auditMetadata;

    // ── Constructeurs factory ─────────────────────────────────────────────────

    protected AuditLog() {}

    public static AuditLog salesforceSynced(String sfObjectType, String sfId,
                                              String operation,
                                              String payloadBefore, String payloadAfter,
                                              AuditMetadata auditMetadata) {
        AuditLog log = new AuditLog();
        log.action = "SALESFORCE_SYNC";
        log.entityType = sfObjectType;
        log.entityId = sfId;
        log.actor = "outbox:salesforce-processor";
        log.payloadBefore = payloadBefore;
        log.payloadAfter = payloadAfter;
        log.outcome = Outcome.SUCCESS;
        log.auditMetadata = auditMetadata;
        return log;
    }

    public static AuditLog salesforceFailed(String sfObjectType, String outboxId,
                                              String operation, String error,
                                              AuditMetadata auditMetadata) {
        AuditLog log = new AuditLog();
        log.action = "SALESFORCE_SYNC_FAILED";
        log.entityType = sfObjectType;
        log.entityId = outboxId;
        log.actor = "outbox:salesforce-processor";
        log.outcome = Outcome.FAILURE;
        log.errorMessage = error;
        log.auditMetadata = auditMetadata;
        return log;
    }

    public static AuditLog deadLetter(String entityType, String messageId,
                                       String reason, AuditMetadata auditMetadata) {
        AuditLog log = new AuditLog();
        log.action = "DEAD_LETTER";
        log.entityType = entityType;
        log.entityId = messageId;
        log.actor = "system";
        log.outcome = Outcome.FAILURE;
        log.errorMessage = reason;
        log.auditMetadata = auditMetadata;
        return log;
    }

    public static AuditLog inboxReceived(String topic, String inboxId,
                                          String eventType, AuditMetadata auditMetadata) {
        AuditLog log = new AuditLog();
        log.action = "INBOX_RECEIVED";
        log.entityType = eventType;
        log.entityId = inboxId;
        log.actor = "kafka:" + topic;
        log.outcome = Outcome.SUCCESS;
        log.auditMetadata = auditMetadata;
        return log;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String getId()                   { return id; }
    public String getAction()               { return action; }
    public String getEntityType()           { return entityType; }
    public String getEntityId()             { return entityId; }
    public String getActor()                { return actor; }
    public String getPayloadBefore()        { return payloadBefore; }
    public String getPayloadAfter()         { return payloadAfter; }
    public Outcome getOutcome()             { return outcome; }
    public String getErrorMessage()         { return errorMessage; }
    public AuditMetadata getAuditMetadata() { return auditMetadata; }

    public enum Outcome { SUCCESS, FAILURE, SKIPPED }
}
