package com.example.outbox;

import com.example.audit.AuditLog;
import com.example.audit.AuditLogRepository;
import com.example.shared.AuditMetadata;
import com.example.shared.TracingMetadataEnricher;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

/**
 * Processor ShedLock : poll l'outbox et envoie vers Salesforce.
 *
 * Le traceId utilisé ici est celui stocké dans l'OutboxMessage.auditMetadata
 * (= le traceId original du message Kafka entrant).
 *
 * On crée un span enfant rattaché à ce traceId pour avoir la chaîne complète :
 *   [Kafka receive] → [Inbox persist] → [Process] → [Outbox send] → [Salesforce]
 * tous sous le même traceId dans Zipkin/Jaeger.
 *
 * Métriques exposées (Prometheus) :
 *   - outbox.sent.total (counter)
 *   - outbox.failed.total (counter)
 *   - outbox.dead_letter.total (counter)
 *   - outbox.send.duration (timer)
 *   - outbox.end_to_end.latency (timer) ← latence Kafka → Salesforce
 *   - outbox.pending.count (gauge)
 */
@Component
public class OutboxSalesforceProcessor {

    private static final Logger log = LoggerFactory.getLogger(OutboxSalesforceProcessor.class);

    private static final int BATCH_SIZE = 50;

    private final OutboxMessageRepository outboxRepository;
    private final AuditLogRepository auditLogRepository;
    private final SalesforceClient salesforceClient;
    private final TracingMetadataEnricher enricher;
    private final ObservationRegistry observationRegistry;
    private final MeterRegistry meterRegistry;
    private final Tracer tracer;

    public OutboxSalesforceProcessor(OutboxMessageRepository outboxRepository,
                                      AuditLogRepository auditLogRepository,
                                      SalesforceClient salesforceClient,
                                      TracingMetadataEnricher enricher,
                                      ObservationRegistry observationRegistry,
                                      MeterRegistry meterRegistry,
                                      Tracer tracer) {
        this.outboxRepository = outboxRepository;
        this.auditLogRepository = auditLogRepository;
        this.salesforceClient = salesforceClient;
        this.enricher = enricher;
        this.observationRegistry = observationRegistry;
        this.meterRegistry = meterRegistry;
        this.tracer = tracer;
    }

    /**
     * Job principal : traite les messages PENDING.
     * ShedLockTracingAspect crée le span racine avant l'acquisition du lock.
     */
    @Scheduled(fixedDelayString = "${app.outbox.poll-interval:PT10S}")
    @SchedulerLock(name = "outbox-salesforce-processor", lockAtMostFor = "PT5M", lockAtLeastFor = "PT5S")
    public void processPendingOutbox() {

        List<OutboxMessage> batch = outboxRepository.findPendingBatch(
            OutboxMessage.OutboxStatus.PENDING, Instant.now(), BATCH_SIZE
        );

        if (batch.isEmpty()) return;

        log.info("Outbox batch: {} messages à traiter", batch.size());

        // Gauge : messages en attente (pour alerting)
        meterRegistry.gauge("outbox.pending.count", outboxRepository.countByStatus(OutboxMessage.OutboxStatus.PENDING));

        for (OutboxMessage msg : batch) {
            processSingle(msg);
        }
    }

    /**
     * Job de retry : reprend les messages FAILED dont nextRetryAt est dépassé.
     */
    @Scheduled(fixedDelayString = "${app.outbox.retry-interval:PT1M}")
    @SchedulerLock(name = "outbox-retry-processor", lockAtMostFor = "PT3M", lockAtLeastFor = "PT30S")
    public void processFailedOutbox() {

        List<OutboxMessage> toRetry = outboxRepository.findRetryable(
            OutboxMessage.OutboxStatus.FAILED, Instant.now(), BATCH_SIZE
        );

        if (toRetry.isEmpty()) return;

        log.info("Outbox retry batch: {} messages à rejouer", toRetry.size());

        for (OutboxMessage msg : toRetry) {
            processSingle(msg);
        }
    }

    /**
     * Traitement d'un seul OutboxMessage avec :
     *  - Span enfant rattaché au traceId original
     *  - Timer de latence bout-en-bout
     *  - Audit log en cas de succès/échec
     */
    @Transactional
    private void processSingle(OutboxMessage msg) {

        AuditMetadata originalContext = msg.getAuditMetadata();

        // Crée un span enfant rattaché au traceId de l'InboxMessage original
        // pour maintenir la chaîne causale dans Zipkin/Jaeger
        Span span = buildChildSpan(originalContext, msg);

        try (Tracer.SpanInScope ws = tracer.withSpan(span)) {

            Timer.Sample sample = Timer.start(meterRegistry);
            msg.markSending();
            outboxRepository.save(msg);

            try {
                // Appel Salesforce
                String salesforceId = salesforceClient.upsert(
                    msg.getSalesforceObjectType(),
                    msg.getOperation(),
                    msg.getPayload()
                );

                msg.markSent(salesforceId);
                outboxRepository.save(msg);

                // Métriques de succès
                sample.stop(Timer.builder("outbox.send.duration")
                    .tag("object_type", msg.getSalesforceObjectType())
                    .tag("operation", msg.getOperation())
                    .tag("status", "success")
                    .register(meterRegistry));

                meterRegistry.counter("outbox.sent.total",
                    "object_type", msg.getSalesforceObjectType()).increment();

                // Latence bout-en-bout (Kafka → Salesforce)
                Duration e2eLatency = msg.computeEndToEndLatency();
                if (e2eLatency != null) {
                    meterRegistry.timer("outbox.end_to_end.latency",
                        "object_type", msg.getSalesforceObjectType()
                    ).record(e2eLatency);

                    log.info("Outbox sent: id={} sfId={} e2e={}ms traceId={} correlationId={}",
                        msg.getId(), salesforceId, e2eLatency.toMillis(),
                        originalContext.getTraceId(), originalContext.getCorrelationId());
                }

                // Audit log : succès de sync Salesforce
                auditLogRepository.save(AuditLog.salesforceSynced(
                    msg.getSalesforceObjectType(),
                    salesforceId,
                    msg.getOperation(),
                    msg.getPayloadBefore(),
                    msg.getPayload(),
                    enricher.capture("outbox:salesforce-processor")
                        .withOriginatingMessageId(msg.getId())
                ));

                span.tag("sf.id", salesforceId).tag("result", "success");

            } catch (Exception ex) {

                msg.markFailed(ex.getMessage());
                outboxRepository.save(msg);

                meterRegistry.counter("outbox.failed.total",
                    "object_type", msg.getSalesforceObjectType(),
                    "retry_count", String.valueOf(msg.getRetryCount())
                ).increment();

                sample.stop(Timer.builder("outbox.send.duration")
                    .tag("object_type", msg.getSalesforceObjectType())
                    .tag("operation", msg.getOperation())
                    .tag("status", "failure")
                    .register(meterRegistry));

                span.tag("result", "failure").error(ex);

                if (msg.getStatus() == OutboxMessage.OutboxStatus.DEAD_LETTER) {
                    // Alerte : dead letter → counter pour règle Prometheus/Alertmanager
                    meterRegistry.counter("outbox.dead_letter.total",
                        "object_type", msg.getSalesforceObjectType()
                    ).increment();

                    log.error("DEAD LETTER: id={} type={} traceId={} correlationId={} error={}",
                        msg.getId(), msg.getSalesforceObjectType(),
                        originalContext.getTraceId(), originalContext.getCorrelationId(),
                        ex.getMessage());
                } else {
                    log.warn("Outbox failed (retry {}): id={} traceId={} nextRetry={} error={}",
                        msg.getRetryCount(), msg.getId(),
                        originalContext.getTraceId(), msg.getNextRetryAt(), ex.getMessage());
                }
            }

        } finally {
            span.end();
        }
    }

    /**
     * Construit un span enfant rattaché au traceId original stocké dans l'OutboxMessage.
     * Sans ça, le span du job ShedLock et l'envoi Salesforce seraient dans des traces séparées.
     */
    private Span buildChildSpan(AuditMetadata ctx, OutboxMessage msg) {
        Span span = tracer.nextSpan()
            .name("outbox.send.salesforce")
            .tag("outbox.id", msg.getId())
            .tag("sf.object_type", msg.getSalesforceObjectType())
            .tag("sf.operation", msg.getOperation())
            .tag("correlation_id", ctx.getCorrelationId() != null ? ctx.getCorrelationId() : "")
            .tag("originating_trace_id", ctx.getTraceId() != null ? ctx.getTraceId() : "");

        return span.start();
    }
}
