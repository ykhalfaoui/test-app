package com.example.shared;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import java.time.Instant;

/**
 * Embeddable partagé par : InboxMessage, OutboxMessage, AuditLog.
 *
 * Contient tous les champs de corrélation nécessaires pour relier :
 *  - un message Kafka (inbox) ←→ son traitement ←→ sa sync Salesforce (outbox)
 *  - le tout lié à un traceId Micrometer et un correlationId métier
 *
 * Survit aux crashes : persisté en base AVANT tout traitement.
 * Permet le replay : on peut retrouver l'origine d'un message depuis n'importe quel point.
 */
@Embeddable
public class AuditMetadata {

    // ── Tracing distribué ──────────────────────────────────────────────────────

    /**
     * TraceId Micrometer (W3C format : 32 hex chars).
     * Identique tout au long de la chaîne : HTTP → Kafka → Inbox → Outbox → Salesforce.
     * Alimenté automatiquement depuis MDC via TracingMetadataEnricher.
     */
    @Column(name = "trace_id", length = 32)
    private String traceId;

    /**
     * SpanId du span courant au moment de la persistance (16 hex chars).
     * Change à chaque étape (listener, processor, outbox sender).
     * Permet de retrouver le span exact dans Zipkin/Jaeger.
     */
    @Column(name = "span_id", length = 16)
    private String spanId;

    // ── Corrélation métier ─────────────────────────────────────────────────────

    /**
     * CorrelationId métier (UUID).
     * Propagé via header HTTP X-Correlation-Id → Kafka header → colonne BDD.
     * Utile pour corréler des entités SANS passer par le traceId Micrometer
     * (ex : support client, audit réglementaire, reporting).
     */
    @Column(name = "correlation_id", length = 36)
    private String correlationId;

    /**
     * Identifiant de la source du message.
     * Ex : "kafka:topic-name", "http:POST:/api/reviews", "shedlock:sync-job"
     */
    @Column(name = "source", length = 120)
    private String source;

    /**
     * Identifiant du message Kafka original (pour inbox → outbox linkage).
     * Permet de retrouver l'InboxMessage depuis l'OutboxMessage et vice-versa.
     */
    @Column(name = "originating_message_id", length = 36)
    private String originatingMessageId;

    // ── Timestamps ────────────────────────────────────────────────────────────

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

    @PrePersist
    void onPersist() {
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }

    // ── Builder fluent ────────────────────────────────────────────────────────

    public static AuditMetadata of(String traceId, String spanId, String correlationId, String source) {
        AuditMetadata m = new AuditMetadata();
        m.traceId = traceId;
        m.spanId = spanId;
        m.correlationId = correlationId;
        m.source = source;
        return m;
    }

    public AuditMetadata withOriginatingMessageId(String id) {
        this.originatingMessageId = id;
        return this;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String getTraceId()               { return traceId; }
    public String getSpanId()                { return spanId; }
    public String getCorrelationId()         { return correlationId; }
    public String getSource()                { return source; }
    public String getOriginatingMessageId()  { return originatingMessageId; }
    public Instant getCreatedAt()            { return createdAt; }
    public Instant getUpdatedAt()            { return updatedAt; }

    // Setters pour JPA
    public void setTraceId(String traceId)               { this.traceId = traceId; }
    public void setSpanId(String spanId)                 { this.spanId = spanId; }
    public void setCorrelationId(String correlationId)   { this.correlationId = correlationId; }
    public void setSource(String source)                 { this.source = source; }
    public void setOriginatingMessageId(String id)       { this.originatingMessageId = id; }
}
