# Architecture Tracing Complet — Inbox / Outbox / AuditTrail / Salesforce

## Vue d'ensemble du flux

```
Kafka Message
│  headers: traceparent (W3C), X-Correlation-Id, X-Event-Type
│
▼
[InboxKafkaListener]
│  • RecordInterceptor restaure le span depuis traceparent header
│  • TracingMetadataEnricher.capture() → AuditMetadata { traceId, spanId, correlationId }
│  • InboxMessage persisté (EntityListener auto-enrichit si vide)
│  • ACK Kafka seulement si persist OK
│
▼
[Modulith @ApplicationModuleListener] (thread async, ContextSnapshot propagé)
│  • Traitement métier dans la MÊME transaction :
│    - InboxMessage → PROCESSED
│    - OutboxMessage créé (payload SF + payloadBefore + originatingMessageId)
│  • AuditLog.inboxReceived() persisté
│
▼ (après commit)
[OutboxSalesforceProcessor] (ShedLock, span racine via ShedLockTracingAspect)
│  • Poll batch PENDING + FAILED retryable
│  • Span enfant avec tag originating_trace_id = traceId InboxMessage original
│  • computeEndToEndLatency() = sentAt - auditMetadata.createdAt
│  • Timer Prometheus + AuditLog.salesforceSynced() avec diff avant/après
│  • Retry backoff exponentiel → dead letter → alerte Prometheus
│
▼
[Prometheus / Grafana / Alertmanager]
  • outbox.end_to_end.latency (p50/p95/p99)
  • outbox.dead_letter.total → alerte critique immédiate
  • outbox.failed.total / failure rate > 10% → alerte warning
  • outbox.pending.count > 500 → alerte backlog
```

---

## Table de corrélation

| Champ | Vit dans | Propagé via |
|-------|----------|-------------|
| `traceId` | Micrometer MDC + AuditMetadata | W3C `traceparent` header |
| `spanId` | Micrometer MDC + AuditMetadata | Change à chaque étape |
| `correlationId` | Baggage Micrometer + AuditMetadata | Header `X-Correlation-Id` |
| `originatingMessageId` | AuditMetadata | Copié InboxMessage → OutboxMessage |

### Requêtes SQL de corrélation

```sql
-- Parcours complet d'un message par traceId
SELECT 'inbox' as type, id, status, trace_id, created_at FROM inbox_message  WHERE trace_id = :tid
UNION ALL
SELECT 'outbox',        id, status, trace_id, created_at FROM outbox_message WHERE trace_id = :tid
UNION ALL
SELECT 'audit',  id, action, trace_id, created_at FROM audit_log            WHERE trace_id = :tid
ORDER BY created_at;

-- Dead letters dernières 24h
SELECT id, salesforce_object_type, retry_count, last_error, trace_id, correlation_id
FROM outbox_message
WHERE status = 'DEAD_LETTER' AND created_at > NOW() - INTERVAL '24 hours';

-- Latence moyenne par objet Salesforce
SELECT salesforce_object_type,
       AVG(EXTRACT(EPOCH FROM (sent_at - created_at))) as avg_sec
FROM outbox_message WHERE status = 'SENT' AND sent_at > NOW() - INTERVAL '1 hour'
GROUP BY salesforce_object_type;
```

---

## Fichiers

| Fichier | Rôle |
|---------|------|
| `shared/AuditMetadata.java` | Embeddable partagé : traceId, spanId, correlationId, source, originatingMessageId |
| `shared/TracingMetadataEnricher.java` | Pont Micrometer → AuditMetadata |
| `inbox/InboxMessage.java` | Entity Inbox avec statuts et retry |
| `inbox/InboxKafkaListener.java` | Reçoit Kafka, idempotence, ACK conditionnel |
| `outbox/OutboxMessage.java` | Entity Outbox avec timestamps latence E2E |
| `outbox/OutboxSalesforceProcessor.java` | ShedLock : envoie SF, métriques, retry backoff, dead letter |
| `audit/AuditLog.java` | Table audit avec diff avant/après |
| `audit/AuditTrailEntityListener.java` | EntityListener global : auto-enrichit @PrePersist |
| `audit/orm.xml` | → META-INF/orm.xml : déclare le listener globalement |
| `monitoring/prometheus-alerts.yml` | Alertes dead letter, latence, failure rate, backlog |

---

## Points d'attention

**EntityListener static holder** — initialiser dans une @Configuration :
```java
@Bean
ApplicationRunner initEntityListener(TracingMetadataEnricher enricher) {
    return args -> AuditTrailEntityListener.setEnricher(enricher);
}
```

**orm.xml emplacement** : `src/main/resources/META-INF/orm.xml`

**Backoff exponentiel** : `30 * 3^(retryCount-1)` secondes → 30s, 2min, 10min, 30min, 1h max

**Idempotence Inbox** : `existsByTopicAndPartitionAndOffset()` absorbe les re-délivrances Kafka
