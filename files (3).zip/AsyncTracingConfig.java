package com.example.tracing.config;

import io.micrometer.context.ContextSnapshot;
import io.micrometer.context.ContextSnapshotFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Configuration du pool de threads @Async avec propagation automatique
 * du contexte Micrometer (traceId / spanId / baggage).
 *
 * Le TaskDecorator est le point clé : il capture le contexte
 * dans le thread appelant et le restaure dans le thread async.
 */
@Configuration
@EnableAsync
public class AsyncTracingConfig implements AsyncConfigurer {

    private final ContextSnapshotFactory contextSnapshotFactory;

    public AsyncTracingConfig(ContextSnapshotFactory contextSnapshotFactory) {
        this.contextSnapshotFactory = contextSnapshotFactory;
    }

    @Override
    public Executor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(new MicrometerContextTaskDecorator(contextSnapshotFactory));
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("async-traced-");
        executor.initialize();
        return executor;
    }

    /**
     * TaskDecorator qui propage le ContextSnapshot Micrometer.
     * Couvre : TraceId, SpanId, et tous les Baggage (correlationId, etc.)
     */
    static class MicrometerContextTaskDecorator implements TaskDecorator {

        private final ContextSnapshotFactory factory;

        MicrometerContextTaskDecorator(ContextSnapshotFactory factory) {
            this.factory = factory;
        }

        @Override
        public Runnable decorate(Runnable runnable) {
            // Capture dans le thread appelant (ex: thread HTTP)
            ContextSnapshot snapshot = factory.captureAll();

            return () -> {
                // Restaure dans le thread async du pool
                try (ContextSnapshot.Scope ignored = snapshot.setThreadLocals()) {
                    runnable.run();
                }
            };
        }
    }
}
