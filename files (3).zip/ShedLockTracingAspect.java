package com.example.tracing.shedlock;

import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * AOP Aspect qui wrapp automatiquement chaque job ShedLock dans une Observation Micrometer.
 *
 * Sans cet aspect, les jobs @SchedulerLock s'exécutent dans un thread de scheduler
 * qui n'a aucun contexte de tracing → traceId/spanId = null dans les logs.
 *
 * Avec cet aspect, chaque job crée son propre span racine, visible dans Zipkin/Jaeger
 * et dans les logs structurés (MDC automatiquement alimenté par Micrometer).
 *
 * @Order(0) pour s'exécuter AVANT l'aspect ShedLock lui-même (@Order par défaut = Ordered.LOWEST_PRECEDENCE)
 */
@Aspect
@Component
@Order(0)
public class ShedLockTracingAspect {

    private static final Logger log = LoggerFactory.getLogger(ShedLockTracingAspect.class);

    private final ObservationRegistry observationRegistry;
    private final Tracer tracer;

    public ShedLockTracingAspect(ObservationRegistry observationRegistry, Tracer tracer) {
        this.observationRegistry = observationRegistry;
        this.tracer = tracer;
    }

    /**
     * Intercepte toutes les méthodes annotées @SchedulerLock.
     *
     * Crée un span racine nommé "job.<methodName>" avec les tags :
     * - job.name  : nom du lock ShedLock
     * - job.class : classe du job
     */
    @Around("@annotation(net.javacrumbs.shedlock.spring.annotation.SchedulerLock)")
    public Object traceScheduledJob(ProceedingJoinPoint pjp) throws Throwable {

        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();

        net.javacrumbs.shedlock.spring.annotation.SchedulerLock lockAnnotation =
                method.getAnnotation(net.javacrumbs.shedlock.spring.annotation.SchedulerLock.class);

        String lockName  = lockAnnotation.name();
        String jobClass  = pjp.getTarget().getClass().getSimpleName();
        String spanName  = "job." + method.getName();

        return Observation.createNotStarted(spanName, observationRegistry)
                .lowCardinalityKeyValue("job.name",  lockName)
                .lowCardinalityKeyValue("job.class", jobClass)
                .observeChecked(() -> {

                    // À ce stade, le span est actif → traceId/spanId disponibles dans MDC
                    Span current = tracer.currentSpan();
                    if (current != null) {
                        log.info("Job démarré: name={} traceId={} spanId={}",
                                lockName,
                                current.context().traceId(),
                                current.context().spanId());
                    }

                    return pjp.proceed();
                });
    }
}
