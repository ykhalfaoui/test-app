package com.example.tracing.modulith;

import io.micrometer.context.ContextSnapshot;
import io.micrometer.context.ContextSnapshotFactory;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.modulith.events.EventPublicationRepository;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.concurrent.Executor;

/**
 * Configuration de la propagation du contexte de tracing pour Spring Modulith.
 *
 * Problème : Spring Modulith publie les domain events de manière asynchrone
 * via un Executor dédié. Par défaut, cet executor n'a pas de TaskDecorator
 * → le contexte Micrometer (traceId/spanId/baggage) est perdu.
 *
 * Solution : déclarer un bean Executor nommé "applicationEventMulticaster"
 * avec le MicrometerContextTaskDecorator.
 *
 * Note sur les @TransactionalEventListener :
 * - AFTER_COMMIT (défaut) : s'exécute dans un thread séparé si @Async
 * - Le traceId doit survivre à la transaction ET au changement de thread
 */
@Configuration
public class ModulithAsyncTracingConfig {

    private static final Logger log = LoggerFactory.getLogger(ModulithAsyncTracingConfig.class);

    private final ContextSnapshotFactory contextSnapshotFactory;
    private final ObservationRegistry observationRegistry;
    private final Tracer tracer;

    public ModulithAsyncTracingConfig(ContextSnapshotFactory contextSnapshotFactory,
                                       ObservationRegistry observationRegistry,
                                       Tracer tracer) {
        this.contextSnapshotFactory = contextSnapshotFactory;
        this.observationRegistry = observationRegistry;
        this.tracer = tracer;
    }

    /**
     * Executor pour les @TransactionalEventListener @Async de Spring Modulith.
     *
     * Spring Modulith utilise ce bean s'il est déclaré avec le nom
     * "modulithAsyncExecutor" ou via ApplicationModuleInitializingBean.
     *
     * Pour les @ApplicationModuleListener (Modulith 1.2+), déclare cet executor
     * dans ton application.yml :
     *
     *   spring.modulith.async-executor: modulith-traced
     */
    @Bean("modulithTracedExecutor")
    public Executor modulithTracedExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(micrometerContextTaskDecorator());
        executor.setCorePoolSize(3);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("modulith-traced-");
        executor.initialize();
        return executor;
    }

    /**
     * TaskDecorator partagé : capture le ContextSnapshot Micrometer
     * dans le thread publiant l'event, restaure dans le thread consommant.
     */
    @Bean
    public TaskDecorator micrometerContextTaskDecorator() {
        return runnable -> {
            // Capture AVANT de passer au thread async (dans le thread de la transaction)
            ContextSnapshot snapshot = contextSnapshotFactory.captureAll();

            return () -> {
                // Restaure dans le thread Modulith async
                try (ContextSnapshot.Scope ignored = snapshot.setThreadLocals()) {
                    runnable.run();
                }
            };
        };
    }

    /**
     * Exemple de listener Modulith correctement tracé.
     *
     * Avec la configuration ci-dessus, le traceId du thread HTTP parent
     * est automatiquement disponible dans ce listener, même après AFTER_COMMIT.
     */
    // @ApplicationModuleListener  // Modulith 1.2+ (= @TransactionalEventListener + @Async)
    // public void onDomainEvent(MyDomainEvent event) {
    //     Span span = tracer.currentSpan();
    //     log.info("Event reçu: traceId={}", span != null ? span.context().traceId() : "NULL");
    //     // tracer.currentSpan() != null grâce au TaskDecorator
    // }

    /**
     * Advice pour wrapper manuellement un listener si tu ne peux pas changer l'Executor.
     * Alternative quand le TaskDecorator n'est pas applicable directement.
     */
    public void executeWithTracingContext(ContextSnapshot snapshot, Runnable task) {
        try (ContextSnapshot.Scope ignored = snapshot.setThreadLocals()) {
            task.run();
        }
    }
}
