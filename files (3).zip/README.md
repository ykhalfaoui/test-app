# Tracing Context Propagation — Spring Boot 3 + Micrometer

## Pourquoi le traceId est null en async ?

Les `ThreadLocal` ne se propagent pas automatiquement d'un thread à un autre.
Micrometer stocke `TraceContext`, `SpanContext` et les `Baggage` fields dans des ThreadLocals.

Dès qu'on change de thread (async, Kafka listener, scheduler), le contexte est perdu.

---

## Architecture de la solution

```
HTTP Request
│  traceId=abc / spanId=123
│
├─▶ @Async (Thread pool)
│     → AsyncTracingConfig + MicrometerContextTaskDecorator
│       ContextSnapshot capturé avant, restauré dans le thread async
│
├─▶ Kafka @KafkaListener (Thread Kafka consumer)
│     → KafkaTracingConfig + RecordInterceptor
│       Headers W3C "traceparent" extraits du ConsumerRecord
│       Span restauré AVANT que le listener reçoive le message
│
├─▶ @SchedulerLock (Thread scheduler)
│     → ShedLockTracingAspect (@Around)
│       Observation.createNotStarted("job.xxx") crée un span racine
│       traceId frais par exécution de job
│
└─▶ Spring Modulith @ApplicationModuleListener (Thread Modulith async)
      → ModulithAsyncTracingConfig + TaskDecorator sur l'executor Modulith
        ContextSnapshot du thread publiant l'event → restauré dans le consumer
```

---

## Fichiers à créer dans ton projet

| Fichier | Rôle |
|---------|------|
| `TracingBeansConfig.java` | Déclare `ContextSnapshotFactory` |
| `TracingContextPropagator.java` | Utilitaire injectable partagé |
| `AsyncTracingConfig.java` | Fix `@Async` Spring |
| `KafkaTracingConfig.java` | Fix `@KafkaListener` |
| `ShedLockTracingAspect.java` | Fix jobs `@SchedulerLock` |
| `ModulithAsyncTracingConfig.java` | Fix events Modulith async |

---

## Dépendances Maven

```xml
<!-- Micrometer Tracing (Brave = Zipkin) -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-tracing-bridge-brave</artifactId>
</dependency>

<!-- Reporter Zipkin -->
<dependency>
    <groupId>io.zipkin.reporter2</groupId>
    <artifactId>zipkin-reporter-brave</artifactId>
</dependency>

<!-- ContextSnapshot - OBLIGATOIRE pour la propagation async -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>context-propagation</artifactId>
</dependency>

<!-- AOP pour ShedLockTracingAspect -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-aop</artifactId>
</dependency>
```

---

## Points clés à retenir

### @Async
- Le `TaskDecorator` est l'**unique point de fix** — sans lui, impossible de propager
- `ContextSnapshot.captureAll()` capture TOUS les ThreadLocals Micrometer enregistrés
- `snapshot.setThreadLocals()` les restaure dans le nouveau thread (try-with-resources)

### Kafka @KafkaListener
- Les headers W3C `traceparent` / `tracestate` sont injectés par le producer (KafkaTemplate)
- Le `RecordInterceptor` les extrait et crée un span AVANT que le listener soit appelé
- `factory.getContainerProperties().setObservationEnabled(true)` active l'auto-instrumentation Kafka (Spring Kafka 3.x)

### ShedLock
- Les jobs n'ont pas de contexte parent → on crée un **span racine**
- `Observation.createNotStarted(name, registry).observeChecked(...)` gère le cycle de vie du span
- `@Order(0)` sur l'aspect est crucial : doit s'exécuter avant l'aspect ShedLock (qui acquiert le lock)

### Spring Modulith Async
- Les `@ApplicationModuleListener` sont exécutés dans un executor Modulith dédié
- Le `TaskDecorator` sur cet executor propage le contexte du thread de publication
- Le traceId survit à la transaction AFTER_COMMIT grâce au `ContextSnapshot`

---

## Vérification rapide

Ajoute ce pattern de log pour confirmer que ça fonctionne :

```java
Span span = tracer.currentSpan();
log.info("traceId={} spanId={}",
    span != null ? span.context().traceId() : "NULL",
    span != null ? span.context().spanId() : "NULL");
```

Si `traceId != NULL` dans tes threads async → la propagation fonctionne ✅
