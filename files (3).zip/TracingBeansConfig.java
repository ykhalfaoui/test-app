package com.example.tracing.config;

import io.micrometer.context.ContextSnapshotFactory;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Tracer;
import io.micrometer.tracing.propagation.Propagator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Beans Micrometer requis pour la propagation du contexte.
 *
 * En Spring Boot 3.x avec spring-boot-starter-actuator et
 * micrometer-tracing-bridge-brave (ou otel), ces beans sont
 * auto-configurés. Ce fichier sert de référence pour s'assurer
 * qu'ils sont bien disponibles.
 *
 * Dépendances Maven requises :
 *
 *   <!-- Micrometer Tracing -->
 *   <dependency>
 *     <groupId>io.micrometer</groupId>
 *     <artifactId>micrometer-tracing-bridge-brave</artifactId>
 *   </dependency>
 *
 *   <!-- Reporter Zipkin (ou Jaeger OTLP) -->
 *   <dependency>
 *     <groupId>io.zipkin.reporter2</groupId>
 *     <artifactId>zipkin-reporter-brave</artifactId>
 *   </dependency>
 *
 *   <!-- Context Propagation (OBLIGATOIRE pour ContextSnapshot) -->
 *   <dependency>
 *     <groupId>io.micrometer</groupId>
 *     <artifactId>context-propagation</artifactId>
 *   </dependency>
 *
 *   <!-- Spring AOP pour ShedLockTracingAspect -->
 *   <dependency>
 *     <groupId>org.springframework.boot</groupId>
 *     <artifactId>spring-boot-starter-aop</artifactId>
 *   </dependency>
 */
@Configuration
public class TracingBeansConfig {

    /**
     * ContextSnapshotFactory - capture et restaure tous les ThreadLocal
     * enregistrés dans le ContextRegistry Micrometer.
     *
     * Inclut automatiquement : TraceContext, SpanContext, Baggage fields.
     *
     * Auto-configuré par Spring Boot 3.x si context-propagation est sur le classpath.
     * Ce bean est déclaré ici pour être explicit et injectable partout.
     */
    @Bean
    public ContextSnapshotFactory contextSnapshotFactory() {
        return ContextSnapshotFactory.builder().build();
    }

    /*
     * Les beans suivants sont auto-configurés par Spring Boot 3.x :
     * - Tracer          → io.micrometer.tracing.Tracer
     * - Propagator      → io.micrometer.tracing.propagation.Propagator
     * - ObservationRegistry → io.micrometer.observation.ObservationRegistry
     *
     * Tu n'as PAS besoin de les déclarer manuellement.
     */
}
