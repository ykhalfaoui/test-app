package com.example.tracing.kafka;

import io.micrometer.context.ContextSnapshot;
import io.micrometer.context.ContextSnapshotFactory;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import io.micrometer.tracing.propagation.Propagator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.MicrometerConsumerListener;
import org.springframework.kafka.core.MicrometerProducerListener;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.RecordInterceptor;

import java.nio.charset.StandardCharsets;

/**
 * Configuration Kafka avec propagation du tracing Micrometer.
 *
 * Deux mécanismes complémentaires :
 * 1. MicrometerConsumerListener / MicrometerProducerListener → métriques automatiques
 * 2. RecordInterceptor custom → restauration du contexte W3C TraceContext dans le listener thread
 */
@Configuration
public class KafkaTracingConfig {

    private static final Logger log = LoggerFactory.getLogger(KafkaTracingConfig.class);

    // Headers W3C Trace Context (standard Micrometer / Spring Cloud Sleuth)
    private static final String TRACEPARENT_HEADER = "traceparent";
    private static final String TRACESTATE_HEADER  = "tracestate";
    // Header custom pour correlationId (Micrometer Baggage)
    private static final String CORRELATION_ID_HEADER = "X-Correlation-Id";

    private final Tracer tracer;
    private final Propagator propagator;
    private final ObservationRegistry observationRegistry;
    private final ContextSnapshotFactory contextSnapshotFactory;

    public KafkaTracingConfig(Tracer tracer,
                               Propagator propagator,
                               ObservationRegistry observationRegistry,
                               ContextSnapshotFactory contextSnapshotFactory) {
        this.tracer = tracer;
        this.propagator = propagator;
        this.observationRegistry = observationRegistry;
        this.contextSnapshotFactory = contextSnapshotFactory;
    }

    /**
     * Listener container factory avec tracing injecté.
     *
     * Le RecordInterceptor extrait les headers W3C du ConsumerRecord
     * et restaure le span dans le thread du listener Kafka.
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
                new ConcurrentKafkaListenerContainerFactory<>();

        factory.setConsumerFactory(consumerFactory);
        factory.getContainerProperties().setObservationEnabled(true); // Spring Kafka 3.x
        factory.setRecordInterceptor(tracingRecordInterceptor());

        // Optionnel : ACK manuel pour meilleur contrôle
        // factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);

        return factory;
    }

    /**
     * RecordInterceptor : restaure le contexte de tracing depuis les headers Kafka.
     *
     * Appelé AVANT que @KafkaListener reçoive le message.
     * Le span créé ici sera le parent du span du listener.
     */
    @Bean
    public RecordInterceptor<String, Object> tracingRecordInterceptor() {
        return new RecordInterceptor<>() {

            @Override
            public ConsumerRecord<String, Object> intercept(ConsumerRecord<String, Object> record) {
                Headers headers = record.headers();

                // Extrait le contexte W3C traceparent depuis les headers Kafka
                Propagator.Getter<Headers> getter = (carrier, key) -> {
                    var header = carrier.lastHeader(key);
                    return header != null ? new String(header.value(), StandardCharsets.UTF_8) : null;
                };

                Span span = propagator.extract(headers, getter).start();

                if (!span.isNoop()) {
                    log.debug("Kafka tracing restauré: topic={} traceId={} spanId={}",
                            record.topic(),
                            span.context().traceId(),
                            span.context().spanId());
                }

                // Le span est mis en scope - sera fermé dans afterRecord()
                tracer.withSpan(span);

                return record;
            }

            @Override
            public void afterRecord(ConsumerRecord<String, Object> record, Exception exception) {
                // Ferme le span créé dans intercept()
                Span current = tracer.currentSpan();
                if (current != null) {
                    if (exception != null) {
                        current.error(exception);
                    }
                    current.end();
                }
            }
        };
    }

    /**
     * Exemple : KafkaTemplate avec injection automatique des headers de tracing.
     *
     * Quand tu envoies un message, les headers traceparent / tracestate
     * sont automatiquement injectés depuis le contexte courant.
     */
    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate(ProducerFactory<String, Object> producerFactory) {
        KafkaTemplate<String, Object> template = new KafkaTemplate<>(producerFactory);
        template.setObservationEnabled(true); // Active l'auto-injection des headers W3C
        return template;
    }

    /**
     * Utilitaire pour injecter manuellement les headers de tracing dans un ProducerRecord.
     * Utile si tu construis des records à la main sans passer par KafkaTemplate directement.
     */
    public void injectTracingHeaders(ProducerRecord<String, Object> record) {
        Propagator.Setter<Headers> setter = (carrier, key, value) ->
                carrier.add(key, value.getBytes(StandardCharsets.UTF_8));

        Span current = tracer.currentSpan();
        if (current != null) {
            propagator.inject(current.context(), record.headers(), setter);
        }
    }
}
