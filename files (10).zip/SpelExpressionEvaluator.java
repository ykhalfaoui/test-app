package com.crok4it.audit.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Évaluateur SpEL pour les expressions de @Auditable.
 *
 * PATTERNS SUPPORTÉS :
 *
 * 1. Par nom de paramètre :
 *    "#payload.reviewId"      → payload est le nom du paramètre Java
 *    "#event.aggregateId"
 *    "#memberId"              → valeur directe du paramètre
 *
 * 2. Par index (#root) :
 *    "#root[0]"               → premier argument
 *    "#root[0].id"            → champ id du premier argument
 *    "#root[1].reason.code"   → accès nested
 *
 * 3. Valeur statique (entre quotes) :
 *    "'salesforce'"           → retourne la chaîne "salesforce"
 *    "'REVIEW_MODULE'"
 *
 * SÉCURITÉ :
 * - Les expressions sont cachées après la première compilation
 * - Les exceptions SpEL sont capturées et ne propagent jamais
 * - Une valeur null ou une expression vide retourne null proprement
 *
 * LIMITATIONS :
 * - Les noms de paramètres nécessitent la compilation avec -parameters
 *   (configuré automatiquement par spring-boot-starter-parent)
 * - Si -parameters n'est pas actif, utiliser #root[index] à la place
 */
@Component
public class SpelExpressionEvaluator {

    private static final Logger log = LoggerFactory.getLogger(SpelExpressionEvaluator.class);

    private final ExpressionParser parser = new SpelExpressionParser();

    // Cache des expressions compilées — thread-safe, évite la recompilation
    private final ConcurrentHashMap<String, Expression> expressionCache = new ConcurrentHashMap<>();

    /**
     * Évalue une expression SpEL dans le contexte d'un join point AOP.
     *
     * @param expression  expression SpEL (ex: "#payload.reviewId")
     * @param joinPoint   join point AOP contenant les arguments de la méthode
     * @return            résultat de l'évaluation converti en String, ou null
     */
    public String evaluate(String expression, ProceedingJoinPoint joinPoint) {
        if (!StringUtils.hasText(expression)) {
            return null;
        }

        try {
            EvaluationContext context = buildContext(joinPoint);
            Expression compiledExpr = expressionCache.computeIfAbsent(
                    expression, parser::parseExpression);

            Object result = compiledExpr.getValue(context);
            return result != null ? result.toString() : null;

        } catch (Exception e) {
            // Ne jamais bloquer l'exécution pour une erreur SpEL
            log.warn("SpEL evaluation failed for expression '{}' on method '{}' — reason: {}",
                    expression,
                    joinPoint.getSignature().getName(),
                    e.getMessage());
            return null;
        }
    }

    /**
     * Construit le contexte SpEL avec :
     *   - Variables nommées par nom de paramètre (#payload, #event, etc.)
     *   - Variable #root = tableau des arguments (accès par index #root[0], #root[1])
     */
    private EvaluationContext buildContext(ProceedingJoinPoint joinPoint) {
        StandardEvaluationContext context = new StandardEvaluationContext();

        Object[] args = joinPoint.getArgs();

        // #root[0], #root[1], ... — accès par index
        context.setRootObject(args);
        context.setVariable("root", args);

        // #paramName — accès par nom de paramètre Java
        // Nécessite -parameters à la compilation (activé par spring-boot-starter-parent)
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        Parameter[] parameters = method.getParameters();

        for (int i = 0; i < parameters.length && i < args.length; i++) {
            String paramName = parameters[i].getName();

            // Vérifie que le nom de paramètre est bien disponible (pas arg0, arg1...)
            if (paramName.startsWith("arg") && paramName.matches("arg\\d+")) {
                log.debug("Parameter names not available for method '{}' — " +
                          "use #root[index] instead or compile with -parameters",
                          method.getName());
            }

            context.setVariable(paramName, args[i]);
        }

        return context;
    }
}
