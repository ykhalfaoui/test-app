package com.crok4it.audit.service;

import com.crok4it.audit.entity.AuditEntry;
import com.crok4it.audit.repository.AuditEntryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service de persistance des entrées d'audit.
 *
 * PROPAGATION REQUIRES_NEW — point crucial :
 * La sauvegarde de l'audit s'exécute dans une transaction INDÉPENDANTE
 * de la transaction métier appelante. Cela garantit que :
 *   1. Si la TX métier rollback (erreur), l'entrée d'audit ERROR est quand même sauvegardée
 *   2. Si la sauvegarde de l'audit échoue, la TX métier n'est pas impactée
 *
 * Ce comportement est intentionnel — l'audit ne doit JAMAIS casser le flux métier.
 */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final AuditEntryRepository repository;

    public AuditService(AuditEntryRepository repository) {
        this.repository = repository;
    }

    /**
     * Sauvegarde une entrée d'audit dans une transaction séparée (REQUIRES_NEW).
     *
     * Cette méthode est appelée par AuditableAspect après chaque exécution
     * de méthode annotée @Auditable.
     *
     * Elle NE PROPAGE PAS les exceptions — un échec de l'audit ne doit pas
     * interrompre le traitement métier.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void save(AuditEntry entry) {
        try {
            repository.save(entry);
            log.debug("Audit saved — action={} entityId={} status={} traceId={}",
                    entry.getAction(),
                    entry.getEntityId(),
                    entry.getStatus(),
                    entry.getTraceId());
        } catch (Exception e) {
            // L'audit ne doit JAMAIS casser le flux métier
            // On logue l'erreur mais on ne propage pas l'exception
            log.error("Audit save failed — action={} entityId={} — reason: {}",
                    entry.getAction(), entry.getEntityId(), e.getMessage(), e);
        }
    }
}
