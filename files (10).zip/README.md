# @Auditable — Audit automatique via AOP + SpEL

## Objectif

Capturer automatiquement chaque exécution de méthode annotée `@Auditable` dans une
table d'audit JPA, avec :
- **Traçabilité des erreurs** : exception class, message, stacktrace
- **Contexte métier via SpEL** : entityId, correlationId extraits du payload
- **Corrélation avec le tracing** : traceId/spanId Micrometer dans chaque entrée
- **Transaction indépendante** : l'audit est toujours sauvegardé même si la TX métier rollback

---

## Composants

| Fichier | Rôle |
|---|---|
| `Auditable.java` | Annotation avec tous les paramètres SpEL |
| `AuditableAspect.java` | Aspect AOP `@Around` — orchestration |
| `SpelExpressionEvaluator.java` | Évaluation sécurisée des expressions SpEL |
| `AuditEntry.java` | Entité JPA avec builder |
| `AuditEntryRepository.java` | Repository avec requêtes métier |
| `AuditService.java` | Persistance en `REQUIRES_NEW` |
| `schema.sql` | DDL de la table `audit_entry` |
| `AuditableUsageExamples.java` | 7 patterns d'utilisation documentés |

---

## Dépendances à ajouter

```xml
<!-- AOP — OBLIGATOIRE -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-aop</artifactId>
</dependency>

<!-- JPA — pour AuditEntry -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>

<!-- Jackson — pour captureArgs/captureResult -->
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
</dependency>
```

---

## Patterns SpEL supportés

### Par nom de paramètre (recommandé)

```java
@Auditable(entityId = "#payload.reviewId", correlationId = "#payload.memberId")
public void syncReview(ReviewSyncPayload payload) { ... }
```

Nécessite la compilation avec `-parameters` — activé automatiquement
par `spring-boot-starter-parent` depuis Boot 3.2.

### Par index (#root)

```java
@Auditable(entityId = "#root[0].id", correlationId = "#root[1]")
public void blockMember(MemberId id, String correlationId) { ... }
```

Utile quand les noms de paramètres ne sont pas disponibles ou pour les types simples.

### Valeur statique

```java
@Auditable(module = "'salesforce'")  // entre quotes simples = String literal SpEL
```

### Accès nested

```java
@Auditable(entityId = "#root[0].blockId.value")  // objet imbriqué
@Auditable(entityId = "#event.aggregate.id")      // chaîne d'accès
```

---

## Transaction REQUIRES_NEW — comportement exact

```
TX Métier (REQUIRED)
  └─ méthode annotée @Auditable
       ├─ proceed() → exécution
       │    └─ EXCEPTION levée
       └─ AuditService.save()
            └─ TX Audit (REQUIRES_NEW) ← TX indépendante
                 └─ INSERT audit_entry (status=ERROR)
                 └─ COMMIT ← même si TX Métier va rollback

TX Métier → ROLLBACK  ← l'erreur est enregistrée dans audit malgré le rollback
```

---

## Guide de debug

### Vérifier que l'aspect est actif

Au démarrage, chercher dans les logs :
```
INFO  AuditableAspect : Initialized
```

Ou inspecter les beans :
```bash
curl http://localhost:8080/actuator/beans | grep -i audit
```

### Vérifier qu'une expression SpEL s'évalue correctement

Activer le niveau DEBUG sur le SpelExpressionEvaluator :
```yaml
logging.level.com.crok4it.audit.aspect.SpelExpressionEvaluator: DEBUG
```

Si le nom du paramètre n'est pas résolu (tu vois `arg0` au lieu du vrai nom) :
- Vérifier que `spring-boot-starter-parent` est bien le parent du pom
- Ou ajouter explicitement dans `pom.xml` :

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <configuration>
        <parameters>true</parameters>
    </configuration>
</plugin>
```

### Vérifier qu'une entrée d'audit est sauvegardée

```sql
-- Dernières entrées d'audit
SELECT id, action, entity_type, entity_id, status, trace_id, created_at
FROM audit_entry
ORDER BY created_at DESC
LIMIT 20;

-- Erreurs récentes
SELECT action, entity_id, error_class, error_message, trace_id, created_at
FROM audit_entry
WHERE status = 'ERROR'
ORDER BY created_at DESC;

-- Par traceId (corrélation avec les logs ELK)
SELECT * FROM audit_entry WHERE trace_id = 'abc123...';

-- Par entité
SELECT * FROM audit_entry
WHERE entity_type = 'Review' AND entity_id = '42'
ORDER BY created_at DESC;
```

### L'audit n'est pas sauvegardé (aucune ligne en base)

1. Vérifier que `spring-boot-starter-aop` est dans le classpath
2. Vérifier que la méthode annotée est appelée depuis un bean Spring
   (l'AOP ne fonctionne pas sur les appels `this.methode()` internes)
3. Vérifier que la classe cible n'est pas `final` (bloque la création du proxy)
4. Activer le debug AOP :
   ```yaml
   logging.level.org.springframework.aop: DEBUG
   ```

### L'entrée d'audit est en status=SUCCESS mais l'exception a été levée

Vérifier `rethrowException` dans l'annotation :
```java
@Auditable(rethrowException = false)  // avale l'exception — à utiliser avec précaution
```

La valeur par défaut est `true` — l'exception est toujours re-propagée.

### traceId vide dans l'entrée d'audit

- Vérifier que `micrometer-tracing-bridge-brave` est dans le classpath
- Vérifier que `management.tracing.sampling.probability=1.0` en dev
- Pour les `@Scheduled` : vérifier que `@Observed` est aussi présent
  (les schedulers n'ont pas de span parent automatique)

### L'entrée d'audit est sauvegardée même quand la TX rollback — est-ce normal ?

**Oui, c'est le comportement attendu et voulu.**
`AuditService.save()` s'exécute en `REQUIRES_NEW` — transaction indépendante.
C'est précisément ce qui permet de tracer les erreurs dans l'audit
même quand la transaction métier est annulée.

---

## Checklist d'intégration

```
□ spring-boot-starter-aop dans pom.xml
□ spring-boot-starter-data-jpa dans pom.xml
□ Table audit_entry créée (schema.sql)
□ @EnableAspectJAutoProxy ou @SpringBootApplication présent
□ Compilation avec -parameters (spring-boot-starter-parent ≥ 3.2 = automatique)
□ @Auditable uniquement sur des méthodes de beans Spring (pas d'appels this.xxx())
□ Pour @Scheduled : combiner avec @Observed pour avoir le traceId
```
