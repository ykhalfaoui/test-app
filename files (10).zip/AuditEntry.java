package com.crok4it.audit.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

/**
 * Entité JPA représentant une entrée d'audit.
 *
 * Chaque entrée correspond à une exécution d'une méthode annotée @Auditable.
 * Stockée dans la table `audit_entry`, toujours dans une transaction REQUIRES_NEW
 * pour garantir la persistance même si la TX métier rollback.
 */
@Entity
@Table(
    name = "audit_entry",
    indexes = {
        @Index(name = "idx_audit_entity",      columnList = "entity_type, entity_id"),
        @Index(name = "idx_audit_action",      columnList = "action"),
        @Index(name = "idx_audit_trace",       columnList = "trace_id"),
        @Index(name = "idx_audit_correlation", columnList = "correlation_id"),
        @Index(name = "idx_audit_status",      columnList = "status"),
        @Index(name = "idx_audit_created_at",  columnList = "created_at")
    }
)
public class AuditEntry {

    // ── Identité ──────────────────────────────────────────────────────────────

    @Id
    @Column(name = "id", updatable = false, nullable = false, length = 36)
    private String id;

    // ── Action auditée ────────────────────────────────────────────────────────

    /**
     * Nom de l'action (ex: REVIEW_SYNC, MEMBER_BLOCK).
     * Correspond à @Auditable#action().
     */
    @Column(name = "action", nullable = false, length = 100)
    private String action;

    /**
     * Type de l'entité concernée (ex: Review, Member).
     */
    @Column(name = "entity_type", length = 100)
    private String entityType;

    /**
     * Identifiant de l'entité concernée — résultat de l'expression SpEL entityId.
     */
    @Column(name = "entity_id", length = 255)
    private String entityId;

    /**
     * Identifiant de corrélation métier — résultat de l'expression SpEL correlationId.
     * Permet de retrouver toutes les entrées d'audit liées à une même opération.
     */
    @Column(name = "correlation_id", length = 255)
    private String correlationId;

    /**
     * Module source (ex: salesforce, review, member).
     */
    @Column(name = "module", length = 100)
    private String module;

    // ── Résultat ──────────────────────────────────────────────────────────────

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private AuditStatus status;

    // ── Payload ───────────────────────────────────────────────────────────────

    /**
     * Arguments d'entrée sérialisés en JSON.
     * Rempli si @Auditable#captureArgs() = true.
     */
    @Column(name = "input_payload", columnDefinition = "TEXT")
    private String inputPayload;

    /**
     * Valeur de retour sérialisée en JSON.
     * Rempli si @Auditable#captureResult() = true.
     */
    @Column(name = "output_payload", columnDefinition = "TEXT")
    private String outputPayload;

    // ── Erreur ────────────────────────────────────────────────────────────────

    /** Classe de l'exception (ex: IllegalStateException). */
    @Column(name = "error_class", length = 255)
    private String errorClass;

    /** Message de l'exception. */
    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    /** Stacktrace complète. Rempli si @Auditable#captureStacktrace() = true. */
    @Column(name = "stacktrace", columnDefinition = "TEXT")
    private String stacktrace;

    // ── Tracing ───────────────────────────────────────────────────────────────

    /** traceId Micrometer — corrélation avec les logs ECS et Zipkin. */
    @Column(name = "trace_id", length = 64)
    private String traceId;

    /** spanId Micrometer. */
    @Column(name = "span_id", length = 32)
    private String spanId;

    // ── Contexte technique ────────────────────────────────────────────────────

    /** Nom complet de la classe et méthode auditée. */
    @Column(name = "method_signature", length = 500)
    private String methodSignature;

    /** Durée d'exécution de la méthode en millisecondes. */
    @Column(name = "duration_ms")
    private Long durationMs;

    /** Timestamp de création de l'entrée d'audit. */
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @PrePersist
    public void prePersist() {
        if (this.id == null) {
            this.id = UUID.randomUUID().toString();
        }
        if (this.createdAt == null) {
            this.createdAt = Instant.now();
        }
    }

    // ── Enum ──────────────────────────────────────────────────────────────────

    public enum AuditStatus {
        SUCCESS,
        ERROR,
        /** Exécution interrompue avant la méthode (ex: SpEL eval failure). */
        UNKNOWN
    }

    // ── Builder ───────────────────────────────────────────────────────────────

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private final AuditEntry entry = new AuditEntry();

        public Builder action(String action)               { entry.action = action;                 return this; }
        public Builder entityType(String entityType)       { entry.entityType = entityType;         return this; }
        public Builder entityId(String entityId)           { entry.entityId = entityId;             return this; }
        public Builder correlationId(String correlationId) { entry.correlationId = correlationId;   return this; }
        public Builder module(String module)               { entry.module = module;                 return this; }
        public Builder status(AuditStatus status)          { entry.status = status;                 return this; }
        public Builder inputPayload(String inputPayload)   { entry.inputPayload = inputPayload;     return this; }
        public Builder outputPayload(String outputPayload) { entry.outputPayload = outputPayload;   return this; }
        public Builder errorClass(String errorClass)       { entry.errorClass = errorClass;         return this; }
        public Builder errorMessage(String errorMessage)   { entry.errorMessage = errorMessage;     return this; }
        public Builder stacktrace(String stacktrace)       { entry.stacktrace = stacktrace;         return this; }
        public Builder traceId(String traceId)             { entry.traceId = traceId;               return this; }
        public Builder spanId(String spanId)               { entry.spanId = spanId;                 return this; }
        public Builder methodSignature(String sig)         { entry.methodSignature = sig;           return this; }
        public Builder durationMs(Long durationMs)         { entry.durationMs = durationMs;         return this; }

        public AuditEntry build() { return entry; }
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String getId()              { return id; }
    public String getAction()          { return action; }
    public String getEntityType()      { return entityType; }
    public String getEntityId()        { return entityId; }
    public String getCorrelationId()   { return correlationId; }
    public String getModule()          { return module; }
    public AuditStatus getStatus()     { return status; }
    public String getInputPayload()    { return inputPayload; }
    public String getOutputPayload()   { return outputPayload; }
    public String getErrorClass()      { return errorClass; }
    public String getErrorMessage()    { return errorMessage; }
    public String getStacktrace()      { return stacktrace; }
    public String getTraceId()         { return traceId; }
    public String getSpanId()          { return spanId; }
    public String getMethodSignature() { return methodSignature; }
    public Long getDurationMs()        { return durationMs; }
    public Instant getCreatedAt()      { return createdAt; }
}
