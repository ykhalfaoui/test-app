package com.crok4it.audit.debug;

import com.crok4it.audit.annotation.Auditable;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Exemples d'utilisation de @Auditable pour tous les vecteurs du projet.
 *
 * Ce fichier est documentaire — à adapter dans tes vrais services.
 */
@Service
public class AuditableUsageExamples {

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 1 — Service métier avec objet payload (SpEL par nom de paramètre)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Accès par nom de paramètre — le plus lisible.
     * #payload.reviewId accède au champ reviewId de l'objet ReviewSyncPayload.
     */
    @Auditable(
        action        = "REVIEW_SALESFORCE_SYNC",
        entityType    = "Review",
        entityId      = "#payload.reviewId",        // champ de l'objet
        correlationId = "#payload.memberId",         // champ de corrélation
        module        = "'salesforce'",              // valeur statique entre quotes
        captureArgs   = false                        // pas de sérialisation du payload complet
    )
    public void syncReviewToSalesforce(ReviewSyncPayload payload) {
        // traceId dans MDC + entrée audit créée automatiquement
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 2 — Accès par index (#root) quand le paramètre est un type simple
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Accès par index quand les paramètres sont de types simples ou sans nom disponible.
     * #root[0] = premier argument, #root[1] = deuxième argument
     */
    @Auditable(
        action        = "MEMBER_BLOCK",
        entityType    = "Member",
        entityId      = "#root[0]",                 // premier arg = memberId (String)
        correlationId = "#root[1]",                 // deuxième arg = correlationId
        module        = "'member'"
    )
    public void blockMember(String memberId, String correlationId) {
        // ...
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 3 — Accès nested (#root[0].field.subfield)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Accès à des propriétés imbriquées.
     * Utile quand l'identifiant est dans un objet value-type.
     */
    @Auditable(
        action     = "BLOCK_SYNC",
        entityType = "Block",
        entityId   = "#root[0].blockId.value",      // blockId est un value object
        module     = "'salesforce'"
    )
    public void syncBlock(BlockSyncEvent event) {
        // ...
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 4 — @KafkaListener (inbox pattern)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Sur un consumer Kafka — traceId déjà restauré par observationEnabled=true.
     * L'entrée d'audit lie l'action au traceId du message Kafka d'origine.
     */
    @KafkaListener(topics = "review-inbox")
    @Auditable(
        action        = "REVIEW_INBOX_CONSUMED",
        entityType    = "Review",
        entityId      = "#record.reviewId",
        correlationId = "#record.correlationId",
        captureArgs   = false                        // éviter de logguer le payload Kafka complet
    )
    public void consumeReviewInbox(ReviewInboxRecord record) {
        // ...
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 5 — @ApplicationModuleListener (Modulith)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Sur un listener Modulith — contexte propagé par ContextPropagatingTaskDecorator.
     */
    @ApplicationModuleListener
    @Auditable(
        action        = "SALESFORCE_EVENT_PROCESSED",
        entityType    = "Review",
        entityId      = "#event.reviewId",
        correlationId = "#event.memberId",
        module        = "'salesforce'",
        captureStacktrace = true
    )
    public void onReviewSyncRequested(ReviewSyncRequestedEvent event) {
        // ...
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 6 — @Scheduled (avec @Observed pour le traceId)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Sur un scheduler — pas de payload, entityId statique ou null.
     * @Observed crée le span racine, @Auditable capture l'exécution.
     */
    @Scheduled(fixedDelay = 5000)
    @io.micrometer.observation.annotation.Observed(name = "outbox.dispatch")
    @Auditable(
        action     = "OUTBOX_DISPATCH",
        entityType = "OutboxBatch",
        module     = "'outbox'"
        // pas d'entityId — aucun paramètre disponible
    )
    public void dispatchOutbox() {
        // ...
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PATTERN 7 — Avec capture du résultat
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Capture la valeur de retour pour tracer le résultat d'une opération.
     */
    @Auditable(
        action        = "SALESFORCE_PUSH",
        entityType    = "Review",
        entityId      = "#payload.reviewId",
        captureResult = true                         // sérialise SalesforcePushResult en JSON
    )
    public SalesforcePushResult pushToSalesforce(ReviewSyncPayload payload) {
        return new SalesforcePushResult("sf-id-123", "SUCCESS");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Stubs des types utilisés dans les exemples
    // ══════════════════════════════════════════════════════════════════════════

    record ReviewSyncPayload(String reviewId, String memberId) {}
    record BlockSyncEvent(BlockId blockId) {}
    record BlockId(String value) {}
    record ReviewInboxRecord(String reviewId, String correlationId) {}
    record ReviewSyncRequestedEvent(String reviewId, String memberId) {}
    record SalesforcePushResult(String salesforceId, String status) {}
}
