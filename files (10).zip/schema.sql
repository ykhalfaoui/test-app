-- Table d'audit — à exécuter lors de la création/migration du schéma
-- Compatible PostgreSQL (production) et H2 (tests)

CREATE TABLE IF NOT EXISTS audit_entry (
    id               VARCHAR(36)   NOT NULL,
    action           VARCHAR(100)  NOT NULL,
    entity_type      VARCHAR(100),
    entity_id        VARCHAR(255),
    correlation_id   VARCHAR(255),
    module           VARCHAR(100),
    status           VARCHAR(20)   NOT NULL,
    input_payload    TEXT,
    output_payload   TEXT,
    error_class      VARCHAR(255),
    error_message    TEXT,
    stacktrace       TEXT,
    trace_id         VARCHAR(64),
    span_id          VARCHAR(32),
    method_signature VARCHAR(500),
    duration_ms      BIGINT,
    created_at       TIMESTAMP     NOT NULL,

    CONSTRAINT pk_audit_entry PRIMARY KEY (id)
);

-- Index pour les recherches fréquentes
CREATE INDEX IF NOT EXISTS idx_audit_entity      ON audit_entry (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_action      ON audit_entry (action);
CREATE INDEX IF NOT EXISTS idx_audit_trace       ON audit_entry (trace_id);
CREATE INDEX IF NOT EXISTS idx_audit_correlation ON audit_entry (correlation_id);
CREATE INDEX IF NOT EXISTS idx_audit_status      ON audit_entry (status);
CREATE INDEX IF NOT EXISTS idx_audit_created_at  ON audit_entry (created_at);
