package com.crok4it.audit.annotation;

import java.lang.annotation.*;

/**
 * Marque une méthode pour l'audit automatique via AOP.
 *
 * Les expressions SpEL sont évaluées sur les paramètres de la méthode.
 * Variables disponibles :
 *   - #nomDuParamètre   → accès par nom (ex: #payload.reviewId)
 *   - #root[0], #root[1] → accès par index (ex: #root[0].id)
 *   - #result            → résultat de retour (uniquement si captureResult=true)
 *
 * Exemples :
 * <pre>
 * {@code
 * @Auditable(
 *     action    = "REVIEW_SYNC",
 *     entityType = "Review",
 *     entityId  = "#payload.reviewId",
 *     correlationId = "#payload.memberId"
 * )
 * public void syncReview(ReviewSyncPayload payload) { ... }
 *
 * @Auditable(
 *     action    = "MEMBER_BLOCK",
 *     entityType = "Member",
 *     entityId  = "#root[0].id"
 * )
 * public void blockMember(MemberId id, BlockReason reason) { ... }
 * }
 * </pre>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Auditable {

    /**
     * Nom de l'action auditée.
     * Exemples : "REVIEW_SYNC", "MEMBER_BLOCK", "SALESFORCE_PUSH"
     */
    String action();

    /**
     * Type de l'entité concernée.
     * Exemples : "Review", "Member", "Block"
     */
    String entityType() default "";

    /**
     * SpEL — identifiant de l'entité concernée.
     * Exemples : "#payload.reviewId", "#root[0].id", "#event.aggregateId"
     */
    String entityId() default "";

    /**
     * SpEL — identifiant de corrélation (ex: memberId, correlationId métier).
     * Utile pour regrouper plusieurs entrées d'audit liées.
     */
    String correlationId() default "";

    /**
     * SpEL — module ou composant source (utile en Modulith).
     * Peut être une valeur statique ou une expression.
     * Exemple : "'salesforce'", "#payload.module"
     */
    String module() default "";

    /**
     * Sérialise les arguments d'entrée en JSON dans inputPayload.
     * Attention : peut exposer des données sensibles — désactiver si besoin.
     */
    boolean captureArgs() default false;

    /**
     * Sérialise la valeur de retour en JSON dans outputPayload.
     * N'a aucun effet sur les méthodes void.
     */
    boolean captureResult() default false;

    /**
     * Capture la stacktrace complète en cas d'exception.
     * true par défaut — désactiver si les stacktraces sont trop volumineuses.
     */
    boolean captureStacktrace() default true;

    /**
     * Si true, l'exception est re-propagée après l'audit.
     * Si false, l'exception est avalée (swallowed) — à utiliser avec précaution.
     * true par défaut — toujours re-propager sauf cas explicite.
     */
    boolean rethrowException() default true;
}
