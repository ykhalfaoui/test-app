package com.crok4it.audit.aspect;

import com.crok4it.audit.annotation.Auditable;
import com.crok4it.audit.entity.AuditEntry;
import com.crok4it.audit.service.AuditService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Aspect AOP principal — intercepte toutes les méthodes annotées @Auditable.
 *
 * ORDRE D'EXÉCUTION :
 * 1. Évaluation des expressions SpEL (avant proceed) sur les args d'entrée
 * 2. Appel de la méthode réelle (proceed)
 * 3. Selon le résultat :
 *    - Succès → AuditEntry(SUCCESS) + outputPayload si captureResult
 *    - Exception → AuditEntry(ERROR) + errorClass + errorMessage + stacktrace
 * 4. Sauvegarde via AuditService (TX REQUIRES_NEW)
 * 5. Re-propagation de l'exception si rethrowException=true (défaut)
 *
 * RÉSILIENCE :
 * La sauvegarde de l'audit est dans un try/catch — une erreur d'audit
 * ne bloque jamais le flux métier.
 */
@Aspect
@Component
public class AuditableAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditableAspect.class);

    private final AuditService auditService;
    private final SpelExpressionEvaluator spelEvaluator;
    private final Tracer tracer;
    private final ObjectMapper objectMapper;

    public AuditableAspect(AuditService auditService,
                           SpelExpressionEvaluator spelEvaluator,
                           Tracer tracer,
                           ObjectMapper objectMapper) {
        this.auditService   = auditService;
        this.spelEvaluator  = spelEvaluator;
        this.tracer         = tracer;
        this.objectMapper   = objectMapper;
    }

    @Around("@annotation(auditable)")
    public Object audit(ProceedingJoinPoint joinPoint, Auditable auditable) throws Throwable {

        long startTime = System.currentTimeMillis();

        // ── 1. Évaluation SpEL AVANT proceed() ────────────────────────────────
        // Important : évaluer avant proceed() pour capturer l'état initial
        // des arguments (ils pourraient être mutés dans la méthode)
        String entityId       = spelEvaluator.evaluate(auditable.entityId(),       joinPoint);
        String correlationId  = spelEvaluator.evaluate(auditable.correlationId(),  joinPoint);
        String module         = spelEvaluator.evaluate(auditable.module(),         joinPoint);
        String inputPayload   = captureArgs(auditable, joinPoint);
        String methodSig      = buildMethodSignature(joinPoint);

        // ── 2. Récupération du contexte de tracing ────────────────────────────
        Span currentSpan = tracer.currentSpan();
        String traceId   = currentSpan != null ? currentSpan.context().traceId() : null;
        String spanId    = currentSpan != null ? currentSpan.context().spanId()  : null;

        // ── 3. Exécution de la méthode réelle ─────────────────────────────────
        Object result;
        try {
            result = joinPoint.proceed();
        } catch (Throwable ex) {
            // ── 4a. Cas ERREUR ─────────────────────────────────────────────────
            long duration = System.currentTimeMillis() - startTime;

            log.debug("@Auditable ERROR — action={} entityId={} traceId={} — {}",
                    auditable.action(), entityId, traceId, ex.getMessage());

            saveAudit(AuditEntry.builder()
                    .action(auditable.action())
                    .entityType(auditable.entityType())
                    .entityId(entityId)
                    .correlationId(correlationId)
                    .module(resolveModule(module, auditable))
                    .status(AuditEntry.AuditStatus.ERROR)
                    .inputPayload(inputPayload)
                    .errorClass(ex.getClass().getName())
                    .errorMessage(ex.getMessage())
                    .stacktrace(auditable.captureStacktrace() ? extractStacktrace(ex) : null)
                    .traceId(traceId)
                    .spanId(spanId)
                    .methodSignature(methodSig)
                    .durationMs(duration)
                    .build());

            // Re-propager selon la configuration
            if (auditable.rethrowException()) {
                throw ex;
            }
            return null;
        }

        // ── 4b. Cas SUCCÈS ─────────────────────────────────────────────────────
        long duration = System.currentTimeMillis() - startTime;

        log.debug("@Auditable SUCCESS — action={} entityId={} traceId={} duration={}ms",
                auditable.action(), entityId, traceId, duration);

        saveAudit(AuditEntry.builder()
                .action(auditable.action())
                .entityType(auditable.entityType())
                .entityId(entityId)
                .correlationId(correlationId)
                .module(resolveModule(module, auditable))
                .status(AuditEntry.AuditStatus.SUCCESS)
                .inputPayload(inputPayload)
                .outputPayload(captureResult(auditable, result))
                .traceId(traceId)
                .spanId(spanId)
                .methodSignature(methodSig)
                .durationMs(duration)
                .build());

        return result;
    }

    // ── Helpers privés ────────────────────────────────────────────────────────

    /**
     * Sauvegarde l'audit de façon sécurisée — ne propage jamais d'exception.
     */
    private void saveAudit(AuditEntry entry) {
        try {
            auditService.save(entry);
        } catch (Exception e) {
            // Déjà géré dans AuditService, mais double-protection ici
            log.error("AuditableAspect: unexpected error during audit save — action={}",
                    entry.getAction(), e);
        }
    }

    /**
     * Sérialise les arguments d'entrée en JSON si captureArgs=true.
     * Les erreurs de sérialisation retournent un message d'erreur JSON-safe.
     */
    private String captureArgs(Auditable auditable, ProceedingJoinPoint joinPoint) {
        if (!auditable.captureArgs()) {
            return null;
        }
        try {
            Object[] args = joinPoint.getArgs();
            return objectMapper.writeValueAsString(args);
        } catch (Exception e) {
            log.debug("Cannot serialize args for audit — {}", e.getMessage());
            return "{\"error\":\"serialization_failed\",\"reason\":\"" + e.getMessage() + "\"}";
        }
    }

    /**
     * Sérialise la valeur de retour en JSON si captureResult=true.
     */
    private String captureResult(Auditable auditable, Object result) {
        if (!auditable.captureResult() || result == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            log.debug("Cannot serialize result for audit — {}", e.getMessage());
            return "{\"error\":\"serialization_failed\"}";
        }
    }

    /**
     * Extrait la stacktrace complète sous forme de String.
     */
    private String extractStacktrace(Throwable ex) {
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        String stacktrace = sw.toString();
        // Limiter à 4000 caractères pour éviter des colonnes TEXT trop volumineuses
        return stacktrace.length() > 4000
                ? stacktrace.substring(0, 4000) + "\n... [truncated]"
                : stacktrace;
    }

    /**
     * Construit la signature lisible de la méthode.
     * Ex: "com.crok4it.review.SalesforceService.syncReview"
     */
    private String buildMethodSignature(ProceedingJoinPoint joinPoint) {
        MethodSignature sig = (MethodSignature) joinPoint.getSignature();
        return sig.getDeclaringTypeName() + "." + sig.getName();
    }

    /**
     * Résout le module : SpEL d'abord, puis annotation value() statique.
     */
    private String resolveModule(String spelResult, Auditable auditable) {
        if (StringUtils.hasText(spelResult)) {
            return spelResult;
        }
        return StringUtils.hasText(auditable.module()) ? auditable.module() : null;
    }
}
