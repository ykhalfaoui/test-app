# Epic - Automatic evaluation of KYC reviews (i-Hub)

Goal: a scheduled job evaluates every open KYC review, builds its context (i-Hub documents, non i-Hub blocks, KYC data / KYT), then applies rules FR 0.0, FR 0.A, FR 0.B and FR 0.C. Each rule either performs an automatic action or creates a Salesforce task for KYCO.

Reference: `kyc-review-cases.drawio`
- tab "Blueprint": the whole flow on one page
- tab "How to read": legend of the case diagrams
- tab "Cases index": the 14 cases and their status
- tabs "Case 1" to "Case 14": one scenario per tab
- tab "Business questions": decisions taken (D1 to D7) and open questions (Q1 to Q12)

Already in place: per-member i-Hub document check, outbox.

| # | Ticket | Depends on | Open questions |
|---|---|---|---|
| 1 | Select eligible reviews | none | none |
| 2 | Review-level document aggregation | 1 | none |
| 3 | Enriched review context | 2 | none |
| 4 | Configuration of the 4 Salesforce tasks | none | Q1 to Q4 |
| 5 | FR 0.0 Documents validated | 3, 4 | none |
| 6 | FR 0.A Blocking | 3, 4 | Q5 to Q7 |
| 7 | FR 0.B Unblocking | 3, 4 | Q10 to Q12 |
| 8 | FR 0.C Validation / finalization | 3, 4, 7 | Q8, Q9, Q12 |
| 9 | Rule orchestrator and end-to-end tests | 5 to 8 | Q11 |

---

## Ticket 1 - Select eligible reviews

**Description**
As the evaluation job, I need to load every review that can still be evaluated, so that each one goes through the context building and the rules.

**Scope**
- Find all reviews with status `Client Communication Ongoing`, `Prepare Client Communication` or `Blocked`.
- For each review, load its members with status not `removed`.
- One failing review must not stop the others (log and continue).

**Acceptance criteria**
- Given reviews in CCO, Prepare com, Blocked and other statuses, when the job runs, then only the 3 eligible statuses are processed.
- Given a review with a `removed` member, then that member is excluded.
- Given an exception on one review, then the error is logged with the review id and the next review is processed.

---

## Ticket 2 - Review-level document aggregation

**Description**
The per-member i-Hub document check already exists. This ticket aggregates the member results into one `reviewDocumentResult` per review.

**Scope**
- `allDocumentsValid`: every i-Hub document of every member is valid.
- `pendingDocument`: at least one document is pending (provided by the client, under back-office validation).
- `rejectedDocument`: at least one document is rejected.
- `blockJustValidated`: at least one block became valid since the previous run. Needs the previous state to be persisted.
- Only blocks (specific or common) that impact the review are taken into account.

**Acceptance criteria**
- Given all documents valid for all members, then `allDocumentsValid = true`.
- Given one pending document, then `pendingDocument = true` and `allDocumentsValid = false`.
- Given one rejected document, then `rejectedDocument = true`.
- Given a block not valid at run N and valid at run N+1, then `blockJustValidated = true` at run N+1 only.

**Technical point:** where to store the previous state (column or table), to agree within the team.

---

## Ticket 3 - Enriched review context

**Description**
Complete the review context so that every rule has what it needs in one object.

**Scope**
- `reviewBlockNonIhubOk`: true if every non i-Hub block is green or grey, false if at least one is amber.
- `kycDataAndKytOk`: KYC data and KYT assessment OK, for the main party and the review.
- `unblockActionProcessed`: state of the unblock process action of the review.
- Final immutable context: status, blocking planned date, pool, AML score, party tiering, main DAO, `reviewDocumentResult`, the three flags above.

**Acceptance criteria**
- Given one non i-Hub block amber, then `reviewBlockNonIhubOk = false`.
- Given KYT KO on the main party, then `kycDataAndKytOk = false`.
- Given an unblock process action marked processed, then `unblockActionProcessed = true`.

---

## Ticket 4 - Configuration of the 4 Salesforce tasks

**Description**
The outbox is already in place. This ticket adds one domain event per task type and the configuration that turns each event into a Salesforce task.

**Scope**

| Rule | Event (name to align with conventions) | Task subject |
|---|---|---|
| FR 0.0 | `ReviewDocumentsCompleted` | KYC REVIEW - i-HUB documents complete. Ready for follow-up |
| FR 0.A | `ReviewEligibleForBlocking` | KYC REVIEW - The customer eligible for blocking |
| FR 0.B | `ReviewRestrictionsToLift` | KYC REVIEW - Restrictions of the customer to be manually lifted |
| FR 0.C | `ReviewEligibleForFinalization` | KYC REVIEW - The review meets the criteria for a finalization |

- Upsert with the unique key `reviewId + taskType`: create if absent, reopen and update if it exists (D7).

**Acceptance criteria**
- Given an event with no existing task of that type, then one task is created.
- Given an event with an open task of the same type, then the existing task is updated, no duplicate.
- Given an event with a closed task of the same type, then the task is reopened and updated.
- Given the same event published twice, then only one task exists.

**Open questions:** Q1 to Q4.

---

## Ticket 5 - FR 0.0 Documents validated

**Description**
Tell KYCO that all i-Hub documents are complete when manual work is still needed on non i-Hub blocks.

**Rule**
- Condition: status in (CCO, Prepare com, Blocked) AND `allDocumentsValid` AND `blockJustValidated` AND `reviewBlockNonIhubOk = false`.
- No condition on the blocking planned date (D1).
- Action: task FR 0.0 only, no automatic action.

**Acceptance criteria**
- Given docs valid, one block just validated, one non i-Hub block amber, then a task FR 0.0 is created. (Case 3)
- Given the same on a Blocked review, then a task FR 0.0 is created. (Case 9)
- Given the same at the same run as FR 0.A, then both outputs are produced. (Case 6)
- Given all non i-Hub blocks OK, then no task FR 0.0.
- Given no block just validated, then no task FR 0.0.

---

## Ticket 6 - FR 0.A Blocking

**Description**
Block the review when the blocking planned date is passed and the review is still incomplete.

**Rule**
- Eligible: status in (CCO, Prepare com) AND blocking planned date < today AND `pendingDocument = false` AND (`allDocumentsValid = false` OR `kycDataAndKytOk = false`).
- Automatic if: tiering 4 or 5 AND pool = Retail AND AML score = Low AND `rejectedDocument = false` -> status `Blocked`.
- Else: task FR 0.A.

**Acceptance criteria**
- Given an eligible review with an auto profile, then status becomes `Blocked`, no task. (Case 4)
- Given an eligible review with a non auto profile, then a task FR 0.A is created. (Case 5)
- Given a rejected document, then a task FR 0.A even with an auto profile. (Case 8)
- Given a pending document, then no action: blocking paused (D2). (Case 7)
- Given that pending document rejected at a later run, then a task FR 0.A. (Case 7)
- Given the blocking planned date not reached, then no action.

**Open questions:** Q5 to Q7.

---

## Ticket 7 - FR 0.B Unblocking

**Description**
Unblock the account of a Blocked review once everything is back to OK. The review status is never changed here (D3).

**Rule**
- Eligible: status = `Blocked` AND `allDocumentsValid` AND `reviewBlockNonIhubOk = true` AND `unblockActionProcessed = false` [AND `kycDataAndKytOk`: Q12].
- Automatic if: pool = Retail AND AML score = Low -> trigger the unblock process action (remove posting restriction). Marked processed, never relaunched.
- Else: task FR 0.B.

**Acceptance criteria**
- Given an eligible review, retail, AML low (831 or not), then the unblock process action is triggered, no task. (Cases 4 and 10)
- Given an eligible review with a non auto profile, then a task FR 0.B is created. (Case 5)
- Given an unblock action already processed, then FR 0.B does nothing.
- Given one non i-Hub block amber, then no action. (Case 9)
- The review status stays `Blocked` in every case.

**Open questions:** Q10 (action in error), Q11 (re-blocking), Q12 (KYC/KYT check).

---

## Ticket 8 - FR 0.C Validation / finalization (STP)

**Description**
Finalize the review automatically when everything is OK, or ask KYCO to finalize it (D5, D6).

**Rule**
- Eligible: `allDocumentsValid` AND `reviewBlockNonIhubOk = true` [AND `kycDataAndKytOk`: Q12] AND one of:
  - status = CCO AND blocking planned date < today,
  - status = `Blocked` AND `unblockActionProcessed = true`.
- Automatic if: main DAO is not 831 Retail International AND pool = Retail AND AML score = Low -> status `Remediated`.
- Else: task FR 0.C.

**Acceptance criteria**
- Given a CCO review, date passed, all OK, auto profile, then `Remediated`. (Case 1)
- Given a CCO review with main DAO 831, then a task FR 0.C. (Case 2)
- Given a Blocked review with the unblock processed automatically, auto profile, then `Remediated`. (Case 4)
- Given a Blocked review with the unblock processed, 831 profile, then a task FR 0.C. (Case 10)
- Given a Blocked review unblocked manually by KYCO, then a task FR 0.C. (Cases 5 and 13)
- Given a Blocked review whose unblock action is not processed, then no action. (Case 11)

**Open questions:** Q8 (why wait for the date), Q9 (831), Q12 (KYC/KYT check).

---

## Ticket 9 - Rule orchestrator and end-to-end tests

**Description**
Run the rules in a fixed order on each review context and cover the 14 cases end to end.

**Scope**
- Order: FR 0.0, FR 0.A, FR 0.B, FR 0.C.
- FR 0.C runs after FR 0.B in the same run: if the unblock action is processed synchronously, the review is finalized in one run, otherwise at the next run.
- One integration test per case of `kyc-review-cases.drawio` (Case 1 to Case 14). Conflict cases (12, 14) are tested once the business has answered.

**Acceptance criteria**
- Given Case 4 inputs, then the review goes Blocked -> unblock processed -> Remediated.
- Given Case 6 inputs, then both FR 0.0 and FR 0.A outputs are produced.
- All case tests pass in CI.

**Open question:** Q11 (re-blocking after unblock).
