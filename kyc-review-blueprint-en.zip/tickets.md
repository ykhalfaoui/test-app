# Tickets - Automatic evaluation of KYC reviews (i-Hub)

| # | Ticket | Notes | Blocked by questions |
|---|---|---|---|
| 1 | Select eligible reviews (CCO, Prepare com, Blocked) + loop per review | | none |
| 2 | Review-level aggregation (`reviewDocumentResult`) + "just validated" delta | Reuses the existing per-member document check | none |
| 3 | Enriched context: non i-Hub blocks, KYC data, KYT | | none |
| 4 | Config of the 4 tasks on event reception (mapping + upsert) | Outbox already in place | 1 to 4 |
| 5 | FR 0.0 - documents complete task | | 5 |
| 6 | FR 0.A - auto blocking or task | | 6 to 8 |
| 7 | FR 0.B - auto unblocking or task | | 9 to 13 |
| 8 | FR 0.C - STP auto or task | | 9 to 13 |
| 9 | Rule orchestrator + end-to-end tests (the 9 cases) | | 10 |

Dependencies: 1 -> 2 -> 3, ticket 4 in parallel, tickets 5 to 8 after 3 and 4, ticket 9 last.

The business questions are listed in the "Business questions" tab of `kyc-review-cases.drawio`.
