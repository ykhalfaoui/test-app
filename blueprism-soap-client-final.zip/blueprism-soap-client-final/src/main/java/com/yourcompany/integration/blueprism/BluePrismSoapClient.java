package com.yourcompany.integration.blueprism;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.soap.*;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Client SOAP RPC/encoded pour BluePrism WS Remediation Services
 * 
 * Opérations supportées:
 * - BlockClient
 * - ValidateClientWorLdCheck
 * - CreateKYCMemo
 * - Ping
 * - DocArchiving
 * 
 * @author Yass
 */
@Service
@Slf4j
public class BluePrismSoapClient {
    
    private static final String NAMESPACE = "urn:blueprism:webservice:wsremediationservices";
    private static final String ENCODING_STYLE = SOAPConstants.URI_NS_SOAP_ENCODING;
    private static final String XSD_NS = "http://www.w3.org/2001/XMLSchema";
    private static final String XSI_NS = "http://www.w3.org/2001/XMLSchema-instance";
    
    private final BluePrismSoapConfig config;
    private final SOAPConnectionFactory connectionFactory;
    private final MessageFactory messageFactory;
    
    public BluePrismSoapClient(
            BluePrismSoapConfig config,
            SOAPConnectionFactory connectionFactory,
            MessageFactory messageFactory) {
        this.config = config;
        this.connectionFactory = connectionFactory;
        this.messageFactory = messageFactory;
    }
    
    /**
     * Opération BlockClient - Bloquer un client
     */
    public BlockClientResponse blockClient(BlockClientRequest request) {
        Map<String, Object> params = new HashMap<>();
        params.put("bpInstance", request.getBpInstance());
        params.put("ClientID", request.getClientId());
        params.put("Letter", request.getLetter());
        params.put("Blocking", request.isBlocking());
        params.put("Unblocking", request.isUnblocking());
        params.put("InitiationDate", formatDate(request.getInitiationDate()));
        params.put("FirstLetterDate", formatDate(request.getFirstLetterDate()));
        params.put("BlockingDateHard", formatDate(request.getBlockingDateHard()));
        params.put("AccountBlockingExemption", request.isAccountBlockingExemption());
        params.put("BlockingExemptionDeadline", formatDate(request.getBlockingExemptionDeadline()));
        params.put("SecondLetterDate", formatDate(request.getSecondLetterDate()));
        params.put("DossierNumber", request.getDossierNumber());
        params.put("FolderStatus", request.getFolderStatus());
        params.put("BLine", request.getbLine());
        params.put("UserPool", request.getUserPool());
        params.put("LettersDate", formatDate(request.getLettersDate()));
        params.put("Agent", request.getAgent());
        params.put("MainRM", request.getMainRM());
        params.put("MainRMEmail", request.getMainRMEmail());
        params.put("Submitter", request.getSubmitter());
        params.put("RequestTime", request.getRequestTime());
        
        Map<String, Object> response = callSoapOperation("BlockClient", params);
        
        return BlockClientResponse.builder()
            .success(parseBoolean(response.get("Success")))
            .message(parseString(response.get("Message")))
            .build();
    }
    
    /**
     * Opération ValidateClientWorLdCheck
     */
    public ValidateClientResponse validateClientWorldCheck(ValidateClientRequest request) {
        Map<String, Object> params = new HashMap<>();
        params.put("bpInstance", request.getBpInstance());
        params.put("DossierNumber", request.getDossierNumber());
        params.put("ClientID", request.getClientId());
        params.put("UserPool", request.getUserPool());
        params.put("Agent", request.getAgent());
        params.put("Submitter", request.getSubmitter());
        params.put("HardRun", request.isHardRun());
        
        Map<String, Object> response = callSoapOperation("ValidateClientWorLdCheck", params);
        
        return ValidateClientResponse.builder()
            .success(parseBoolean(response.get("Success")))
            .message(parseString(response.get("Message")))
            .build();
    }
    
    /**
     * Opération CreateKYCMemo
     */
    public CreateKYCMemoResponse createKYCMemo(CreateKYCMemoRequest request) {
        Map<String, Object> params = new HashMap<>();
        params.put("bpInstance", request.getBpInstance());
        params.put("DossierNumber", request.getDossierNumber());
        params.put("ClientID", request.getClientId());
        params.put("UserPool", request.getUserPool());
        params.put("Agent", request.getAgent());
        params.put("Submitter", request.getSubmitter());
        params.put("AnalysisStatus", request.getAnalysisStatus());
        params.put("AnalysisComment", request.getAnalysisComment());
        params.put("AnalysisDate", formatDate(request.getAnalysisDate()));
        params.put("WorldCheckDocumentUrl", request.getWorldCheckDocumentUrl());
        
        Map<String, Object> response = callSoapOperation("CreateKYCMemo", params);
        
        return CreateKYCMemoResponse.builder()
            .success(parseBoolean(response.get("Success")))
            .message(parseString(response.get("Message")))
            .build();
    }
    
    /**
     * Opération Ping - Health check
     */
    public PingResponse ping(String bpInstance, String check) {
        Map<String, Object> params = new HashMap<>();
        params.put("bpInstance", bpInstance);
        params.put("Check", check);
        
        Map<String, Object> response = callSoapOperation("Ping", params);
        
        return PingResponse.builder()
            .check(parseString(response.get("Check")))
            .success(parseBoolean(response.get("Success")))
            .build();
    }
    
    /**
     * Appel SOAP générique RPC/encoded
     */
    private Map<String, Object> callSoapOperation(String operationName, Map<String, Object> parameters) {
        SOAPConnection connection = null;
        
        try {
            // 1. Créer la connexion
            connection = connectionFactory.createConnection();
            
            // 2. Construire le message SOAP
            SOAPMessage request = buildRpcEncodedMessage(operationName, parameters);
            
            // 3. Logger la requête (dev uniquement)
            if (log.isDebugEnabled()) {
                log.debug("SOAP REQUEST:\n{}", soapMessageToString(request));
            }
            
            // 4. Appel SOAP
            SOAPMessage response = connection.call(request, config.getEndpoint());
            
            // 5. Logger la réponse
            if (log.isDebugEnabled()) {
                log.debug("SOAP RESPONSE:\n{}", soapMessageToString(response));
            }
            
            // 6. Parser la réponse
            return parseRpcEncodedResponse(response, operationName);
            
        } catch (SOAPException e) {
            log.error("SOAP call failed for operation: {}", operationName, e);
            throw new BluePrismSoapException("SOAP operation failed: " + operationName, e);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Construction du message SOAP RPC/encoded
     */
    private SOAPMessage buildRpcEncodedMessage(String operationName, Map<String, Object> parameters) 
            throws SOAPException {
        
        SOAPMessage message = messageFactory.createMessage();
        SOAPPart soapPart = message.getSOAPPart();
        SOAPEnvelope envelope = soapPart.getEnvelope();
        
        // Namespaces requis pour RPC/encoded
        envelope.addNamespaceDeclaration("xsi", XSI_NS);
        envelope.addNamespaceDeclaration("xsd", XSD_NS);
        envelope.addNamespaceDeclaration("soapenc", ENCODING_STYLE);
        
        // Namespace du service BluePrism
        String prefix = "tns";
        envelope.addNamespaceDeclaration(prefix, NAMESPACE);
        
        SOAPBody body = envelope.getBody();
        
        // Créer l'élément de l'opération
        SOAPElement operation = body.addChildElement(operationName, prefix);
        
        // CRITIQUE : Encoding style pour RPC/encoded
        operation.setEncodingStyle(ENCODING_STYLE);
        
        // Ajouter les paramètres avec typage explicite
        for (Map.Entry<String, Object> entry : parameters.entrySet()) {
            addRpcEncodedParameter(envelope, operation, entry.getKey(), entry.getValue());
        }
        
        message.saveChanges();
        return message;
    }
    
    /**
     * Ajout d'un paramètre avec typage RPC/encoded
     */
    private void addRpcEncodedParameter(
            SOAPEnvelope envelope,
            SOAPElement parent,
            String name,
            Object value) throws SOAPException {
        
        SOAPElement param = parent.addChildElement(name);
        
        if (value == null) {
            param.addAttribute(
                envelope.createName("nil", "xsi", XSI_NS),
                "true"
            );
            return;
        }
        
        // Déterminer le type XSD
        String xsdType = getXsdType(value);
        
        // Ajouter l'attribut xsi:type (OBLIGATOIRE pour RPC/encoded)
        param.addAttribute(
            envelope.createName("type", "xsi", XSI_NS),
            "xsd:" + xsdType
        );
        
        // Ajouter la valeur
        param.addTextNode(String.valueOf(value));
    }
    
    /**
     * Détermination du type XSD selon le type Java
     */
    private String getXsdType(Object value) {
        if (value instanceof String) return "string";
        if (value instanceof Boolean) return "boolean";
        if (value instanceof Integer) return "int";
        if (value instanceof Long) return "long";
        if (value instanceof BigDecimal) return "decimal";
        if (value instanceof LocalDate) return "date";
        return "string"; // fallback
    }
    
    /**
     * Parser la réponse SOAP RPC/encoded
     */
    private Map<String, Object> parseRpcEncodedResponse(SOAPMessage response, String operationName) 
            throws SOAPException {
        
        SOAPBody body = response.getSOAPBody();
        
        // Vérifier les erreurs SOAP
        if (body.hasFault()) {
            SOAPFault fault = body.getFault();
            throw new BluePrismSoapFaultException(
                fault.getFaultCode(),
                fault.getFaultString()
            );
        }
        
        // Trouver l'élément de réponse (format : <OperationNameResponse>)
        String responseName = operationName + "Response";
        NodeList responseNodes = body.getElementsByTagName(responseName);
        
        if (responseNodes.getLength() == 0) {
            throw new BluePrismSoapException("Response element not found: " + responseName);
        }
        
        Node responseNode = responseNodes.item(0);
        
        // Extraire tous les paramètres de retour
        Map<String, Object> result = new HashMap<>();
        NodeList children = responseNode.getChildNodes();
        
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                String paramName = child.getLocalName();
                String paramValue = child.getTextContent();
                result.put(paramName, paramValue);
            }
        }
        
        return result;
    }
    
    /**
     * Utilitaires de parsing
     */
    private String parseString(Object value) {
        return value != null ? String.valueOf(value) : null;
    }
    
    private Boolean parseBoolean(Object value) {
        if (value == null) return null;
        String str = String.valueOf(value).toLowerCase();
        return "true".equals(str) || "1".equals(str);
    }
    
    private String formatDate(LocalDate date) {
        if (date == null) return null;
        return date.format(DateTimeFormatter.ISO_DATE);
    }
    
    private String soapMessageToString(SOAPMessage message) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            message.writeTo(out);
            return out.toString(StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "[Failed to convert SOAP message to string]";
        }
    }
    
    private void closeConnection(SOAPConnection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SOAPException e) {
                log.warn("Failed to close SOAP connection", e);
            }
        }
    }
}
