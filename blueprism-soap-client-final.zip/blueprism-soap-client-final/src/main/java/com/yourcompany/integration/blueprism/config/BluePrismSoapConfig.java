package com.yourcompany.integration.blueprism.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPException;

/**
 * Configuration pour le client SOAP BluePrism
 */
@Data
@Validated
@ConfigurationProperties(prefix = "blueprism.soap")
public class BluePrismSoapConfig {
    
    /**
     * URL de l'endpoint SOAP
     * Exemple: http://WILL:APP556:8181/ws/WSREMEDIATIONSERVICESSoap
     */
    @NotBlank(message = "L'endpoint SOAP est obligatoire")
    private String endpoint;
    
    /**
     * Timeout de connexion en millisecondes
     */
    @Min(value = 1000, message = "Le timeout doit être au moins 1000ms")
    private int connectionTimeout = 30000;
    
    /**
     * Timeout de lecture socket en millisecondes
     */
    @Min(value = 1000, message = "Le socket timeout doit être au moins 1000ms")
    private int socketTimeout = 60000;
    
    /**
     * Activer les logs SOAP détaillés (uniquement en dev)
     */
    private boolean enableDetailedLogging = false;
    
    /**
     * Nom d'utilisateur pour authentication BASIC (si requis)
     */
    private String username;
    
    /**
     * Mot de passe pour authentication BASIC (si requis)
     */
    private String password;
    
    /**
     * Instance BluePrism par défaut
     */
    private String defaultBpInstance = "PROD";
}

/**
 * Configuration des beans SOAP
 */
@Configuration
public class SoapClientConfiguration {
    
    @Bean
    public SOAPConnectionFactory soapConnectionFactory() throws SOAPException {
        return SOAPConnectionFactory.newInstance();
    }
    
    @Bean
    public MessageFactory messageFactory() throws SOAPException {
        // SOAP 1.1 pour RPC/encoded
        return MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
    }
}
