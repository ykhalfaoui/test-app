package com.yourcompany.integration.blueprism.service;

import com.yourcompany.integration.blueprism.BluePrismSoapClient;
import com.yourcompany.integration.blueprism.dto.*;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Service métier pour les opérations BluePrism
 * Avec retry, circuit breaker et métriques
 * 
 * @author Yass
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class BluePrismRemediationService {
    
    private final BluePrismSoapClient soapClient;
    
    /**
     * Bloquer un client avec gestion de la résilience
     */
    @Retry(name = "blueprism")
    @CircuitBreaker(name = "blueprism", fallbackMethod = "blockClientFallback")
    @Timed(value = "blueprism.block.client", description = "Time to block client")
    public BlockClientResponse blockClient(
            String bpInstance,
            String clientId,
            BigDecimal letter,
            boolean blocking,
            LocalDate initiationDate,
            String dossierNumber,
            String agent,
            String submitter) {
        
        log.info("Blocking client {} with dossier {}", clientId, dossierNumber);
        
        BlockClientRequest request = BlockClientRequest.builder()
            .bpInstance(bpInstance)
            .clientId(clientId)
            .letter(letter)
            .blocking(blocking)
            .unblocking(false)
            .initiationDate(initiationDate)
            .dossierNumber(dossierNumber)
            .agent(agent)
            .submitter(submitter)
            .requestTime(LocalDate.now().toString())
            .build();
        
        BlockClientResponse response = soapClient.blockClient(request);
        
        if (Boolean.TRUE.equals(response.getSuccess())) {
            log.info("Client {} blocked successfully", clientId);
        } else {
            log.warn("Failed to block client {}: {}", clientId, response.getMessage());
        }
        
        return response;
    }
    
    /**
     * Fallback pour blockClient en cas d'erreur
     */
    private BlockClientResponse blockClientFallback(
            String bpInstance,
            String clientId,
            BigDecimal letter,
            boolean blocking,
            LocalDate initiationDate,
            String dossierNumber,
            String agent,
            String submitter,
            Exception ex) {
        
        log.error("Circuit breaker activated for blockClient - clientId: {}", clientId, ex);
        
        return BlockClientResponse.builder()
            .success(false)
            .message("Service temporairement indisponible - " + ex.getMessage())
            .build();
    }
    
    /**
     * Valider un client avec World Check
     */
    @Retry(name = "blueprism")
    @CircuitBreaker(name = "blueprism")
    @Timed(value = "blueprism.validate.client", description = "Time to validate client")
    public ValidateClientResponse validateClientWorldCheck(
            String bpInstance,
            String clientId,
            String dossierNumber,
            String agent,
            boolean hardRun) {
        
        log.info("Validating client {} with World Check (hardRun: {})", clientId, hardRun);
        
        ValidateClientRequest request = ValidateClientRequest.builder()
            .bpInstance(bpInstance)
            .clientId(clientId)
            .dossierNumber(dossierNumber)
            .agent(agent)
            .submitter(agent)
            .hardRun(hardRun)
            .build();
        
        return soapClient.validateClientWorldCheck(request);
    }
    
    /**
     * Créer un mémo KYC
     */
    @Retry(name = "blueprism")
    @CircuitBreaker(name = "blueprism")
    @Timed(value = "blueprism.create.kyc.memo", description = "Time to create KYC memo")
    public CreateKYCMemoResponse createKYCMemo(
            String bpInstance,
            String clientId,
            String dossierNumber,
            String analysisStatus,
            String analysisComment,
            String agent) {
        
        log.info("Creating KYC memo for client {} - dossier {}", clientId, dossierNumber);
        
        CreateKYCMemoRequest request = CreateKYCMemoRequest.builder()
            .bpInstance(bpInstance)
            .clientId(clientId)
            .dossierNumber(dossierNumber)
            .analysisStatus(analysisStatus)
            .analysisComment(analysisComment)
            .analysisDate(LocalDate.now())
            .agent(agent)
            .submitter(agent)
            .build();
        
        return soapClient.createKYCMemo(request);
    }
    
    /**
     * Health check du service BluePrism
     */
    @Timed(value = "blueprism.ping", description = "Time to ping service")
    public boolean isServiceAvailable(String bpInstance) {
        try {
            PingResponse response = soapClient.ping(bpInstance, "health-check");
            return Boolean.TRUE.equals(response.getSuccess());
        } catch (Exception e) {
            log.error("BluePrism service is not available", e);
            return false;
        }
    }
}
