package com.yourcompany.integration.blueprism.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request pour l'opération BlockClient
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BlockClientRequest {
    private String bpInstance;
    private String clientId;
    private BigDecimal letter;
    private boolean blocking;
    private boolean unblocking;
    private LocalDate initiationDate;
    private LocalDate firstLetterDate;
    private LocalDate blockingDateHard;
    private boolean accountBlockingExemption;
    private LocalDate blockingExemptionDeadline;
    private LocalDate secondLetterDate;
    private String dossierNumber;
    private String folderStatus;
    private String bLine;
    private String userPool;
    private LocalDate lettersDate;
    private String agent;
    private String mainRM;
    private String mainRMEmail;
    private String submitter;
    private String requestTime;
}

/**
 * Response pour l'opération BlockClient
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BlockClientResponse {
    private Boolean success;
    private String message;
}

/**
 * Request pour l'opération ValidateClientWorLdCheck
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidateClientRequest {
    private String bpInstance;
    private String dossierNumber;
    private String clientId;
    private String userPool;
    private String agent;
    private String submitter;
    private boolean hardRun;
}

/**
 * Response pour ValidateClientWorLdCheck
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidateClientResponse {
    private Boolean success;
    private String message;
}

/**
 * Request pour CreateKYCMemo
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateKYCMemoRequest {
    private String bpInstance;
    private String dossierNumber;
    private String clientId;
    private String userPool;
    private String agent;
    private String submitter;
    private String analysisStatus;
    private String analysisComment;
    private LocalDate analysisDate;
    private String worldCheckDocumentUrl;
}

/**
 * Response pour CreateKYCMemo
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateKYCMemoResponse {
    private Boolean success;
    private String message;
}

/**
 * Request pour Ping
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PingRequest {
    private String bpInstance;
    private String check;
}

/**
 * Response pour Ping
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PingResponse {
    private String check;
    private Boolean success;
}

/**
 * Request pour DocArchiving
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocArchivingRequest {
    private String bpInstance;
    private String dossierNumber;
    private String clientId;
    private String clientName;
    private String folderName;
    private String documentType;
    private boolean fullArchiving;
}

/**
 * Response pour DocArchiving
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocArchivingResponse {
    private Boolean success;
    private String message;
}
