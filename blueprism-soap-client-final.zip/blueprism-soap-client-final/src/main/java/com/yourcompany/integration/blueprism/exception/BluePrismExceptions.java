package com.yourcompany.integration.blueprism.exception;

import lombok.Getter;

/**
 * Exception de base pour les erreurs SOAP BluePrism
 */
@Getter
public class BluePrismSoapException extends RuntimeException {
    
    public BluePrismSoapException(String message) {
        super(message);
    }
    
    public BluePrismSoapException(String message, Throwable cause) {
        super(message, cause);
    }
}

/**
 * Exception pour les SOAP Faults
 */
@Getter
public class BluePrismSoapFaultException extends BluePrismSoapException {
    
    private final String faultCode;
    private final String faultString;
    
    public BluePrismSoapFaultException(String faultCode, String faultString) {
        super(String.format("SOAP Fault - Code: %s, Message: %s", faultCode, faultString));
        this.faultCode = faultCode;
        this.faultString = faultString;
    }
}

/**
 * Exception pour les erreurs d'authentification
 */
public class BluePrismSoapAuthenticationException extends BluePrismSoapException {
    
    public BluePrismSoapAuthenticationException(String message) {
        super(message);
    }
}

/**
 * Exception pour les timeouts
 */
public class BluePrismSoapTimeoutException extends BluePrismSoapException {
    
    public BluePrismSoapTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}
