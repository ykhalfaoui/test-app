package com.yourcompany.integration.blueprism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.yourcompany.integration.blueprism.config.BluePrismSoapConfig;

/**
 * Application Spring Boot principale pour le client SOAP BluePrism
 * 
 * @author Yass
 */
@SpringBootApplication
@EnableConfigurationProperties(BluePrismSoapConfig.class)
public class BluePrismSoapClientApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(BluePrismSoapClientApplication.class, args);
    }
}
