package com.yourcompany.integration.blueprism;

import com.yourcompany.integration.blueprism.dto.BlockClientResponse;
import com.yourcompany.integration.blueprism.dto.PingResponse;
import com.yourcompany.integration.blueprism.service.BluePrismRemediationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Exemple d'utilisation du client SOAP BluePrism
 * Activer avec: --spring.profiles.active=example
 * 
 * @author Yass
 */
@Component
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(name = "blueprism.example.enabled", havingValue = "true")
public class BluePrismExampleRunner implements CommandLineRunner {
    
    private final BluePrismRemediationService service;
    
    @Override
    public void run(String... args) {
        log.info("=== Démarrage des exemples BluePrism SOAP Client ===");
        
        try {
            // Exemple 1: Health Check
            log.info("\n--- Exemple 1: Ping (Health Check) ---");
            boolean isAvailable = service.isServiceAvailable("PROD");
            log.info("Service disponible: {}", isAvailable);
            
            // Exemple 2: Bloquer un client (décommenter pour utiliser)
            /*
            log.info("\n--- Exemple 2: BlockClient ---");
            BlockClientResponse blockResponse = service.blockClient(
                "PROD",                    // bpInstance
                "CLIENT123",               // clientId
                BigDecimal.ONE,           // letter
                true,                     // blocking
                LocalDate.now(),          // initiationDate
                "DOS-001",                // dossierNumber
                "agent-test",             // agent
                "submitter-test"          // submitter
            );
            
            log.info("BlockClient - Success: {}, Message: {}", 
                blockResponse.getSuccess(), 
                blockResponse.getMessage());
            */
            
            log.info("\n=== Exemples terminés ===");
            
        } catch (Exception e) {
            log.error("Erreur lors de l'exécution des exemples", e);
        }
    }
}
