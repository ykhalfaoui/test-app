package com.yourcompany.integration.blueprism;

import com.github.tomakehurst.wiremock.junit5.WireMockExtension;
import com.yourcompany.integration.blueprism.config.BluePrismSoapConfig;
import com.yourcompany.integration.blueprism.dto.BlockClientRequest;
import com.yourcompany.integration.blueprism.dto.BlockClientResponse;
import com.yourcompany.integration.blueprism.dto.PingResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPConstants;
import java.math.BigDecimal;
import java.time.LocalDate;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Tests unitaires pour BluePrismSoapClient avec WireMock
 * 
 * @author Yass
 */
@SpringBootTest
class BluePrismSoapClientTest {
    
    @RegisterExtension
    static WireMockExtension wireMock = WireMockExtension.newInstance()
        .options(wireMockConfig().dynamicPort())
        .build();
    
    private BluePrismSoapClient soapClient;
    
    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("blueprism.soap.endpoint", 
            () -> "http://localhost:" + wireMock.getPort() + "/ws/soap");
    }
    
    @BeforeEach
    void setUp() throws Exception {
        BluePrismSoapConfig config = new BluePrismSoapConfig();
        config.setEndpoint("http://localhost:" + wireMock.getPort() + "/ws/soap");
        config.setConnectionTimeout(5000);
        config.setSocketTimeout(10000);
        
        SOAPConnectionFactory connectionFactory = SOAPConnectionFactory.newInstance();
        MessageFactory messageFactory = MessageFactory.newInstance(
            SOAPConstants.SOAP_1_1_PROTOCOL);
        
        soapClient = new BluePrismSoapClient(
            config, 
            connectionFactory, 
            messageFactory
        );
    }
    
    @Test
    void shouldBlockClientSuccessfully() {
        // Given
        String soapResponse = """
            <?xml version="1.0" encoding="UTF-8"?>
            <soapenv:Envelope 
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema">
                <soapenv:Body>
                    <BlockClientResponse xmlns="urn:blueprism:webservice:wsremediationservices">
                        <Success xsi:type="xsd:boolean">true</Success>
                        <Message xsi:type="xsd:string">Client blocked successfully</Message>
                    </BlockClientResponse>
                </soapenv:Body>
            </soapenv:Envelope>
            """;
        
        wireMock.stubFor(post("/ws/soap")
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "text/xml; charset=utf-8")
                .withBody(soapResponse)));
        
        // When
        BlockClientRequest request = BlockClientRequest.builder()
            .bpInstance("TEST")
            .clientId("12345")
            .letter(BigDecimal.ONE)
            .blocking(true)
            .unblocking(false)
            .initiationDate(LocalDate.now())
            .dossierNumber("DOS-001")
            .agent("agent-test")
            .submitter("submitter-test")
            .requestTime(LocalDate.now().toString())
            .build();
        
        BlockClientResponse response = soapClient.blockClient(request);
        
        // Then
        assertThat(response).isNotNull();
        assertThat(response.getSuccess()).isTrue();
        assertThat(response.getMessage()).isEqualTo("Client blocked successfully");
        
        // Verify request was made
        wireMock.verify(postRequestedFor(urlEqualTo("/ws/soap"))
            .withHeader("Content-Type", containing("text/xml"))
            .withRequestBody(containing("BlockClient"))
            .withRequestBody(containing("12345"))
            .withRequestBody(containing("DOS-001")));
    }
    
    @Test
    void shouldHandleSoapFault() {
        // Given
        String soapFault = """
            <?xml version="1.0" encoding="UTF-8"?>
            <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
                <soapenv:Body>
                    <soapenv:Fault>
                        <faultcode>Server.Authentication</faultcode>
                        <faultstring>Authentication failed</faultstring>
                    </soapenv:Fault>
                </soapenv:Body>
            </soapenv:Envelope>
            """;
        
        wireMock.stubFor(post("/ws/soap")
            .willReturn(aResponse()
                .withStatus(500)
                .withHeader("Content-Type", "text/xml")
                .withBody(soapFault)));
        
        // When/Then
        BlockClientRequest request = BlockClientRequest.builder()
            .bpInstance("TEST")
            .clientId("12345")
            .build();
        
        assertThatThrownBy(() -> soapClient.blockClient(request))
            .hasMessageContaining("SOAP Fault")
            .hasMessageContaining("Authentication failed");
    }
    
    @Test
    void shouldPingSuccessfully() {
        // Given
        String soapResponse = """
            <?xml version="1.0" encoding="UTF-8"?>
            <soapenv:Envelope 
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema">
                <soapenv:Body>
                    <PingResponse xmlns="urn:blueprism:webservice:wsremediationservices">
                        <Check xsi:type="xsd:string">pong</Check>
                        <Success xsi:type="xsd:boolean">true</Success>
                    </PingResponse>
                </soapenv:Body>
            </soapenv:Envelope>
            """;
        
        wireMock.stubFor(post("/ws/soap")
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "text/xml")
                .withBody(soapResponse)));
        
        // When
        PingResponse response = soapClient.ping("TEST", "ping");
        
        // Then
        assertThat(response).isNotNull();
        assertThat(response.getSuccess()).isTrue();
        assertThat(response.getCheck()).isEqualTo("pong");
    }
    
    @Test
    void shouldHandleConnectionTimeout() {
        // Given - Simuler un timeout
        wireMock.stubFor(post("/ws/soap")
            .willReturn(aResponse()
                .withStatus(200)
                .withFixedDelay(15000))); // Délai > timeout
        
        // When/Then
        BlockClientRequest request = BlockClientRequest.builder()
            .bpInstance("TEST")
            .clientId("12345")
            .build();
        
        assertThatThrownBy(() -> soapClient.blockClient(request))
            .hasMessageContaining("SOAP operation failed");
    }
    
    @Test
    void shouldVerifyRpcEncodedFormat() {
        // Given
        wireMock.stubFor(post("/ws/soap")
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "text/xml")
                .withBody("""
                    <?xml version="1.0" encoding="UTF-8"?>
                    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
                        <soapenv:Body>
                            <BlockClientResponse xmlns="urn:blueprism:webservice:wsremediationservices">
                                <Success>true</Success>
                                <Message>OK</Message>
                            </BlockClientResponse>
                        </soapenv:Body>
                    </soapenv:Envelope>
                    """)));
        
        // When
        BlockClientRequest request = BlockClientRequest.builder()
            .bpInstance("TEST")
            .clientId("12345")
            .letter(BigDecimal.valueOf(2.5))
            .blocking(true)
            .build();
        
        soapClient.blockClient(request);
        
        // Then - Vérifier le format RPC/encoded
        wireMock.verify(postRequestedFor(urlEqualTo("/ws/soap"))
            // Vérifier namespace
            .withRequestBody(containing("urn:blueprism:webservice:wsremediationservices"))
            // Vérifier encoding style
            .withRequestBody(containing("http://schemas.xmlsoap.org/soap/encoding"))
            // Vérifier les attributs xsi:type
            .withRequestBody(containing("xsi:type=\"xsd:string\""))
            .withRequestBody(containing("xsi:type=\"xsd:boolean\""))
            .withRequestBody(containing("xsi:type=\"xsd:decimal\"")));
    }
}
