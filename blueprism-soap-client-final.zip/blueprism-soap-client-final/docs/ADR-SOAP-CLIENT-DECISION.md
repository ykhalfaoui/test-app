# Architecture Decision Record (ADR)
# Choix de la solution pour client SOAP RPC/encoded

**Date**: 30 Janvier 2026  
**Statut**: ✅ RECOMMANDÉ - Apache CXF  
**Auteur**: Yass - Solution Architect

---

## 📋 Contexte

Nous devons créer un client SOAP pour consommer le service **BluePrism WS Remediation Services** qui utilise :
- **Style**: RPC (deprecated)
- **Encoding**: encoded (deprecated) 
- **Protocol**: SOAP 1.1
- **Namespace**: `urn:blueprism:webservice:wsremediationservices`

### Contraintes
- ❌ Pas de génération automatique avec plugin Maven possible
- ✅ Java 17 + Spring Boot 3.4
- ✅ Maintenance long terme requise
- ✅ Peu de modifications attendues
- ✅ Compréhension facile pour l'équipe

---

## 🎯 Options Évaluées

### Option 1: SAAJ (SOAP with Attachments API for Java)
### Option 2: Apache CXF
### Option 3: Spring Web Services (Spring-WS)

---

## 📊 Comparaison Détaillée

| Critère | SAAJ | Apache CXF | Spring-WS |
|---------|------|------------|-----------|
| **Support RPC/encoded** | ✅ Natif | ✅ Via JAX-WS | ❌ Document/literal uniquement |
| **Niveau d'abstraction** | ⚠️ Très bas | ✅ Haut | ✅ Haut |
| **Complexité du code** | ❌ Élevée | ✅ Faible | N/A |
| **Maintenabilité** | ⚠️ Moyenne | ✅ Excellente | N/A |
| **Courbe d'apprentissage** | ❌ Difficile | ✅ Standard JAX-WS | N/A |
| **Génération de stubs** | ❌ Non | ✅ Oui (wsimport) | ✅ Oui (wsdl2java) |
| **Intégration Spring Boot** | ⚠️ Manuelle | ✅ Native | ✅ Native |
| **Documentation/Communauté** | ⚠️ Limitée | ✅ Excellente | ✅ Excellente |
| **Support RPC/encoded moderne** | ✅ Oui | ⚠️ **ATTENTION** | ❌ Non |
| **Performances** | ✅ Excellentes | ✅ Excellentes | ✅ Excellentes |

---

## ⚠️ **DÉCOUVERTE CRITIQUE**

Après recherche approfondie, **JAX-WS 2.0+ (et donc CXF) NE SUPPORTE PAS RPC/encoded** :

```
[ERROR] rpc/encoded wsdls are not supported in JAXWS 2.0
```

Source: Red Hat, Apache CXF documentation

### Implications
- ❌ **Apache CXF ne peut PAS générer de stubs pour RPC/encoded**
- ❌ **wsimport échoue sur RPC/encoded WSDL**
- ✅ **SAAJ reste la SEULE option viable pour RPC/encoded**

---

## 🏆 **DÉCISION FINALE : SAAJ avec Architecture Améliorée**

### Pourquoi SAAJ ?

1. **Seule solution qui fonctionne vraiment avec RPC/encoded**
2. **Pas de dépendance à des frameworks qui ne supportent pas RPC/encoded**
3. **Contrôle total sur le XML généré**
4. **Pas de surprises à l'exécution**

### Mais avec des améliorations architecturales

Au lieu d'un SAAJ "brut" difficile à maintenir, on crée une **architecture en couches** :

```
┌─────────────────────────────────────────┐
│   Service Métier (Business Logic)      │  ← Niveau développeur
│   + Resilience4j                        │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│   Client Façade (High-Level API)       │  ← API simple
│   + DTOs typés                          │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│   SOAP Operation Executor               │  ← Orchestration
│   + Template Method Pattern             │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│   Message Builder + Parser              │  ← Construction XML
│   (SAAJ)                                │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│   BluePrism SOAP Service                │
└─────────────────────────────────────────┘
```

---

## ✅ **Solution Recommandée : SAAJ + Architecture Propre**

### Architecture en 4 couches

#### 1. **Layer Service (Business)**
```java
@Service
public class BluePrismRemediationService {
    // API métier simple, retry, circuit breaker
    @Retry(name = "blueprism")
    public BlockClientResponse blockClient(...) {
        return facade.blockClient(...);
    }
}
```

#### 2. **Layer Façade (API Simplifiée)**
```java
@Component
public class BluePrismSoapFacade {
    // Convertit DTOs métier → SOAP Operation
    public BlockClientResponse blockClient(BlockClientRequest dto) {
        SoapOperation op = operationFactory.createBlockClient(dto);
        return executor.execute(op, BlockClientResponse.class);
    }
}
```

#### 3. **Layer Executor (Template Method)**
```java
@Component
public class SoapOperationExecutor {
    // Template method pour tous les appels SOAP
    public <T> T execute(SoapOperation operation, Class<T> responseType) {
        SOAPMessage request = messageBuilder.build(operation);
        SOAPMessage response = connection.call(request);
        return responseParser.parse(response, responseType);
    }
}
```

#### 4. **Layer SAAJ (Construction XML)**
```java
@Component
public class RpcEncodedMessageBuilder {
    // Gestion bas niveau du XML RPC/encoded
    public SOAPMessage build(SoapOperation operation) {
        // Construction XML avec namespaces, xsi:type, etc.
    }
}
```

---

## 📈 **Avantages de cette Architecture**

### Maintenabilité ⭐⭐⭐⭐⭐
- ✅ Séparation claire des responsabilités
- ✅ Chaque couche testable indépendamment
- ✅ Code SAAJ isolé dans une seule couche

### Compréhension ⭐⭐⭐⭐⭐
- ✅ API métier claire et typée
- ✅ Complexité XML cachée
- ✅ Nouveaux développeurs utilisent la façade uniquement

### Extensibilité ⭐⭐⭐⭐
- ✅ Ajouter une opération = nouveau DTO + mapping
- ✅ Pattern Template Method pour réutilisation
- ✅ Facile d'ajouter logging, métriques, etc.

### Performance ⭐⭐⭐⭐⭐
- ✅ Aucun overhead de framework inutile
- ✅ SAAJ est la solution la plus rapide
- ✅ Connection pooling possible

---

## 🚫 **Pourquoi PAS Apache CXF ?**

### Raisons Techniques

1. **RPC/encoded non supporté**
   ```
   ERROR: rpc/encoded wsdls are not supported in JAXWS 2.0
   ```

2. **Workarounds complexes et fragiles**
   - Nécessite manipulation WSDL
   - Code généré cassé
   - Maintenance cauchemardesque

3. **Sur-engineering pour ce cas**
   - Framework lourd pour un seul service
   - Fonctionnalités avancées inutilisées
   - Dépendances nombreuses

### Raisons Pratiques

- ❌ Génération automatique impossible
- ❌ Configuration complexe pour RPC/encoded
- ❌ Risque de bugs liés au framework
- ❌ Overhead inutile

---

## 🎯 **Recommandation Finale**

### ✅ Utiliser SAAJ avec l'architecture en couches proposée

**Pourquoi ?**

1. **C'est la seule solution qui FONCTIONNE vraiment** avec RPC/encoded
2. **Architecture propre** = maintenabilité maximale
3. **Pas de magie noire** = compréhension facile
4. **Performances optimales** = pas d'overhead framework
5. **Évolutif** = facile d'ajouter des opérations

### 📝 Plan d'Implémentation

**Phase 1: Core (1-2 jours)**
- ✅ SoapOperationExecutor (template method)
- ✅ RpcEncodedMessageBuilder
- ✅ SoapResponseParser
- ✅ Configuration Spring Boot

**Phase 2: Opérations (1 jour)**
- ✅ DTOs pour chaque opération
- ✅ Factory pour créer SoapOperation
- ✅ BluePrismSoapFacade

**Phase 3: Service & Resilience (1 jour)**
- ✅ BluePrismRemediationService
- ✅ Resilience4j (retry, circuit breaker)
- ✅ Métriques Micrometer

**Phase 4: Tests (1 jour)**
- ✅ Tests unitaires avec WireMock
- ✅ Tests d'intégration
- ✅ Documentation

**Total**: 4-5 jours de développement

---

## 📚 **Références**

- [JAX-WS RPC/encoded limitation](https://access.redhat.com/solutions/44846)
- [SAAJ Tutorial](https://docs.oracle.com/javaee/7/tutorial/saaj.htm)
- [Apache CXF - Stack Comparison](http://wiki.apache.org/ws/StackComparison)
- [Spring Boot SOAP Best Practices](https://spring.io/guides/gs/consuming-web-service/)

---

## 🔄 **Alternative Future (Si migration possible)**

Si un jour BluePrism migre vers **document/literal** :

1. Garder la même architecture en couches
2. Remplacer uniquement le MessageBuilder/Parser
3. Potentiellement utiliser CXF ou Spring-WS
4. **Aucun impact sur le code métier**

Cette architecture est **future-proof** ! 🚀

---

## ✍️ **Signature**

**Décision prise par**: Yass - Solution Architect & Java Tech Lead  
**Date**: 30 Janvier 2026  
**Revue par**: [À compléter]  
**Statut**: APPROUVÉ pour implémentation
