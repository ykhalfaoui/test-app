# BluePrism SOAP Client - RPC/Encoded ✅ Production Ready

Client SOAP professionnel pour **BluePrism WS Remediation Services** (style RPC/encoded legacy).

## 🎯 Quick Links

- 📖 **[Guide Rapide](QUICKSTART.md)** - Démarrage en 5 minutes
- 🏗️ **[Architecture Decision Record](docs/ADR-SOAP-CLIENT-DECISION.md)** - Pourquoi SAAJ ?
- 🧪 **Tests** - Voir `src/test/java/`

## ⚡ Démarrage Ultra-Rapide

```bash
# 1. Extraire
unzip blueprism-soap-client.zip
cd blueprism-soap-client-final

# 2. Configurer (éditer application.yml)
blueprism.soap.endpoint: http://your-server:8181/ws/...

# 3. Lancer
mvn spring-boot:run
```

## 📋 Opérations Disponibles

✅ **BlockClient** - Bloquer/débloquer un client  
✅ **ValidateClientWorLdCheck** - Validation World Check  
✅ **CreateKYCMemo** - Créer un mémo KYC  
✅ **Ping** - Health check

## 💡 Utilisation

```java
@Autowired
private BluePrismRemediationService service;

// Health check
boolean available = service.isServiceAvailable("PROD");

// Bloquer un client
BlockClientResponse response = service.blockClient(
    "PROD", "CLIENT123", BigDecimal.ONE, true,
    LocalDate.now(), "DOS-001", "agent", "submitter"
);
```

## 🏗️ Architecture

```
Service Métier (Resilience4j)
    ↓
Client SOAP (SAAJ)
    ↓
BluePrism Service
```

## ❓ Pourquoi SAAJ ?

**Réponse courte**: C'est la **SEULE** solution qui fonctionne avec RPC/encoded.

**Réponse détaillée**: Lire [ADR](docs/ADR-SOAP-CLIENT-DECISION.md)

### Fait Technique

```
[ERROR] rpc/encoded wsdls are not supported in JAXWS 2.0
```

Apache CXF, Spring-WS, JAX-WS RI → **NE SUPPORTENT PAS** RPC/encoded.

## ✅ Ce qui rend ce projet maintenable

✅ Architecture en couches (pas de SAAJ spaghetti)  
✅ Séparation des responsabilités  
✅ Tests complets avec WireMock  
✅ Resilience4j (retry, circuit breaker)  
✅ Métriques Prometheus  
✅ Documentation complète

## 📊 Features

- 🔄 **Retry automatique** (3 tentatives avec backoff exponentiel)
- 🔌 **Circuit Breaker** (protection contre cascade failures)
- 📈 **Métriques** (Prometheus ready)
- 🧪 **Tests** (WireMock + JUnit 5)
- 📝 **Logs** (SOAP request/response activables)

## 🔧 Configuration

```yaml
blueprism:
  soap:
    endpoint: http://server:8181/ws/...
    connection-timeout: 30000
    socket-timeout: 60000

resilience4j:
  retry:
    instances:
      blueprism:
        max-attempts: 3
```

## 📚 Documentation Complète

| Document | Description |
|----------|-------------|
| **[QUICKSTART.md](QUICKSTART.md)** | Guide de démarrage (5 min) |
| **[docs/ADR-SOAP-CLIENT-DECISION.md](docs/ADR-SOAP-CLIENT-DECISION.md)** | Décision d'architecture |
| **Tests** | Exemples d'utilisation |

## 🧪 Tests

```bash
mvn test                    # Tous les tests
mvn jacoco:report          # Couverture de code
```

## 🚧 Limitations

⚠️ **RPC/encoded est deprecated** depuis SOAP 1.1  
⚠️ **Pas de génération automatique** (mapping manuel requis)  
⚠️ **SOAP 1.1 uniquement** (pas de SOAP 1.2)

## 📝 License

Proprietary - Usage interne uniquement

## 👤 Auteur

**Yass** - Solution Architect & Java Tech Lead

---

⚠️ **IMPORTANT**: Lire le [ADR](docs/ADR-SOAP-CLIENT-DECISION.md) avant toute modification architecturale
