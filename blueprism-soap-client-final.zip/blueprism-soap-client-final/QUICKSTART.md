# 🚀 Guide de Démarrage Rapide - BluePrism SOAP Client

## Installation

### 1. Extraire le projet

```bash
unzip blueprism-soap-client.zip
cd blueprism-soap-client
```

### 2. Configuration

Éditer `src/main/resources/application.yml`:

```yaml
blueprism:
  soap:
    endpoint: http://YOUR-SERVER:8181/ws/WSREMEDIATIONSERVICESSoap
    connection-timeout: 30000
    socket-timeout: 60000
```

### 3. Build

```bash
mvn clean install
```

### 4. Lancer l'application

```bash
mvn spring-boot:run
```

Ou avec le JAR:

```bash
java -jar target/blueprism-soap-client-1.0.0-SNAPSHOT.jar
```

## Test rapide avec l'exemple

Activer l'exemple dans `application.yml`:

```yaml
blueprism:
  example:
    enabled: true
```

Puis lancer:

```bash
mvn spring-boot:run
```

## Utilisation dans votre code

### 1. Injecter le service

```java
@Autowired
private BluePrismRemediationService service;
```

### 2. Appeler les opérations

```java
// Health check
boolean available = service.isServiceAvailable("PROD");

// Bloquer un client
BlockClientResponse response = service.blockClient(
    "PROD",                    // bpInstance
    "CLIENT123",               // clientId
    BigDecimal.ONE,           // letter
    true,                     // blocking
    LocalDate.now(),          // initiationDate
    "DOS-001",                // dossierNumber
    "agent-name",             // agent
    "submitter-name"          // submitter
);

if (response.getSuccess()) {
    log.info("Client bloqué avec succès");
}
```

## Tests

```bash
# Lancer tous les tests
mvn test

# Avec rapport de couverture
mvn clean test jacoco:report
```

Rapport disponible: `target/site/jacoco/index.html`

## Monitoring

Une fois l'application lancée:

- Health: http://localhost:8080/actuator/health
- Metrics: http://localhost:8080/actuator/metrics
- Prometheus: http://localhost:8080/actuator/prometheus

## Profiles Spring Boot

### Development

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

Logs détaillés activés automatiquement.

### Production

```bash
java -jar target/blueprism-soap-client-1.0.0-SNAPSHOT.jar --spring.profiles.active=prod
```

Retry augmenté à 5 tentatives.

## Troubleshooting

### Problème de connexion

```yaml
logging:
  level:
    com.yourcompany.integration.blueprism: DEBUG

blueprism:
  soap:
    enable-detailed-logging: true
```

### Timeout

Augmenter les timeouts:

```yaml
blueprism:
  soap:
    connection-timeout: 60000
    socket-timeout: 120000
```

## Structure du projet

```
blueprism-soap-client/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/yourcompany/integration/blueprism/
│   │   │       ├── BluePrismSoapClient.java              # Client SOAP
│   │   │       ├── BluePrismSoapClientApplication.java   # Main
│   │   │       ├── BluePrismExampleRunner.java           # Exemples
│   │   │       ├── config/
│   │   │       │   └── BluePrismSoapConfig.java          # Configuration
│   │   │       ├── dto/
│   │   │       │   └── BluePrismDTOs.java                # Request/Response
│   │   │       ├── exception/
│   │   │       │   └── BluePrismExceptions.java          # Exceptions
│   │   │       └── service/
│   │   │           └── BluePrismRemediationService.java  # Service métier
│   │   └── resources/
│   │       └── application.yml                            # Configuration
│   └── test/
│       └── java/
│           └── com/yourcompany/integration/blueprism/
│               └── BluePrismSoapClientTest.java          # Tests
├── pom.xml                                                # Maven
├── README.md                                              # Documentation
└── QUICKSTART.md                                          # Ce fichier
```

## Support

Pour toute question, consulter:
- README.md (documentation complète)
- Les tests dans `src/test/java/`
- Les exemples dans `BluePrismExampleRunner.java`
