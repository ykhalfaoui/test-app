@org.springframework.modulith.ApplicationModule
package com.example.kyc.kyc360;
