package com.example.kyc.relations;
import org.springframework.data.jpa.repository.JpaRepository;
public interface RelationTypeBlockScopeRepository extends JpaRepository<RelationTypeBlockScope, String> { }
