package com.example.kyc.blocks.api;
public record BlockReviewRequested(String partyId, String kind) {}
