package com.example.kyc.blocks.api;
public record BlockVersionFinalized(String blockVersionId, String partyId, String kind, String finalStatus) {}
