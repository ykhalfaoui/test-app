package com.example.kyc.hits.api;
public record HitQualified(String hitId, String partyId, String hitType) {}
