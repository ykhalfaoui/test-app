package com.example.kyc.hits;
import org.springframework.data.jpa.repository.JpaRepository;
public interface HitRepository extends JpaRepository<Hit, String> {}
