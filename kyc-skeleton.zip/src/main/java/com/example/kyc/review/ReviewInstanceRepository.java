package com.example.kyc.review;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ReviewInstanceRepository extends JpaRepository<ReviewInstance, String> {}
