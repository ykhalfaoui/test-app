package com.example.kyc.review.api;
public record ReviewStarted(String reviewId, String hitId, String partyId) {}
