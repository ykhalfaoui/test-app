package com.example.kyc.party;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PartyRepository extends JpaRepository<Party, String> {}
