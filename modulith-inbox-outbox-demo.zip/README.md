# Modulith Inbox/Outbox Demo

Flow: **Kafka Hit event** → **Inbox** → **HitHandler** → **Hit domain event (@DomainEvents)** → **Outbox** → **Salesforce integration**.
Also: **Hit domain event** → **ReviewHandler** → **Outbox** → **Salesforce integration**.

Run:
```
mvn spring-boot:run
```
