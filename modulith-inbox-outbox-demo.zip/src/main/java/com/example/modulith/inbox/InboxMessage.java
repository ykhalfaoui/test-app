package com.example.modulith.inbox;

import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "INBOX")
public class InboxMessage {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "MESSAGE_ID", nullable = false, length = 200)
  private String messageId;
  @Column(name = "SOURCE_SYSTEM", nullable = false, length = 100)
  private String sourceSystem;
  @Column(name = "TOPIC", nullable = false, length = 200)
  private String topic;
  @Column(name = "STATUS", nullable = false, length = 20)
  private String status = "RECEIVED";
  @Lob @Column(name = "PAYLOAD")
  private String payload;
  @Lob @Column(name = "RAW_PAYLOAD_BASE64")
  private String rawPayloadBase64;
  @Column(name = "ATTEMPTS", nullable = false)
  private int attempts = 0;
  @Column(name = "NEXT_ATTEMPT_AT")
  private OffsetDateTime nextAttemptAt;
  @Column(name = "RECEIVED_AT", nullable = false)
  private OffsetDateTime receivedAt = OffsetDateTime.now();
  public Long getId() { return id; }
  public String getMessageId() { return messageId; }
  public void setMessageId(String messageId) { this.messageId = messageId; }
  public String getSourceSystem() { return sourceSystem; }
  public void setSourceSystem(String sourceSystem) { this.sourceSystem = sourceSystem; }
  public String getTopic() { return topic; }
  public void setTopic(String topic) { this.topic = topic; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
  public String getPayload() { return payload; }
  public void setPayload(String payload) { this.payload = payload; }
  public String getRawPayloadBase64() { return rawPayloadBase64; }
  public void setRawPayloadBase64(String rawPayloadBase64) { this.rawPayloadBase64 = rawPayloadBase64; }
  public int getAttempts() { return attempts; }
  public void setAttempts(int attempts) { this.attempts = attempts; }
  public OffsetDateTime getNextAttemptAt() { return nextAttemptAt; }
  public void setNextAttemptAt(OffsetDateTime nextAttemptAt) { this.nextAttemptAt = nextAttemptAt; }
  public OffsetDateTime getReceivedAt() { return receivedAt; }
  public void setReceivedAt(OffsetDateTime receivedAt) { this.receivedAt = receivedAt; }
}
