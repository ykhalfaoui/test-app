package com.example.modulith.kafka;

import com.example.modulith.inbox.InboxMessage;
import com.example.modulith.inbox.InboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class InboundKafkaConsumer {
  private final InboxRepository inboxRepository;
  private final String sourceSystem = "ihub";

  public InboundKafkaConsumer(InboxRepository inboxRepository) {
    this.inboxRepository = inboxRepository;
  }

  @KafkaListener(topics = "#{@hitTopic}", containerFactory = "kafkaListenerContainerFactory")
  public void onMessage(String payload) {
    InboxMessage m = new InboxMessage();
    m.setMessageId(java.util.UUID.randomUUID().toString());
    m.setSourceSystem(sourceSystem);
    m.setTopic("hits");
    m.setPayload(payload);
    m.setStatus("RECEIVED");
    inboxRepository.save(m);
  }

  @Component("hitTopic")
  static class HitTopicProvider {
    @Value("${app.topics.hit-events:hits}")
    private String topic;
    @Override public String toString() { return topic; }
  }
}
