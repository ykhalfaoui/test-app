package com.example.modulith.integration.salesforce;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SalesforceClient {
  private static final Logger log = LoggerFactory.getLogger(SalesforceClient.class);
  public void upsert(String objectName, String externalIdField, String externalIdValue, String jsonBody) {
    // Stub for demo. Replace with WebClient and real OAuth token handling
    log.info("SFDC UPSERT {}({}={}) body={}", objectName, externalIdField, externalIdValue, jsonBody);
  }
}
