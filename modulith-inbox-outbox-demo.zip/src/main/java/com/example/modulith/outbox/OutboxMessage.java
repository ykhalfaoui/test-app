package com.example.modulith.outbox;

import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "OUTBOX")
public class OutboxMessage {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "AGGREGATE_TYPE", nullable = false, length = 50)
  private String aggregateType;
  @Column(name = "AGGREGATE_ID", nullable = false, length = 200)
  private String aggregateId;
  @Column(name = "EVENT_TYPE", nullable = false, length = 200)
  private String eventType;
  @Lob @Column(name = "PAYLOAD", nullable = false)
  private String payload;
  @Column(name = "DESTINATION", nullable = false, length = 200)
  private String destination;
  @Column(name = "STATUS", nullable = false, length = 20)
  private String status = "PENDING";
  @Column(name = "ATTEMPTS", nullable = false)
  private int attempts = 0;
  @Column(name = "NEXT_ATTEMPT_AT")
  private OffsetDateTime nextAttemptAt;
  @Column(name = "CREATED_AT", nullable = false)
  private OffsetDateTime createdAt = OffsetDateTime.now();
  public OutboxMessage() {}
  public OutboxMessage(String aggregateType, String aggregateId, String eventType, String payload, String destination) {
    this.aggregateType = aggregateType; this.aggregateId = aggregateId; this.eventType = eventType;
    this.payload = payload; this.destination = destination;
  }
  public Long getId() { return id; }
  public String getAggregateType() { return aggregateType; }
  public String getAggregateId() { return aggregateId; }
  public String getEventType() { return eventType; }
  public String getPayload() { return payload; }
  public String getDestination() { return destination; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
  public int getAttempts() { return attempts; }
  public void setAttempts(int attempts) { this.attempts = attempts; }
  public OffsetDateTime getNextAttemptAt() { return nextAttemptAt; }
  public void setNextAttemptAt(OffsetDateTime nextAttemptAt) { this.nextAttemptAt = nextAttemptAt; }
  public OffsetDateTime getCreatedAt() { return createdAt; }
}
