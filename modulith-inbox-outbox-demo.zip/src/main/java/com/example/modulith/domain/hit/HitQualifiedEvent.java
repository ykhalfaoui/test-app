package com.example.modulith.domain.hit;

public record HitQualifiedEvent(Long hitId, String externalId) {}
