package com.example.modulith.application.review;

import com.example.modulith.domain.hit.HitQualifiedEvent;
import com.example.modulith.outbox.OutboxMessage;
import com.example.modulith.outbox.OutboxRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.modulith.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Component
public class ReviewHandler {
  private final OutboxRepository outbox;
  private final ObjectMapper mapper = new ObjectMapper();
  public ReviewHandler(OutboxRepository outbox) { this.outbox = outbox; }

  @ApplicationModuleListener
  @Transactional
  public void on(HitQualifiedEvent event) {
    try {
      String payload = mapper.writeValueAsString(Map.of(
        "externalId", event.externalId(),
        "status", "REVIEW_PENDING"
      ));
      OutboxMessage msg = new OutboxMessage("Hit", String.valueOf(event.hitId()),
        "ReviewRequested", payload, "HTTP:SFDC:REST:Review__c");
      outbox.save(msg);
    } catch (Exception e) { throw new RuntimeException(e); }
  }
}
