package com.example.modulith.application.hit;

import com.example.modulith.domain.hit.Hit;
import com.example.modulith.domain.hit.HitRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class HitHandler {
  private final HitRepository hits;
  private final ObjectMapper mapper = new ObjectMapper();

  public HitHandler(HitRepository hits) { this.hits = hits; }

  @Transactional
  public void handle(String inboxPayloadJson) {
    try {
      JsonNode n = mapper.readTree(inboxPayloadJson);
      String extId = n.path("hitExternalId").asText();
      boolean positive = n.path("positive").asBoolean(false);
      Hit hit = new Hit(extId);
      if (positive) hit.qualifyPositive(); // emits @DomainEvents
      hits.save(hit); // events published on save
    } catch (Exception e) {
      throw new RuntimeException("Cannot parse hit payload", e);
    }
  }
}
