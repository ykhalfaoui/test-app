package com.example.modulith.application.hit;

import com.example.modulith.domain.hit.HitQualifiedEvent;
import com.example.modulith.outbox.OutboxMessage;
import com.example.modulith.outbox.OutboxRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.modulith.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Component
public class HitDomainToOutbox {
  private final OutboxRepository outbox;
  private final ObjectMapper mapper = new ObjectMapper();
  public HitDomainToOutbox(OutboxRepository outbox) { this.outbox = outbox; }

  @ApplicationModuleListener
  @Transactional
  public void on(HitQualifiedEvent event) {
    try {
      String payload = mapper.writeValueAsString(Map.of(
        "externalId", event.externalId(),
        "qualified", true
      ));
      OutboxMessage msg = new OutboxMessage("Hit", String.valueOf(event.hitId()),
        "HitUpsertRequested", payload, "HTTP:SFDC:REST:Hit__c");
      outbox.save(msg);
    } catch (Exception e) { throw new RuntimeException(e); }
  }
}
