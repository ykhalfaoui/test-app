package com.example.modulith.application.inbox;

import com.example.modulith.inbox.InboxMessage;
import com.example.modulith.inbox.InboxRepository;
import com.example.modulith.application.hit.HitHandler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class InboxWorker {
  private final InboxRepository inbox;
  private final HitHandler hitHandler;

  public InboxWorker(InboxRepository inbox, HitHandler hitHandler) {
    this.inbox = inbox; this.hitHandler = hitHandler;
  }

  @Scheduled(fixedDelay = 1000)
  @Transactional
  public void tick() {
    for (InboxMessage m : inbox.lockNextBatch()) {
      try {
        hitHandler.handle(m.getPayload());
        m.setStatus("PROCESSED");
      } catch (Exception ex) {
        m.setStatus("RETRY");
        m.setAttempts(m.getAttempts() + 1);
      }
    }
  }
}
