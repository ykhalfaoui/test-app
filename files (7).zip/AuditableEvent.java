package com.example.audit;

/**
 * Interface marqueur à implémenter par tous les domain events auditables.
 * Le champ auditMetadata DOIT s'appeler exactement "auditMetadata"
 * pour que la reflection dans AuditAwareEventPublisher fonctionne.
 *
 * Convention :
 *   public record MyEvent(String myField, AuditMetadata auditMetadata)
 *       implements AuditableEvent {}
 */
public interface AuditableEvent {
    AuditMetadata auditMetadata();
}
