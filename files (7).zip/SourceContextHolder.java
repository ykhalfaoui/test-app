package com.example.audit;

import org.springframework.stereotype.Component;

/**
 * Ton ThreadLocal existant pour la détection de la source.
 * À adapter selon ton implémentation actuelle.
 * Les entry points (Filter, KafkaInterceptor, ShedLock Aspect) posent la valeur ici.
 */
@Component
public class SourceContextHolder {

    public enum Source {
        HTTP, KAFKA, SHEDLOCK, REPLAY, INTERNAL
    }

    private static final ThreadLocal<String> SOURCE = ThreadLocal.withInitial(
        () -> Source.INTERNAL.name()
    );

    public static void set(Source source) {
        SOURCE.set(source.name());
    }

    public static void clear() {
        SOURCE.remove();
    }

    /** Lecture utilisée par AuditContextHolder */
    public String current() {
        return SOURCE.get();
    }
}
