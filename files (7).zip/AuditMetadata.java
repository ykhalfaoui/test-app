package com.example.audit;

import java.time.Instant;

/**
 * Contexte d'audit embarqué dans chaque domain event.
 * Survit aux crashs, replays et changements de thread.
 */
public record AuditMetadata(
    String correlationId,
    String traceId,
    String spanId,
    String userId,
    String sourceSystem,  // HTTP | KAFKA | SHEDLOCK | REPLAY | INTERNAL
    Instant initiatedAt
) {
    /** Utilisé uniquement en dernier recours (events système Spring, tests) */
    public static AuditMetadata unknown() {
        return new AuditMetadata(
            "unknown-" + java.util.UUID.randomUUID(),
            null, null,
            "system",
            "INTERNAL",
            Instant.now()
        );
    }
}
