package com.example.audit;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

/**
 * Construit l'AuditMetadata à partir de :
 *  1. Micrometer Tracer (traceId, spanId, correlationId via Baggage)
 *  2. Ton ThreadLocal existant pour la source (HTTP/KAFKA/SHEDLOCK)
 *  3. Fallback défensif si aucun span actif
 */
@Component
public class AuditContextHolder {

    private static final String BAGGAGE_CORRELATION_ID = "correlation-id";
    private static final String BAGGAGE_USER_ID        = "user-id";

    private final Tracer tracer;
    private final SourceContextHolder sourceContextHolder; // ton ThreadLocal existant

    public AuditContextHolder(Tracer tracer, SourceContextHolder sourceContextHolder) {
        this.tracer = tracer;
        this.sourceContextHolder = sourceContextHolder;
    }

    public AuditMetadata current() {
        Span currentSpan = tracer.currentSpan();

        String traceId = null;
        String spanId  = null;
        String correlationId;
        String userId;

        if (currentSpan != null) {
            traceId      = currentSpan.context().traceId();
            spanId       = currentSpan.context().spanId();
            correlationId = getBaggageOrGenerate(BAGGAGE_CORRELATION_ID);
            userId        = getBaggageOrFallback(BAGGAGE_USER_ID, "system");
        } else {
            // Pas de span actif — batch interne, test, event système Spring
            correlationId = "no-trace-" + UUID.randomUUID();
            userId        = "system";
        }

        return new AuditMetadata(
            correlationId,
            traceId,
            spanId,
            userId,
            sourceContextHolder.current(), // délègue à ton ThreadLocal
            Instant.now()
        );
    }

    private String getBaggageOrGenerate(String key) {
        return Optional.ofNullable(tracer.getBaggage(key))
            .map(b -> b.get())
            .filter(v -> v != null && !v.isBlank())
            .orElseGet(() -> {
                String generated = UUID.randomUUID().toString();
                try {
                    tracer.createBaggage(key, generated);
                } catch (Exception ignored) {
                    // pas de span actif — on retourne quand même la valeur
                }
                return generated;
            });
    }

    private String getBaggageOrFallback(String key, String fallback) {
        return Optional.ofNullable(tracer.getBaggage(key))
            .map(b -> b.get())
            .filter(v -> v != null && !v.isBlank())
            .orElse(fallback);
    }
}
