package com.example.audit.entrypoint;

import com.example.audit.SourceContextHolder;
import io.micrometer.tracing.Tracer;
import org.apache.kafka.clients.consumer.ConsumerInterceptor;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Header;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Intercepteur Kafka : pose le contexte d'audit avant traitement du message.
 *
 * Configuration dans application.yml :
 *   spring.kafka.consumer.properties.interceptor.classes: com.example.audit.entrypoint.AuditKafkaConsumerInterceptor
 *
 * Note : les intercepteurs Kafka ne sont pas des beans Spring.
 * On utilise SpringBeanAutowiringSupport ou on passe par un holder statique.
 * Ici on utilise un holder statique pour le Tracer (pattern recommandé pour Kafka interceptors).
 */
public class AuditKafkaConsumerInterceptor<K, V> implements ConsumerInterceptor<K, V> {

    // Kafka interceptors ne sont pas des Spring beans — on utilise un holder statique
    private static Tracer tracerRef;

    /** Appelé au démarrage par un @PostConstruct dans un bean Spring */
    public static void setTracer(Tracer tracer) {
        tracerRef = tracer;
    }

    @Override
    public ConsumerRecords<K, V> onConsume(ConsumerRecords<K, V> records) {
        records.forEach(record -> {
            String correlationId = extractHeader(record.headers().toArray(), "X-Correlation-Id")
                .orElse("KAFKA-" + UUID.randomUUID());
            String userId = extractHeader(record.headers().toArray(), "X-User-Id")
                .orElse("system");

            if (tracerRef != null && tracerRef.currentSpan() != null) {
                tracerRef.createBaggage("correlation-id", correlationId);
                tracerRef.createBaggage("user-id", userId);
            }
        });

        SourceContextHolder.set(SourceContextHolder.Source.KAFKA);
        return records;
    }

    @Override
    public void onCommit(Map<TopicPartition, OffsetAndMetadata> offsets) {
        SourceContextHolder.clear();
    }

    @Override
    public void close() {
        SourceContextHolder.clear();
    }

    @Override
    public void configure(Map<String, ?> configs) {}

    private Optional<String> extractHeader(org.apache.kafka.common.header.Header[] headers, String key) {
        for (org.apache.kafka.common.header.Header h : headers) {
            if (key.equals(h.key()) && h.value() != null) {
                return Optional.of(new String(h.value(), StandardCharsets.UTF_8));
            }
        }
        return Optional.empty();
    }
}
