# Configuration Java 17 / Spring Boot 3.x / 2CPU / 2Gi / K8s

## Ce qui change avec Java 17

### JVM Flags — diff complet

```
OBSOLÈTES / SUPPRIMÉS        JAVA 17 CORRECT
──────────────────────────   ──────────────────────────────────────────
-XX:PermSize                 → supprimé Java 8, utiliser MaxMetaspaceSize
-XX:+UseConcMarkSweepGC      → supprimé Java 14
-XX:+PrintGCDetails          → -Xlog:gc*:stdout:time,uptime,level,tags
-XX:+UseParNewGC             → supprimé Java 14
(rien)                       → --add-opens java.base/java.lang=ALL-UNNAMED
(rien)                       → --add-opens java.base/java.util=ALL-UNNAMED
(rien)                       → -XX:+HeapDumpOnOutOfMemoryError (bonne pratique)
```

### Flags complets pour 2CPU / 2Gi

```bash
# Option A : G1GC (défaut Java 17, recommandé workload mixte)
JAVA_TOOL_OPTIONS="\
  -Xms512m \
  -Xmx1536m \
  -XX:+UseG1GC \
  -XX:MaxGCPauseMillis=200 \
  -XX:G1HeapRegionSize=4m \
  -XX:InitiatingHeapOccupancyPercent=35 \
  -XX:MetaspaceSize=128m \
  -XX:MaxMetaspaceSize=256m \
  --add-opens java.base/java.lang=ALL-UNNAMED \
  --add-opens java.base/java.util=ALL-UNNAMED \
  --add-opens java.base/java.lang.reflect=ALL-UNNAMED \
  -Xlog:gc*:stdout:time,uptime,level,tags \
  -XX:+HeapDumpOnOutOfMemoryError \
  -XX:HeapDumpPath=/tmp/heapdump.hprof"

# Option B : ZGC (si GC pauses G1 causent des rebalances Kafka)
# ZGC = pauses < 1ms, mais overhead CPU ~10% plus élevé
JAVA_TOOL_OPTIONS="\
  -Xms512m \
  -Xmx1536m \
  -XX:+UseZGC \
  -XX:SoftMaxHeapSize=1280m \
  ..."
```

**Quand choisir ZGC ?**
Si tu vois dans les logs Kafka : `Consumer group rebalance` corrélé avec des GC pauses
G1 > 200ms → ZGC élimine ce problème (pauses < 1ms).

### Spring Boot 3.x spécifique

| Sujet | Spring Boot 2.x | Spring Boot 3.x |
|-------|-----------------|-----------------|
| Namespace Jakarta | `javax.*` | `jakarta.*` |
| Tracing | Spring Cloud Sleuth | Micrometer Observation API |
| Hibernate | 5.x | 6.x (jakarta.persistence) |
| ContextSnapshot | Non disponible | `io.micrometer:context-propagation` |
| Probes K8s | Manuel | `/actuator/health/liveness` + `/readiness` auto |
| ShedLock | `shedlock-spring 4.x` | `shedlock-spring 5.x` |
| Resilience4j | `resilience4j-spring-boot2` | `resilience4j-spring-boot3` |

### Java 17 features utilisées dans le code

```java
// Records (Java 16+) — ThreadPoolHealthIndicator
record PoolStatus(String name, int active, int max, ...) { }

// Pattern matching instanceof (Java 16+) — ThreadPoolHealthIndicator
if (executor instanceof ThreadPoolExecutor tpe) { ... }

// String.formatted() (Java 15+) — ThreadPoolHealthIndicator
"%.0f%%".formatted(poolLoad * 100)

// var (Java 11+) — ThreadPoolsConfig
var executor = new ThreadPoolTaskExecutor();

// switch expression (Java 14+) — ThreadPoolHealthIndicator
return switch (true) {
    case true when critical -> Health.down()...;
    default -> Health.up()...;
};
```

### --add-opens : pourquoi c'est nécessaire

Java 17 renforce le module system (Strong Encapsulation).
Hibernate 6 accède aux entités par réflexion → interdit sans `--add-opens`.

Spring Boot Maven Plugin les ajoute automatiquement via `spring-boot:run`.
**En production (JAR nu ou image Docker)** : ils doivent être dans `JAVA_TOOL_OPTIONS`.

## Budget threads (2CPU)

```
Pool              Core  Max  Queue  Rejet
──────────────────────────────────────────────────────
async-*            2     4   100    CallerRuns
modulith-*         2     4    50    CallerRuns
sf-http-*          2     4    20    Abort + CB
shedlock-*         1     2     5    Abort
kafka-consumers    2     4     0    Back-pressure
──────────────────────────────────────────────────────
TOTAL CORE         9    18
Actifs simultanés visés : ≤ 12  (2 CPU × IO factor 6)
```

## Mémoire (2Gi)

```
2Gi
├── 300Mi  OS + JVM (GC, JIT, classes chargées)
├── 256Mi  Metaspace (Spring Boot 3 + Modulith + Kafka + Hibernate 6)
├──   7Mi  Stack (14 threads × 512k)
└── ~1.5Gi Heap (-Xmx1536m)
             ├── ~300Mi  Hibernate L1 cache + sessions
             ├── ~100Mi  Payloads Kafka en traitement
             ├── ~50Mi   Hikari pool (10 connexions)
             ├── ~1.5Mo  Queues thread pools
             └── ~1Gi    Heap libre pour code applicatif
```

## Checklist déploiement

- [ ] `limits.cpu: "2"` dans deployment.yaml → `CORES = 2`
- [ ] `JAVA_TOOL_OPTIONS` avec `--add-opens` (Hibernate 6)
- [ ] `-Xlog:gc*` au lieu de `-XX:+PrintGCDetails`
- [ ] `spring-kafka 3.x` pour `setObservationEnabled(true)`
- [ ] `shedlock-spring 5.x` (compatible Spring Boot 3.x)
- [ ] `resilience4j-spring-boot3` (pas spring-boot2)
- [ ] `io.micrometer:context-propagation` dans le pom.xml
- [ ] `management.endpoint.health.probes.enabled: true` pour K8s probes
- [ ] `spring.lifecycle.timeout-per-shutdown-phase: 35s`
