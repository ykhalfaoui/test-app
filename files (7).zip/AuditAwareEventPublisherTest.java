package com.example.audit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentCaptor.forClass;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuditAwareEventPublisherTest {

    @Mock ApplicationEventPublisher delegate;
    @Mock AuditContextHolder auditContextHolder;

    AuditAwareEventPublisher publisher;

    AuditMetadata testMetadata = new AuditMetadata(
        "corr-123", "trace-abc", "span-xyz",
        "user-1", "HTTP", Instant.now()
    );

    @BeforeEach
    void setUp() {
        publisher = new AuditAwareEventPublisher(auditContextHolder);
        publisher.setApplicationEventPublisher(delegate);
    }

    // -------------------------------------------------------------------------
    // Cas nominal
    // -------------------------------------------------------------------------

    @Test
    void shouldInjectAuditMetadataIntoAuditableEvent() {
        when(auditContextHolder.current()).thenReturn(testMetadata);

        var event = new TestOrderEvent("order-1", null);
        publisher.publishEvent(event);

        var captor = forClass(Object.class);
        verify(delegate).publishEvent(captor.capture());

        var enriched = (TestOrderEvent) captor.getValue();
        assertThat(enriched.orderId()).isEqualTo("order-1");
        assertThat(enriched.auditMetadata()).isNotNull();
        assertThat(enriched.auditMetadata().correlationId()).isEqualTo("corr-123");
        assertThat(enriched.auditMetadata().sourceSystem()).isEqualTo("HTTP");
    }

    // -------------------------------------------------------------------------
    // Replay — metadata déjà présente
    // -------------------------------------------------------------------------

    @Test
    void shouldPreserveExistingMetadataOnReplay() {
        AuditMetadata originalMeta = new AuditMetadata(
            "original-corr", "original-trace", null,
            "system", "REPLAY", Instant.now().minusSeconds(60)
        );

        var event = new TestOrderEvent("order-1", originalMeta);
        publisher.publishEvent(event);

        var captor = forClass(Object.class);
        verify(delegate).publishEvent(captor.capture());

        var published = (TestOrderEvent) captor.getValue();
        assertThat(published.auditMetadata().correlationId()).isEqualTo("original-corr");
        verifyNoInteractions(auditContextHolder); // pas touché au contexte
    }

    // -------------------------------------------------------------------------
    // Events non-auditables (events Spring système, etc.)
    // -------------------------------------------------------------------------

    @Test
    void shouldPassThroughNonAuditableEvents() {
        var systemEvent = new Object();
        publisher.publishEvent(systemEvent);

        verify(delegate).publishEvent(systemEvent);
        verifyNoInteractions(auditContextHolder);
    }

    // -------------------------------------------------------------------------
    // Resilience — echec reflection ne crashe pas
    // -------------------------------------------------------------------------

    @Test
    void shouldPublishOriginalEventIfEnrichmentFails() {
        when(auditContextHolder.current()).thenThrow(new RuntimeException("tracer down"));

        var event = new TestOrderEvent("order-1", null);
        publisher.publishEvent(event); // ne doit pas throw

        verify(delegate).publishEvent(event); // publie l'original
    }

    // -------------------------------------------------------------------------
    // Test record
    // -------------------------------------------------------------------------

    record TestOrderEvent(
        String orderId,
        AuditMetadata auditMetadata
    ) implements AuditableEvent {}
}
