package com.example.config.threads;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Health indicator Spring Boot Actuator — Java 17 / Spring Boot 3.x
 *
 * GET /actuator/health/threadPools
 *
 * Contribue au readiness probe K8s → le pod est retiré du load balancer
 * si un pool est saturé à 80%.
 *
 * Java 17 :
 *  - Record PoolStatus : immutable, compact, equals/hashCode/toString gratuits
 *  - Pattern matching instanceof pour le scheduler
 *  - switch expression pour le statut
 */
@Component("threadPools")
public class ThreadPoolHealthIndicator implements HealthIndicator {

    private static final double WARN_THRESHOLD     = 0.60;
    private static final double CRITICAL_THRESHOLD = 0.80;

    private final ThreadPoolTaskExecutor asyncExecutor;
    private final ThreadPoolTaskExecutor modulithAsyncExecutor;
    private final ThreadPoolTaskExecutor salesforceExecutor;
    private final ThreadPoolTaskScheduler shedLockScheduler;

    public ThreadPoolHealthIndicator(
            ThreadPoolTaskExecutor asyncExecutor,
            ThreadPoolTaskExecutor modulithAsyncExecutor,
            ThreadPoolTaskExecutor salesforceExecutor,
            ThreadPoolTaskScheduler shedLockScheduler) {
        this.asyncExecutor = asyncExecutor;
        this.modulithAsyncExecutor = modulithAsyncExecutor;
        this.salesforceExecutor = salesforceExecutor;
        this.shedLockScheduler = shedLockScheduler;
    }

    @Override
    public Health health() {
        var details = new LinkedHashMap<String, Object>();
        details.put("budget", ThreadBudget.summary());

        var async     = checkExecutor("async",     asyncExecutor.getThreadPoolExecutor());
        var modulith  = checkExecutor("modulith",  modulithAsyncExecutor.getThreadPoolExecutor());
        var sf        = checkExecutor("salesforce", salesforceExecutor.getThreadPoolExecutor());
        // Java 17 pattern matching instanceof (stable depuis Java 16)
        var shedlock  = shedLockScheduler.getScheduledExecutor() instanceof ThreadPoolExecutor tpe
                        ? checkExecutor("shedlock", tpe)
                        : PoolStatus.unknown("shedlock");

        details.put("async",      async.toMap());
        details.put("modulith",   modulith.toMap());
        details.put("salesforce", sf.toMap());
        details.put("shedlock",   shedlock.toMap());

        boolean critical = async.critical() || modulith.critical() || sf.critical() || shedlock.critical();
        boolean warning  = async.warning()  || modulith.warning()  || sf.warning()  || shedlock.warning();

        // Java 17 switch expression (stable depuis Java 14)
        return switch (true) {
            case true  when critical -> Health.down()
                .withDetails(details)
                .withDetail("cause", "Pool(s) saturé(s) à 80%+")
                .build();
            case true  when warning  -> Health.unknown()
                .withDetails(details)
                .withDetail("cause", "Pool(s) à 60%+ de charge")
                .build();
            default                  -> Health.up()
                .withDetails(details)
                .build();
        };
    }

    private PoolStatus checkExecutor(String name, ThreadPoolExecutor executor) {
        int active   = executor.getActiveCount();
        int max      = executor.getMaximumPoolSize();
        int core     = executor.getCorePoolSize();
        int queued   = executor.getQueue().size();
        int queueCap = executor.getQueue().remainingCapacity() + queued;

        double poolLoad  = max > 0 ? (double) active / max : 0;
        double queueLoad = queueCap > 0 ? (double) queued / queueCap : 0;

        return new PoolStatus(
            name, active, max, core, queued, queueCap, poolLoad, queueLoad,
            poolLoad >= WARN_THRESHOLD || queueLoad >= WARN_THRESHOLD,
            poolLoad >= CRITICAL_THRESHOLD || queueLoad >= CRITICAL_THRESHOLD
        );
    }

    /**
     * Java 17 Record — remplace le POJO avec getters.
     * Compact, immutable, equals/hashCode/toString auto-générés.
     */
    record PoolStatus(
        String name,
        int active, int max, int core,
        int queued, int queueCapacity,
        double poolLoad, double queueLoad,
        boolean warning, boolean critical
    ) {
        /** Factory pour les cas où l'executor n'est pas un ThreadPoolExecutor */
        static PoolStatus unknown(String name) {
            return new PoolStatus(name, 0, 0, 0, 0, 0, 0, 0, false, false);
        }

        Map<String, Object> toMap() {
            // Java 17 : Map.of() avec les valeurs formatées
            return Map.of(
                "active",        active + "/" + max,
                "core",          core,
                "queued",        queued + "/" + queueCapacity,
                "poolLoad",      "%.0f%%".formatted(poolLoad * 100),  // Java 15+ String.formatted()
                "queueLoad",     "%.0f%%".formatted(queueLoad * 100),
                "status",        critical ? "CRITICAL" : warning ? "WARNING" : "OK"
            );
        }
    }
}
