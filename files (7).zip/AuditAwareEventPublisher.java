package com.example.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

import java.lang.reflect.Constructor;
import java.lang.reflect.RecordComponent;
import java.util.Arrays;

/**
 * Publisher décoré qui enrichit automatiquement tout AuditableEvent
 * avec l'AuditMetadata du contexte courant.
 *
 * Intercepte :
 *  - applicationEventPublisher.publishEvent()   → appel explicite
 *  - @DomainEvents via AbstractAggregateRoot    → Spring Data utilise ce bean
 *
 * Utilise la reflection sur les Records pour reconstruire l'event
 * avec auditMetadata injecté — zéro boilerplate dans les event classes.
 *
 * Guards défensifs :
 *  - Events non-AuditableEvent → passent sans modification
 *  - AuditMetadata déjà présent → préservé (cas replay Modulith)
 *  - Echec reflection → log warn + publie l'event original (no crash)
 */
@Component
@Qualifier("auditAware")
public class AuditAwareEventPublisher implements ApplicationEventPublisher, ApplicationEventPublisherAware {

    private static final Logger log = LoggerFactory.getLogger(AuditAwareEventPublisher.class);

    private ApplicationEventPublisher delegate;
    private final AuditContextHolder auditContextHolder;

    public AuditAwareEventPublisher(AuditContextHolder auditContextHolder) {
        this.auditContextHolder = auditContextHolder;
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.delegate = applicationEventPublisher;
    }

    @Override
    public void publishEvent(Object event) {
        delegate.publishEvent(enrich(event));
    }

    // -------------------------------------------------------------------------
    // Enrichissement
    // -------------------------------------------------------------------------

    private Object enrich(Object event) {
        // Guard 1 : pas un event auditable (events système Spring, etc.)
        if (!(event instanceof AuditableEvent auditable)) {
            return event;
        }

        // Guard 2 : déjà enrichi → replay Modulith, on préserve le contexte original
        if (auditable.auditMetadata() != null) {
            log.debug("AuditMetadata already present on {}, skipping enrichment (replay?)",
                event.getClass().getSimpleName());
            return event;
        }

        // Enrichissement via reflection
        try {
            return injectMetadata(event, auditContextHolder.current());
        } catch (Exception e) {
            log.warn("Failed to inject AuditMetadata into {} — publishing original event. Cause: {}",
                event.getClass().getSimpleName(), e.getMessage());
            return event; // ne jamais crasher le flux métier
        }
    }

    /**
     * Reconstruit le Record en injectant l'AuditMetadata.
     * Convention : le Record DOIT avoir un champ nommé exactement "auditMetadata".
     */
    @SuppressWarnings("unchecked")
    private <T> T injectMetadata(T event, AuditMetadata metadata) throws Exception {
        Class<?> clazz = event.getClass();

        if (!clazz.isRecord()) {
            throw new UnsupportedOperationException(
                clazz.getSimpleName() + " is not a Record. Only Records are supported for reflection-based enrichment."
            );
        }

        RecordComponent[] components = clazz.getRecordComponents();

        // Valeurs actuelles du record
        Object[] values = new Object[components.length];
        for (int i = 0; i < components.length; i++) {
            values[i] = components[i].getAccessor().invoke(event);
        }

        // Injecte l'AuditMetadata au bon index
        boolean found = false;
        for (int i = 0; i < components.length; i++) {
            if ("auditMetadata".equals(components[i].getName())) {
                values[i] = metadata;
                found = true;
                break;
            }
        }

        if (!found) {
            throw new IllegalStateException(
                clazz.getSimpleName() + " implements AuditableEvent but has no 'auditMetadata' field. " +
                "Add: AuditMetadata auditMetadata to the record components."
            );
        }

        // Reconstruit via le constructeur canonique
        Class<?>[] paramTypes = Arrays.stream(components)
            .map(RecordComponent::getType)
            .toArray(Class[]::new);

        Constructor<?> canonical = clazz.getDeclaredConstructor(paramTypes);
        canonical.setAccessible(true);
        return (T) canonical.newInstance(values);
    }
}
