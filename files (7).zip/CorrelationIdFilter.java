package com.example.audit.entrypoint;

import com.example.audit.SourceContextHolder;
import io.micrometer.tracing.Tracer;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

/**
 * Pose le contexte d'audit pour chaque requête HTTP entrante.
 * - Lit X-Correlation-Id du header entrant (ou en génère un)
 * - Stocke dans Micrometer Baggage pour propagation downstream
 * - Pose la source HTTP dans le ThreadLocal
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter extends OncePerRequestFilter {

    private static final String HEADER_CORRELATION_ID = "X-Correlation-Id";
    private static final String HEADER_USER_ID        = "X-User-Id";

    private final Tracer tracer;

    public CorrelationIdFilter(Tracer tracer) {
        this.tracer = tracer;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String correlationId = Optional
            .ofNullable(request.getHeader(HEADER_CORRELATION_ID))
            .filter(h -> !h.isBlank())
            .orElse(UUID.randomUUID().toString());

        String userId = Optional
            .ofNullable(request.getHeader(HEADER_USER_ID))
            .orElse("anonymous");

        // Baggage Micrometer — propagation automatique cross-thread (@Async, Modulith async events)
        if (tracer.currentSpan() != null) {
            tracer.createBaggage("correlation-id", correlationId);
            tracer.createBaggage("user-id", userId);
        }

        // ThreadLocal source
        SourceContextHolder.set(SourceContextHolder.Source.HTTP);

        // Propage le correlationId dans la réponse
        response.setHeader(HEADER_CORRELATION_ID, correlationId);

        try {
            filterChain.doFilter(request, response);
        } finally {
            SourceContextHolder.clear(); // toujours cleaner en finally
        }
    }
}
