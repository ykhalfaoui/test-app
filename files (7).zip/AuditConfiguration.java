package com.example.audit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * Expose AuditAwareEventPublisher comme bean @Primary.
 * Spring Data (AbstractAggregateRoot) et tous les appels
 * applicationEventPublisher.publishEvent() passeront par ce bean.
 *
 * ApplicationEventPublisherAware injecte le publisher réel (delegate)
 * dans AuditAwareEventPublisher — évite la dépendance circulaire.
 */
@Configuration
public class AuditConfiguration {

    @Bean
    @Primary
    public AuditAwareEventPublisher auditAwareEventPublisher(
        AuditContextHolder auditContextHolder
    ) {
        return new AuditAwareEventPublisher(auditContextHolder);
    }
}
