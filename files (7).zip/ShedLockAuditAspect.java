package com.example.audit.entrypoint;

import com.example.audit.SourceContextHolder;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Pose le contexte d'audit pour les jobs ShedLock.
 * Crée un nouveau span + baggage pour chaque exécution de batch.
 */
@Aspect
@Component
public class ShedLockAuditAspect {

    private final Tracer tracer;

    public ShedLockAuditAspect(Tracer tracer) {
        this.tracer = tracer;
    }

    @Around("@annotation(net.javacrumbs.shedlock.spring.annotation.SchedulerLock)")
    public Object aroundScheduledJob(ProceedingJoinPoint pjp) throws Throwable {
        String jobName = pjp.getSignature().getName();
        String correlationId = "BATCH-" + jobName + "-" + UUID.randomUUID();

        Span span = tracer.nextSpan()
            .name("shedlock." + jobName)
            .start();

        try (Tracer.SpanInScope ignored = tracer.withSpan(span)) {
            tracer.createBaggage("correlation-id", correlationId);
            tracer.createBaggage("user-id", "system");

            SourceContextHolder.set(SourceContextHolder.Source.SHEDLOCK);

            return pjp.proceed();
        } finally {
            SourceContextHolder.clear();
            span.end();
        }
    }
}
