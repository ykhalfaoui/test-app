package com.example.order;

import com.example.audit.AuditMetadata;
import com.example.audit.AuditableEvent;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.springframework.data.domain.AbstractAggregateRoot;

/**
 * Exemple d'agrégat Order utilisant AbstractAggregateRoot.
 *
 * L'entité est 100% pure DDD :
 *  - Elle ne connaît pas AuditContextHolder
 *  - Elle crée ses events SANS AuditMetadata (null)
 *  - L'enrichissement est fait par AuditAwareEventPublisher au moment du save()
 */
@Entity
public class Order extends AbstractAggregateRoot<Order> {

    @Id
    private String id;
    private String customerId;
    private OrderStatus status;

    public Order confirm() {
        if (this.status != OrderStatus.PENDING) {
            throw new IllegalStateException("Only PENDING orders can be confirmed");
        }
        this.status = OrderStatus.CONFIRMED;

        // ← Aucune mention d'audit ici. L'entité reste pure.
        registerEvent(new OrderConfirmedEvent(this.id, this.customerId));
        return this;
    }

    public Order cancel(String reason) {
        this.status = OrderStatus.CANCELLED;
        registerEvent(new OrderCancelledEvent(this.id, reason));
        return this;
    }

    // -------------------------------------------------------------------------
    // Domain Events — Records immuables, auditMetadata null à la création
    // -------------------------------------------------------------------------

    /**
     * Event créé par l'entité — auditMetadata est null.
     * Il sera injecté par AuditAwareEventPublisher lors du repository.save().
     */
    public record OrderConfirmedEvent(
        String orderId,
        String customerId,
        AuditMetadata auditMetadata   // null à la création, injecté au publish
    ) implements AuditableEvent {

        /** Constructeur utilisé par l'entité — sans metadata */
        public OrderConfirmedEvent(String orderId, String customerId) {
            this(orderId, customerId, null);
        }
    }

    public record OrderCancelledEvent(
        String orderId,
        String reason,
        AuditMetadata auditMetadata
    ) implements AuditableEvent {

        public OrderCancelledEvent(String orderId, String reason) {
            this(orderId, reason, null);
        }
    }

    public enum OrderStatus { PENDING, CONFIRMED, CANCELLED }
}
