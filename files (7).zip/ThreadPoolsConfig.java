package com.example.config.threads;

import io.micrometer.context.ContextSnapshot;
import io.micrometer.context.ContextSnapshotFactory;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.jvm.ExecutorServiceMetrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.concurrent.*;

/**
 * Configuration centrale de tous les pools — Java 17 / Spring Boot 3.x / 2CPU / 2Gi
 *
 * Java 17 spécifique :
 *  - Records utilisés pour PoolStatus (stable Java 16+) ✅
 *  - Pattern matching instanceof dans les helpers ✅
 *  - Pas de virtual threads (Java 21 uniquement) → platform threads ✅
 *  - ContextSnapshotFactory Micrometer 1.10+ (Spring Boot 3.x) ✅
 *  - ExecutorServiceMetrics pour exposition Prometheus de chaque pool ✅
 *
 * Spring Boot 3.x spécifique :
 *  - jakarta.* au lieu de javax.* (migration Jakarta EE 10) ✅
 *  - Micrometer Observation API (remplace Spring Cloud Sleuth) ✅
 *  - @EnableAsync sur cette classe (pas sur @SpringBootApplication) ✅
 */
@Configuration
@EnableAsync
public class ThreadPoolsConfig {

    private static final Logger log = LoggerFactory.getLogger(ThreadPoolsConfig.class);

    private final ContextSnapshotFactory snapshotFactory;
    private final MeterRegistry meterRegistry;

    public ThreadPoolsConfig(ContextSnapshotFactory snapshotFactory,
                              MeterRegistry meterRegistry) {
        this.snapshotFactory = snapshotFactory;
        this.meterRegistry = meterRegistry;

        // Log au démarrage pour confirmer les valeurs réelles sur le pod
        log.info("Initialisation thread pools : {}", ThreadBudget.summary());
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 1. @Async — pool principal
    // ══════════════════════════════════════════════════════════════════════════

    @Bean("asyncExecutor")
    @Primary
    public ThreadPoolTaskExecutor asyncExecutor() {
        var executor = buildExecutor(
            "async-",
            ThreadBudget.ASYNC_CORE,
            ThreadBudget.ASYNC_MAX,
            ThreadBudget.ASYNC_QUEUE,
            new CallerRunsWithLogPolicy("async")
        );
        monitorExecutor(executor, "async");
        return executor;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 2. Modulith async — domain events AFTER_COMMIT
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Pool dédié aux @ApplicationModuleListener Spring Modulith.
     *
     * ISOLATION : séparé du pool @Async pour que les domain events ne soient
     * jamais bloqués par des tâches métier longues.
     *
     * Spring Modulith 1.x + Spring Boot 3.x :
     * Ce bean est détecté automatiquement si nommé "applicationTaskExecutor"
     * ou configuré via spring.modulith.async-executor dans application.yml.
     */
    @Bean("modulithAsyncExecutor")
    public ThreadPoolTaskExecutor modulithAsyncExecutor() {
        var executor = buildExecutor(
            "modulith-",
            ThreadBudget.MODULITH_CORE,
            ThreadBudget.MODULITH_MAX,
            ThreadBudget.MODULITH_QUEUE,
            new CallerRunsWithLogPolicy("modulith")
        );
        monitorExecutor(executor, "modulith");
        return executor;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 3. Salesforce HTTP — appels REST isolés
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Pool isolé pour les appels HTTP Salesforce (200-800ms typique).
     *
     * AbortPolicy intentionnel : si SF est lent et que la queue est pleine,
     * on veut un RejectedExecutionException immédiat que Resilience4j intercepte
     * pour ouvrir le circuit — pas accumuler des appels qui vont tous timeout.
     */
    @Bean("salesforceExecutor")
    public ThreadPoolTaskExecutor salesforceExecutor() {
        var executor = buildExecutor(
            "sf-http-",
            ThreadBudget.SF_CORE,
            ThreadBudget.SF_MAX,
            ThreadBudget.SF_QUEUE,
            new AbortWithMetricPolicy("salesforce", meterRegistry)
        );
        monitorExecutor(executor, "salesforce");
        return executor;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 4. ShedLock scheduler
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Scheduler ThreadPool pour @Scheduled + ShedLock.
     *
     * Spring Boot 3.x : ThreadPoolTaskScheduler implémente TaskScheduler.
     * ShedLockTracingAspect (déclaré ailleurs) wrapp chaque job dans une Observation.
     *
     * Pool size = SHEDLOCK_MAX (2 sur 2 CPU) :
     * ShedLock garantit un seul pod par job dans le cluster.
     * 2 threads = peut exécuter 2 jobs DIFFÉRENTS en parallèle sur le même pod.
     */
    @Bean("shedLockScheduler")
    public ThreadPoolTaskScheduler shedLockScheduler() {
        var scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(ThreadBudget.SHEDLOCK_MAX);
        scheduler.setThreadNamePrefix("shedlock-");
        scheduler.setWaitForTasksToCompleteOnShutdown(true);
        scheduler.setAwaitTerminationSeconds(ThreadBudget.SHUTDOWN_AWAIT_SECONDS);
        scheduler.setRejectedExecutionHandler(
            new AbortWithMetricPolicy("shedlock", meterRegistry)
        );
        scheduler.initialize();

        log.info("Pool ShedLock: size={}", ThreadBudget.SHEDLOCK_MAX);
        return scheduler;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 5. TaskDecorator Micrometer — propagation tracing dans tous les threads
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Propage le ContextSnapshot Micrometer dans tous les threads async.
     *
     * Spring Boot 3.x + Micrometer 1.10+ :
     * ContextSnapshotFactory.captureAll() capture :
     *  - TraceContext (traceId, spanId)
     *  - Baggage fields (correlationId, etc.)
     *  - Tous les ThreadLocal enregistrés dans ContextRegistry
     *
     * Note Java 17 : try-with-resources sur ContextSnapshot.Scope
     * utilise l'AutoCloseable standard — pas de hack de réflexion nécessaire.
     */
    @Bean
    public TaskDecorator micrometerTracingDecorator() {
        return runnable -> {
            // Capture dans le thread appelant (HTTP, Kafka listener, etc.)
            ContextSnapshot snapshot = snapshotFactory.captureAll();
            // Retourne un Runnable qui restaure le contexte dans le thread du pool
            return () -> {
                try (ContextSnapshot.Scope ignored = snapshot.setThreadLocals()) {
                    runnable.run();
                }
            };
        };
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Helpers privés
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Factory method : construit un ThreadPoolTaskExecutor standardisé.
     * Toutes les options de robustesse sont appliquées ici une seule fois.
     */
    private ThreadPoolTaskExecutor buildExecutor(String namePrefix,
                                                   int coreSize, int maxSize,
                                                   int queueCapacity,
                                                   RejectedExecutionHandler rejectionHandler) {
        var executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(coreSize);
        executor.setMaxPoolSize(maxSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setKeepAliveSeconds(ThreadBudget.KEEPALIVE_SECONDS);
        executor.setAllowCoreThreadTimeOut(false); // core threads toujours vivants
        executor.setThreadNamePrefix(namePrefix);
        executor.setTaskDecorator(micrometerTracingDecorator());
        executor.setRejectedExecutionHandler(rejectionHandler);
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(ThreadBudget.SHUTDOWN_AWAIT_SECONDS);
        executor.initialize();

        log.info("Pool {}: core={} max={} queue={}",
            namePrefix.strip(), coreSize, maxSize, queueCapacity);
        return executor;
    }

    /**
     * Enregistre les métriques Micrometer d'un executor.
     * Expose dans Prometheus :
     *   executor.pool.size{name="async-executor"}
     *   executor.queued{name="async-executor"}
     *   executor.active{name="async-executor"}
     *   executor.completed{name="async-executor"}
     */
    private void monitorExecutor(ThreadPoolTaskExecutor executor, String name) {
        ExecutorServiceMetrics.monitor(
            meterRegistry,
            executor.getThreadPoolExecutor(),
            name + "-executor",
            "pool", name
        );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Rejection Handlers — Java 17 : records pour les données immuables
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * CallerRunsPolicy avec log structuré.
     * Le thread appelant exécute la tâche → back-pressure naturel sans perte de données.
     * Utilisé pour : async, modulith (les events ne doivent jamais être perdus).
     */
    static class CallerRunsWithLogPolicy implements RejectedExecutionHandler {

        private static final Logger log = LoggerFactory.getLogger(CallerRunsWithLogPolicy.class);
        private final String poolName;

        CallerRunsWithLogPolicy(String poolName) { this.poolName = poolName; }

        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            // Log structuré compatible avec Loki / ELK
            log.warn("pool.rejection pool={} policy=caller-runs active={} queued={} max={}",
                poolName,
                executor.getActiveCount(),
                executor.getQueue().size(),
                executor.getMaximumPoolSize());

            if (!executor.isShutdown()) {
                r.run(); // Exécute dans le thread appelant
            }
        }
    }

    /**
     * AbortPolicy avec métrique Micrometer.
     * Lance une RejectedExecutionException → le circuit breaker Resilience4j l'intercepte.
     * Utilisé pour : salesforce (fail fast), shedlock (saturation = bug).
     */
    static class AbortWithMetricPolicy implements RejectedExecutionHandler {

        private static final Logger log = LoggerFactory.getLogger(AbortWithMetricPolicy.class);
        private final String poolName;
        private final MeterRegistry meterRegistry;

        AbortWithMetricPolicy(String poolName, MeterRegistry meterRegistry) {
            this.poolName = poolName;
            this.meterRegistry = meterRegistry;
        }

        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            // Métrique Prometheus : threadpool_rejected_total{pool="salesforce"}
            meterRegistry.counter("threadpool.rejected", "pool", poolName).increment();

            log.error("pool.rejection pool={} policy=abort active={} queued={} max={}",
                poolName,
                executor.getActiveCount(),
                executor.getQueue().size(),
                executor.getMaximumPoolSize());

            throw new RejectedExecutionException(
                "Pool [" + poolName + "] saturé — active=" + executor.getActiveCount() +
                "/" + executor.getMaximumPoolSize()
            );
        }
    }
}
