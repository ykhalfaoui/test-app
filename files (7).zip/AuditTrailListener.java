package com.example.trail;

import com.example.audit.AuditMetadata;
import com.example.audit.AuditableEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

/**
 * Module Trail — seul endroit qui connaît l'audit.
 *
 * @ApplicationModuleListener = async + transactionnel propre à Spring Modulith.
 * Tous les events AuditableEvent arrivent ici avec leur AuditMetadata déjà injecté.
 */
@Component
public class AuditTrailListener {

    private static final Logger log = LoggerFactory.getLogger(AuditTrailListener.class);

    private final AuditTrailRepository repository;
    private final ObjectMapper objectMapper;

    public AuditTrailListener(AuditTrailRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    @ApplicationModuleListener
    public void on(AuditableEvent event) {
        AuditMetadata meta = event.auditMetadata();

        if (meta == null) {
            // Ne devrait jamais arriver — log et skip plutôt que crasher
            log.warn("Received AuditableEvent {} without AuditMetadata — skipping trail entry",
                event.getClass().getSimpleName());
            return;
        }

        AuditTrailEntry entry = new AuditTrailEntry(
            UUID.randomUUID().toString(),
            event.getClass().getSimpleName(),
            meta.correlationId(),
            meta.traceId(),
            meta.spanId(),
            meta.userId(),
            meta.sourceSystem(),
            meta.initiatedAt(),
            serialize(event)
        );

        repository.save(entry);

        log.debug("Audit trail: event={} correlationId={} source={}",
            entry.eventType(), entry.correlationId(), entry.sourceSystem());
    }

    private String serialize(Object event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            return "{\"error\": \"serialization failed\"}";
        }
    }

    // -------------------------------------------------------------------------
    // Entité Trail (dans le même module trail)
    // -------------------------------------------------------------------------

    @Entity
    public record AuditTrailEntry(
        @Id String id,
        String eventType,
        String correlationId,
        String traceId,
        String spanId,
        String userId,
        String sourceSystem,
        Instant occurredAt,
        String payload
    ) {}
}
