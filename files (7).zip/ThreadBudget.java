package com.example.config.threads;

/**
 * Budget de threads — Java 17 / Spring Boot 3.x / 2 CPU / 2Gi / Kubernetes
 *
 * ══════════════════════════════════════════════════════════════════════
 * ANALYSE MÉMOIRE (2Gi)
 * ══════════════════════════════════════════════════════════════════════
 *
 *  2Gi  total
 *  - 300Mi  OS + JVM overhead (GC threads, JIT compiler, classes)
 *  - 256Mi  Metaspace (Spring Boot 3 + Modulith + Kafka + Hibernate 6)
 *  -  ~7Mi  Stack threads (14 threads max × 512k = 7Mi)
 *  ─────────────────────────────────────────────────────────────────
 *  ~1.5Gi   heap disponible  →  -Xmx1536m
 *
 *  Queues en heap (pire cas) :
 *    async    100 × 10Ko = 1Mo
 *    modulith  50 ×  5Ko = 250Ko
 *    sf-http   20 × 10Ko = 200Ko
 *  ─────────────────────────────────────────────────────────────────
 *  ~1.5Mo queues  →  négligeable, heap dominée par JPA/cache Hibernate
 *
 * ══════════════════════════════════════════════════════════════════════
 * BUDGET THREADS (2 CPU)
 * ══════════════════════════════════════════════════════════════════════
 *
 *  Pool              Core  Max   Queue   Politique rejet
 *  ──────────────────────────────────────────────────────────────────
 *  kafka-consumers    2     4     0      Back-pressure Kafka
 *  modulith-*         2     4    50      CallerRunsPolicy
 *  async-*            2     4   100      CallerRunsPolicy
 *  sf-http-*          2     4    20      AbortPolicy + circuit breaker
 *  shedlock-*         1     2     5      AbortPolicy
 *  ──────────────────────────────────────────────────────────────────
 *  TOTAL CORE         9    18
 *
 *  Budget actif visé : ≤ 12 threads  (2 CPU × facteur IO 6)
 *
 * ══════════════════════════════════════════════════════════════════════
 * JAVA 17 — FLAGS JVM RECOMMANDÉS
 * ══════════════════════════════════════════════════════════════════════
 *
 *  GC : deux options selon ton profil de latence
 *
 *  Option A — G1GC (défaut Java 17, recommandé workload mixte) :
 *    -XX:+UseG1GC
 *    -XX:MaxGCPauseMillis=200
 *    -XX:G1HeapRegionSize=4m        ← optimal pour heap 1-4Gi
 *    -XX:InitiatingHeapOccupancyPercent=35
 *
 *  Option B — ZGC (recommandé si latence Kafka critique, pauses < 1ms) :
 *    -XX:+UseZGC
 *    -XX:SoftMaxHeapSize=1280m      ← ZGC libère la heap plus agressivement
 *    Note : ZGC ignore MaxGCPauseMillis
 *
 *  Strong Encapsulation Java 17 (module system) :
 *    --add-opens java.base/java.lang=ALL-UNNAMED
 *    --add-opens java.base/java.util=ALL-UNNAMED
 *    → Requis par Hibernate 6 ORM pour l'accès réflexif aux entités
 *    → Spring Boot 3.x les inclut via spring-boot-maven-plugin, mais
 *      à ajouter explicitement dans JAVA_TOOL_OPTIONS si déployé en JAR nu
 *
 *  Unified Logging (remplace -XX:+PrintGCDetails obsolète) :
 *    -Xlog:gc*:file=/var/log/gc.log:time,uptime,level,tags:filecount=5,filesize=20m
 *
 *  Voir JvmFlags.RECOMMENDED ci-dessous pour le bloc complet.
 */
public final class ThreadBudget {

    private ThreadBudget() {}

    /**
     * CORES = 2 sur un pod K8s avec limits.cpu: "2".
     * La JVM 17 est cgroup-aware par défaut (UseContainerSupport activé).
     * Aucun flag supplémentaire requis contrairement à Java 8.
     */
    public static final int CORES = Runtime.getRuntime().availableProcessors();

    // ── Pools ─────────────────────────────────────────────────────────────────

    public static final int KAFKA_CORE     = Math.max(2, CORES);
    public static final int KAFKA_MAX      = Math.max(4, CORES * 2);

    public static final int MODULITH_CORE  = Math.max(2, CORES);
    public static final int MODULITH_MAX   = Math.max(4, CORES * 2);

    public static final int ASYNC_CORE     = Math.max(2, CORES);
    public static final int ASYNC_MAX      = Math.max(4, CORES * 2);

    public static final int SF_CORE        = Math.max(2, CORES);
    public static final int SF_MAX         = Math.max(4, CORES * 2);

    public static final int SHEDLOCK_CORE  = 1;
    public static final int SHEDLOCK_MAX   = Math.max(2, CORES / 2);

    // ── Queues ────────────────────────────────────────────────────────────────

    /** 0 = pas de queue → back-pressure immédiat sur le consumer Kafka */
    public static final int KAFKA_QUEUE    = 0;
    public static final int MODULITH_QUEUE = 50;
    public static final int ASYNC_QUEUE    = 100;
    public static final int SF_QUEUE       = 20;
    public static final int SHEDLOCK_QUEUE = 5;

    // ── Timeouts ──────────────────────────────────────────────────────────────

    public static final int KEEPALIVE_SECONDS      = 60;
    public static final int SHUTDOWN_AWAIT_SECONDS = 30;

    // ── Flags JVM Java 17 ─────────────────────────────────────────────────────

    /**
     * Flags JVM recommandés pour Java 17 / 2CPU / 2Gi.
     * À injecter dans JAVA_TOOL_OPTIONS dans le Dockerfile ou deployment.yaml.
     *
     * Différences clés vs Java 8/11 :
     *  ✅ UseContainerSupport activé par DÉFAUT (pas besoin de le déclarer)
     *  ✅ G1GC est le GC par défaut (pas besoin de -XX:+UseG1GC)
     *  ✅ ZGC stable et recommandé pour latence (nouveau en Java 17)
     *  ✅ -Xlog:gc* remplace -XX:+PrintGCDetails (Unified Logging)
     *  ✅ --add-opens requis pour Hibernate 6 / réflexion Java 17
     *  ❌ -XX:+UseConcMarkSweepGC supprimé (Java 14)
     *  ❌ -XX:PermSize supprimé (Java 8)
     */
    public static final class JvmFlags {

        /** Option A : G1GC — workload mixte Kafka + BDD + Salesforce */
        public static final String G1GC =
            "-Xms512m " +
            "-Xmx1536m " +
            "-XX:+UseG1GC " +
            "-XX:MaxGCPauseMillis=200 " +
            "-XX:G1HeapRegionSize=4m " +
            "-XX:InitiatingHeapOccupancyPercent=35 " +
            "-XX:MetaspaceSize=128m " +
            "-XX:MaxMetaspaceSize=256m " +
            // Strong encapsulation Java 17 — requis par Hibernate 6
            "--add-opens java.base/java.lang=ALL-UNNAMED " +
            "--add-opens java.base/java.util=ALL-UNNAMED " +
            "--add-opens java.base/java.lang.reflect=ALL-UNNAMED " +
            // Unified GC logging (remplace -XX:+PrintGCDetails)
            "-Xlog:gc*:stdout:time,uptime,level,tags " +
            // Crash dump en cas d'OOMError
            "-XX:+HeapDumpOnOutOfMemoryError " +
            "-XX:HeapDumpPath=/tmp/heapdump.hprof";

        /**
         * Option B : ZGC — si la latence Kafka est critique (pauses < 1ms).
         * À utiliser si max.poll.interval.ms est serré ou si les GC pauses
         * G1 déclenchent des rebalances Kafka.
         */
        public static final String ZGC =
            "-Xms512m " +
            "-Xmx1536m " +
            "-XX:+UseZGC " +
            // SoftMaxHeapSize : ZGC essaie de rester sous cette limite,
            // libère la heap plus agressivement pour rester sous 1280m
            "-XX:SoftMaxHeapSize=1280m " +
            "-XX:MetaspaceSize=128m " +
            "-XX:MaxMetaspaceSize=256m " +
            "--add-opens java.base/java.lang=ALL-UNNAMED " +
            "--add-opens java.base/java.util=ALL-UNNAMED " +
            "--add-opens java.base/java.lang.reflect=ALL-UNNAMED " +
            "-Xlog:gc*:stdout:time,uptime,level,tags " +
            "-XX:+HeapDumpOnOutOfMemoryError " +
            "-XX:HeapDumpPath=/tmp/heapdump.hprof";
    }

    public static String summary() {
        return String.format(
            "ThreadBudget[java=%s cores=%d heap=1536m | " +
            "kafka=%d/%d | modulith=%d/%d | async=%d/%d | sf=%d/%d | shedlock=%d/%d]",
            System.getProperty("java.version"), CORES,
            KAFKA_CORE, KAFKA_MAX, MODULITH_CORE, MODULITH_MAX,
            ASYNC_CORE, ASYNC_MAX, SF_CORE, SF_MAX,
            SHEDLOCK_CORE, SHEDLOCK_MAX
        );
    }
}
