package com.example.modulith;
import com.example.modulith.inbox.InboxRepository; import com.example.modulith.outbox.OutboxRepository;
import org.apache.kafka.clients.producer.ProducerRecord; import org.awaitility.Awaitility; import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate; import org.springframework.kafka.test.EmbeddedKafkaBroker; import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.DynamicPropertyRegistry; import org.springframework.test.context.DynamicPropertySource;
import java.time.Duration; import java.util.concurrent.TimeUnit; import static org.assertj.core.api.Assertions.assertThat;
@SpringBootTest @EmbeddedKafka(topics={"hits"}, partitions=1, brokerProperties={"listeners=PLAINTEXT://localhost:0","port=0"})
class KafkaFlowTests {
  @Autowired EmbeddedKafkaBroker broker; @Autowired KafkaTemplate<String,String> template; @Autowired InboxRepository inbox; @Autowired OutboxRepository outbox;
  @DynamicPropertySource static void kafkaProps(DynamicPropertyRegistry r){ r.add("spring.kafka.bootstrap-servers", () -> System.getProperty("spring.embedded.kafka.brokers")); }
  @Test void happyPath_validJson_toInboxProcessed_andOutboxDispatched(){
    String json = "{"type":"HitEventCreated","payload":{"hitExternalId":"HIT-123","positive":true}}";
    template.send(new ProducerRecord<>("hits", json));
    Awaitility.await().atMost(10, TimeUnit.SECONDS).untilAsserted(() -> {
      long processed = inbox.findAll().stream().filter(i -> "PROCESSED".equals(i.getStatus())).count();
      long dispatched = outbox.findAll().stream().filter(o -> "DISPATCHED".equals(o.getStatus())).count();
      assertThat(processed).isGreaterThanOrEqualTo(1); assertThat(dispatched).isGreaterThanOrEqualTo(2);
    });
  }
  @Test void serdeError_invalidJson_isCapturedInInboxSerdeError(){
    template.send(new ProducerRecord<>("hits", "not-a-json"));
    Awaitility.await().atMost(Duration.ofSeconds(10)).untilAsserted(() -> {
      boolean hasSerde = inbox.findAll().stream().anyMatch(i -> "SERDE_ERROR".equals(i.getStatus()) && i.getRawPayloadBase64() != null);
      assertThat(hasSerde).isTrue();
    });
  }
}
