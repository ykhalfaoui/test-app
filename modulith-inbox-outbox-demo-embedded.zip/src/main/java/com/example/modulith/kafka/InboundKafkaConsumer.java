package com.example.modulith.kafka;
import com.example.modulith.inbox.*; import com.fasterxml.jackson.databind.JsonNode; import org.springframework.kafka.annotation.KafkaListener; import org.springframework.kafka.support.KafkaHeaders; import org.springframework.messaging.handler.annotation.Header; import org.springframework.stereotype.Component; import java.util.UUID;
@Component
public class InboundKafkaConsumer {
  private final InboxRepository inbox; public InboundKafkaConsumer(InboxRepository inbox){ this.inbox=inbox; }
  @KafkaListener(topics="${app.topics.hit-events:hits}")
  public void on(JsonNode value, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic){
    InboxMessage m = new InboxMessage(); m.setMessageId(UUID.randomUUID().toString()); m.setSourceSystem("ihub"); m.setTopic(topic);
    m.setPayload(value.toString()); m.setStatus("RECEIVED"); inbox.save(m);
  }
}
