package com.example.modulith.kafka;
import com.example.modulith.inbox.*; import org.apache.kafka.clients.consumer.ConsumerRecord; import org.springframework.context.annotation.*; import org.springframework.kafka.listener.*; import org.springframework.kafka.support.serializer.DeserializationException; import org.springframework.util.backoff.FixedBackOff; import java.util.Base64; import java.util.UUID;
@Configuration
public class KafkaErrorHandlingConfig {
  @Bean
  CommonErrorHandler commonErrorHandler(InboxRepository inbox){
    DefaultErrorHandler h = new DefaultErrorHandler((rec, ex) -> persistSerdeError(inbox, rec, ex), new FixedBackOff(0, 0));
    h.addNotRetryableExceptions(DeserializationException.class);
    return h;
  }
  private void persistSerdeError(InboxRepository repo, ConsumerRecord<?, ?> rec, Exception ex){
    byte[] bytes = ex instanceof DeserializationException de ? de.getData() : null;
    String b64 = bytes != null ? Base64.getEncoder().encodeToString(bytes) : null;
    InboxMessage m = new InboxMessage(); m.setMessageId(UUID.randomUUID().toString()); m.setSourceSystem("ihub"); m.setTopic(rec.topic());
    m.setRawPayloadBase64(b64); m.setStatus("SERDE_ERROR"); repo.save(m);
  }
}
