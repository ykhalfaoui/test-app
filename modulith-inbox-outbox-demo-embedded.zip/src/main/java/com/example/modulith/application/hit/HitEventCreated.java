package com.example.modulith.application.hit;
public record HitEventCreated(String hitExternalId, boolean positive) {}
