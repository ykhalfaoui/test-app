package com.example.modulith.application.hit;
import com.example.modulith.application.dispatch.EventHandler; import org.springframework.stereotype.Component;
@Component
public class HitEventHandler implements EventHandler<HitEventCreated> {
  private final HitService service; public HitEventHandler(HitService service){ this.service=service; }
  @Override public void handle(HitEventCreated event){ service.process(event); }
  @Override public Class<HitEventCreated> payloadType(){ return HitEventCreated.class; }
  @Override public String supportsType(){ return "HitEventCreated"; }
}
