package com.example.modulith.application.outbox;
import com.example.modulith.outbox.*; import com.example.modulith.integration.salesforce.SalesforceClient; import com.fasterxml.jackson.databind.*; import org.springframework.scheduling.annotation.Scheduled; import org.springframework.stereotype.Component; import org.springframework.transaction.annotation.Transactional;
@Component
public class OutboxPublisher {
  private final OutboxRepository outbox; private final SalesforceClient sfdc; private final ObjectMapper mapper = new ObjectMapper();
  public OutboxPublisher(OutboxRepository outbox, SalesforceClient sfdc){ this.outbox=outbox; this.sfdc=sfdc; }
  @Scheduled(fixedDelay=200) @Transactional
  public void tick(){
    for (OutboxMessage m : outbox.lockPending()){
      try{
        String[] parts = m.getDestination().split(":"); String objectName = parts[3];
        JsonNode body = mapper.readTree(m.getPayload()); String externalId = body.path("externalId").asText();
        sfdc.upsert(objectName, "ExternalId__c", externalId, m.getPayload());
        m.setStatus("DISPATCHED");
      } catch (Exception e){ m.setStatus("PENDING"); m.setAttempts(m.getAttempts()+1); }
    }
  }
}
