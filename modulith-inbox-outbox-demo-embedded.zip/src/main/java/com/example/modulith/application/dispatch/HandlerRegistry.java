package com.example.modulith.application.dispatch;
import org.springframework.stereotype.Component; import java.util.*;
@Component
public class HandlerRegistry {
  private final Map<String, EventHandler<?>> byType = new HashMap<>();
  public HandlerRegistry(java.util.List<EventHandler<?>> handlers){ handlers.forEach(h -> byType.put(h.supportsType(), h)); }
  public java.util.Optional<EventHandler<?>> find(String type){ return java.util.Optional.ofNullable(byType.get(type)); }
}
