package com.example.modulith.application.hit;
import com.example.modulith.domain.hit.*; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
@Service
public class HitService {
  private final HitRepository hits;
  public HitService(HitRepository hits){ this.hits=hits; }
  @Transactional public void process(HitEventCreated evt){
    Hit h = new Hit(evt.hitExternalId());
    if(evt.positive()) h.qualifyPositive();
    hits.save(h);
  }
}
