package com.example.modulith.application.hit;
import com.example.modulith.domain.hit.*; import com.example.modulith.outbox.*; import com.fasterxml.jackson.databind.ObjectMapper; import org.springframework.modulith.ApplicationModuleListener; import org.springframework.stereotype.Component; import org.springframework.transaction.annotation.Transactional; import java.util.Map;
@Component
public class HitDomainToOutbox {
  private final OutboxRepository outbox; private final ObjectMapper mapper = new ObjectMapper();
  public HitDomainToOutbox(OutboxRepository outbox){ this.outbox=outbox; }
  @ApplicationModuleListener @Transactional
  public void on(HitQualifiedEvent event){
    try{
      String payload = mapper.writeValueAsString(Map.of("externalId", event.externalId(), "qualified", true));
      outbox.save(new OutboxMessage("Hit", String.valueOf(event.hitId()), "HitUpsertRequested", payload, "HTTP:SFDC:REST:Hit__c"));
    } catch (Exception e){ throw new RuntimeException(e); }
  }
}
