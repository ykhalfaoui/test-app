package com.example.modulith.application.inbox;
import com.example.modulith.application.dispatch.InboxDispatcher; import com.example.modulith.inbox.*; import org.springframework.scheduling.annotation.Scheduled; import org.springframework.stereotype.Component; import org.springframework.transaction.annotation.Transactional;
@Component
public class InboxWorker {
  private final InboxRepository inbox; private final InboxDispatcher dispatcher;
  public InboxWorker(InboxRepository inbox, InboxDispatcher dispatcher){ this.inbox=inbox; this.dispatcher=dispatcher; }
  @Scheduled(fixedDelay=200) @Transactional
  public void tick(){
    for (InboxMessage m : inbox.lockNextBatch()){
      try { dispatcher.dispatch(m); m.setStatus("PROCESSED"); }
      catch(Exception e){ m.setStatus("RETRY"); m.setAttempts(m.getAttempts()+1); }
    }
  }
}
