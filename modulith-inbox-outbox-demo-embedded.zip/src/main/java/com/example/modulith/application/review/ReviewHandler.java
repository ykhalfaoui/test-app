package com.example.modulith.application.review;
import com.example.modulith.domain.hit.*; import com.example.modulith.outbox.*; import com.fasterxml.jackson.databind.ObjectMapper; import org.springframework.modulith.ApplicationModuleListener; import org.springframework.stereotype.Component; import org.springframework.transaction.annotation.Transactional; import java.util.Map;
@Component
public class ReviewHandler {
  private final OutboxRepository outbox; private final ObjectMapper mapper = new ObjectMapper();
  public ReviewHandler(OutboxRepository outbox){ this.outbox=outbox; }
  @ApplicationModuleListener @Transactional
  public void on(HitQualifiedEvent event){
    try{
      String payload = mapper.writeValueAsString(Map.of("externalId", event.externalId(), "status", "REVIEW_PENDING"));
      outbox.save(new OutboxMessage("Hit", String.valueOf(event.hitId()), "ReviewRequested", payload, "HTTP:SFDC:REST:Review__c"));
    } catch (Exception e){ throw new RuntimeException(e); }
  }
}
