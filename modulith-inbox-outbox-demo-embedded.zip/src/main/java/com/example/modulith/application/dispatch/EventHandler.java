package com.example.modulith.application.dispatch;
public interface EventHandler<T> { void handle(T event); Class<T> payloadType(); String supportsType(); }
