package com.example.modulith.application.dispatch;
import com.example.modulith.inbox.InboxMessage; import com.fasterxml.jackson.databind.*; import org.springframework.stereotype.Component;
@Component
public class InboxDispatcher {
  private final HandlerRegistry registry; private final ObjectMapper mapper = new ObjectMapper();
  public InboxDispatcher(HandlerRegistry registry){ this.registry=registry; }
  public void dispatch(InboxMessage row) throws Exception {
    JsonNode root = mapper.readTree(row.getPayload());
    String type = root.path("type").asText(); JsonNode body = root.has("payload") ? root.path("payload") : root;
    var handler = registry.find(type).orElseThrow(() -> new IllegalArgumentException("No handler for type="+type));
    Object typed = mapper.treeToValue(body, handler.payloadType()); invoke(handler, typed);
  }
  @SuppressWarnings("unchecked") private <T> void invoke(EventHandler<?> raw, Object obj){ ((EventHandler<T>)raw).handle((T)obj); }
}
