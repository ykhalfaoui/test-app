package com.example.modulith.inbox;
import jakarta.persistence.*; import java.time.OffsetDateTime;
@Entity @Table(name="INBOX")
public class InboxMessage {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(nullable=false,length=200) private String messageId;
  @Column(nullable=false,length=100) private String sourceSystem;
  @Column(nullable=false,length=200) private String topic;
  @Column(nullable=false,length=20) private String status="RECEIVED";
  @Lob @Column private String payload;
  @Lob @Column private String rawPayloadBase64;
  @Column(nullable=false) private int attempts=0;
  @Column private OffsetDateTime nextAttemptAt;
  @Column(nullable=false) private OffsetDateTime receivedAt=OffsetDateTime.now();
  public Long getId(){return id;}
  public String getMessageId(){return messageId;} public void setMessageId(String v){this.messageId=v;}
  public String getSourceSystem(){return sourceSystem;} public void setSourceSystem(String v){this.sourceSystem=v;}
  public String getTopic(){return topic;} public void setTopic(String v){this.topic=v;}
  public String getStatus(){return status;} public void setStatus(String v){this.status=v;}
  public String getPayload(){return payload;} public void setPayload(String v){this.payload=v;}
  public String getRawPayloadBase64(){return rawPayloadBase64;} public void setRawPayloadBase64(String v){this.rawPayloadBase64=v;}
  public int getAttempts(){return attempts;} public void setAttempts(int v){this.attempts=v;}
  public OffsetDateTime getNextAttemptAt(){return nextAttemptAt;} public void setNextAttemptAt(OffsetDateTime v){this.nextAttemptAt=v;}
  public OffsetDateTime getReceivedAt(){return receivedAt;} public void setReceivedAt(OffsetDateTime v){this.receivedAt=v;}
}
