package com.example.modulith.domain.hit;
import org.springframework.data.domain.*; import jakarta.persistence.*; import java.util.*;
@Entity
public class Hit {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String externalId; private String status;
  @Transient private final List<Object> domainEvents = new ArrayList<>();
  protected Hit(){}
  public Hit(String externalId){ this.externalId=externalId; this.status="NEW"; }
  public void qualifyPositive(){ if(!"QUALIFIED_POSITIVE".equals(status)){ status="QUALIFIED_POSITIVE"; domainEvents.add(new HitQualifiedEvent(id, externalId)); } }
  @DomainEvents public Collection<Object> domainEvents(){ return List.copyOf(domainEvents); }
  @AfterDomainEventPublication public void clearEvents(){ domainEvents.clear(); }
  public Long getId(){return id;} public String getExternalId(){return externalId;} public String getStatus(){return status;}
}
