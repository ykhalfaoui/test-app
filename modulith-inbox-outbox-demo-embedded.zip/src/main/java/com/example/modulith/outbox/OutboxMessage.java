package com.example.modulith.outbox;
import jakarta.persistence.*; import java.time.OffsetDateTime;
@Entity @Table(name="OUTBOX")
public class OutboxMessage {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(nullable=false,length=50)  private String aggregateType;
  @Column(nullable=false,length=200) private String aggregateId;
  @Column(nullable=false,length=200) private String eventType;
  @Lob @Column(nullable=false) private String payload;
  @Column(nullable=false,length=200) private String destination;
  @Column(nullable=false,length=20) private String status="PENDING";
  @Column(nullable=false) private int attempts=0;
  @Column private OffsetDateTime nextAttemptAt;
  @Column(nullable=false) private OffsetDateTime createdAt=OffsetDateTime.now();
  public OutboxMessage(){}
  public OutboxMessage(String aggType,String aggId,String evtType,String payload,String dest){
    this.aggregateType=aggType; this.aggregateId=aggId; this.eventType=evtType;
    this.payload=payload; this.destination=dest;
  }
  public Long getId(){return id;}
  public String getAggregateType(){return aggregateType;}
  public String getAggregateId(){return aggregateId;}
  public String getEventType(){return eventType;}
  public String getPayload(){return payload;}
  public String getDestination(){return destination;}
  public String getStatus(){return status;} public void setStatus(String v){this.status=v;}
  public int getAttempts(){return attempts;} public void setAttempts(int v){this.attempts=v;}
  public OffsetDateTime getNextAttemptAt(){return nextAttemptAt;} public void setNextAttemptAt(OffsetDateTime v){this.nextAttemptAt=v;}
  public OffsetDateTime getCreatedAt(){return createdAt;}
}
