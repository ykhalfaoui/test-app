package com.example.modulith.outbox;
import org.springframework.data.jpa.repository.*; import org.springframework.stereotype.Repository;
import jakarta.persistence.LockModeType; import java.util.List;
@Repository
public interface OutboxRepository extends JpaRepository<OutboxMessage, Long> {
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select o from OutboxMessage o where o.status='PENDING' order by o.createdAt")
  List<OutboxMessage> lockPending();
}
