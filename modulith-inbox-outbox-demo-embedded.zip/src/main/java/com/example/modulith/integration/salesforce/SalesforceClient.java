package com.example.modulith.integration.salesforce;
import org.slf4j.*; import org.springframework.stereotype.Component;
@Component
public class SalesforceClient {
  private static final Logger log = LoggerFactory.getLogger(SalesforceClient.class);
  public void upsert(String objectName, String externalIdField, String externalIdValue, String jsonBody){
    log.info("SFDC UPSERT {}({}={}) body={}", objectName, externalIdField, externalIdValue, jsonBody);
  }
}
