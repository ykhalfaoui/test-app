package com.yourcompany.integration.blueprism.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Intercepteur pour logger les requêtes/réponses SOAP
 * Gère les erreurs de décodage en loggant le XML brut
 * 
 * @author Yass
 */
@Slf4j
public class SoapLoggingInterceptor implements ClientInterceptor {
    
    private final boolean logPayload;
    
    public SoapLoggingInterceptor(boolean logPayload) {
        this.logPayload = logPayload;
    }
    
    @Override
    public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
        if (logPayload) {
            logMessage("SOAP REQUEST", messageContext.getRequest());
        }
        return true;
    }
    
    @Override
    public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
        if (logPayload) {
            logMessage("SOAP RESPONSE", messageContext.getResponse());
        }
        return true;
    }
    
    @Override
    public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
        // ⭐ Toujours logger les SOAP Faults
        log.error("SOAP FAULT RECEIVED");
        logMessage("SOAP FAULT", messageContext.getResponse());
        return true;
    }
    
    @Override
    public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {
        if (ex != null) {
            log.error("SOAP call failed with exception", ex);
            
            // ⭐ Si erreur de décodage, logger le XML brut
            if (ex.getMessage() != null && 
                (ex.getMessage().contains("unmarshal") || 
                 ex.getMessage().contains("decode") ||
                 ex.getMessage().contains("parse"))) {
                
                log.error("❌ DECODING ERROR - Logging raw XML response:");
                
                if (messageContext.hasResponse()) {
                    String rawXml = extractRawXml(messageContext.getResponse());
                    log.error("RAW XML RESPONSE:\n{}", rawXml);
                    
                    // Sauvegarder dans un fichier pour analyse
                    saveToFile(rawXml, "error-response.xml");
                }
            }
        }
    }
    
    /**
     * Logger un message SOAP
     */
    private void logMessage(String prefix, WebServiceMessage message) {
        try {
            String xml = extractRawXml(message);
            log.debug("{}:\n{}", prefix, xml);
        } catch (Exception e) {
            log.warn("Failed to log SOAP message", e);
        }
    }
    
    /**
     * ⭐ Extraire le XML brut d'un message
     */
    private String extractRawXml(WebServiceMessage message) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            message.writeTo(out);
            return out.toString(StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "[Failed to extract XML: " + e.getMessage() + "]";
        }
    }
    
    /**
     * Sauvegarder le XML dans un fichier pour analyse
     */
    private void saveToFile(String xml, String filename) {
        try {
            java.nio.file.Path path = java.nio.file.Paths.get("logs", filename);
            java.nio.file.Files.createDirectories(path.getParent());
            java.nio.file.Files.writeString(
                path, 
                xml, 
                StandardCharsets.UTF_8,
                java.nio.file.StandardOpenOption.CREATE,
                java.nio.file.StandardOpenOption.TRUNCATE_EXISTING
            );
            log.info("✅ Raw XML saved to: {}", path.toAbsolutePath());
        } catch (IOException e) {
            log.warn("Failed to save XML to file", e);
        }
    }
}
