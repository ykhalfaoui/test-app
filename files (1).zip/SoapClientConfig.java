package com.yourcompany.integration.blueprism.config;

import com.yourcompany.integration.blueprism.interceptor.SoapLoggingInterceptor;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Configuration Spring-WS avec intercepteurs
 * - Authentification BASIC
 * - Logs requêtes/réponses
 * - Gestion erreurs de décodage
 * 
 * @author Yass
 */
@Configuration
public class SoapClientConfig {
    
    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.yourcompany.integration.blueprism.generated");
        return marshaller;
    }
    
    /**
     * ⭐ Intercepteur d'authentification BASIC
     */
    @Bean
    public ClientInterceptor basicAuthInterceptor(SoapProperties properties) {
        return (request, execution) -> {
            if (properties.getUsername() != null && !properties.getUsername().isEmpty()) {
                String auth = properties.getUsername() + ":" + properties.getPassword();
                String encodedAuth = Base64.getEncoder()
                    .encodeToString(auth.getBytes(StandardCharsets.UTF_8));
                request.getHeaders().add("Authorization", "Basic " + encodedAuth);
            }
            return execution.execute(request);
        };
    }
    
    /**
     * ⭐ Intercepteur de logs avec gestion d'erreurs
     */
    @Bean
    public ClientInterceptor loggingInterceptor(SoapProperties properties) {
        return new SoapLoggingInterceptor(properties.isEnableDetailedLogging());
    }
    
    @Bean
    public WebServiceTemplate webServiceTemplate(
            Jaxb2Marshaller marshaller,
            ClientInterceptor basicAuthInterceptor,
            ClientInterceptor loggingInterceptor,
            SoapProperties properties) {
        
        WebServiceTemplate template = new WebServiceTemplate();
        template.setMarshaller(marshaller);
        template.setUnmarshaller(marshaller);
        template.setDefaultUri(properties.getEndpoint());
        
        // ⭐ Ajouter TOUS les intercepteurs (ordre important !)
        template.setInterceptors(new ClientInterceptor[] {
            basicAuthInterceptor,  // 1. Auth d'abord
            loggingInterceptor     // 2. Logs ensuite
        });
        
        // Message sender avec timeouts
        HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
        messageSender.setConnectionTimeout(properties.getConnectionTimeout());
        messageSender.setReadTimeout(properties.getSocketTimeout());
        template.setMessageSender(messageSender);
        
        return template;
    }
    
    @Bean
    @ConfigurationProperties(prefix = "blueprism.soap")
    public SoapProperties soapProperties() {
        return new SoapProperties();
    }
}

@Data
class SoapProperties {
    private String endpoint;
    private String username;
    private String password;
    private int connectionTimeout = 30000;
    private int socketTimeout = 60000;
    private boolean enableDetailedLogging = false;  // ⭐ Flag pour logs détaillés
}
