# 📦 CONFIGURATION MAVEN & DÉPENDANCES

## pom.xml - Dépendances complètes

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example</groupId>
    <artifactId>spring-modulith-party-service</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>Party Service - Spring Modulith</name>
    <description>Production-ready Spring Modulith with TraceId, Audit, Retry</description>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.0</version>
        <relativePath/>
    </parent>

    <properties>
        <java.version>21</java.version>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <spring-modulith.version>1.2.0</spring-modulith.version>
        <resilience4j.version>2.1.0</resilience4j.version>
        <jackson.version>2.16.0</jackson.version>
    </properties>

    <dependencies>

        <!-- ============================================ -->
        <!-- CORE SPRING -->
        <!-- ============================================ -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>

        <!-- ============================================ -->
        <!-- SPRING MODULITH -->
        <!-- ============================================ -->
        <dependency>
            <groupId>org.springframework.modulith</groupId>
            <artifactId>spring-modulith-starter-core</artifactId>
            <version>${spring-modulith.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework.modulith</groupId>
            <artifactId>spring-modulith-starter-jpa</artifactId>
            <version>${spring-modulith.version}</version>
        </dependency>

        <!-- ============================================ -->
        <!-- DATABASE -->
        <!-- ============================================ -->
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <version>8.2.0</version>
            <scope>runtime</scope>
        </dependency>

        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-core</artifactId>
            <version>9.22.3</version>
        </dependency>

        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-mysql</artifactId>
            <version>9.22.3</version>
        </dependency>

        <!-- ============================================ -->
        <!-- RESILIENCE & RETRY -->
        <!-- ============================================ -->
        <dependency>
            <groupId>io.github.resilience4j</groupId>
            <artifactId>resilience4j-spring-boot3</artifactId>
            <version>${resilience4j.version}</version>
        </dependency>

        <dependency>
            <groupId>io.github.resilience4j</groupId>
            <artifactId>resilience4j-circuitbreaker</artifactId>
            <version>${resilience4j.version}</version>
        </dependency>

        <dependency>
            <groupId>io.github.resilience4j</groupId>
            <artifactId>resilience4j-retry</artifactId>
            <version>${resilience4j.version}</version>
        </dependency>

        <dependency>
            <groupId>io.github.resilience4j</groupId>
            <artifactId>resilience4j-timelimiter</artifactId>
            <version>${resilience4j.version}</version>
        </dependency>

        <!-- ============================================ -->
        <!-- SERIALIZATION -->
        <!-- ============================================ -->
        <dependency>
            <groupId>com.fasterxml.jackson.core</groupId>
            <artifactId>jackson-databind</artifactId>
            <version>${jackson.version}</version>
        </dependency>

        <dependency>
            <groupId>com.fasterxml.jackson.datatype</groupId>
            <artifactId>jackson-datatype-jsr310</artifactId>
            <version>${jackson.version}</version>
        </dependency>

        <!-- ============================================ -->
        <!-- LOGGING -->
        <!-- ============================================ -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-logging</artifactId>
        </dependency>

        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
        </dependency>

        <dependency>
            <groupId>ch.qos.logback</groupId>
            <artifactId>logback-classic</artifactId>
        </dependency>

        <!-- ============================================ -->
        <!-- MONITORING & METRICS -->
        <!-- ============================================ -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>

        <dependency>
            <groupId>io.micrometer</groupId>
            <artifactId>micrometer-registry-prometheus</artifactId>
        </dependency>

        <!-- ============================================ -->
        <!-- NOTIFICATIONS (Optional) -->
        <!-- ============================================ -->
        <!-- Pour Slack -->
        <dependency>
            <groupId>com.slack.api</groupId>
            <artifactId>slack-api-client</artifactId>
            <version>1.36.0</version>
        </dependency>

        <!-- ============================================ -->
        <!-- TEST -->
        <!-- ============================================ -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>

        <dependency>
            <groupId>org.springframework.modulith</groupId>
            <artifactId>spring-modulith-starter-test</artifactId>
            <version>${spring-modulith.version}</version>
            <scope>test</scope>
        </dependency>

        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>testcontainers</artifactId>
            <version>1.19.3</version>
            <scope>test</scope>
        </dependency>

        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>mysql</artifactId>
            <version>1.19.3</version>
            <scope>test</scope>
        </dependency>

        <dependency>
            <groupId>org.mockito</groupId>
            <artifactId>mockito-core</artifactId>
            <scope>test</scope>
        </dependency>

        <dependency>
            <groupId>org.mockito</groupId>
            <artifactId>mockito-junit-jupiter</artifactId>
            <scope>test</scope>
        </dependency>

    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>

            <!-- Vérifier la structure modulaire -->
            <plugin>
                <groupId>org.springframework.modulith</groupId>
                <artifactId>spring-modulith-maven-plugin</artifactId>
                <version>${spring-modulith.version}</version>
            </plugin>

            <!-- Code coverage -->
            <plugin>
                <groupId>org.jacoco</groupId>
                <artifactId>jacoco-maven-plugin</artifactId>
                <version>0.8.10</version>
                <executions>
                    <execution>
                        <goals>
                            <goal>prepare-agent</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>report</id>
                        <phase>test</phase>
                        <goals>
                            <goal>report</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>

</project>
```

---

## application.yml - Configuration

```yaml
spring:
  application:
    name: party-service

  # ============================================
  # DATABASE
  # ============================================
  datasource:
    url: jdbc:mysql://localhost:3306/party_db?useSSL=false&serverTimezone=UTC&characterEncoding=utf8mb4&allowPublicKeyRetrieval=true
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
    hikari:
      maximum-pool-size: 20
      minimum-idle: 5
      connection-timeout: 30000
      idle-timeout: 600000
      max-lifetime: 1800000

  # ============================================
  # JPA / HIBERNATE
  # ============================================
  jpa:
    hibernate:
      ddl-auto: validate
    properties:
      hibernate:
        dialect: org.hibernate.dialect.MySQL8Dialect
        format_sql: true
        jdbc:
          batch_size: 20
          fetch_size: 50
        order_inserts: true
        order_updates: true
    show-sql: false

  # ============================================
  # FLYWAY MIGRATIONS
  # ============================================
  flyway:
    enabled: true
    locations: classpath:db/migration
    baselineOnMigrate: false
    outOfOrder: false
    validateOnMigrate: true

  # ============================================
  # ASYNC
  # ============================================
  task:
    execution:
      pool:
        core-size: 5
        max-size: 10
        queue-capacity: 100
        thread-name-prefix: async-
      thread-name-prefix: async-
    scheduling:
      pool:
        size: 5
      thread-name-prefix: scheduler-

  # ============================================
  # SERIALIZATION
  # ============================================
  jackson:
    serialization:
      write-dates-as-timestamps: false
      indent-output: false
    deserialization:
      fail-on-unknown-properties: false
    time-zone: UTC

  # ============================================
  # SECURITY
  # ============================================
  security:
    user:
      name: admin
      password: changeme

# ============================================
# LOGGING
# ============================================
logging:
  level:
    root: INFO
    com.example: DEBUG
    org.springframework.web: INFO
    org.springframework.security: DEBUG
    org.springframework.data: DEBUG
    org.hibernate.SQL: DEBUG
    org.hibernate.type.descriptor.sql.BasicBinder: TRACE
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n [%thread] %-5level %logger{36} - %X{traceId} %X{userId}%n"
    file: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n [%thread] %-5level %logger{36} - %X{traceId} %X{userId}%n"
  file:
    name: logs/party-service.log
    max-size: 10MB
    max-history: 10

# ============================================
# ACTUATOR
# ============================================
management:
  endpoints:
    web:
      exposure:
        include: health,metrics,prometheus,info
  endpoint:
    health:
      show-details: always
    metrics:
      enabled: true
  metrics:
    export:
      prometheus:
        enabled: true

# ============================================
# RESILIENCE4J
# ============================================
resilience4j:
  circuitbreaker:
    instances:
      remotePartySync:
        registerHealthIndicator: true
        sliding-window-size: 10
        failure-rate-threshold: 50
        slow-call-rate-threshold: 50
        slow-call-duration-threshold: 10s
        wait-duration-in-open-state: 60s
        minimum-number-of-calls: 5
        automatic-transition-from-open-to-half-open-enabled: true
        permitted-number-of-calls-in-half-open-state: 3

  retry:
    instances:
      remotePartySync:
        max-attempts: 3
        wait-duration: 1000
        retry-exceptions:
          - com.example.infrastructure.retry.RetryableException
          - java.io.IOException
          - java.net.ConnectException

  timelimiter:
    instances:
      remotePartySync:
        timeout-duration: 10s
        cancel-running-future: true

# ============================================
# SPRING MODULITH
# ============================================
spring.modulith:
  enabled: true
  events:
    # Publication registry pour retry automatique
    publication-registry: default

# ============================================
# SERVER
# ============================================
server:
  port: 8080
  servlet:
    context-path: /api
  error:
    include-message: always
    include-binding-errors: always

---

# ============================================
# PROFILE : development
# ============================================
spring:
  config:
    activate:
      on-profile: dev

  jpa:
    show-sql: true

  datasource:
    url: jdbc:mysql://localhost:3306/party_db_dev?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
    username: dev
    password: dev

logging:
  level:
    root: INFO
    com.example: DEBUG
    org.springframework: DEBUG

---

# ============================================
# PROFILE : production
# ============================================
spring:
  config:
    activate:
      on-profile: prod

  jpa:
    show-sql: false
    hibernate:
      ddl-auto: validate

  datasource:
    url: jdbc:mysql://${DB_HOST}:${DB_PORT}/party_db?useSSL=true&serverTimezone=UTC&allowPublicKeyRetrieval=false
    username: ${DB_USER}
    password: ${DB_PASSWORD}
    hikari:
      maximum-pool-size: 30
      minimum-idle: 10

logging:
  level:
    root: WARN
    com.example: INFO
  file:
    name: /var/log/party-service/party-service.log
    max-size: 100MB
    max-history: 30
```

---

## logback-spring.xml - Configuration Logback avancée

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <springProperty name="LOG_FILE" source="logging.file.name" defaultValue="logs/app.log"/>
    <springProperty name="LOG_LEVEL" source="logging.level.root" defaultValue="INFO"/>

    <!-- Console Appender -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>
                %d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %X{traceId} %X{userId} - %msg%n
            </pattern>
            <charset>utf8</charset>
        </encoder>
    </appender>

    <!-- File Appender -->
    <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOG_FILE}</file>
        <encoder>
            <pattern>
                %d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %X{traceId} %X{userId} - %msg%n
            </pattern>
            <charset>utf8</charset>
        </encoder>
        <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
            <fileNamePattern>${LOG_FILE}.%d{yyyy-MM-dd}.%i.gz</fileNamePattern>
            <maxFileSize>100MB</maxFileSize>
            <maxHistory>30</maxHistory>
            <totalSizeCap>3GB</totalSizeCap>
        </rollingPolicy>
    </appender>

    <!-- Error File Appender (only errors) -->
    <appender name="ERROR_FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOG_FILE}.error</file>
        <filter class="ch.qos.logback.classic.filter.LevelFilter">
            <level>ERROR</level>
            <onMatch>ACCEPT</onMatch>
            <onMismatch>DENY</onMismatch>
        </filter>
        <encoder>
            <pattern>
                %d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %X{traceId} %X{userId} - %msg%n%ex
            </pattern>
            <charset>utf8</charset>
        </encoder>
        <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
            <fileNamePattern>${LOG_FILE}.error.%d{yyyy-MM-dd}.%i.gz</fileNamePattern>
            <maxFileSize>50MB</maxFileSize>
            <maxHistory>30</maxHistory>
        </rollingPolicy>
    </appender>

    <!-- Async Appender pour performance -->
    <appender name="ASYNC_FILE" class="ch.qos.logback.classic.AsyncAppender">
        <queueSize>512</queueSize>
        <discardingThreshold>0</discardingThreshold>
        <appender-ref ref="FILE"/>
    </appender>

    <!-- Logger for specific packages -->
    <logger name="com.example" level="DEBUG"/>
    <logger name="org.springframework.web" level="INFO"/>
    <logger name="org.springframework.security" level="DEBUG"/>
    <logger name="org.springframework.data" level="DEBUG"/>
    <logger name="org.hibernate.SQL" level="DEBUG"/>

    <!-- Root Logger -->
    <root level="${LOG_LEVEL}">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="ASYNC_FILE"/>
        <appender-ref ref="ERROR_FILE"/>
    </root>

    <!-- Profils -->
    <springProfile name="dev">
        <root level="DEBUG">
            <appender-ref ref="CONSOLE"/>
        </root>
    </springProfile>

    <springProfile name="prod">
        <root level="INFO">
            <appender-ref ref="ASYNC_FILE"/>
            <appender-ref ref="ERROR_FILE"/>
        </root>
    </springProfile>

</configuration>
```

---

## Docker Compose - Infrastructure locale

```yaml
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    container_name: party-mysql
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: party_db
      MYSQL_USER: party_user
      MYSQL_PASSWORD: party_password
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
      - ./docker/mysql-init.sql:/docker-entrypoint-initdb.d/init.sql
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
      timeout: 20s
      retries: 10

  adminer:
    image: adminer
    container_name: party-adminer
    ports:
      - "8081:8080"
    depends_on:
      - mysql

  redis:
    image: redis:7-alpine
    container_name: party-redis
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      timeout: 3s
      retries: 5

  prometheus:
    image: prom/prometheus:latest
    container_name: party-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./docker/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'

  grafana:
    image: grafana/grafana:latest
    container_name: party-grafana
    ports:
      - "3000:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: admin
    volumes:
      - grafana_data:/var/lib/grafana
    depends_on:
      - prometheus

volumes:
  mysql_data:
  prometheus_data:
  grafana_data:
```

---

## docker/mysql-init.sql

```sql
-- Création de la base et utilisateur
CREATE DATABASE IF NOT EXISTS party_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'party_user'@'%' IDENTIFIED BY 'party_password';
GRANT ALL PRIVILEGES ON party_db.* TO 'party_user'@'%';
GRANT ALL PRIVILEGES ON party_db.* TO 'root'@'%';
FLUSH PRIVILEGES;

USE party_db;

-- Tables initiales (seront créées par Flyway en démarrage)
```

---

## docker/prometheus.yml

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'party-service'
    static_configs:
      - targets: ['localhost:8080']
    metrics_path: '/api/actuator/prometheus'
```

---

## Commandes utiles

```bash
# 1. Démarrer l'infrastructure
docker-compose up -d

# 2. Vérifier les services
docker-compose ps

# 3. Logs MySQL
docker-compose logs -f mysql

# 4. Arrêter tout
docker-compose down

# 5. Nettoyer les volumes
docker-compose down -v

# 6. Accès aux outils
# Adminer MySQL : http://localhost:8081
# Grafana       : http://localhost:3000 (admin/admin)
# Prometheus    : http://localhost:9090

# 7. Build Spring Boot
mvn clean package -DskipTests

# 8. Run Spring Boot
java -Dspring.profiles.active=dev -jar target/spring-modulith-party-service-1.0.0.jar

# 9. Compiler avec vérification modulith
mvn verify

# 10. Voir les modules détectés
mvn spring-modulith:list
```

---

## Checklist de configuration

- [ ] Dépendances Maven téléchargées
- [ ] Database MySQL configurée et démarrée
- [ ] Fichier `application.yml` adapté
- [ ] `logback-spring.xml` en place
- [ ] Flyway migrations dans `src/main/resources/db/migration/`
- [ ] Docker Compose (optionnel) configuré
- [ ] Tests lancés avec succès : `mvn test`
- [ ] Application démarre sans erreur
- [ ] Accès à `/api/actuator/health` retourne `UP`
- [ ] Logs contiennent le `traceId` en MDC

C'est prêt ! 🚀
