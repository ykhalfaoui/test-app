package com.crok4it.snowflake.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.snowflake.client.jdbc.SnowflakeBasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.security.PrivateKey;
import java.util.Properties;

/**
 * Configure la DataSource Snowflake avec authentification par clé privée.
 *
 * On utilise directement SnowflakeBasicDataSource pour injecter la PrivateKey
 * Java object — contrairement à HikariCP qui ne supporte pas ce mode natif.
 *
 * Note : Snowflake JDBC gère lui-même le pooling interne via son propre pool
 * de sessions. Pas besoin de HikariCP pour Snowflake en production.
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class SnowflakeDataSourceConfig {

    private final SnowflakeProperties props;
    private final PrivateKeyLoader privateKeyLoader;

    @Bean
    public DataSource snowflakeDataSource() {
        PrivateKey privateKey = privateKeyLoader.load(props);

        SnowflakeBasicDataSource ds = new SnowflakeBasicDataSource();

        // JDBC URL — format officiel Snowflake
        String jdbcUrl = String.format(
            "jdbc:snowflake://%s.snowflakecomputing.com",
            props.getAccount()
        );
        ds.setUrl(jdbcUrl);

        // Authentification par clé privée (pas de mot de passe !)
        ds.setUser(props.getUser());
        ds.setPrivateKey(privateKey);

        // Contexte de session
        ds.setWarehouse(props.getWarehouse());
        ds.setDatabaseName(props.getDatabase());
        ds.setSchema(props.getSchema());
        ds.setRole(props.getRole());

        log.info("DataSource Snowflake configurée → account={}, user={}, warehouse={}, db={}, schema={}",
            props.getAccount(), props.getUser(), props.getWarehouse(),
            props.getDatabase(), props.getSchema());

        return ds;
    }
}
