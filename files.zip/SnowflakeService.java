package com.crok4it.snowflake.service;

import com.crok4it.snowflake.model.QueryResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.time.Instant;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class SnowflakeService {

    private final DataSource snowflakeDataSource;

    // -------------------------------------------------------------------------
    // Endpoint 1 — Infos de session courante
    // -------------------------------------------------------------------------

    public QueryResult currentSession() {
        String sql = """
            SELECT
                CURRENT_USER()       AS current_user,
                CURRENT_ROLE()       AS current_role,
                CURRENT_WAREHOUSE()  AS current_warehouse,
                CURRENT_DATABASE()   AS current_database,
                CURRENT_SCHEMA()     AS current_schema,
                CURRENT_TIMESTAMP()  AS server_time
            """;
        return executeQuery(sql);
    }

    // -------------------------------------------------------------------------
    // Endpoint 2 — Top tables du schéma courant
    // -------------------------------------------------------------------------

    public QueryResult listTables() {
        String sql = """
            SELECT
                TABLE_CATALOG,
                TABLE_SCHEMA,
                TABLE_NAME,
                TABLE_TYPE,
                ROW_COUNT,
                BYTES
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = CURRENT_SCHEMA()
            ORDER BY ROW_COUNT DESC NULLS LAST
            LIMIT 20
            """;
        return executeQuery(sql);
    }

    // -------------------------------------------------------------------------
    // Endpoint 3 — Query history des 10 dernières requêtes
    // -------------------------------------------------------------------------

    public QueryResult recentQueryHistory() {
        String sql = """
            SELECT
                QUERY_ID,
                QUERY_TEXT,
                USER_NAME,
                WAREHOUSE_NAME,
                EXECUTION_STATUS,
                TOTAL_ELAPSED_TIME,
                START_TIME
            FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY(
                DATEADD('hours', -1, CURRENT_TIMESTAMP()),
                CURRENT_TIMESTAMP()
            ))
            WHERE USER_NAME = CURRENT_USER()
            ORDER BY START_TIME DESC
            LIMIT 10
            """;
        return executeQuery(sql);
    }

    // -------------------------------------------------------------------------
    // Moteur d'exécution générique
    // -------------------------------------------------------------------------

    public QueryResult executeQuery(String sql) {
        long start = Instant.now().toEpochMilli();
        log.debug("Exécution Snowflake: {}", sql.strip().replace("\n", " "));

        try (Connection conn = snowflakeDataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            ResultSetMetaData meta = rs.getMetaData();
            int colCount = meta.getColumnCount();

            List<String> columns = new ArrayList<>(colCount);
            for (int i = 1; i <= colCount; i++) {
                columns.add(meta.getColumnName(i));
            }

            List<Map<String, Object>> rows = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 1; i <= colCount; i++) {
                    row.put(meta.getColumnName(i), rs.getObject(i));
                }
                rows.add(row);
            }

            long elapsed = Instant.now().toEpochMilli() - start;
            log.info("Requête exécutée en {}ms — {} lignes retournées", elapsed, rows.size());

            return QueryResult.builder()
                .query(sql.strip())
                .columns(columns)
                .rows(rows)
                .rowCount(rows.size())
                .executionTimeMs(elapsed)
                .build();

        } catch (SQLException e) {
            log.error("Erreur SQL Snowflake [code={}]: {}", e.getErrorCode(), e.getMessage());
            throw new SnowflakeQueryException("Erreur lors de l'exécution de la requête Snowflake", e);
        }
    }

    // -------------------------------------------------------------------------
    // Exception métier
    // -------------------------------------------------------------------------

    public static class SnowflakeQueryException extends RuntimeException {
        public SnowflakeQueryException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
