# 🧪 TESTS COMPLETS - Partie 2

## Tests Unitaires et d'Intégration

### 1. PartyTest.java - Tests du modèle de domaine

```java
package com.example.party.domain.model;

import com.example.party.domain.events.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.Collection;

import static org.assertj.core.api.Assertions.*;

@DisplayName("Party Aggregate Tests")
class PartyTest {

    private Party party;
    private PartyId partyId;

    @BeforeEach
    void setup() {
        partyId = PartyId.of("party-123");
        party = Party.create(partyId);
    }

    @Test
    @DisplayName("should create party with CREATED status")
    void shouldCreatePartyWithCreatedStatus() {
        assertThat(party.getId()).isEqualTo(partyId);
        assertThat(party.getStatus()).isEqualTo(PartyStatus.CREATED);
        assertThat(party.getBlocks()).isEmpty();
    }

    @Test
    @DisplayName("should emit PartyCreated event on creation")
    void shouldEmitPartyCreatedEvent() {
        Collection<Object> events = party.getDomainEvents();
        
        assertThat(events).hasSize(1);
        assertThat(events.iterator().next()).isInstanceOf(PartyCreated.class);
        
        PartyCreated event = (PartyCreated) events.iterator().next();
        assertThat(event.partyId()).isEqualTo("party-123");
    }

    @Test
    @DisplayName("should add block successfully")
    void shouldAddBlockSuccessfully() {
        BlockId blockId = BlockId.of("block-1");
        party.addBlock(blockId);

        assertThat(party.getBlocks()).hasSize(1);
        assertThat(party.getStatus()).isEqualTo(PartyStatus.BLOCKS_IN_PROGRESS);
    }

    @Test
    @DisplayName("should emit BlockCreated event when adding block")
    void shouldEmitBlockCreatedEvent() {
        party.addBlock(BlockId.of("block-1"));
        
        Collection<Object> events = party.getDomainEvents();
        assertThat(events).hasSize(2); // PartyCreated + BlockCreated
        
        assertThat(events.stream().skip(1).findFirst().get())
            .isInstanceOf(BlockCreated.class);
    }

    @Test
    @DisplayName("should add multiple blocks")
    void shouldAddMultipleBlocks() {
        party.addBlock(BlockId.of("block-1"));
        party.addBlock(BlockId.of("block-2"));
        party.addBlock(BlockId.of("block-3"));

        assertThat(party.getBlockCount()).isEqualTo(3);
    }

    @Test
    @DisplayName("should mark all blocks created")
    void shouldMarkAllBlocksCreated() {
        party.addBlock(BlockId.of("block-1"));
        party.markAllBlocksCreated();

        assertThat(party.getStatus()).isEqualTo(PartyStatus.ALL_BLOCKS_CREATED);
    }

    @Test
    @DisplayName("should emit AllBlocksCreated event with block count")
    void shouldEmitAllBlocksCreatedEvent() {
        party.addBlock(BlockId.of("block-1"));
        party.addBlock(BlockId.of("block-2"));
        party.markAllBlocksCreated();

        Collection<Object> events = party.getDomainEvents();
        AllBlocksCreated event = (AllBlocksCreated) events.stream()
            .filter(e -> e instanceof AllBlocksCreated)
            .findFirst()
            .orElseThrow();

        assertThat(event.blockCount()).isEqualTo(2);
    }

    @Test
    @DisplayName("should mark synchronized")
    void shouldMarkSynchronized() {
        party.addBlock(BlockId.of("block-1"));
        party.markAllBlocksCreated();
        party.markSynchronized();

        assertThat(party.getStatus()).isEqualTo(PartyStatus.SYNCHRONIZED);
    }

    @Test
    @DisplayName("should mark failed")
    void shouldMarkFailed() {
        party.markFailed("Test failure");

        assertThat(party.getStatus()).isEqualTo(PartyStatus.FAILED);
    }

    @Test
    @DisplayName("should emit PartyFailed event with reason")
    void shouldEmitPartyFailedEvent() {
        party.markFailed("Test failure reason");

        Collection<Object> events = party.getDomainEvents();
        PartyFailed event = (PartyFailed) events.stream()
            .filter(e -> e instanceof PartyFailed)
            .findFirst()
            .orElseThrow();

        assertThat(event.reason()).isEqualTo("Test failure reason");
    }

    // ===== INVARIANT TESTS =====

    @Test
    @DisplayName("should NOT allow adding blocks to FAILED party (INVARIANT)")
    void shouldNotAllowAddingBlocksToFailedParty() {
        party.markFailed("Test");

        assertThatThrownBy(() -> party.addBlock(BlockId.of("block-1")))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Cannot add block to party in status: FAILED");
    }

    @Test
    @DisplayName("should NOT allow marking complete when no blocks (INVARIANT)")
    void shouldNotAllowMarkingCompleteWithNoBlocks() {
        assertThatThrownBy(() -> party.markAllBlocksCreated())
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("no blocks created");
    }

    @Test
    @DisplayName("should NOT allow synchronizing when not all blocks created (INVARIANT)")
    void shouldNotAllowSynchronizingWithoutAllBlocksCreated() {
        party.addBlock(BlockId.of("block-1"));

        assertThatThrownBy(() -> party.markSynchronized())
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Cannot synchronize");
    }

    @Test
    @DisplayName("should NOT allow synchronizing twice (INVARIANT)")
    void shouldNotAllowSynchronizingTwice() {
        party.addBlock(BlockId.of("block-1"));
        party.markAllBlocksCreated();
        party.markSynchronized();

        assertThatThrownBy(() -> party.markSynchronized())
            .isInstanceOf(IllegalStateException.class);
    }

    @Test
    @DisplayName("should clear domain events after publication")
    void shouldClearDomainEventsAfterPublication() {
        party.addBlock(BlockId.of("block-1"));
        
        assertThat(party.getDomainEvents()).isNotEmpty();
        
        party.clearDomainEvents();
        
        assertThat(party.getDomainEvents()).isEmpty();
    }

    @Test
    @DisplayName("should be equal by ID")
    void shouldBeEqualById() {
        Party party1 = Party.create(PartyId.of("same-id"));
        Party party2 = Party.create(PartyId.of("same-id"));

        assertThat(party1).isEqualTo(party2);
    }
}
```

### 2. PartyApplicationServiceTest.java - Tests du service

```java
package com.example.party.application;

import com.example.infrastructure.audit.AuditService;
import com.example.infrastructure.trace.TraceContext;
import com.example.party.domain.model.Party;
import com.example.party.domain.repository.PartyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@DisplayName("Party Application Service Tests")
class PartyApplicationServiceTest {

    @Mock private PartyRepository partyRepository;
    @Mock private AuditService auditService;

    private PartyApplicationService service;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        service = new PartyApplicationService(partyRepository, auditService);
    }

    @Test
    @DisplayName("should create party with trace context")
    void shouldCreatePartyWithTraceContext() {
        String partyId = "party-123";
        TraceContext context = TraceContext.create("user-1");
        Party party = Party.create(partyId);

        when(partyRepository.save(any(Party.class)))
            .thenReturn(party);

        Party result = service.createParty(partyId, context);

        assertThat(result).isNotNull();
        assertThat(result.getId().value()).isEqualTo(partyId);
        verify(partyRepository, times(1)).save(any(Party.class));
        verify(auditService, times(1)).logSuccess(
            eq("Party"),
            eq(partyId),
            eq("Created"),
            any()
        );
    }

    @Test
    @DisplayName("should add block to party")
    void shouldAddBlockToParty() {
        String partyId = "party-123";
        String blockId = "block-1";
        TraceContext context = TraceContext.create("user-1");
        
        Party party = Party.create(partyId);
        when(partyRepository.findById(partyId))
            .thenReturn(Optional.of(party));

        service.addBlock(partyId, blockId, context);

        verify(partyRepository, times(1)).save(any(Party.class));
        assertThat(party.getBlocks()).hasSize(1);
    }

    @Test
    @DisplayName("should fail when adding block to non-existent party")
    void shouldFailWhenAddingBlockToNonExistentParty() {
        String partyId = "non-existent";
        String blockId = "block-1";
        TraceContext context = TraceContext.create("user-1");

        when(partyRepository.findById(partyId))
            .thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.addBlock(partyId, blockId, context))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("Party not found");
    }

    @Test
    @DisplayName("should mark all blocks created")
    void shouldMarkAllBlocksCreated() {
        String partyId = "party-123";
        TraceContext context = TraceContext.create("user-1");
        
        Party party = Party.create(partyId);
        party.addBlock(com.example.party.domain.model.BlockId.of("block-1"));
        
        when(partyRepository.findById(partyId))
            .thenReturn(Optional.of(party));

        service.markAllBlocksCreated(partyId, context);

        verify(partyRepository, times(1)).save(any(Party.class));
        assertThat(party.getStatus()).isEqualTo(com.example.party.domain.model.PartyStatus.ALL_BLOCKS_CREATED);
    }

    @Test
    @DisplayName("should log audit on success")
    void shouldLogAuditOnSuccess() {
        String partyId = "party-123";
        TraceContext context = TraceContext.create("user-1");
        Party party = Party.create(partyId);

        when(partyRepository.save(any(Party.class)))
            .thenReturn(party);

        service.createParty(partyId, context);

        verify(auditService, times(1)).logSuccess(
            "Party", partyId, "Created", party
        );
    }

    @Test
    @DisplayName("should log audit error on failure")
    void shouldLogAuditErrorOnFailure() {
        String partyId = "party-123";
        TraceContext context = TraceContext.create("user-1");

        when(partyRepository.findById(partyId))
            .thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.addBlock(partyId, "block-1", context))
            .isInstanceOf(IllegalArgumentException.class);

        verify(auditService, times(1)).logError(
            eq("Party"), 
            eq(partyId), 
            eq("AddBlockFailed"), 
            any(Exception.class)
        );
    }
}
```

### 3. OutboxProcessorTest.java - Tests du processeur Outbox

```java
package com.example.infrastructure.outbox;

import com.example.infrastructure.audit.AuditService;
import com.example.infrastructure.trace.TraceContextHolder;
import com.example.party.outbox.RemotePartySyncClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collections;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@DisplayName("Outbox Processor Tests")
class OutboxProcessorTest {

    @Mock private OutboxItemRepository outboxRepository;
    @Mock private RemotePartySyncClient remoteClient;
    @Mock private AuditService auditService;

    private OutboxProcessor processor;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        processor = new OutboxProcessor(outboxRepository, remoteClient, auditService);
    }

    @Test
    @DisplayName("should process pending items successfully")
    void shouldProcessPendingItemsSuccessfully() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        
        when(outboxRepository.findByStatusOrderByCreatedAtAsc("PENDING"))
            .thenReturn(Arrays.asList(item));

        processor.processPendingItems();

        verify(remoteClient, times(1)).syncParty("party-123");
        verify(outboxRepository, times(1)).save(any(OutboxItem.class));
        assertThat(item.getStatus()).isEqualTo("SENT");
    }

    @Test
    @DisplayName("should handle error and mark as ERROR with retry calculation")
    void shouldHandleErrorAndMarkAsError() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        
        when(outboxRepository.findByStatusOrderByCreatedAtAsc("PENDING"))
            .thenReturn(Arrays.asList(item));
        
        doThrow(new RuntimeException("Sync failed"))
            .when(remoteClient).syncParty("party-123");

        processor.processPendingItems();

        assertThat(item.getStatus()).isEqualTo("ERROR");
        assertThat(item.getRetryCount()).isEqualTo(1);
        assertThat(item.getLastErrorMessage()).contains("Sync failed");
    }

    @Test
    @DisplayName("should process retry items with exponential backoff")
    void shouldProcessRetryItemsWithExponentialBackoff() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        item.markError("First attempt failed");
        
        assertThat(item.getRetryCount()).isEqualTo(1);
        
        // Le nextRetryAt doit être 2^1 = 2 secondes plus tard
        item.markError("Second attempt failed");
        
        assertThat(item.getRetryCount()).isEqualTo(2);
    }

    @Test
    @DisplayName("should move item to DEAD_LETTER after max retries")
    void shouldMoveItemToDeadLetterAfterMaxRetries() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        
        for (int i = 0; i < 5; i++) {
            item.markError("Attempt " + (i + 1) + " failed");
        }

        assertThat(item.getRetryCount()).isEqualTo(5);
        assertThat(item.isExpired()).isTrue();
    }

    @Test
    @DisplayName("should not retry if max retries not exceeded yet")
    void shouldNotRetryIfMaxRetriesNotExceeded() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        item.markError("First attempt");
        
        assertThat(item.shouldRetry()).isFalse(); // Le nextRetryAt est dans le futur
    }

    @Test
    @DisplayName("should process no items if queue is empty")
    void shouldProcessNoItemsIfQueueIsEmpty() {
        when(outboxRepository.findByStatusOrderByCreatedAtAsc("PENDING"))
            .thenReturn(Collections.emptyList());

        processor.processPendingItems();

        verify(remoteClient, never()).syncParty(anyString());
    }
}
```

### 4. OutboxRetryTest.java - Tests spécifiques aux retries

```java
package com.example.infrastructure.outbox;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.*;

@DisplayName("Outbox Retry Tests")
class OutboxRetryTest {

    @Test
    @DisplayName("should calculate exponential backoff correctly")
    void shouldCalculateExponentialBackoffCorrectly() {
        OutboxItem item = OutboxItem.create("trace-1", "user-1", "corr-1", "party-1");
        
        LocalDateTime createdAt = LocalDateTime.now();
        
        // First retry: 2^1 = 2 seconds
        item.markError("Error 1");
        LocalDateTime nextRetry1 = item.getNextRetryAt();
        long delay1 = java.time.temporal.ChronoUnit.SECONDS.between(createdAt, nextRetry1);
        assertThat(delay1).isCloseTo(2L, org.assertj.core.api.Offset.offset(1L));
        
        // Second retry: 2^2 = 4 seconds
        item.markError("Error 2");
        LocalDateTime nextRetry2 = item.getNextRetryAt();
        long delay2 = java.time.temporal.ChronoUnit.SECONDS.between(nextRetry1, nextRetry2);
        assertThat(delay2).isCloseTo(4L, org.assertj.core.api.Offset.offset(1L));
        
        // Third retry: 2^3 = 8 seconds
        item.markError("Error 3");
        LocalDateTime nextRetry3 = item.getNextRetryAt();
        long delay3 = java.time.temporal.ChronoUnit.SECONDS.between(nextRetry2, nextRetry3);
        assertThat(delay3).isCloseTo(8L, org.assertj.core.api.Offset.offset(1L));
    }

    @Test
    @DisplayName("should cap max delay at 2^10 = 1024 seconds")
    void shouldCapMaxDelay() {
        OutboxItem item = OutboxItem.create("trace-1", "user-1", "corr-1", "party-1");
        
        for (int i = 0; i < 15; i++) {
            item.markError("Error " + (i + 1));
        }
        
        // Vérifier que le retryCount est à 15 mais le délai n'explose pas
        assertThat(item.getRetryCount()).isEqualTo(15);
    }

    @Test
    @DisplayName("should NOT retry if retry count >= max retries")
    void shouldNotRetryIfMaxRetriesReached() {
        OutboxItem item = OutboxItem.create("trace-1", "user-1", "corr-1", "party-1");
        
        for (int i = 0; i < 5; i++) {
            item.markError("Error " + i);
        }
        
        assertThat(item.shouldRetry()).isFalse();
    }

    @Test
    @DisplayName("should preserve error message on retry")
    void shouldPreserveErrorMessageOnRetry() {
        OutboxItem item = OutboxItem.create("trace-1", "user-1", "corr-1", "party-1");
        
        String errorMsg = "Connection timeout";
        item.markError(errorMsg);
        
        assertThat(item.getLastErrorMessage()).isEqualTo(errorMsg);
        assertThat(item.getStatus()).isEqualTo("ERROR");
    }
}
```

### 5. OutboxDLQHandlerTest.java - Tests DLQ

```java
package com.example.infrastructure.outbox;

import com.example.infrastructure.audit.AuditService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@DisplayName("Outbox DLQ Handler Tests")
class OutboxDLQHandlerTest {

    @Mock private OutboxItemRepository outboxRepository;
    @Mock private AuditService auditService;

    private OutboxDLQHandler handler;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        handler = new OutboxDLQHandler(outboxRepository, auditService);
    }

    @Test
    @DisplayName("should move expired items to DEAD_LETTER")
    void shouldMoveExpiredItemsToDeadLetter() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        for (int i = 0; i < 5; i++) {
            item.markError("Error " + i);
        }
        
        when(outboxRepository.findByStatusAndRetryCountGreaterThanEqualOrderByCreatedAtAsc("ERROR", 5))
            .thenReturn(Arrays.asList(item));

        handler.processDLQItems();

        assertThat(item.getStatus()).isEqualTo("DEAD_LETTER");
        verify(outboxRepository, times(1)).save(item);
        verify(auditService, times(1)).logError(
            eq("OutboxDLQ"),
            eq("party-123"),
            eq("DEAD_LETTER"),
            any(Exception.class)
        );
    }

    @Test
    @DisplayName("should log error details when moving to DLQ")
    void shouldLogErrorDetailsWhenMovingToDLQ() {
        OutboxItem item = OutboxItem.create("trace-123", "user-1", "corr-123", "party-123");
        for (int i = 0; i < 5; i++) {
            item.markError("Connection error");
        }
        
        when(outboxRepository.findByStatusAndRetryCountGreaterThanEqualOrderByCreatedAtAsc("ERROR", 5))
            .thenReturn(Arrays.asList(item));

        handler.processDLQItems();

        verify(auditService, times(1)).logError(
            "OutboxDLQ",
            "party-123",
            "DEAD_LETTER",
            new RuntimeException("Max retries exceeded: Connection error")
        );
    }
}
```

### 6. AuditServiceTest.java - Tests de l'audit

```java
package com.example.infrastructure.audit;

import com.example.infrastructure.trace.TraceContext;
import com.example.infrastructure.trace.TraceContextHolder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.Instant;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@DisplayName("Audit Service Tests")
class AuditServiceTest {

    @Mock private AuditEventRepository auditRepository;

    private AuditService auditService;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        objectMapper = new ObjectMapper();
        auditService = new AuditService(auditRepository, objectMapper);
        
        TraceContext context = new TraceContext("trace-123", "user-1", "corr-123", Instant.now());
        TraceContextHolder.set(context);
    }

    @Test
    @DisplayName("should log success event")
    void shouldLogSuccessEvent() {
        auditService.logSuccess("Party", "party-1", "Created", "test-payload");

        verify(auditRepository, times(1)).save(any(AuditEvent.class));
    }

    @Test
    @DisplayName("should log error event")
    void shouldLogErrorEvent() {
        auditService.logError("Party", "party-1", "CreationFailed", 
            new RuntimeException("Test error"));

        verify(auditRepository, times(1)).save(any(AuditEvent.class));
    }

    @Test
    @DisplayName("should log retry event")
    void shouldLogRetryEvent() {
        auditService.logRetry("Party", "party-1", "Sync", 1);

        verify(auditRepository, times(1)).save(any(AuditEvent.class));
    }

    @Test
    @DisplayName("should preserve trace context in audit")
    void shouldPreserveTraceContextInAudit() {
        auditService.logSuccess("Party", "party-1", "Created", "payload");

        verify(auditRepository).save(argThat(event ->
            event.getTraceId().equals("trace-123") &&
            event.getUserId().equals("user-1") &&
            event.getCorrelationId().equals("corr-123")
        ));
    }
}
```

### 7. TraceContextTest.java - Tests du contexte de trace

```java
package com.example.infrastructure.trace;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.assertj.core.api.Assertions.*;

@DisplayName("Trace Context Tests")
class TraceContextTest {

    @Test
    @DisplayName("should create with all fields")
    void shouldCreateWithAllFields() {
        String traceId = "trace-123";
        String userId = "user-1";
        String correlationId = "corr-123";
        
        TraceContext context = new TraceContext(traceId, userId, correlationId, java.time.Instant.now());

        assertThat(context.traceId()).isEqualTo(traceId);
        assertThat(context.userId()).isEqualTo(userId);
        assertThat(context.correlationId()).isEqualTo(correlationId);
    }

    @Test
    @DisplayName("should fail if traceId is blank")
    void shouldFailIfTraceIdIsBlank() {
        assertThatThrownBy(() -> new TraceContext("", "user-1", "corr-1", java.time.Instant.now()))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("traceId cannot be blank");
    }

    @Test
    @DisplayName("should fail if userId is blank")
    void shouldFailIfUserIdIsBlank() {
        assertThatThrownBy(() -> new TraceContext("trace-1", "", "corr-1", java.time.Instant.now()))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("userId cannot be blank");
    }

    @Test
    @DisplayName("should create with factory method")
    void shouldCreateWithFactoryMethod() {
        TraceContext context = TraceContext.create("user-1");

        assertThat(context.traceId()).isNotEmpty();
        assertThat(context.userId()).isEqualTo("user-1");
        assertThat(context.correlationId()).isNotEmpty();
    }

    @Test
    @DisplayName("should create from existing traceId")
    void shouldCreateFromExistingTraceId() {
        String existingTraceId = "trace-existing";
        TraceContext context = TraceContext.from(existingTraceId, "user-1");

        assertThat(context.traceId()).isEqualTo(existingTraceId);
        assertThat(context.userId()).isEqualTo("user-1");
    }
}
```

### 8. TraceContextFilterTest.java - Tests du filter HTTP

```java
package com.example.infrastructure.web;

import com.example.infrastructure.trace.TraceContextHolder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockFilterChain;

import java.io.IOException;
import javax.servlet.ServletException;

import static org.assertj.core.api.Assertions.*;

@DisplayName("Trace Context Filter Tests")
class TraceContextFilterTest {

    private TraceContextFilter filter;

    @BeforeEach
    void setup() {
        filter = new TraceContextFilter();
    }

    @Test
    @DisplayName("should generate traceId if not provided")
    void shouldGenerateTraceIdIfNotProvided() throws IOException, ServletException {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/test");
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        String traceId = response.getHeader("X-Trace-Id");
        assertThat(traceId).isNotEmpty();
    }

    @Test
    @DisplayName("should propagate traceId from request header")
    void shouldPropagateTraceIdFromRequestHeader() throws IOException, ServletException {
        String expectedTraceId = "trace-from-request";
        
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/test");
        request.addHeader("X-Trace-Id", expectedTraceId);
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        String responseTraceId = response.getHeader("X-Trace-Id");
        assertThat(responseTraceId).isEqualTo(expectedTraceId);
    }

    @Test
    @DisplayName("should add correlationId to response")
    void shouldAddCorrelationIdToResponse() throws IOException, ServletException {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/test");
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        String correlationId = response.getHeader("X-Correlation-Id");
        assertThat(correlationId).isNotEmpty();
    }

    @Test
    @DisplayName("should clear context after request")
    void shouldClearContextAfterRequest() throws IOException, ServletException {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/test");
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        assertThat(TraceContextHolder.isPresent()).isFalse();
    }
}
```

### 9. ModulesTest.java - Tests de la structure modulaire

```java
package com.example;

import org.springframework.modulith.core.ApplicationModules;
import org.springframework.modulith.docs.Documenter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.assertj.core.api.Assertions.*;

@DisplayName("Spring Modulith Structure Tests")
class ModulesTest {

    @Test
    @DisplayName("should verify module structure")
    void shouldVerifyModuleStructure() {
        ApplicationModules modules = ApplicationModules.of(PartyServiceApplication.class);
        
        assertThatNoException().isThrownBy(modules::verify);
    }

    @Test
    @DisplayName("should have party module")
    void shouldHavePartyModule() {
        ApplicationModules modules = ApplicationModules.of(PartyServiceApplication.class);
        
        assertThat(modules.stream()
            .anyMatch(m -> m.getName().equals("party")))
            .isTrue();
    }

    @Test
    @DisplayName("should have infrastructure module")
    void shouldHaveInfrastructureModule() {
        ApplicationModules modules = ApplicationModules.of(PartyServiceApplication.class);
        
        assertThat(modules.stream()
            .anyMatch(m -> m.getName().equals("infrastructure")))
            .isTrue();
    }

    @Test
    @DisplayName("should generate module documentation")
    void shouldGenerateModuleDocumentation() {
        ApplicationModules modules = ApplicationModules.of(PartyServiceApplication.class);
        
        assertThatNoException().isThrownBy(() -> {
            new Documenter(modules)
                .writeDocumentationTo(new java.io.File("target/modules"));
        });
    }
}
```

### 10. PartyEndToEndTest.java - Tests E2E

```java
package com.example.party.application;

import com.example.infrastructure.audit.AuditEvent;
import com.example.infrastructure.audit.AuditEventRepository;
import com.example.infrastructure.outbox.OutboxItem;
import com.example.infrastructure.outbox.OutboxItemRepository;
import com.example.infrastructure.trace.TraceContext;
import com.example.party.domain.model.Party;
import com.example.party.domain.repository.PartyRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@DisplayName("Party End-to-End Tests")
class PartyEndToEndTest {

    @Autowired private PartyApplicationService partyService;
    @Autowired private PartyRepository partyRepository;
    @Autowired private AuditEventRepository auditRepository;
    @Autowired private OutboxItemRepository outboxRepository;

    @Test
    @DisplayName("should complete full party creation flow")
    void shouldCompleteFullPartyCreationFlow() {
        // Arrange
        String partyId = "party-e2e-123";
        TraceContext context = TraceContext.create("e2e-user");

        // Act
        Party party = partyService.createParty(partyId, context);
        partyService.addBlock(partyId, "block-1", context);
        partyService.addBlock(partyId, "block-2", context);
        partyService.markAllBlocksCreated(partyId, context);

        // Assert
        Party savedParty = partyRepository.findById(partyId).orElseThrow();
        assertThat(savedParty.getBlockCount()).isEqualTo(2);
        assertThat(savedParty.getStatus()).isEqualTo(com.example.party.domain.model.PartyStatus.ALL_BLOCKS_CREATED);

        // Vérifier l'audit trail
        List<AuditEvent> auditEvents = auditRepository.findByTraceId(context.traceId());
        assertThat(auditEvents).hasSize(4); // PartyCreated, BlockCreated x2, AllBlocksCreated
        assertThat(auditEvents).allMatch(e -> e.getStatus().equals("SUCCESS"));

        // Vérifier l'outbox
        List<OutboxItem> outboxItems = outboxRepository.findByTraceId(context.traceId());
        assertThat(outboxItems).hasSize(1);
        assertThat(outboxItems.get(0).getStatus()).isEqualTo("PENDING");
    }

    @Test
    @DisplayName("should handle failure and audit it")
    void shouldHandleFailureAndAuditIt() {
        // Arrange
        String partyId = "party-fail-123";
        TraceContext context = TraceContext.create("fail-user");

        Party party = partyService.createParty(partyId, context);
        partyService.addBlock(partyId, "block-1", context);

        // Act
        partyService.markAllBlocksCreated(partyId, context);
        
        Party savedParty = partyRepository.findById(partyId).orElseThrow();
        savedParty.markFailed("Test failure");
        partyRepository.save(savedParty);

        // Assert
        List<AuditEvent> failureAudits = auditRepository.findByStatus("FAILURE");
        assertThat(failureAudits).isNotEmpty();
    }
}
```

---

## 📁 Structure des fichiers de test

```
src/test/java/com/example/
├── party/
│   ├── domain/
│   │   ├── model/
│   │   │   ├── PartyTest.java
│   │   │   ├── BlockIdTest.java
│   │   │   └── PartyIdTest.java
│   │   └── events/
│   │       └── PartyEventsTest.java
│   ├── application/
│   │   ├── PartyApplicationServiceTest.java
│   │   ├── PartyAsyncHandlerTest.java
│   │   └── PartyEndToEndTest.java
│   └── outbox/
│       └── OutboxListenerTest.java
├── infrastructure/
│   ├── audit/
│   │   ├── AuditServiceTest.java
│   │   └── AuditTrailListenerTest.java
│   ├── outbox/
│   │   ├── OutboxProcessorTest.java
│   │   ├── OutboxRetryTest.java
│   │   ├── OutboxDLQHandlerTest.java
│   │   └── OutboxItemTest.java
│   ├── trace/
│   │   ├── TraceContextTest.java
│   │   ├── TraceContextHolderTest.java
│   │   └── TraceContextScopeTest.java
│   └── web/
│       └── TraceContextFilterTest.java
└── ModulesTest.java
```

---

## 🧪 Exécuter les tests

```bash
# Tous les tests
mvn test

# Tests d'un package spécifique
mvn test -Dtest=PartyTest

# Tests avec coverage
mvn test jacoco:report

# Tests en mode verbose
mvn test -X

# Tests avec logs DEBUG
mvn test -Dorg.slf4j.simpleLogger.defaultLogLevel=debug
```

---

## ✅ Checklist de test

- [x] Tests unitaires du domaine (agrégat, value objects, invariants)
- [x] Tests du service application (création, ajout de blocks, etc.)
- [x] Tests des erreurs et assertions
- [x] Tests de l'audit (logSuccess, logError, logRetry)
- [x] Tests du retry (exponential backoff, max retries)
- [x] Tests du DLQ (dead letter queue)
- [x] Tests du TraceContext (création, propagation, cleanup)
- [x] Tests du Filter HTTP (génération traceId, propagation, cleanup)
- [x] Tests E2E (flux complet)
- [x] Tests de la structure modulaire
- [x] Tests des invariants métier

Nombre total de tests : **60+**
Coverage cible : **85%+**
