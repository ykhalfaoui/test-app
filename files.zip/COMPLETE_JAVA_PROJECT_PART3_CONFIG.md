# 📋 MIGRATIONS SQL & CONFIGURATION - Partie 3

## V1__Initial_Schema.sql

```sql
-- V1__Initial_Schema.sql
-- Schéma initial pour les parties et blocks

CREATE TABLE IF NOT EXISTS parties (
    id VARCHAR(100) PRIMARY KEY,
    status VARCHAR(50) NOT NULL DEFAULT 'CREATED',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS party_blocks (
    party_id VARCHAR(100) NOT NULL,
    id VARCHAR(100) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (party_id, id),
    FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE CASCADE,
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    trace_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50) NOT NULL,
    
    aggregate_type VARCHAR(100),
    aggregate_id VARCHAR(100),
    
    event_type VARCHAR(100) NOT NULL,
    details LONGTEXT,
    
    status VARCHAR(20) NOT NULL DEFAULT 'SUCCESS',
    error_message LONGTEXT,
    retry_count INT DEFAULT 0,
    
    timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_trace_id (trace_id),
    INDEX idx_user_id (user_id),
    INDEX idx_aggregate_id (aggregate_id),
    INDEX idx_event_type (event_type),
    INDEX idx_status (status),
    INDEX idx_timestamp (timestamp),
    INDEX idx_trace_timestamp (trace_id, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS outbox_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    trace_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50) NOT NULL,
    
    party_id VARCHAR(100) NOT NULL,
    
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING',
    
    retry_count INT NOT NULL DEFAULT 0,
    max_retries INT NOT NULL DEFAULT 5,
    
    next_retry_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    last_error_message LONGTEXT,
    
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_trace_id (trace_id),
    INDEX idx_party_id (party_id),
    INDEX idx_next_retry_at (next_retry_at),
    INDEX idx_status_created (status, created_at),
    INDEX idx_status_next_retry (status, next_retry_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## logback-spring.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <property name="LOG_LEVEL" value="INFO"/>

    <!-- Console Appender -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>
                %d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %X{traceId} %X{userId} - %msg%n
            </pattern>
            <charset>utf8</charset>
        </encoder>
    </appender>

    <!-- Async File Appender -->
    <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>logs/party-service.log</file>
        <encoder>
            <pattern>
                %d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %X{traceId} %X{userId} - %msg%n
            </pattern>
            <charset>utf8</charset>
        </encoder>
        <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
            <fileNamePattern>logs/party-service.%d{yyyy-MM-dd}.%i.gz</fileNamePattern>
            <maxFileSize>10MB</maxFileSize>
            <maxHistory>10</maxHistory>
        </rollingPolicy>
    </appender>

    <!-- Logger configurations -->
    <logger name="com.example" level="DEBUG"/>
    <logger name="org.springframework.web" level="INFO"/>
    <logger name="org.springframework.security" level="DEBUG"/>
    <logger name="org.springframework.data" level="DEBUG"/>

    <!-- Root Logger -->
    <root level="${LOG_LEVEL}">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="FILE"/>
    </root>

    <!-- Profils -->
    <springProfile name="dev">
        <root level="DEBUG">
            <appender-ref ref="CONSOLE"/>
        </root>
    </springProfile>

    <springProfile name="test">
        <root level="INFO">
            <appender-ref ref="CONSOLE"/>
        </root>
    </springProfile>

</configuration>
```

---

## application-test.yml

```yaml
spring:
  application:
    name: party-service-test

  datasource:
    url: jdbc:h2:mem:testdb;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
    driver-class-name: org.h2.Driver
    username: sa
    password:

  jpa:
    hibernate:
      ddl-auto: create-drop
    properties:
      hibernate:
        dialect: org.hibernate.dialect.H2Dialect
        format_sql: true
    show-sql: false

  flyway:
    enabled: false

  h2:
    console:
      enabled: true

logging:
  level:
    root: INFO
    com.example: DEBUG
  pattern:
    console: "%d{HH:mm:ss} [%thread] %-5level %logger{36} - %X{traceId} - %msg%n"

server:
  port: 0  # Random port for tests
```

---

## SecurityConfig.java

```java
package com.example.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable()
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/actuator/health").permitAll()
                .requestMatchers("/actuator/**").authenticated()
                .anyRequest().permitAll()
            )
            .httpBasic();

        return http.build();
    }
}
```

---

## CircuitBreakerConfig.java

```java
package com.example.infrastructure.config;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

@Configuration
public class CircuitBreakerConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(CircuitBreakerConfiguration.class);

    @Bean
    public CircuitBreakerRegistry circuitBreakerRegistry() {
        CircuitBreakerConfig defaultConfig = CircuitBreakerConfig.custom()
            .failureRateThreshold(50.0f)
            .slowCallRateThreshold(50.0f)
            .slowCallDurationThreshold(Duration.ofSeconds(10))
            .waitDurationInOpenState(Duration.ofSeconds(30))
            .permittedNumberOfCallsInHalfOpenState(3)
            .minimumNumberOfCalls(10)
            .automaticTransitionFromOpenToHalfOpenEnabled(true)
            .build();

        CircuitBreakerRegistry registry = CircuitBreakerRegistry.of(defaultConfig);

        registry.getEventPublisher()
            .onEntryAdded(event -> logger.info("Circuit breaker registered: {}", event.getAddedEntry().getName()))
            .onEntryRemoved(event -> logger.info("Circuit breaker removed: {}", event.getRemovedEntry().getName()));

        return registry;
    }

    @Bean
    public CircuitBreaker remotePartySyncCircuitBreaker(CircuitBreakerRegistry registry) {
        return registry.circuitBreaker("remotePartySync", CircuitBreakerConfig.custom()
            .failureRateThreshold(50.0f)
            .waitDurationInOpenState(Duration.ofSeconds(60))
            .minimumNumberOfCalls(5)
            .build());
    }
}
```

---

## RemotePartySyncClientImpl.java (Mock implementation pour tests)

```java
package com.example.party.outbox;

import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class RemotePartySyncClientImpl implements RemotePartySyncClient {

    private static final Logger logger = LoggerFactory.getLogger(RemotePartySyncClientImpl.class);

    @Override
    public void syncParty(String partyId) {
        logger.info("Syncing party: {}", partyId);
        // Simulation of remote call
        // In production, this would call a real external service
        logger.info("Party {} synchronized successfully", partyId);
    }
}
```

---

## docker-compose.yml

```yaml
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    container_name: party-mysql
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: party_db
      MYSQL_USER: party_user
      MYSQL_PASSWORD: party_password
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
      timeout: 20s
      retries: 10

  adminer:
    image: adminer
    container_name: party-adminer
    ports:
      - "8081:8080"
    depends_on:
      - mysql

  prometheus:
    image: prom/prometheus:latest
    container_name: party-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./docker/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus

  grafana:
    image: grafana/grafana:latest
    container_name: party-grafana
    ports:
      - "3000:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: admin
    volumes:
      - grafana_data:/var/lib/grafana
    depends_on:
      - prometheus

volumes:
  mysql_data:
  prometheus_data:
  grafana_data:
```

---

## README.md - Guide d'utilisation complet

```markdown
# 🚀 Party Service - Spring Modulith avec TraceId, Audit et Retry

Projet Java complet demonstrant les meilleures pratiques avec Spring Boot 3, Spring Modulith, et patterns de production (TraceId, Audit Trail, Outbox, Retry, DLQ).

## ✨ Caractéristiques

- ✅ **TraceId en ThreadLocal** - Traçage automatique de tous les logs
- ✅ **Domain-Driven Design** - Agrégats avec invariants métier
- ✅ **Audit Trail complète** - Tous les événements enregistrés
- ✅ **Outbox Pattern** - Garantie de remise "at-least-once"
- ✅ **Retry avec Exponential Backoff** - Résilience automatique
- ✅ **Dead Letter Queue** - Gestion des erreurs définitives
- ✅ **Spring Modulith** - Architecture modulaire vérifiée
- ✅ **60+ tests** - Tests unitaires et d'intégration complets

## 📋 Prérequis

- Java 21+
- Maven 3.8+
- Docker & Docker Compose (optionnel)
- MySQL 8.0+ (optionnel, utilise H2 par défaut pour les tests)

## 🛠️ Démarrage rapide

### 1. Cloner le projet

```bash
git clone <repo>
cd party-service-project
```

### 2. Lancer avec H2 (en mémoire)

```bash
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=dev"
```

### 3. Lancer avec MySQL (optionnel)

```bash
# Démarrer l'infrastructure
docker-compose up -d

# Patienter 10 secondes que MySQL soit prêt
sleep 10

# Lancer l'application
mvn spring-boot:run
```

### 4. Accéder aux services

- **Application** : http://localhost:8080
- **Actuator** : http://localhost:8080/actuator/health
- **Adminer (DB UI)** : http://localhost:8081
- **Prometheus** : http://localhost:9090
- **Grafana** : http://localhost:3000 (admin/admin)

## 🧪 Exécuter les tests

```bash
# Tous les tests
mvn test

# Tests spécifiques
mvn test -Dtest=PartyTest
mvn test -Dtest=OutboxProcessorTest

# Avec coverage (Jacoco)
mvn test jacoco:report
open target/site/jacoco/index.html

# Tests en mode verbose
mvn test -X
```

## 📊 Cas de test couverts

### ✅ Tests du Domaine (Party Aggregate)
- Création avec événement PartyCreated
- Ajout de blocks avec validation
- Marquage comme "all blocks created"
- Marquage comme "synchronized"
- Marquage comme "failed"
- **Invariants métier** :
  - ❌ Pas de blocks sur Party FAILED
  - ❌ Pas de marquage complet sans blocks
  - ❌ Pas de synchronisation sans blocks complets

### ✅ Tests du Service Application
- Création de party avec TraceContext
- Ajout de blocks
- Marquage complet
- Audit logging
- Gestion d'erreurs

### ✅ Tests de l'Outbox (Retry & DLQ)
- Traitement des items PENDING
- Retry avec exponential backoff (2^n secondes)
- Déplacement en ERROR après échec
- Déplacement en DEAD_LETTER après max retries (5)
- Audit du DLQ

### ✅ Tests du TraceContext
- Génération automatique de traceId
- Propagation via ThreadLocal
- Cleanup après requête
- Enrichissement des logs MDC

### ✅ Tests E2E
- Flux complet: création → blocks → synchronisation
- Audit trail complète
- Outbox avec retry
- Gestion des erreurs

### ✅ Tests de la Structure Modulaire
- Vérification des modules détectés
- Vérification des dépendances
- Génération de documentation

## 🏗️ Architecture

```
party-service-project/
├── infrastructure/          # Infrastructure cross-cutting
│   ├── trace/              # TraceContext + ThreadLocal
│   ├── audit/              # Audit trail + AuditService
│   ├── outbox/             # Outbox pattern + Retry + DLQ
│   ├── web/                # Filter HTTP
│   └── config/             # Configurations (Async, Circuit Breaker, etc.)
├── party/                  # Domaine Party
│   ├── domain/
│   │   ├── model/          # Party, Block, Value Objects
│   │   ├── events/         # Domain Events
│   │   └── repository/     # PartyRepository
│   ├── application/        # Application Service
│   └── outbox/             # Outbox listener
└── resources/
    ├── application.yml
    └── db/migration/       # Flyway migrations
```

## 🔄 Flux d'une requête

```
1. HTTP Request
   ↓
2. TraceContextFilter
   ├─ Génère/reçoit traceId
   ├─ Enrichit MDC
   └─ Propage en response headers
   ↓
3. PartyApplicationService
   ├─ @Transactional
   ├─ Crée/modifie Party
   ├─ Événement de domaine émis
   └─ AuditTrailListener reçoit event
   ↓
4. AuditTrailListener
   ├─ Enregistre dans audit_events
   └─ AuditService.logSuccess()
   ↓
5. Si AllBlocksCreated
   ├─ OutboxListener crée OutboxItem
   └─ Status PENDING
   ↓
6. OutboxProcessor (scheduled @5s)
   ├─ Récupère items PENDING
   ├─ Appelle RemotePartySyncClient
   ├─ Mark as SENT ou ERROR
   └─ Si erreur: exponential backoff
   ↓
7. OutboxDLQHandler (scheduled @30s)
   ├─ Vérifie retry_count >= 5
   ├─ Move to DEAD_LETTER
   └─ Alerte critiquealytics

## 📊 Schéma SQL

### parties
```sql
id (PK)          | VARCHAR(100)
status           | CREATED / BLOCKS_IN_PROGRESS / ALL_BLOCKS_CREATED / SYNCHRONIZED / FAILED
created_at       | TIMESTAMP
updated_at       | TIMESTAMP
```

### party_blocks
```sql
party_id (FK)    | VARCHAR(100)
id               | VARCHAR(100)
created_at       | TIMESTAMP
```

### audit_events
```sql
id (PK)          | BIGINT AUTO_INCREMENT
trace_id         | VARCHAR(50)      ← Pour traçabilité
user_id          | VARCHAR(100)
aggregate_id     | VARCHAR(100)     ← party-123
event_type       | VARCHAR(100)     ← PartyCreated, BlockCreated, etc.
status           | SUCCESS/FAILURE/RETRY
error_message    | TEXT
timestamp        | TIMESTAMP
```

### outbox_items
```sql
id (PK)          | BIGINT AUTO_INCREMENT
trace_id         | VARCHAR(50)
party_id         | VARCHAR(100)
status           | PENDING/SENT/ERROR/DEAD_LETTER
retry_count      | INT              ← 0 à 5
max_retries      | INT              ← 5
next_retry_at    | TIMESTAMP        ← 2^retry_count secondes
last_error_msg   | TEXT
```

## 🔍 Requêtes SQL utiles

```sql
-- Audit trail pour un trace
SELECT * FROM audit_events 
WHERE trace_id = 'trace-123' 
ORDER BY timestamp ASC;

-- Items Outbox en attente
SELECT * FROM outbox_items 
WHERE status = 'PENDING' 
ORDER BY created_at ASC;

-- Dead letter items
SELECT * FROM outbox_items 
WHERE status = 'DEAD_LETTER' 
ORDER BY updated_at DESC;

-- Taux de succès par heure
SELECT 
    DATE(timestamp) as date,
    HOUR(timestamp) as hour,
    COUNT(*) as total,
    SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as success,
    ROUND(100.0 * SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) / COUNT(*), 2) as success_rate
FROM audit_events
WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY DATE(timestamp), HOUR(timestamp)
ORDER BY date DESC, hour DESC;
```

## 🎯 Métriques Prometheus

```
# Métriques disponibles sur http://localhost:9090/metrics

http_requests_total         # Total des requêtes HTTP
http_request_duration_ms    # Latence des requêtes
jpa_entitymanager_create    # Créations d'entités
db_client_connections       # Connexions DB
process_uptime_seconds      # Uptime du process
```

## 📝 Exemples d'utilisation

### Créer une Party via API

```bash
curl -X POST http://localhost:8080/api/parties \
  -H "Content-Type: application/json" \
  -H "X-Trace-Id: trace-manual-1" \
  -d '{"id": "party-123"}'
```

### Consulter les logs avec traceId

```bash
grep "trace-manual-1" logs/party-service.log
```

### Vérifier l'audit trail

```sql
SELECT event_type, status, timestamp 
FROM audit_events 
WHERE trace_id = 'trace-manual-1';
```

## 🐛 Debugging

### MDC inclus dans tous les logs

```
[20:45:30] ... - traceId=trace-123 userId=user-1 - Party created
```

### Traces distribuées avec X-Trace-Id

```bash
# Requête avec traceId custom
curl -H "X-Trace-Id: my-trace-id" ...

# Response headers incluent le traceId
X-Trace-Id: my-trace-id
X-Correlation-Id: auto-generated
```

## 🚀 Production

Pour passer en production:

1. **Changer le profil** : `spring.profiles.active=prod`
2. **Configurer MySQL** : `src/main/resources/application-prod.yml`
3. **Activer Flyway** : `spring.flyway.enabled=true`
4. **Monitoring** : Prometheus + Grafana
5. **Alertes** : Configurer des DLQ handlers avec Slack/PagerDuty
6. **Secrets** : Utiliser Spring Cloud Config ou Vault

## 📚 Références

- [Spring Boot 3 Docs](https://docs.spring.io/spring-boot/docs/current/reference/)
- [Spring Modulith](https://spring.io/projects/spring-modulith)
- [Domain-Driven Design](https://www.domainlanguage.com/)
- [Outbox Pattern](https://microservices.io/patterns/data/transactional-outbox.html)

## 📞 Support

Pour des questions ou problèmes, consultez les tests dans `src/test/java/com/example/` pour des exemples d'utilisation.

---

**Créé avec ❤️ pour le développement production-ready**
```

---

## 📊 Fichiers de configuration Prometheus

```yaml
# docker/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'party-service'
    static_configs:
      - targets: ['localhost:8080']
    metrics_path: '/actuator/prometheus'
```

---

## 🎯 Commandes utiles

```bash
# Build
mvn clean package

# Tests avec coverage
mvn clean test jacoco:report

# Vérifier la structure modulaire
mvn spring-modulith:list

# Générer la documentation des modules
mvn spring-modulith:document

# Démarrer en développement
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=dev"

# Démarrer en production
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=prod"

# Nettoyer
mvn clean

# Compiler sans tests
mvn clean compile

# Créer un JAR
mvn clean package -DskipTests
```

---

## ✅ Checklist pré-production

- [ ] Tous les tests passent (`mvn test`)
- [ ] Coverage > 80% (`mvn test jacoco:report`)
- [ ] Structure modulaire vérifiée (`mvn spring-modulith:verify`)
- [ ] Logs contiennent traceId (`grep traceId logs/`)
- [ ] Audit trail visible en BD
- [ ] Retry + DLQ fonctionne
- [ ] Monitoring Prometheus actif
- [ ] Circuit breaker testé
- [ ] Database migrations Flyway à jour
- [ ] Variables d'environnement configurées

Bonne chance! 🚀
