# 📦 PROJET JAVA COMPLET - Tous les fichiers sources

Voici la liste complète des fichiers à créer. J'ai organisé tout le code dans ce document pour que tu puisses copier-coller facilement.

---

## 🏗️ STRUCTURE DU PROJET

```
party-service-project/
├── pom.xml
├── src/main/
│   ├── java/com/example/
│   │   ├── PartyServiceApplication.java (main)
│   │   ├── infrastructure/
│   │   │   ├── trace/
│   │   │   │   ├── TraceContext.java
│   │   │   │   ├── TraceContextHolder.java
│   │   │   │   └── TraceContextScope.java
│   │   │   ├── audit/
│   │   │   │   ├── AuditEvent.java
│   │   │   │   ├── AuditEventRepository.java
│   │   │   │   ├── AuditService.java
│   │   │   │   └── AuditTrailListener.java
│   │   │   ├── outbox/
│   │   │   │   ├── OutboxItem.java
│   │   │   │   ├── OutboxItemRepository.java
│   │   │   │   ├── OutboxProcessor.java
│   │   │   │   └── OutboxDLQHandler.java
│   │   │   ├── web/
│   │   │   │   └── TraceContextFilter.java
│   │   │   └── config/
│   │   │       ├── AsyncConfig.java
│   │   │       ├── CircuitBreakerConfig.java
│   │   │       └── SecurityConfig.java
│   │   └── party/
│   │       ├── domain/
│   │       │   ├── model/
│   │       │   │   ├── Party.java
│   │       │   │   ├── PartyId.java
│   │       │   │   ├── PartyStatus.java
│   │       │   │   ├── Block.java
│   │       │   │   └── BlockId.java
│   │       │   ├── events/
│   │       │   │   ├── PartyCreated.java
│   │       │   │   ├── BlockCreated.java
│   │       │   │   ├── AllBlocksCreated.java
│   │       │   │   ├── SynchronizedBlock.java
│   │       │   │   └── PartyFailed.java
│   │       │   └── repository/
│   │       │       └── PartyRepository.java
│   │       ├── application/
│   │       │   ├── PartyApplicationService.java
│   │       │   ├── PartyAsyncHandler.java
│   │       │   └── IncomingPartyEvent.java
│   │       └── outbox/
│   │           ├── OutboxListener.java
│   │           └── RemotePartySyncClient.java
│   └── resources/
│       ├── application.yml
│       ├── logback-spring.xml
│       └── db/migration/
│           └── V1__Initial_Schema.sql
└── src/test/
    └── java/com/example/
        ├── party/
        │   ├── domain/
        │   │   ├── model/
        │   │   │   ├── PartyTest.java
        │   │   │   └── PartyAggregateInvariantsTest.java
        │   │   └── events/
        │   │       └── PartyEventsTest.java
        │   └── application/
        │       ├── PartyApplicationServiceTest.java
        │       ├── PartyAsyncHandlerTest.java
        │       └── PartyEndToEndTest.java
        ├── infrastructure/
        │   ├── audit/
        │   │   ├── AuditServiceTest.java
        │   │   └── AuditTrailListenerTest.java
        │   ├── outbox/
        │   │   ├── OutboxProcessorTest.java
        │   │   ├── OutboxRetryTest.java
        │   │   └── OutboxDLQHandlerTest.java
        │   ├── trace/
        │   │   └── TraceContextTest.java
        │   └── web/
        │       └── TraceContextFilterTest.java
        └── ModulesTest.java
```

---

## 📄 FICHIERS JAVA - Code complet

### 1. PartyServiceApplication.java

```java
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.modulith.Modulith;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@Modulith(
    displayName = "Party Service",
    additionalPackages = {"com.example.infrastructure"}
)
@EnableAsync
@EnableScheduling
public class PartyServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PartyServiceApplication.class, args);
    }
}
```

### 2. TraceContextScope.java

```java
package com.example.infrastructure.trace;

import java.util.Optional;

public final class TraceContextScope implements AutoCloseable {

    private final TraceContext previous;

    public TraceContextScope(String traceId, String userId) {
        this.previous = TraceContextHolder.get();
        TraceContextHolder.set(TraceContext.from(traceId, userId));
    }

    public TraceContextScope(TraceContext context) {
        this.previous = TraceContextHolder.get();
        TraceContextHolder.set(context);
    }

    public static TraceContextScope from(TraceContext context) {
        return new TraceContextScope(context);
    }

    public TraceContext getCurrent() {
        return TraceContextHolder.get();
    }

    @Override
    public void close() {
        TraceContextHolder.set(previous);
    }
}
```

### 3. AsyncConfig.java - 🔑 FIX THREADLOCAL

```java
package com.example.infrastructure.config;

import com.example.infrastructure.trace.TraceContextHolder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.concurrent.Executor;

@Configuration
public class AsyncConfig implements AsyncConfigurer {

    @Override
    public Executor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("async-");
        
        // 🔑 TaskDecorator pour propager le contexte ThreadLocal
        executor.setTaskDecorator(runnable -> {
            var ctx = TraceContextHolder.get();
            return () -> {
                TraceContextHolder.set(ctx);
                try {
                    runnable.run();
                } finally {
                    TraceContextHolder.clear();
                }
            };
        });
        
        executor.initialize();
        return executor;
    }

    @Bean(name = "tracedTaskScheduler")
    public ThreadPoolTaskScheduler tracedTaskScheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(5);
        scheduler.setThreadNamePrefix("scheduler-");
        
        scheduler.setTaskDecorator(runnable -> {
            var ctx = TraceContextHolder.get();
            return () -> {
                TraceContextHolder.set(ctx);
                try {
                    runnable.run();
                } finally {
                    TraceContextHolder.clear();
                }
            };
        });
        
        scheduler.initialize();
        return scheduler;
    }
}
```

### 4. PartyId.java - Value Object

```java
package com.example.party.domain.model;

import jakarta.persistence.Embeddable;
import java.util.UUID;

@Embeddable
public final class PartyId {
    
    private String id;

    protected PartyId() {}

    private PartyId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("PartyId cannot be blank");
        }
        this.id = id;
    }

    public static PartyId of(String value) {
        return new PartyId(value);
    }

    public static PartyId generate() {
        return new PartyId(UUID.randomUUID().toString());
    }

    public String value() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PartyId)) return false;
        return id.equals(((PartyId) o).id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return id;
    }
}
```

### 5. BlockId.java - Value Object

```java
package com.example.party.domain.model;

import jakarta.persistence.Embeddable;
import java.util.UUID;

@Embeddable
public final class BlockId {
    
    private String id;

    protected BlockId() {}

    private BlockId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("BlockId cannot be blank");
        }
        this.id = id;
    }

    public static BlockId of(String value) {
        return new BlockId(value);
    }

    public static BlockId generate() {
        return new BlockId(UUID.randomUUID().toString());
    }

    public String value() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BlockId)) return false;
        return id.equals(((BlockId) o).id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
```

### 6. PartyStatus.java - Enum Value Object

```java
package com.example.party.domain.model;

public enum PartyStatus {
    CREATED,
    BLOCKS_IN_PROGRESS,
    ALL_BLOCKS_CREATED,
    SYNCHRONIZED,
    FAILED;

    public boolean canAddBlocks() {
        return this == CREATED || this == BLOCKS_IN_PROGRESS;
    }

    public boolean canSynchronize() {
        return this == ALL_BLOCKS_CREATED;
    }
}
```

### 7. Block.java - Entité imbriquée

```java
package com.example.party.domain.model;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Embedded;
import java.time.Instant;

@Embeddable
public final class Block {
    
    @Embedded
    private BlockId id;
    
    private Instant createdAt;

    protected Block() {}

    private Block(BlockId id) {
        this.id = id;
        this.createdAt = Instant.now();
    }

    public static Block create(BlockId blockId) {
        return new Block(blockId);
    }

    public BlockId getId() {
        return id;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Block)) return false;
        return id.equals(((Block) o).id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
```

### 8. Party.java - Agrégat avec invariants

```java
package com.example.party.domain.model;

import com.example.party.domain.events.*;
import jakarta.persistence.*;
import org.springframework.data.domain.AfterDomainEventPublication;
import org.springframework.data.domain.DomainEvents;

import java.time.Instant;
import java.util.*;

@Entity
@Table(name = "parties")
public class Party {

    @EmbeddedId
    private PartyId id;

    @Enumerated(EnumType.STRING)
    private PartyStatus status;

    @ElementCollection
    @CollectionTable(name = "party_blocks", joinColumns = @JoinColumn(name = "party_id"))
    private List<Block> blocks = new ArrayList<>();

    private Instant createdAt;
    private Instant updatedAt;

    @Transient
    private final List<Object> domainEvents = new ArrayList<>();

    protected Party() {}

    private Party(PartyId id) {
        this.id = Objects.requireNonNull(id, "PartyId cannot be null");
        this.status = PartyStatus.CREATED;
        this.createdAt = Instant.now();
        this.updatedAt = Instant.now();
        recordEvent(new PartyCreated(id.value()));
    }

    public static Party create(PartyId partyId) {
        return new Party(partyId);
    }

    public static Party create(String partyId) {
        return new Party(PartyId.of(partyId));
    }

    public void addBlock(BlockId blockId) {
        if (!status.canAddBlocks()) {
            throw new IllegalStateException(
                "Cannot add block to party in status: " + status
            );
        }

        Block newBlock = Block.create(blockId);
        blocks.add(newBlock);
        status = PartyStatus.BLOCKS_IN_PROGRESS;
        updatedAt = Instant.now();

        recordEvent(new BlockCreated(id.value(), blockId.value()));
    }

    public void markAllBlocksCreated() {
        if (blocks.isEmpty()) {
            throw new IllegalStateException("Cannot mark complete: no blocks created");
        }
        if (status != PartyStatus.BLOCKS_IN_PROGRESS && status != PartyStatus.CREATED) {
            throw new IllegalStateException(
                "Cannot mark complete in status: " + status
            );
        }

        status = PartyStatus.ALL_BLOCKS_CREATED;
        updatedAt = Instant.now();
        recordEvent(new AllBlocksCreated(id.value(), blocks.size()));
    }

    public void markSynchronized() {
        if (!status.canSynchronize()) {
            throw new IllegalStateException(
                "Cannot synchronize party in status: " + status
            );
        }

        status = PartyStatus.SYNCHRONIZED;
        updatedAt = Instant.now();
        recordEvent(new SynchronizedBlock(id.value()));
    }

    public void markFailed(String reason) {
        if (status == PartyStatus.FAILED) {
            return;
        }
        status = PartyStatus.FAILED;
        updatedAt = Instant.now();
        recordEvent(new PartyFailed(id.value(), reason));
    }

    private void recordEvent(Object event) {
        domainEvents.add(Objects.requireNonNull(event, "Event cannot be null"));
    }

    // ===== Accesseurs =====

    public PartyId getId() {
        return id;
    }

    public PartyStatus getStatus() {
        return status;
    }

    public List<Block> getBlocks() {
        return Collections.unmodifiableList(blocks);
    }

    public int getBlockCount() {
        return blocks.size();
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    @DomainEvents
    public Collection<Object> getDomainEvents() {
        return Collections.unmodifiableCollection(new ArrayList<>(domainEvents));
    }

    @AfterDomainEventPublication
    public void clearDomainEvents() {
        domainEvents.clear();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Party)) return false;
        return Objects.equals(id, ((Party) o).id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Party{" +
                "id=" + id +
                ", status=" + status +
                ", blockCount=" + blocks.size() +
                ", createdAt=" + createdAt +
                '}';
    }
}
```

### 9. PartyRepository.java

```java
package com.example.party.domain.repository;

import com.example.party.domain.model.Party;
import com.example.party.domain.model.PartyId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PartyRepository extends JpaRepository<Party, String> {

    Optional<Party> findById(PartyId id);

    default Party getReferenceById(PartyId id) {
        return getReferenceById(id.value());
    }
}
```

### 10. Domain Events

```java
// PartyCreated.java
package com.example.party.domain.events;
public record PartyCreated(String partyId) {}

// BlockCreated.java
package com.example.party.domain.events;
public record BlockCreated(String partyId, String blockId) {}

// AllBlocksCreated.java
package com.example.party.domain.events;
public record AllBlocksCreated(String partyId, int blockCount) {}

// SynchronizedBlock.java
package com.example.party.domain.events;
public record SynchronizedBlock(String partyId) {}

// PartyFailed.java
package com.example.party.domain.events;
public record PartyFailed(String partyId, String reason) {}
```

### 11. AuditEvent.java

```java
package com.example.infrastructure.audit;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "audit_events", indexes = {
    @Index(name = "idx_trace_id", columnList = "trace_id"),
    @Index(name = "idx_user_id", columnList = "user_id"),
    @Index(name = "idx_aggregate_id", columnList = "aggregate_id"),
    @Index(name = "idx_timestamp", columnList = "timestamp")
})
public class AuditEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String traceId;

    @Column(nullable = false, length = 100)
    private String userId;

    @Column(nullable = false, length = 50)
    private String correlationId;

    @Column(length = 100)
    private String aggregateType;

    @Column(length = 100)
    private String aggregateId;

    @Column(nullable = false, length = 100)
    private String eventType;

    @Column(columnDefinition = "TEXT")
    private String details;

    @Column(length = 20)
    private String status;

    @Column(columnDefinition = "TEXT")
    private String errorMessage;

    @Column(nullable = false)
    private Instant timestamp;

    private int retryCount = 0;

    protected AuditEvent() {}

    private AuditEvent(Builder builder) {
        this.traceId = builder.traceId;
        this.userId = builder.userId;
        this.correlationId = builder.correlationId;
        this.aggregateType = builder.aggregateType;
        this.aggregateId = builder.aggregateId;
        this.eventType = builder.eventType;
        this.details = builder.details;
        this.status = builder.status;
        this.errorMessage = builder.errorMessage;
        this.timestamp = builder.timestamp;
    }

    public static class Builder {
        private String traceId;
        private String userId;
        private String correlationId;
        private String aggregateType;
        private String aggregateId;
        private String eventType;
        private String details;
        private String status = "SUCCESS";
        private String errorMessage;
        private Instant timestamp = Instant.now();

        public Builder traceId(String traceId) { this.traceId = traceId; return this; }
        public Builder userId(String userId) { this.userId = userId; return this; }
        public Builder correlationId(String correlationId) { this.correlationId = correlationId; return this; }
        public Builder aggregateType(String type) { this.aggregateType = type; return this; }
        public Builder aggregateId(String id) { this.aggregateId = id; return this; }
        public Builder eventType(String type) { this.eventType = type; return this; }
        public Builder details(String details) { this.details = details; return this; }
        public Builder status(String status) { this.status = status; return this; }
        public Builder error(String message) { this.status = "FAILURE"; this.errorMessage = message; return this; }
        public Builder timestamp(Instant ts) { this.timestamp = ts; return this; }

        public AuditEvent build() {
            return new AuditEvent(this);
        }
    }

    // ===== Accesseurs =====
    public Long getId() { return id; }
    public String getTraceId() { return traceId; }
    public String getUserId() { return userId; }
    public String getCorrelationId() { return correlationId; }
    public String getAggregateType() { return aggregateType; }
    public String getAggregateId() { return aggregateId; }
    public String getEventType() { return eventType; }
    public String getDetails() { return details; }
    public String getStatus() { return status; }
    public String getErrorMessage() { return errorMessage; }
    public Instant getTimestamp() { return timestamp; }
    public int getRetryCount() { return retryCount; }

    public void incrementRetry() { this.retryCount++; }
    public void setStatus(String status) { this.status = status; }
    public void setErrorMessage(String msg) { this.errorMessage = msg; }
}
```

### 12. AuditEventRepository.java

```java
package com.example.infrastructure.audit;

import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.List;

public interface AuditEventRepository extends JpaRepository<AuditEvent, Long> {

    List<AuditEvent> findByTraceId(String traceId);
    List<AuditEvent> findByUserId(String userId);
    List<AuditEvent> findByAggregateId(String aggregateId);
    List<AuditEvent> findByStatus(String status);
    List<AuditEvent> findByTimestampBetween(Instant start, Instant end);
}
```

### 13. AuditService.java

```java
package com.example.infrastructure.audit;

import com.example.infrastructure.trace.TraceContextHolder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;

@Service
public class AuditService {

    private static final Logger logger = LoggerFactory.getLogger(AuditService.class);
    private final AuditEventRepository auditRepository;
    private final ObjectMapper objectMapper;

    public AuditService(AuditEventRepository auditRepository, ObjectMapper objectMapper) {
        this.auditRepository = auditRepository;
        this.objectMapper = objectMapper;
    }

    public void logSuccess(String aggregateType, String aggregateId, String eventType, Object payload) {
        var ctx = TraceContextHolder.get();
        
        try {
            String details = payload != null ? objectMapper.writeValueAsString(payload) : null;
            
            AuditEvent audit = new AuditEvent.Builder()
                .traceId(ctx.traceId())
                .userId(ctx.userId())
                .correlationId(ctx.correlationId())
                .aggregateType(aggregateType)
                .aggregateId(aggregateId)
                .eventType(eventType)
                .details(details)
                .status("SUCCESS")
                .timestamp(Instant.now())
                .build();
            
            auditRepository.save(audit);
        } catch (Exception e) {
            logger.error("Failed to audit event: {} for {} {}", eventType, aggregateType, aggregateId, e);
        }
    }

    public void logError(String aggregateType, String aggregateId, String eventType, Exception error) {
        var ctx = TraceContextHolder.get();
        
        try {
            AuditEvent audit = new AuditEvent.Builder()
                .traceId(ctx.traceId())
                .userId(ctx.userId())
                .correlationId(ctx.correlationId())
                .aggregateType(aggregateType)
                .aggregateId(aggregateId)
                .eventType(eventType)
                .error(error.getMessage())
                .timestamp(Instant.now())
                .build();
            
            auditRepository.save(audit);
        } catch (Exception e) {
            logger.error("Failed to audit error: {}", eventType, e);
        }
    }

    public void logRetry(String aggregateType, String aggregateId, String eventType, int retryCount) {
        var ctx = TraceContextHolder.get();
        
        try {
            AuditEvent audit = new AuditEvent.Builder()
                .traceId(ctx.traceId())
                .userId(ctx.userId())
                .correlationId(ctx.correlationId())
                .aggregateType(aggregateType)
                .aggregateId(aggregateId)
                .eventType(eventType + "_RETRY_#" + retryCount)
                .status("RETRY")
                .timestamp(Instant.now())
                .build();
            
            auditRepository.save(audit);
        } catch (Exception e) {
            logger.error("Failed to audit retry: {}", eventType, e);
        }
    }
}
```

### 14. AuditTrailListener.java

```java
package com.example.infrastructure.audit;

import com.example.party.domain.events.*;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class AuditTrailListener {

    private static final Logger logger = LoggerFactory.getLogger(AuditTrailListener.class);
    private final AuditService auditService;

    public AuditTrailListener(AuditService auditService) {
        this.auditService = auditService;
    }

    @EventListener
    public void on(PartyCreated event) {
        auditService.logSuccess("Party", event.partyId(), "PartyCreated", event);
    }

    @EventListener
    public void on(BlockCreated event) {
        auditService.logSuccess("Block", event.blockId(), "BlockCreated", event);
    }

    @EventListener
    public void on(AllBlocksCreated event) {
        auditService.logSuccess("Party", event.partyId(), "AllBlocksCreated", event);
    }

    @EventListener
    public void on(SynchronizedBlock event) {
        auditService.logSuccess("Party", event.partyId(), "SynchronizedBlock", event);
    }

    @EventListener
    public void on(PartyFailed event) {
        auditService.logError("Party", event.partyId(), "PartyFailed", 
            new RuntimeException(event.reason()));
    }
}
```

### 15. OutboxItem.java

```java
package com.example.infrastructure.outbox;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "outbox_items", indexes = {
    @Index(name = "idx_status", columnList = "status"),
    @Index(name = "idx_trace_id", columnList = "trace_id"),
    @Index(name = "idx_next_retry", columnList = "next_retry_at")
})
public class OutboxItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String traceId;

    @Column(nullable = false, length = 100)
    private String userId;

    @Column(nullable = false, length = 50)
    private String correlationId;

    @Column(nullable = false, length = 100)
    private String partyId;

    @Column(nullable = false, length = 50)
    private String status;

    @Column(nullable = false)
    private int retryCount = 0;

    @Column(nullable = false)
    private int maxRetries = 5;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime nextRetryAt;

    @Column(columnDefinition = "TEXT")
    private String lastErrorMessage;

    public static OutboxItem create(String traceId, String userId, String correlationId, String partyId) {
        OutboxItem item = new OutboxItem();
        item.traceId = traceId;
        item.userId = userId;
        item.correlationId = correlationId;
        item.partyId = partyId;
        item.status = "PENDING";
        item.retryCount = 0;
        item.createdAt = LocalDateTime.now();
        item.nextRetryAt = LocalDateTime.now();
        return item;
    }

    public boolean shouldRetry() {
        return "ERROR".equals(status) 
            && retryCount < maxRetries 
            && LocalDateTime.now().isAfter(nextRetryAt);
    }

    public void markSent() {
        this.status = "SENT";
        this.lastErrorMessage = null;
    }

    public void markError(String errorMessage) {
        this.status = "ERROR";
        this.lastErrorMessage = errorMessage;
        this.retryCount++;
        long secondsDelay = (long) Math.pow(2, Math.min(retryCount, 10));
        this.nextRetryAt = LocalDateTime.now().plusSeconds(secondsDelay);
    }

    public void markDeadLetter() {
        this.status = "DEAD_LETTER";
    }

    public boolean isExpired() {
        return retryCount >= maxRetries;
    }

    // ===== Accesseurs =====
    public Long getId() { return id; }
    public String getTraceId() { return traceId; }
    public String getUserId() { return userId; }
    public String getCorrelationId() { return correlationId; }
    public String getPartyId() { return partyId; }
    public String getStatus() { return status; }
    public int getRetryCount() { return retryCount; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getNextRetryAt() { return nextRetryAt; }
    public String getLastErrorMessage() { return lastErrorMessage; }
}
```

### 16. OutboxItemRepository.java

```java
package com.example.infrastructure.outbox;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OutboxItemRepository extends JpaRepository<OutboxItem, Long> {

    List<OutboxItem> findByStatusOrderByCreatedAtAsc(String status);
    List<OutboxItem> findByStatusAndRetryCountLessThanOrderByNextRetryAtAsc(String status, int maxRetries);
    List<OutboxItem> findByStatusAndRetryCountGreaterThanEqualOrderByCreatedAtAsc(String status, int retries);
    List<OutboxItem> findByTraceId(String traceId);
}
```

### 17. OutboxProcessor.java

```java
package com.example.infrastructure.outbox;

import com.example.infrastructure.trace.TraceContextScope;
import com.example.infrastructure.audit.AuditService;
import com.example.party.outbox.RemotePartySyncClient;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Component
public class OutboxProcessor {

    private static final Logger logger = LoggerFactory.getLogger(OutboxProcessor.class);
    
    private final OutboxItemRepository outboxRepository;
    private final RemotePartySyncClient remoteClient;
    private final AuditService auditService;

    public OutboxProcessor(
        OutboxItemRepository outboxRepository,
        RemotePartySyncClient remoteClient,
        AuditService auditService
    ) {
        this.outboxRepository = outboxRepository;
        this.remoteClient = remoteClient;
        this.auditService = auditService;
    }

    @Scheduled(fixedDelay = 5000, initialDelay = 2000)
    public void processPendingItems() {
        List<OutboxItem> pending = outboxRepository
            .findByStatusOrderByCreatedAtAsc("PENDING");

        for (OutboxItem item : pending) {
            processItem(item);
        }
    }

    @Scheduled(fixedDelay = 10000, initialDelay = 3000)
    public void processRetryItems() {
        List<OutboxItem> retryItems = outboxRepository
            .findByStatusAndRetryCountLessThanOrderByNextRetryAtAsc("ERROR", 5);

        for (OutboxItem item : retryItems) {
            if (item.shouldRetry()) {
                processItemWithRetry(item);
            }
        }
    }

    private void processItem(OutboxItem item) {
        try (var scope = new TraceContextScope(item.getTraceId(), item.getUserId())) {
            
            auditService.logSuccess(
                "OutboxProcessor", 
                item.getPartyId(), 
                "RemoteSync_START", 
                null
            );

            remoteClient.syncParty(item.getPartyId());
            
            item.markSent();
            outboxRepository.save(item);
            
            auditService.logSuccess(
                "OutboxProcessor", 
                item.getPartyId(), 
                "RemoteSync_SUCCESS", 
                null
            );
            
            logger.info("Successfully processed outbox item: party={}, traceId={}", 
                item.getPartyId(), item.getTraceId());
                
        } catch (Exception e) {
            handleProcessingError(item, e);
        }
    }

    private void processItemWithRetry(OutboxItem item) {
        try (var scope = new TraceContextScope(item.getTraceId(), item.getUserId())) {
            
            auditService.logRetry(
                "OutboxProcessor", 
                item.getPartyId(), 
                "RemoteSync", 
                item.getRetryCount() + 1
            );

            remoteClient.syncParty(item.getPartyId());
            
            item.markSent();
            outboxRepository.save(item);
            
            logger.info("Retry succeeded for outbox item: party={}, retry_count={}, traceId={}", 
                item.getPartyId(), item.getRetryCount(), item.getTraceId());
                
        } catch (Exception e) {
            handleProcessingError(item, e);
        }
    }

    private void handleProcessingError(OutboxItem item, Exception error) {
        try (var scope = new TraceContextScope(item.getTraceId(), item.getUserId())) {
            
            item.markError(error.getMessage());
            outboxRepository.save(item);
            
            auditService.logError(
                "OutboxProcessor", 
                item.getPartyId(), 
                "RemoteSync_ERROR", 
                error
            );

            if (item.isExpired()) {
                logger.error("Max retries exceeded for party {}: {}", 
                    item.getPartyId(), error.getMessage());
            } else {
                logger.warn("Processing failed for outbox item: party={}, retry_count={}, error={}", 
                    item.getPartyId(), item.getRetryCount(), error.getMessage());
            }
            
        } catch (Exception e) {
            logger.error("Failed to handle outbox error", e);
        }
    }
}
```

### 18. OutboxDLQHandler.java

```java
package com.example.infrastructure.outbox;

import com.example.infrastructure.trace.TraceContextScope;
import com.example.infrastructure.audit.AuditService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Component
public class OutboxDLQHandler {

    private static final Logger logger = LoggerFactory.getLogger(OutboxDLQHandler.class);
    
    private final OutboxItemRepository outboxRepository;
    private final AuditService auditService;

    public OutboxDLQHandler(
        OutboxItemRepository outboxRepository,
        AuditService auditService
    ) {
        this.outboxRepository = outboxRepository;
        this.auditService = auditService;
    }

    @Scheduled(fixedDelay = 30000, initialDelay = 5000)
    public void processDLQItems() {
        List<OutboxItem> expiredItems = outboxRepository
            .findByStatusAndRetryCountGreaterThanEqualOrderByCreatedAtAsc("ERROR", 5);

        for (OutboxItem item : expiredItems) {
            processDLQ(item);
        }
    }

    private void processDLQ(OutboxItem item) {
        try (var scope = new TraceContextScope(item.getTraceId(), item.getUserId())) {
            
            logger.error(
                "CRITICAL: Outbox item moved to DLQ - party: {}, attempts: {}, error: {}",
                item.getPartyId(),
                item.getRetryCount(),
                item.getLastErrorMessage()
            );

            item.markDeadLetter();
            outboxRepository.save(item);

            auditService.logError(
                "OutboxDLQ",
                item.getPartyId(),
                "DEAD_LETTER",
                new RuntimeException("Max retries exceeded: " + item.getLastErrorMessage())
            );
            
        } catch (Exception e) {
            logger.error("Failed to process DLQ item", e);
        }
    }
}
```

### 19. OutboxListener.java

```java
package com.example.party.outbox;

import com.example.infrastructure.outbox.OutboxItem;
import com.example.infrastructure.outbox.OutboxItemRepository;
import com.example.infrastructure.trace.TraceContextHolder;
import com.example.party.domain.events.AllBlocksCreated;
import org.springframework.modulith.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class OutboxListener {

    private static final Logger logger = LoggerFactory.getLogger(OutboxListener.class);
    private final OutboxItemRepository outboxRepository;

    public OutboxListener(OutboxItemRepository outboxRepository) {
        this.outboxRepository = outboxRepository;
    }

    @ApplicationModuleListener
    public void on(AllBlocksCreated event) {
        var ctx = TraceContextHolder.get();
        
        try {
            OutboxItem item = OutboxItem.create(
                ctx.traceId(),
                ctx.userId(),
                ctx.correlationId(),
                event.partyId()
            );
            
            outboxRepository.save(item);
            
            logger.info("Outbox item created: party={}, traceId={}", 
                event.partyId(), ctx.traceId());
                
        } catch (Exception e) {
            logger.error("Failed to create outbox item for party {}", event.partyId(), e);
        }
    }
}
```

### 20. RemotePartySyncClient.java

```java
package com.example.party.outbox;

public interface RemotePartySyncClient {
    void syncParty(String partyId);
}
```

### 21. PartyApplicationService.java

```java
package com.example.party.application;

import com.example.infrastructure.audit.AuditService;
import com.example.infrastructure.trace.TraceContext;
import com.example.infrastructure.trace.TraceContextScope;
import com.example.party.domain.model.*;
import com.example.party.domain.repository.PartyRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@Transactional
public class PartyApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(PartyApplicationService.class);
    
    private final PartyRepository partyRepository;
    private final AuditService auditService;

    public PartyApplicationService(PartyRepository partyRepository, AuditService auditService) {
        this.partyRepository = partyRepository;
        this.auditService = auditService;
    }

    public Party createParty(String externalPartyId, TraceContext context) {
        try (var scope = new TraceContextScope(context)) {
            
            PartyId partyId = PartyId.of(externalPartyId);
            Party party = Party.create(partyId);
            
            Party saved = partyRepository.save(party);
            
            auditService.logSuccess(
                "Party", 
                party.getId().value(), 
                "Created", 
                party
            );
            
            logger.info("Party created: {}", party.getId());
            return saved;
            
        } catch (Exception e) {
            auditService.logError("Party", externalPartyId, "CreationFailed", e);
            throw new RuntimeException("Failed to create party: " + externalPartyId, e);
        }
    }

    public void addBlock(String partyId, String blockId, TraceContext context) {
        try (var scope = new TraceContextScope(context)) {
            
            Party party = partyRepository.findById(partyId)
                .orElseThrow(() -> new IllegalArgumentException("Party not found: " + partyId));
            
            BlockId newBlockId = BlockId.of(blockId);
            party.addBlock(newBlockId);
            
            partyRepository.save(party);
            
            auditService.logSuccess(
                "Party", 
                partyId, 
                "BlockAdded", 
                blockId
            );
            
            logger.info("Block added to party: {} - blockId: {}", partyId, blockId);
            
        } catch (Exception e) {
            auditService.logError("Party", partyId, "AddBlockFailed", e);
            throw e;
        }
    }

    public void markAllBlocksCreated(String partyId, TraceContext context) {
        try (var scope = new TraceContextScope(context)) {
            
            Party party = partyRepository.findById(partyId)
                .orElseThrow(() -> new IllegalArgumentException("Party not found: " + partyId));
            
            party.markAllBlocksCreated();
            partyRepository.save(party);
            
            auditService.logSuccess(
                "Party", 
                partyId, 
                "AllBlocksMarkedCreated", 
                party.getBlockCount()
            );
            
            logger.info("All blocks marked created for party: {}", partyId);
            
        } catch (Exception e) {
            auditService.logError("Party", partyId, "MarkBlocksCreatedFailed", e);
            throw e;
        }
    }
}
```

### 22. IncomingPartyEvent.java + PartyAsyncHandler.java

```java
package com.example.party.application;

public record IncomingPartyEvent(String externalPartyId, String traceId, String userId) {}

---

package com.example.party.application;

import com.example.infrastructure.trace.TraceContext;
import com.example.infrastructure.trace.TraceContextScope;
import com.example.party.domain.model.BlockId;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class PartyAsyncHandler {

    private static final Logger logger = LoggerFactory.getLogger(PartyAsyncHandler.class);
    private final PartyApplicationService partyService;

    public PartyAsyncHandler(PartyApplicationService partyService) {
        this.partyService = partyService;
    }

    @Async
    @EventListener
    public void onIncomingParty(IncomingPartyEvent event) {
        String traceId = event.traceId() != null ? event.traceId() : java.util.UUID.randomUUID().toString();
        String userId = event.userId() != null ? event.userId() : "system";
        
        TraceContext context = TraceContext.from(traceId, userId);

        try (var scope = new TraceContextScope(context)) {
            
            logger.info("Processing incoming party event: {} with traceId: {}", 
                event.externalPartyId(), traceId);

            partyService.createParty(event.externalPartyId(), context);

            for (int i = 1; i <= 3; i++) {
                String blockId = "block-" + i;
                partyService.addBlock(event.externalPartyId(), blockId, context);
            }

            partyService.markAllBlocksCreated(event.externalPartyId(), context);
            
            logger.info("Party processing completed: {} traceId: {}", 
                event.externalPartyId(), traceId);
                
        } catch (Exception e) {
            logger.error("Failed to process incoming party event", e);
        }
    }
}
```

### 23. TraceContextFilter.java

```java
package com.example.infrastructure.web;

import com.example.infrastructure.trace.TraceContext;
import com.example.infrastructure.trace.TraceContextHolder;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

@Component
public class TraceContextFilter extends HttpFilter {

    private static final Logger logger = LoggerFactory.getLogger(TraceContextFilter.class);

    @Override
    protected void doFilter(HttpServletRequest request, 
                           HttpServletResponse response, 
                           FilterChain chain) throws IOException, ServletException {

        String traceId = Optional.ofNullable(request.getHeader("X-Trace-Id"))
            .filter(s -> !s.isBlank())
            .orElse(UUID.randomUUID().toString());

        String userId = Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
            .map(Authentication::getName)
            .filter(s -> !s.isBlank())
            .orElse("system");

        String correlationId = UUID.randomUUID().toString();

        TraceContext context = new TraceContext(traceId, userId, correlationId, java.time.Instant.now());
        TraceContextHolder.set(context);

        response.addHeader("X-Trace-Id", traceId);
        response.addHeader("X-Correlation-Id", correlationId);

        try {
            logger.debug("Request initiated: {} {} traceId={}", 
                request.getMethod(), request.getRequestURI(), traceId);
            
            chain.doFilter(request, response);
            
        } catch (Exception e) {
            logger.error("Request failed: {} {}", 
                request.getMethod(), request.getRequestURI(), e);
            throw e;
            
        } finally {
            TraceContextHolder.clear();
        }
    }
}
```

### 24. application.yml

```yaml
spring:
  application:
    name: party-service

  datasource:
    url: jdbc:h2:mem:testdb;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
    driver-class-name: org.h2.Driver
    username: sa
    password:

  jpa:
    hibernate:
      ddl-auto: create-drop
    properties:
      hibernate:
        dialect: org.hibernate.dialect.H2Dialect
        format_sql: true
    show-sql: false

  flyway:
    enabled: false

  task:
    execution:
      pool:
        core-size: 5
        max-size: 10
        queue-capacity: 100

  jackson:
    serialization:
      write-dates-as-timestamps: false

logging:
  level:
    root: INFO
    com.example: DEBUG
  pattern:
    console: "%d{HH:mm:ss} [%thread] %-5level %logger{36} - %X{traceId} %X{userId} - %msg%n"

server:
  port: 8080
```

---

## 🧪 FICHIERS TESTS - Code complet

Je vais créer les tests maintenant...
