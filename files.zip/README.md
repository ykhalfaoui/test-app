# snowflake-demo — Spring Boot + Snowflake Private Key Auth

## Génération de la clé privée RSA

```bash
# 1. Générer la clé privée (non chiffrée)
openssl genrsa 2048 | openssl pkcs8 -topk8 -nocrypt -out rsa_key.p8

# 1b. Ou avec passphrase (chiffrée)
openssl genrsa 2048 | openssl pkcs8 -topk8 -out rsa_key.p8

# 2. Extraire la clé publique
openssl rsa -in rsa_key.p8 -pubout -out rsa_key.pub

# 3. Copier la clé publique (sans en-têtes) dans Snowflake
cat rsa_key.pub | grep -v "PUBLIC KEY" | tr -d '\n'
```

## Enregistrer la clé publique dans Snowflake

```sql
-- En tant qu'ACCOUNTADMIN ou SECURITYADMIN
ALTER USER SVC_SPRING_BOOT SET RSA_PUBLIC_KEY='MIIBIjANBgkqhki...';

-- Vérifier
DESC USER SVC_SPRING_BOOT;
```

## Configuration locale (développement)

```bash
export SNOWFLAKE_ACCOUNT=myorg-myaccount
export SNOWFLAKE_USER=SVC_SPRING_BOOT
export SNOWFLAKE_DATABASE=MY_DB
export SNOWFLAKE_SCHEMA=PUBLIC
export SNOWFLAKE_WAREHOUSE=COMPUTE_WH
export SNOWFLAKE_ROLE=MY_ROLE
export SNOWFLAKE_PRIVATE_KEY_PATH=/chemin/vers/rsa_key.p8
# ou base64 pour CI/CD :
export SNOWFLAKE_PRIVATE_KEY_B64=$(base64 -w0 rsa_key.p8)
```

## Lancer le service

```bash
mvn spring-boot:run
```

## Endpoints disponibles

### Session courante
```bash
curl http://localhost:8080/api/snowflake/session | jq
```

### Lister les tables du schéma
```bash
curl http://localhost:8080/api/snowflake/tables | jq
```

### Historique des requêtes
```bash
curl http://localhost:8080/api/snowflake/query-history | jq
```

### Requête custom (SELECT uniquement)
```bash
curl -X POST http://localhost:8080/api/snowflake/query \
  -H "Content-Type: application/json" \
  -d '{"sql": "SELECT COUNT(*) AS total FROM MY_TABLE"}' | jq
```

## Déploiement OpenShift

```bash
# 1. Créer les secrets
oc create secret generic snowflake-pkey \
  --from-file=rsa_key.p8=./rsa_key.p8 \
  -n my-project

oc create secret generic snowflake-env \
  --from-literal=SNOWFLAKE_ACCOUNT=myorg-myaccount \
  --from-literal=SNOWFLAKE_USER=SVC_SPRING_BOOT \
  --from-literal=SNOWFLAKE_DATABASE=MY_DB \
  --from-literal=SNOWFLAKE_SCHEMA=PUBLIC \
  --from-literal=SNOWFLAKE_WAREHOUSE=COMPUTE_WH \
  --from-literal=SNOWFLAKE_ROLE=MY_ROLE \
  -n my-project

# 2. Déployer
oc apply -f openshift-deployment.yaml

# 3. Vérifier les policies réseau
oc get egressnetworkpolicy -n my-project
oc get networkpolicy -n my-project
```

## Architecture des clés dans OpenShift

```
K8s Secret (snowflake-pkey)
    └── rsa_key.p8
         └── monté en volume → /secrets/snowflake/rsa_key.p8
              └── lu par PrivateKeyLoader (BouncyCastle)
                   └── injecté dans SnowflakeBasicDataSource.setPrivateKey()
```
