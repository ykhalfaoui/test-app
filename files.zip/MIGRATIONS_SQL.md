# 🗄️ MIGRATIONS SQL - Tables refactorisées

## Flyway Migrations

Créer les fichiers dans `src/main/resources/db/migration/`

---

## V1__Create_Party_Tables.sql

```sql
-- V1__Create_Party_Tables.sql
-- Initial party domain tables

CREATE TABLE parties (
    id VARCHAR(100) PRIMARY KEY,
    status VARCHAR(50) NOT NULL DEFAULT 'CREATED',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE party_blocks (
    party_id VARCHAR(100) NOT NULL,
    id VARCHAR(100) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (party_id, id),
    FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE CASCADE,
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## V2__Create_Audit_Trail_Tables.sql

```sql
-- V2__Create_Audit_Trail_Tables.sql
-- Audit trail with enriched context

CREATE TABLE audit_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- Context information
    trace_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50) NOT NULL,
    
    -- Aggregate information
    aggregate_type VARCHAR(100),
    aggregate_id VARCHAR(100),
    
    -- Event information
    event_type VARCHAR(100) NOT NULL,
    details LONGTEXT,  -- JSON payload
    
    -- Status information
    status VARCHAR(20) NOT NULL DEFAULT 'SUCCESS',  -- SUCCESS, FAILURE, RETRY
    error_message LONGTEXT,
    retry_count INT DEFAULT 0,
    
    -- Timestamps
    timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes for efficient querying
    INDEX idx_trace_id (trace_id),
    INDEX idx_user_id (user_id),
    INDEX idx_aggregate_id (aggregate_id),
    INDEX idx_event_type (event_type),
    INDEX idx_status (status),
    INDEX idx_timestamp (timestamp),
    INDEX idx_trace_timestamp (trace_id, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Partitioning by month for better performance
ALTER TABLE audit_events PARTITION BY RANGE (YEAR_MONTH(timestamp)) (
    PARTITION p_202501 VALUES LESS THAN (202502),
    PARTITION p_202502 VALUES LESS THAN (202503),
    PARTITION p_202503 VALUES LESS THAN (202504),
    PARTITION p_future VALUES LESS THAN MAXVALUE
);
```

---

## V3__Create_Outbox_Tables.sql

```sql
-- V3__Create_Outbox_Tables.sql
-- Outbox pattern with retry and DLQ support

CREATE TABLE outbox_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- Context information
    trace_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50) NOT NULL,
    
    -- Business information
    party_id VARCHAR(100) NOT NULL,
    
    -- Status and retry information
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING',
    -- Valid statuses: PENDING, SENT, ERROR, DEAD_LETTER
    
    retry_count INT NOT NULL DEFAULT 0,
    max_retries INT NOT NULL DEFAULT 5,
    
    -- Retry scheduling
    next_retry_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Error tracking
    last_error_message LONGTEXT,
    
    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Indexes for efficient processing
    INDEX idx_status (status),
    INDEX idx_trace_id (trace_id),
    INDEX idx_party_id (party_id),
    INDEX idx_next_retry_at (next_retry_at),
    INDEX idx_status_created (status, created_at),
    INDEX idx_status_next_retry (status, next_retry_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- View pour monitoring
CREATE VIEW v_outbox_pending AS
SELECT 
    COUNT(*) as pending_count,
    MIN(created_at) as oldest_pending
FROM outbox_items
WHERE status = 'PENDING'
AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR);

CREATE VIEW v_outbox_dlq AS
SELECT 
    id,
    trace_id,
    party_id,
    retry_count,
    last_error_message,
    created_at,
    updated_at
FROM outbox_items
WHERE status = 'DEAD_LETTER'
ORDER BY updated_at DESC
LIMIT 100;

CREATE VIEW v_outbox_errors_by_party AS
SELECT 
    party_id,
    COUNT(*) as error_count,
    MAX(updated_at) as last_error,
    GROUP_CONCAT(DISTINCT last_error_message) as error_messages
FROM outbox_items
WHERE status IN ('ERROR', 'DEAD_LETTER')
GROUP BY party_id
ORDER BY error_count DESC;
```

---

## V4__Create_Trace_Context_Tables.sql (Optionnel)

```sql
-- V4__Create_Trace_Context_Tables.sql
-- Optionnel : pour stocker les contextes de trace pour analyse

CREATE TABLE trace_contexts (
    trace_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50) NOT NULL,
    
    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP,
    duration_ms BIGINT,
    
    status VARCHAR(20) NOT NULL DEFAULT 'IN_PROGRESS',  -- IN_PROGRESS, SUCCESS, FAILURE
    error_message LONGTEXT,
    
    request_uri VARCHAR(255),
    request_method VARCHAR(10),
    response_status INT,
    
    INDEX idx_user_id (user_id),
    INDEX idx_started_at (started_at),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Nettoyer les vieux traces (retention de 30 jours)
CREATE EVENT IF NOT EXISTS clean_old_traces
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
    DELETE FROM trace_contexts 
    WHERE started_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
```

---

## V5__Migrate_Existing_Outbox_Data.sql

```sql
-- V5__Migrate_Existing_Outbox_Data.sql
-- Migration des données Outbox existantes

-- Si vous aviez une ancienne table outbox_items
ALTER TABLE outbox_items_old
ADD COLUMN trace_id VARCHAR(50) NOT NULL DEFAULT 'MIGRATED',
ADD COLUMN user_id VARCHAR(100) NOT NULL DEFAULT 'system',
ADD COLUMN correlation_id VARCHAR(50) NOT NULL DEFAULT UUID(),
ADD COLUMN retry_count INT NOT NULL DEFAULT 0,
ADD COLUMN max_retries INT NOT NULL DEFAULT 5,
ADD COLUMN next_retry_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN last_error_message LONGTEXT;

-- Migrer vers la nouvelle table
INSERT INTO outbox_items (
    trace_id, 
    user_id, 
    correlation_id, 
    party_id, 
    status, 
    retry_count, 
    max_retries, 
    next_retry_at, 
    created_at
)
SELECT 
    COALESCE(trace_id, 'MIGRATED'),
    COALESCE(user_id, 'system'),
    UUID(),
    party_id,
    CASE 
        WHEN status = 'PENDING' THEN 'PENDING'
        WHEN status = 'SENT' THEN 'SENT'
        WHEN status = 'ERROR' THEN 'ERROR'
        ELSE 'ERROR'
    END,
    COALESCE(retry_count, 0),
    5,
    CURRENT_TIMESTAMP,
    created_at
FROM outbox_items_old;

-- Supprimer l'ancienne table
DROP TABLE outbox_items_old;
```

---

## V6__Migrate_Existing_Audit_Data.sql

```sql
-- V6__Migrate_Existing_Audit_Data.sql
-- Migration des données d'audit existantes

-- Si vous aviez une ancienne table audit_events
ALTER TABLE audit_events_old
ADD COLUMN correlation_id VARCHAR(50) NOT NULL DEFAULT UUID(),
ADD COLUMN aggregate_type VARCHAR(100),
ADD COLUMN aggregate_id VARCHAR(100),
ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'SUCCESS',
ADD COLUMN error_message LONGTEXT,
ADD COLUMN retry_count INT NOT NULL DEFAULT 0;

-- Migrer vers la nouvelle table
INSERT INTO audit_events (
    trace_id,
    user_id,
    correlation_id,
    aggregate_type,
    aggregate_id,
    event_type,
    details,
    status,
    error_message,
    timestamp
)
SELECT 
    trace_id,
    user_id,
    UUID(),
    'Party',  -- Assumer que tous les événements sont sur Party
    aggregate_id,
    event_type,
    details,
    'SUCCESS',  -- Assumer que tous les anciens événements sont SUCCESS
    NULL,
    timestamp
FROM audit_events_old;

-- Supprimer l'ancienne table
DROP TABLE audit_events_old;
```

---

## V7__Create_Monitoring_Views.sql

```sql
-- V7__Create_Monitoring_Views.sql
-- Vues pour monitoring et debugging

-- Vue : Audit trail complète pour un trace
CREATE OR REPLACE VIEW v_audit_by_trace AS
SELECT 
    trace_id,
    user_id,
    COUNT(*) as event_count,
    MIN(timestamp) as started_at,
    MAX(timestamp) as ended_at,
    TIMESTAMPDIFF(SECOND, MIN(timestamp), MAX(timestamp)) as duration_seconds,
    GROUP_CONCAT(DISTINCT event_type) as event_types,
    SUM(CASE WHEN status = 'FAILURE' THEN 1 ELSE 0 END) as failure_count
FROM audit_events
GROUP BY trace_id
ORDER BY started_at DESC;

-- Vue : Événements échoués pour investigation
CREATE OR REPLACE VIEW v_failed_events AS
SELECT 
    trace_id,
    user_id,
    timestamp,
    event_type,
    aggregate_id,
    error_message,
    retry_count
FROM audit_events
WHERE status = 'FAILURE'
ORDER BY timestamp DESC
LIMIT 100;

-- Vue : Parties avec problèmes
CREATE OR REPLACE VIEW v_problematic_parties AS
SELECT 
    ae.aggregate_id as party_id,
    COUNT(*) as total_events,
    SUM(CASE WHEN ae.status = 'FAILURE' THEN 1 ELSE 0 END) as failure_count,
    oi.error_count as outbox_errors,
    MAX(ae.timestamp) as last_activity
FROM audit_events ae
LEFT JOIN v_outbox_errors_by_party oi ON ae.aggregate_id = oi.party_id
WHERE ae.aggregate_type = 'Party'
GROUP BY ae.aggregate_id
HAVING failure_count > 0 OR oi.error_count > 0
ORDER BY failure_count DESC;

-- Vue : Performance metrics
CREATE OR REPLACE VIEW v_performance_metrics AS
SELECT 
    DATE(timestamp) as date,
    HOUR(timestamp) as hour,
    COUNT(*) as total_events,
    COUNT(DISTINCT trace_id) as unique_traces,
    SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as success_count,
    SUM(CASE WHEN status = 'FAILURE' THEN 1 ELSE 0 END) as failure_count,
    ROUND(100.0 * SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) / COUNT(*), 2) as success_rate
FROM audit_events
WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY DATE(timestamp), HOUR(timestamp)
ORDER BY date DESC, hour DESC;

-- Vue : Top errors
CREATE OR REPLACE VIEW v_top_errors AS
SELECT 
    error_message,
    COUNT(*) as occurrence_count,
    COUNT(DISTINCT trace_id) as affected_traces,
    MAX(timestamp) as last_occurrence
FROM audit_events
WHERE status = 'FAILURE' AND error_message IS NOT NULL
GROUP BY error_message
ORDER BY occurrence_count DESC
LIMIT 20;
```

---

## Queries de monitoring

```sql
-- Requête 1 : Audit trail pour un trace spécifique
SELECT * FROM audit_events 
WHERE trace_id = 'trace-123' 
ORDER BY timestamp ASC;

-- Requête 2 : Items Outbox en attente depuis plus de 1 heure
SELECT * FROM outbox_items 
WHERE status = 'PENDING' 
AND created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)
ORDER BY created_at ASC;

-- Requête 3 : Dead letter items
SELECT * FROM outbox_items 
WHERE status = 'DEAD_LETTER' 
ORDER BY updated_at DESC;

-- Requête 4 : Taux de succès par heure
SELECT 
    DATE(timestamp) as date,
    HOUR(timestamp) as hour,
    COUNT(*) as total,
    SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as success,
    ROUND(100.0 * SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) / COUNT(*), 2) as success_rate
FROM audit_events
WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY DATE(timestamp), HOUR(timestamp)
ORDER BY date DESC, hour DESC;

-- Requête 5 : Erreurs les plus courantes
SELECT 
    error_message,
    COUNT(*) as occurrence_count,
    MAX(timestamp) as last_occurrence
FROM audit_events
WHERE status = 'FAILURE' AND error_message IS NOT NULL
GROUP BY error_message
ORDER BY occurrence_count DESC
LIMIT 10;

-- Requête 6 : Parties avec le plus d'erreurs
SELECT 
    aggregate_id as party_id,
    COUNT(*) as error_count,
    GROUP_CONCAT(DISTINCT event_type) as failed_events,
    MAX(timestamp) as last_error
FROM audit_events
WHERE aggregate_type = 'Party' AND status = 'FAILURE'
GROUP BY aggregate_id
ORDER BY error_count DESC
LIMIT 10;

-- Requête 7 : Items en retry actuellement
SELECT * FROM outbox_items 
WHERE status = 'ERROR' 
AND next_retry_at <= NOW()
ORDER BY next_retry_at ASC
LIMIT 20;

-- Requête 8 : Distribution des erreurs par jour
SELECT 
    DATE(timestamp) as date,
    COUNT(*) as error_count,
    COUNT(DISTINCT trace_id) as affected_traces
FROM audit_events
WHERE status = 'FAILURE'
AND timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(timestamp)
ORDER BY date DESC;
```

---

## Configuration Liquibase (alternative à Flyway)

Si vous préférez Liquibase au lieu de Flyway :

```xml
<!-- pom.xml -->
<dependency>
    <groupId>org.liquibase</groupId>
    <artifactId>liquibase-core</artifactId>
    <version>4.20.0</version>
</dependency>
```

```yaml
# application.yml
spring:
  liquibase:
    change-log: classpath:db/changelog/db.changelog-master.xml
```

```xml
<!-- db/changelog/db.changelog-master.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<databaseChangeLog
    xmlns="http://www.liquibase.org/xml/ns/dbchangelog"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog
    http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-4.20.xsd">

    <include file="db/changelog/01-initial-schema.xml"/>
    <include file="db/changelog/02-audit-tables.xml"/>
    <include file="db/changelog/03-outbox-tables.xml"/>
    
</databaseChangeLog>
```

---

## 🧪 Tests des migrations

```bash
# Vérifier la structure
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME IN ('parties', 'outbox_items', 'audit_events')
ORDER BY TABLE_NAME, ORDINAL_POSITION;

# Vérifier les indexes
SELECT INDEX_NAME, COLUMN_NAME 
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_NAME IN ('outbox_items', 'audit_events')
ORDER BY TABLE_NAME, INDEX_NAME;

# Vérifier les contraintes
SELECT CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME 
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE TABLE_NAME IN ('parties', 'outbox_items', 'audit_events');
```
