package com.crok4it.snowflake.config;

import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.bc.BcPEMDecryptorProvider;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo;
import org.bouncycastle.pkcs.PKCSException;
import org.bouncycastle.pkcs.jcajce.JcePKCSPBEInputDecryptorProviderBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.PrivateKey;
import java.util.Base64;

/**
 * Charge une clé privée RSA pour l'authentification Snowflake.
 *
 * Supporte 3 modes (par ordre de priorité) :
 *   1. privateKeyB64   — contenu PEM encodé Base64 (idéal K8s Secret env var)
 *   2. privateKeyPath  — chemin vers fichier .p8 monté (K8s Secret volume)
 *   3. Erreur si aucun n'est fourni
 *
 * Supporte clé chiffrée (PKCS8 encrypted) et non chiffrée.
 */
@Slf4j
@Component
public class PrivateKeyLoader {

    private static final JcaPEMKeyConverter CONVERTER = new JcaPEMKeyConverter();

    public PrivateKey load(SnowflakeProperties props) {
        try {
            String pemContent = resolvePemContent(props);
            return parsePem(pemContent, props.getPrivateKeyPassphrase());
        } catch (IOException | PKCSException e) {
            throw new IllegalStateException("Impossible de charger la clé privée Snowflake", e);
        }
    }

    // -------------------------------------------------------------------------
    // Résolution du contenu PEM
    // -------------------------------------------------------------------------

    private String resolvePemContent(SnowflakeProperties props) throws IOException {
        if (StringUtils.hasText(props.getPrivateKeyB64())) {
            log.debug("Chargement clé privée depuis variable Base64");
            byte[] decoded = Base64.getDecoder().decode(props.getPrivateKeyB64().trim());
            return new String(decoded, StandardCharsets.UTF_8);
        }

        if (StringUtils.hasText(props.getPrivateKeyPath())) {
            log.debug("Chargement clé privée depuis fichier: {}", props.getPrivateKeyPath());
            return Files.readString(Path.of(props.getPrivateKeyPath()), StandardCharsets.UTF_8);
        }

        throw new IllegalStateException(
            "Aucune clé privée Snowflake configurée. " +
            "Définissez SNOWFLAKE_PRIVATE_KEY_B64 ou SNOWFLAKE_PRIVATE_KEY_PATH."
        );
    }

    // -------------------------------------------------------------------------
    // Parsing PEM via BouncyCastle
    // -------------------------------------------------------------------------

    private PrivateKey parsePem(String pem, String passphrase) throws IOException, PKCSException {
        try (PEMParser parser = new PEMParser(new StringReader(pem))) {
            Object obj = parser.readObject();

            if (obj == null) {
                throw new IllegalStateException("Fichier PEM vide ou format invalide");
            }

            // Cas 1 : PKCS8 chiffré  — BEGIN ENCRYPTED PRIVATE KEY
            if (obj instanceof PKCS8EncryptedPrivateKeyInfo encrypted) {
                log.debug("Clé PKCS8 chiffrée détectée");
                requirePassphrase(passphrase);
                PrivateKeyInfo keyInfo = encrypted.decryptPrivateKeyInfo(
                    new JcePKCSPBEInputDecryptorProviderBuilder()
                        .setProvider("BC")
                        .build(passphrase.toCharArray())
                );
                return CONVERTER.getPrivateKey(keyInfo);
            }

            // Cas 2 : PKCS8 non chiffré — BEGIN PRIVATE KEY
            if (obj instanceof PrivateKeyInfo keyInfo) {
                log.debug("Clé PKCS8 non chiffrée détectée");
                return CONVERTER.getPrivateKey(keyInfo);
            }

            // Cas 3 : PEM traditionnel chiffré — BEGIN RSA PRIVATE KEY (Proc-Type: 4,ENCRYPTED)
            if (obj instanceof PEMEncryptedKeyPair encryptedKeyPair) {
                log.debug("Clé PEM traditionnelle chiffrée détectée");
                requirePassphrase(passphrase);
                PEMKeyPair keyPair = encryptedKeyPair.decryptKeyPair(
                    new BcPEMDecryptorProvider(passphrase.toCharArray())
                );
                return CONVERTER.getPrivateKey(keyPair.getPrivateKeyInfo());
            }

            // Cas 4 : PEM traditionnel non chiffré — BEGIN RSA PRIVATE KEY
            if (obj instanceof PEMKeyPair keyPair) {
                log.debug("Clé PEM traditionnelle non chiffrée détectée");
                return CONVERTER.getPrivateKey(keyPair.getPrivateKeyInfo());
            }

            throw new IllegalStateException("Format de clé PEM non reconnu: " + obj.getClass().getName());
        }
    }

    private void requirePassphrase(String passphrase) {
        if (!StringUtils.hasText(passphrase)) {
            throw new IllegalStateException(
                "La clé privée est chiffrée mais SNOWFLAKE_PRIVATE_KEY_PASSPHRASE n'est pas défini."
            );
        }
    }
}
