# 📋 GUIDE DE MIGRATION - Solution Refactorisée

## 🎯 Objectif

Ce document te guide pour migrer de la solution initiale vers la solution refactorisée qui corrige tous les problèmes identifiés.

---

## 🔴 PROBLÈMES RÉSOLUS

### 1️⃣ ThreadLocal + @Async (CRITIQUE)

**Avant** ❌
```java
@Async
@EventListener
public void onIncomingParty(IncomingPartyEvent event) {
    TraceContextHolder.set(new TraceContext(traceId, "system"));
    // ThreadLocal se perd quand @Async crée un nouveau thread !
}
```

**Après** ✅
```java
// AsyncConfig.java
@Bean
public Executor getAsyncExecutor() {
    executor.setTaskDecorator(runnable -> {
        var ctx = TraceContextHolder.get();
        return () -> {
            TraceContextHolder.set(ctx);  // Restaurer le contexte dans le nouveau thread
            try {
                runnable.run();
            } finally {
                TraceContextHolder.clear();
            }
        };
    });
    return executor;
}
```

**Impact** : Sans cette correction, tous les logs en `@Async` n'avaient pas le `traceId` ! 🚨

---

### 2️⃣ DDD - Agrégat trop simple

**Avant** ❌
```java
public class Party {
    public void addBlock(String blockId) {
        domainEvents.add(new BlockCreated(this.id, blockId));  // Aucune validation
    }
}
```

**Après** ✅
```java
public class Party {
    private PartyStatus status;  // Value Object
    private List<Block> blocks;  // Entités

    public void addBlock(BlockId blockId) {
        if (!status.canAddBlocks()) {  // INVARIANT : validation métier
            throw new IllegalStateException("Cannot add block in status: " + status);
        }
        
        Block newBlock = Block.create(blockId);
        blocks.add(newBlock);
        status = PartyStatus.BLOCKS_IN_PROGRESS;
        recordEvent(new BlockCreated(id.value(), blockId.value()));
    }
}
```

**Impact** : 
- ✅ Règles métier appliquées au niveau du domaine
- ✅ Impossible d'avoir une Party dans un état invalide
- ✅ Vrai DDD avec invariants

---

### 3️⃣ Audit Trail insuffisant

**Avant** ❌
```java
@EventListener
public void on(CorrelatedEvent<?> event) {
    AuditEvent ae = new AuditEvent();
    ae.setTraceId(event.traceId());
    ae.setEventType(type);
    ae.setStatus("SUCCESS");  // Toujours SUCCESS !
    auditRepo.save(ae);
}
```

**Après** ✅
```java
public class AuditEvent {
    private String traceId;
    private String userId;
    private String correlationId;
    private String aggregateType;      // "Party", "Block"
    private String aggregateId;        // party-123
    private String eventType;          // "PartyCreated"
    private String details;            // JSON
    private String status;             // "SUCCESS", "FAILURE", "RETRY"
    private String errorMessage;       // Exception message
    private Instant timestamp;
    private int retryCount;            // Nombre de tentatives
}

@Service
public class AuditService {
    public void logSuccess(String aggType, String aggId, String eventType, Object payload) {
        AuditEvent audit = new AuditEvent.Builder()
            .aggregateType(aggType)
            .aggregateId(aggId)
            .eventType(eventType)
            .details(serializeAsJson(payload))
            .status("SUCCESS")
            .build();
        auditRepository.save(audit);
    }

    public void logError(String aggType, String aggId, String eventType, Exception error) {
        AuditEvent audit = new AuditEvent.Builder()
            .eventType(eventType)
            .status("FAILURE")
            .error(error.getMessage())
            .build();
        auditRepository.save(audit);
    }
}
```

**Impact** :
- ✅ Traçabilité complète des succès ET erreurs
- ✅ Contexte métier dans l'audit
- ✅ Facilité pour déboguer

---

### 4️⃣ Pas de Retry / DLQ

**Avant** ❌
```java
@Scheduled(fixedDelay = 5000)
public void processOutbox() {
    for (OutboxItem item : pending) {
        try {
            remoteClient.syncParty(item.getPartyId());
            item.setStatus("SENT");
        } catch (Exception ex) {
            item.setStatus("ERROR");  // Pas de retry !
            // L'item est perdu
        }
    }
}
```

**Après** ✅
```java
public class OutboxItem {
    private int retryCount = 0;
    private int maxRetries = 5;
    private LocalDateTime nextRetryAt;
    private String status;  // "PENDING", "SENT", "ERROR", "DEAD_LETTER"

    public boolean shouldRetry() {
        return "ERROR".equals(status) 
            && retryCount < maxRetries 
            && LocalDateTime.now().isAfter(nextRetryAt);
    }

    public void markError(String errorMessage) {
        this.status = "ERROR";
        this.lastErrorMessage = errorMessage;
        this.retryCount++;
        
        // Exponential backoff : 2^retryCount secondes
        long secondsDelay = (long) Math.pow(2, Math.min(retryCount, 10));
        this.nextRetryAt = LocalDateTime.now().plusSeconds(secondsDelay);
    }
}

@Component
public class OutboxProcessor {
    
    @Scheduled(fixedDelay = 5000)
    public void processPendingItems() {
        List<OutboxItem> pending = outboxRepository.findByStatusOrderByCreatedAtAsc("PENDING");
        for (OutboxItem item : pending) {
            processItem(item);
        }
    }

    @Scheduled(fixedDelay = 10000)
    public void processRetryItems() {
        List<OutboxItem> retryItems = outboxRepository
            .findByStatusAndRetryCountLessThanOrderByNextRetryAtAsc("ERROR", 5);
        
        for (OutboxItem item : retryItems) {
            if (item.shouldRetry()) {
                processItemWithRetry(item);
            }
        }
    }
}

@Component
public class OutboxDLQHandler {
    
    @Scheduled(fixedDelay = 30000)
    public void processDLQItems() {
        List<OutboxItem> expiredItems = outboxRepository
            .findByStatusAndRetryCountGreaterThanEqualOrderByCreatedAtAsc("ERROR", 5);
        
        for (OutboxItem item : expiredItems) {
            // Alerter (Slack, PagerDuty)
            notificationService.alertCritical(
                "🚨 OUTBOX DLQ ALERT: Party " + item.getPartyId() + " failed after " + item.getRetryCount() + " retries"
            );
            item.markDeadLetter();
            outboxRepository.save(item);
        }
    }
}
```

**Impact** :
- ✅ Retry automatique avec exponential backoff
- ✅ Dead Letter Queue pour les items bloqués
- ✅ Alertes critiques en cas d'échec définitif

---

### 5️⃣ Spring Modulith - Underused

**Avant** ❌
```java
@ApplicationModuleListener
public void on(CorrelatedEvent<AllBlocksCreated> event) {
    // Juste un @EventListener dans le module
}
```

**Après** ✅
```java
// Structure modulaire
com.example.party/
com.example.audit/
com.example.outbox/

// Test de structure
@SpringBootTest
class ModulesTest {
    @Test
    void verifyModuleStructure() {
        var modules = ApplicationModules.of(Application.class);
        modules.verify();  // Vérifie que les dépendances sont respectées
    }
}

// Listener inter-modules propre
@Component
public class AuditTrailListener {
    
    @EventListener
    public void on(PartyCreated event) {
        // PartyCreated est dans le module Party
        // Audit reçoit l'événement de domaine pur
        auditService.logSuccess("Party", event.partyId(), "PartyCreated", event);
    }
}
```

**Impact** :
- ✅ Architecture modulaire vérifiée
- ✅ Pas de dépendances circulaires
- ✅ Limites claires entre modules

---

### 6️⃣ Testabilité - ThreadLocal makes testing hard

**Avant** ❌
```java
@Test
void shouldCreatePartyWithTraceId() {
    IncomingPartyEvent event = new IncomingPartyEvent("party-123", "trace-abc");
    handler.onIncomingParty(event);
    
    // Comment vérifier que le traceId a été propagé ?
    // ThreadLocal n'est plus accessible après la méthode
}
```

**Après** ✅
```java
@Test
@DisplayName("should create party with trace context")
void shouldCreatePartyWithTraceContext() {
    // Arrange
    String partyId = "party-123";
    TraceContext context = TraceContext.create("user-1");
    Party party = Party.create(partyId);

    when(partyRepository.save(any(Party.class)))
        .thenReturn(party);

    // Act
    Party result = service.createParty(partyId, context);

    // Assert
    assertThat(result).isNotNull();
    verify(partyRepository, times(1)).save(any(Party.class));
    verify(auditService, times(1)).logSuccess(
        eq("Party"),
        eq(partyId),
        eq("Created"),
        any()
    );
}
```

**Impact** :
- ✅ Tests clairs et déterministes
- ✅ Pas d'effets de bord avec ThreadLocal
- ✅ Contexte passé explicitement

---

### 7️⃣ TraceContextFilter - Incomplete

**Avant** ❌
```java
TraceContextHolder.set(new TraceContext(traceId, userId));
try {
    chain.doFilter(request, response);
} finally {
    TraceContextHolder.clear();
}
// Pas de propagation du traceId au client !
```

**Après** ✅
```java
TraceContextHolder.set(context);

// 🔑 Propager en response
response.addHeader("X-Trace-Id", traceId);
response.addHeader("X-Correlation-Id", correlationId);

try {
    chain.doFilter(request, response);
} catch (Exception e) {
    logger.error("Request failed", e);  // Le traceId est en MDC automatiquement
    throw e;
} finally {
    TraceContextHolder.clear();
}
```

**Impact** :
- ✅ Client reçoit le traceId pour faire des requêtes de suivi
- ✅ Logs automatiquement enrichis en cas d'erreur
- ✅ Traçabilité end-to-end

---

### 8️⃣ CorrelatedEvent<T> - Leaky Abstraction

**Avant** ❌
```java
// Tous les handlers reçoivent CorrelatedEvent<Object>
@EventListener
public void on(CorrelatedEvent<?> event) {
    Object payload = event.payload();  // Type unknown à runtime
}

// Domain events mélangés avec détails techniques
new CorrelatedEvent<>(traceId, userId, event)
```

**Après** ✅
```java
// Domain events purs (pas de CorrelatedEvent)
public record PartyCreated(String partyId) {}
public record BlockCreated(String partyId, String blockId) {}

// Handlers reçoivent les events typés
@EventListener
public void on(PartyCreated event) {
    // Type-safe ! Pas de CorrelatedEvent<Object>
    auditService.logSuccess("Party", event.partyId(), "PartyCreated", event);
}

// Le traçage est transparent via ThreadLocal + Bridge
// Pas besoin de passer CorrelatedEvent partout
```

**Impact** :
- ✅ Domain events purs et testables
- ✅ Type-safety partout
- ✅ Pas de wrapper qui cache les vrais events

---

## 📊 TABLE DE COMPARAISON

| **Aspect** | **Avant** | **Après** | **Gain** |
|-----------|---------|---------|---------|
| **ThreadLocal + @Async** | 🔴 Cassé | ✅ TaskDecorator | Contexte propagé |
| **DDD** | 🟡 Simple | ✅ Riche avec Value Objects | Invariants métier |
| **Audit** | 🟡 Basic | ✅ Détaillé + Erreurs | Traçabilité complète |
| **Retry** | 🔴 Aucun | ✅ Exponential backoff | Résilience |
| **DLQ** | 🔴 Absent | ✅ Implémenté | Alertes critiques |
| **Testabilité** | 🟡 Difficile | ✅ Facile | Tests déterministes |
| **Spring Modulith** | 🟡 Underused | ✅ Properly used | Architecture vérifiée |
| **Type-safety** | 🟡 CorrelatedEvent<Object> | ✅ Events typés | Maintenabilité |
| **Error handling** | 🔴 Minimal | ✅ Complet | Production-ready |

---

## 🚀 CHECKLIST DE MIGRATION

### Phase 1 : Infrastructure (0-2 jours)

- [ ] Copier `TraceContext` + `TraceContextHolder` + `TraceContextScope`
- [ ] Configurer `AsyncConfig` avec `TaskDecorator`
- [ ] Ajouter `TraceContextFilter` amélioré
- [ ] Créer `AuditEvent` + `AuditService`
- [ ] Mettre à jour `AuditTrailListener`

**Test** : Vérifier que les logs contiennent `traceId` en MDC

### Phase 2 : DDD - Domaine (2-4 jours)

- [ ] Créer Value Objects (`PartyId`, `BlockId`, `PartyStatus`)
- [ ] Refactoriser `Party` avec invariants
- [ ] Créer entité `Block`
- [ ] Mettre à jour Domain Events (purs, sans CorrelatedEvent)
- [ ] Tests unitaires du domaine

**Test** : Vérifier que les invariants sont appliqués

### Phase 3 : Outbox + Retry (2-3 jours)

- [ ] Créer `OutboxItem` enrichi (retryCount, DLQ, etc.)
- [ ] Implémenter `OutboxProcessor` avec retry
- [ ] Implémenter `OutboxDLQHandler`
- [ ] Ajouter alertes (Slack, PagerDuty, etc.)

**Test** : Simuler des erreurs et vérifier les retries

### Phase 4 : Application Service + Handlers (1-2 jours)

- [ ] Créer `PartyApplicationService` testable
- [ ] Créer `PartyAsyncHandler` avec contexte injecté
- [ ] Tests unitaires des services
- [ ] Intégration avec les handlers existants

**Test** : Vérifier que tous les logs ont le traceId

### Phase 5 : Circuit Breaker (Optionnel, 1 jour)

- [ ] Ajouter Resilience4J dependency
- [ ] Configurer `CircuitBreakerConfiguration`
- [ ] Protéger appels microservice externes

**Test** : Simuler des appels microservice défaillants

### Phase 6 : Tests End-to-End (2-3 jours)

- [ ] Tests d'intégration complets
- [ ] Vérifier audit trail complète
- [ ] Vérifier retry + DLQ
- [ ] Vérifier Spring Modulith structure

---

## 📌 POINTS D'ATTENTION

### ⚠️ Migration de TraceId

**Avant** :
```java
// Les events n'avaient pas de traceId
partyRepository.save(party);
```

**Après** :
```java
// Les events sont automatiquement enrichis du traceId via ThreadLocal
// Aucun changement dans le code métier !
partyRepository.save(party);
```

**Action** : Aucune action requise ! Les events de domaine restent identiques.

---

### ⚠️ Migration des Listeners

**Avant** :
```java
@EventListener
public void on(CorrelatedEvent<?> event) {
    Object payload = event.payload();
}
```

**Après** :
```java
@EventListener
public void on(PartyCreated event) {
    // Type-safe
    auditService.logSuccess(...);
}
```

**Action** : Créer un listener par type d'event domain

---

### ⚠️ Base de données

**Avant** :
```sql
CREATE TABLE outbox_items (
    id BIGINT PRIMARY KEY,
    party_id VARCHAR(100),
    status VARCHAR(50),
    created_at TIMESTAMP
);
```

**Après** :
```sql
CREATE TABLE outbox_items (
    id BIGINT PRIMARY KEY,
    trace_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50),
    party_id VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    retry_count INT DEFAULT 0,
    max_retries INT DEFAULT 5,
    next_retry_at TIMESTAMP,
    last_error_message TEXT,
    created_at TIMESTAMP NOT NULL,
    
    INDEX idx_status (status),
    INDEX idx_trace_id (trace_id),
    INDEX idx_next_retry (next_retry_at)
);

CREATE TABLE audit_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    trace_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(50),
    aggregate_type VARCHAR(100),
    aggregate_id VARCHAR(100),
    event_type VARCHAR(100) NOT NULL,
    details TEXT,
    status VARCHAR(20) NOT NULL,
    error_message TEXT,
    retry_count INT DEFAULT 0,
    timestamp TIMESTAMP NOT NULL,
    
    INDEX idx_trace_id (trace_id),
    INDEX idx_user_id (user_id),
    INDEX idx_aggregate_id (aggregate_id),
    INDEX idx_timestamp (timestamp)
);
```

**Action** : Créer des migrations Flyway/Liquibase

---

## 🧪 VALIDATION POST-MIGRATION

```bash
# 1. Tests unitaires
mvn test

# 2. Vérifier structure modulaire
mvn test -Dtest=ModulesTest

# 3. Vérifier les logs contiennent traceId
# Chercher dans les logs : "traceId=trace-123"

# 4. Vérifier l'audit trail
SELECT * FROM audit_events ORDER BY timestamp DESC LIMIT 10;

# 5. Vérifier les retries
SELECT * FROM outbox_items WHERE status IN ('ERROR', 'DEAD_LETTER');

# 6. Tests de charge
# Simuler 1000 parties en parallèle, vérifier les retries
```

---

## 📞 SUPPORT & QUESTIONS

- Q: "Pourquoi TaskDecorator et pas @EnableAsync ?"
  A: TaskDecorator capture le contexte ThreadLocal AVANT de créer le nouveau thread. @EnableAsync seul ne le fait pas.

- Q: "Faut-il changer les Domain Events ?"
  A: Non ! Les Domain Events restent purs. Le traçage est transparent via ThreadLocal.

- Q: "Comment déboguer le traceId ?"
  A: Tous les logs SLF4J contiennent "traceId=..." en MDC. Utilise les logs pour tracker un flux.

- Q: "Que faire des anciens enregistrements d'audit ?"
  A: Migrer les données existantes avec une migration Flyway qui ajoute les colonnes manquantes avec des defaults.

---

Bonne chance ! 🎯
