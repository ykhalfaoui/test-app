# 🚀 GUIDE COMPLET D'INSTALLATION - Projet Java Spring Modulith

## 📋 Sommaire des fichiers fournis

Vous avez reçu 3 fichiers principaux :

1. **COMPLETE_JAVA_PROJECT_PART1.md** - Code source complet (24 fichiers Java)
2. **COMPLETE_JAVA_PROJECT_PART2_TESTS.md** - Tests complets (60+ tests)
3. **COMPLETE_JAVA_PROJECT_PART3_CONFIG.md** - Configuration et migrations SQL

## 🏗️ Mise en place du projet

### ÉTAPE 1 : Créer la structure du projet

```bash
# Créer le répertoire principal
mkdir party-service-project
cd party-service-project

# Créer la structure Maven
mkdir -p src/{main,test}/java/com/example/{infrastructure,party}
mkdir -p src/{main,test}/java/com/example/infrastructure/{trace,audit,outbox,web,config}
mkdir -p src/{main,test}/java/com/example/party/{domain,application,outbox}
mkdir -p src/{main,test}/java/com/example/party/domain/{model,events,repository}
mkdir -p src/main/resources/{db/migration}
mkdir -p docker
```

### ÉTAPE 2 : Copier le pom.xml

Copier le contenu `pom.xml` depuis **PART1** et le placer à la racine du projet.

### ÉTAPE 3 : Copier tous les fichiers Java

#### Infrastructure - Trace
Fichiers à créer dans `src/main/java/com/example/infrastructure/trace/`:

1. **TraceContext.java** (Record immutable)
2. **TraceContextHolder.java** (Gestion ThreadLocal)
3. **TraceContextScope.java** (Try-with-resources)

#### Infrastructure - Audit
Fichiers à créer dans `src/main/java/com/example/infrastructure/audit/`:

1. **AuditEvent.java** (Entité JPA enrichie)
2. **AuditEventRepository.java** (Repository)
3. **AuditService.java** (Service d'audit)
4. **AuditTrailListener.java** (Event listener)

#### Infrastructure - Outbox
Fichiers à créer dans `src/main/java/com/example/infrastructure/outbox/`:

1. **OutboxItem.java** (Entité avec retry)
2. **OutboxItemRepository.java** (Repository)
3. **OutboxProcessor.java** (Processeur avec retry)
4. **OutboxDLQHandler.java** (Gestionnaire DLQ)

#### Infrastructure - Web
Fichiers à créer dans `src/main/java/com/example/infrastructure/web/`:

1. **TraceContextFilter.java** (Filter HTTP)

#### Infrastructure - Config
Fichiers à créer dans `src/main/java/com/example/infrastructure/config/`:

1. **AsyncConfig.java** (Configuration Async + TaskDecorator - 🔑 CRITIQUE)
2. **CircuitBreakerConfig.java** (Configuration Resilience4J)
3. **SecurityConfig.java** (Configuration Spring Security)

#### Party - Domain - Model
Fichiers à créer dans `src/main/java/com/example/party/domain/model/`:

1. **PartyId.java** (Value Object)
2. **BlockId.java** (Value Object)
3. **PartyStatus.java** (Enum Value Object)
4. **Block.java** (Entité imbriquée)
5. **Party.java** (Agrégat avec invariants)

#### Party - Domain - Events
Fichiers à créer dans `src/main/java/com/example/party/domain/events/`:

1. **PartyCreated.java** (Record)
2. **BlockCreated.java** (Record)
3. **AllBlocksCreated.java** (Record)
4. **SynchronizedBlock.java** (Record)
5. **PartyFailed.java** (Record)

#### Party - Domain - Repository
Fichiers à créer dans `src/main/java/com/example/party/domain/repository/`:

1. **PartyRepository.java** (JPA Repository)

#### Party - Application
Fichiers à créer dans `src/main/java/com/example/party/application/`:

1. **IncomingPartyEvent.java** (Record)
2. **PartyApplicationService.java** (Service application - testable)
3. **PartyAsyncHandler.java** (Handler async avec @Async)

#### Party - Outbox
Fichiers à créer dans `src/main/java/com/example/party/outbox/`:

1. **OutboxListener.java** (Listener outbox)
2. **RemotePartySyncClient.java** (Interface client)
3. **RemotePartySyncClientImpl.java** (Implémentation mock)

#### Main Application
Fichier à créer dans `src/main/java/com/example/`:

1. **PartyServiceApplication.java** (@SpringBootApplication + @Modulith)

### ÉTAPE 4 : Copier les fichiers de configuration

```bash
# Application configuration
cp <contenu application.yml> src/main/resources/application.yml
cp <contenu application-test.yml> src/main/resources/application-test.yml
cp <contenu logback-spring.xml> src/main/resources/logback-spring.xml

# Migrations
cp <contenu V1__Initial_Schema.sql> src/main/resources/db/migration/V1__Initial_Schema.sql
```

### ÉTAPE 5 : Copier les tests

Créer les fichiers de tests dans `src/test/java/com/example/`:

#### Domain Tests
1. **party/domain/model/PartyTest.java**
2. **party/domain/model/PartyAggregateInvariantsTest.java**

#### Application Tests
1. **party/application/PartyApplicationServiceTest.java**
2. **party/application/PartyEndToEndTest.java**

#### Infrastructure Tests
1. **infrastructure/audit/AuditServiceTest.java**
2. **infrastructure/outbox/OutboxProcessorTest.java**
3. **infrastructure/outbox/OutboxRetryTest.java**
4. **infrastructure/outbox/OutboxDLQHandlerTest.java**
5. **infrastructure/trace/TraceContextTest.java**
6. **infrastructure/web/TraceContextFilterTest.java**

#### Modulith Tests
1. **ModulesTest.java** (à la racine de src/test/java/com/example/)

### ÉTAPE 6 : Copier Docker Compose

```bash
cp <contenu docker-compose.yml> docker-compose.yml
cp <contenu prometheus.yml> docker/prometheus.yml
```

## 📁 Structure finale

```
party-service-project/
├── pom.xml
├── docker-compose.yml
├── src/
│   ├── main/
│   │   ├── java/com/example/
│   │   │   ├── PartyServiceApplication.java
│   │   │   ├── infrastructure/
│   │   │   │   ├── trace/
│   │   │   │   │   ├── TraceContext.java
│   │   │   │   │   ├── TraceContextHolder.java
│   │   │   │   │   └── TraceContextScope.java
│   │   │   │   ├── audit/
│   │   │   │   │   ├── AuditEvent.java
│   │   │   │   │   ├── AuditEventRepository.java
│   │   │   │   │   ├── AuditService.java
│   │   │   │   │   └── AuditTrailListener.java
│   │   │   │   ├── outbox/
│   │   │   │   │   ├── OutboxItem.java
│   │   │   │   │   ├── OutboxItemRepository.java
│   │   │   │   │   ├── OutboxProcessor.java
│   │   │   │   │   └── OutboxDLQHandler.java
│   │   │   │   ├── web/
│   │   │   │   │   └── TraceContextFilter.java
│   │   │   │   └── config/
│   │   │   │       ├── AsyncConfig.java
│   │   │   │       ├── CircuitBreakerConfig.java
│   │   │   │       └── SecurityConfig.java
│   │   │   └── party/
│   │   │       ├── domain/
│   │   │       │   ├── model/
│   │   │       │   │   ├── Party.java
│   │   │       │   │   ├── PartyId.java
│   │   │       │   │   ├── PartyStatus.java
│   │   │       │   │   ├── Block.java
│   │   │       │   │   └── BlockId.java
│   │   │       │   ├── events/
│   │   │       │   │   ├── PartyCreated.java
│   │   │       │   │   ├── BlockCreated.java
│   │   │       │   │   ├── AllBlocksCreated.java
│   │   │       │   │   ├── SynchronizedBlock.java
│   │   │       │   │   └── PartyFailed.java
│   │   │       │   └── repository/
│   │   │       │       └── PartyRepository.java
│   │   │       ├── application/
│   │   │       │   ├── PartyApplicationService.java
│   │   │       │   ├── PartyAsyncHandler.java
│   │   │       │   └── IncomingPartyEvent.java
│   │   │       └── outbox/
│   │   │           ├── OutboxListener.java
│   │   │           ├── RemotePartySyncClient.java
│   │   │           └── RemotePartySyncClientImpl.java
│   │   └── resources/
│   │       ├── application.yml
│   │       ├── application-test.yml
│   │       ├── logback-spring.xml
│   │       └── db/migration/
│   │           └── V1__Initial_Schema.sql
│   └── test/
│       └── java/com/example/
│           ├── party/
│           │   ├── domain/model/
│           │   │   ├── PartyTest.java
│           │   │   └── PartyAggregateInvariantsTest.java
│           │   ├── application/
│           │   │   ├── PartyApplicationServiceTest.java
│           │   │   └── PartyEndToEndTest.java
│           │   └── outbox/
│           │       └── OutboxListenerTest.java
│           ├── infrastructure/
│           │   ├── audit/
│           │   │   ├── AuditServiceTest.java
│           │   │   └── AuditTrailListenerTest.java
│           │   ├── outbox/
│           │   │   ├── OutboxProcessorTest.java
│           │   │   ├── OutboxRetryTest.java
│           │   │   └── OutboxDLQHandlerTest.java
│           │   ├── trace/
│           │   │   └── TraceContextTest.java
│           │   └── web/
│           │       └── TraceContextFilterTest.java
│           └── ModulesTest.java
└── docker/
    └── prometheus.yml
```

## ✅ Validation de la structure

```bash
# Vérifier que tous les fichiers sont présents
find src/main/java -name "*.java" | wc -l  # Doit afficher ~24

find src/test/java -name "*.java" | wc -l  # Doit afficher ~10
```

## 🧪 Premier démarrage

### Option 1 : Avec H2 (recommandé pour tests)

```bash
# 1. Compiler
mvn clean package

# 2. Lancer les tests
mvn test

# 3. Vérifier la couverture
mvn test jacoco:report
open target/site/jacoco/index.html

# 4. Démarrer l'application
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=dev"

# 5. Tester l'application
curl http://localhost:8080/actuator/health
```

### Option 2 : Avec MySQL

```bash
# 1. Démarrer MySQL
docker-compose up -d mysql

# 2. Patienter 10 secondes
sleep 10

# 3. Lancer les tests
mvn test

# 4. Démarrer l'application
mvn spring-boot:run

# 5. Accéder aux services
open http://localhost:8080/actuator/health
open http://localhost:8081  # Adminer (UI MySQL)
```

## 🧪 Exécuter les tests

```bash
# Tous les tests
mvn test

# Tests spécifiques
mvn test -Dtest=PartyTest
mvn test -Dtest=OutboxProcessorTest
mvn test -Dtest=ModulesTest

# Avec logs DEBUG
mvn test -Dorg.slf4j.simpleLogger.defaultLogLevel=debug

# Avec couverture
mvn clean test jacoco:report

# Tests en parallèle
mvn test -T 1C
```

## 📊 Cas de tests disponibles

### ✅ Domaine (15 tests)
- Création de Party
- Ajout de blocks
- Marquage comme complété
- Marquage comme synchronisé
- Marquage comme failed
- **Invariants**:
  - Pas de blocks sur FAILED
  - Pas de marquage sans blocks
  - Pas de sync sans ALL_BLOCKS_CREATED

### ✅ Application Service (10 tests)
- Création de party
- Ajout de blocks
- Marquage complet
- Audit logging
- Gestion d'erreurs

### ✅ Outbox & Retry (20 tests)
- Traitement PENDING
- Retry avec exponential backoff (2^n)
- Déplacement ERROR → DEAD_LETTER
- DLQ handling
- Preservation des messages d'erreur

### ✅ Audit (8 tests)
- Log success
- Log error
- Log retry
- Preservation du TraceContext

### ✅ TraceContext (7 tests)
- Création
- Validation (blank checking)
- Factory methods
- Propagation

### ✅ HTTP Filter (5 tests)
- Génération traceId
- Propagation en response
- Cleanup après requête

### ✅ Modulith (5 tests)
- Structure vérifiée
- Modules détectés
- Documentation générée

## 🔍 Vérifier l'installation

```bash
# 1. Vérifier la compilation
mvn clean compile

# 2. Vérifier la structure modulaire
mvn spring-modulith:list

# 3. Exécuter les tests
mvn test

# 4. Vérifier la couverture
mvn test jacoco:report
cat target/site/jacoco/index.html | grep "Total"

# 5. Démarrer l'application
mvn spring-boot:run

# 6. Dans un autre terminal, tester
curl http://localhost:8080/actuator/health | jq .
```

## 🐛 Troubleshooting

### "Java 21 not found"
```bash
export JAVA_HOME=/path/to/jdk21
mvn -v
```

### "Tests fail: Cannot acquire table lock"
```bash
# Augmenter le timeout dans application-test.yml
spring:
  jpa:
    properties:
      hibernate:
        jdbc:
          batch_size: 10
```

### "Port 8080 already in use"
```bash
# Utiliser un port différent
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8081"
```

### "MySQL container won't start"
```bash
# Vérifier les logs
docker-compose logs mysql

# Nettoyer et redémarrer
docker-compose down -v
docker-compose up -d
```

## 📊 Générer les rapports

```bash
# Jacoco (code coverage)
mvn clean test jacoco:report
open target/site/jacoco/index.html

# Spring Modulith documentation
mvn spring-modulith:document
cat target/spring-modulith/modules.txt

# Surefire (test results)
mvn surefire-report:report
open target/site/surefire-report.html
```

## 🎯 Étapes suivantes

1. ✅ Installer le projet (cette section)
2. ✅ Exécuter les tests
3. ✅ Comprendre l'architecture
4. ✅ Modifier selon vos besoins
5. ✅ Ajouter vos propres entités/services
6. ✅ Déployer en production

## 📚 Documentation supplémentaire

- **COMPLETE_JAVA_PROJECT_PART1.md** - Code source détaillé
- **COMPLETE_JAVA_PROJECT_PART2_TESTS.md** - Tests complets avec explications
- **COMPLETE_JAVA_PROJECT_PART3_CONFIG.md** - Configuration et SQL

## 🚀 Liens utiles

- [Spring Boot 3](https://spring.io/projects/spring-boot)
- [Spring Modulith](https://spring.io/projects/spring-modulith)
- [Domain-Driven Design](https://www.domainlanguage.com/)
- [Outbox Pattern](https://microservices.io/patterns/data/transactional-outbox.html)

## ✨ Points clés à retenir

🔑 **AsyncConfig + TaskDecorator** - Le secret pour propager le ThreadLocal en @Async

🔑 **Agrégat riche** - Party avec invariants qui garantissent la cohérence des données

🔑 **Outbox Pattern** - Garantie "at-least-once" des événements externes

🔑 **Retry avec backoff exponentiel** - Récupération automatique des erreurs

🔑 **Audit trail complète** - Chaque action tracée avec le traceId

---

**Créé avec ❤️ pour la production**

Bon développement ! 🚀
