package com.crok4it.snowflake.controller;

import com.crok4it.snowflake.model.QueryResult;
import com.crok4it.snowflake.service.SnowflakeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Endpoints REST exposant des requêtes Snowflake.
 *
 * GET /api/snowflake/session       → infos de session courante
 * GET /api/snowflake/tables        → liste des tables du schéma courant
 * GET /api/snowflake/query-history → 10 dernières requêtes de l'utilisateur
 * POST /api/snowflake/query        → exécution d'une requête custom (lecture seule)
 */
@Slf4j
@RestController
@RequestMapping("/api/snowflake")
@RequiredArgsConstructor
public class SnowflakeController {

    private final SnowflakeService snowflakeService;

    // -------------------------------------------------------------------------
    // GET /api/snowflake/session
    // -------------------------------------------------------------------------

    @GetMapping("/session")
    public ResponseEntity<QueryResult> currentSession() {
        log.info("GET /api/snowflake/session");
        return ResponseEntity.ok(snowflakeService.currentSession());
    }

    // -------------------------------------------------------------------------
    // GET /api/snowflake/tables
    // -------------------------------------------------------------------------

    @GetMapping("/tables")
    public ResponseEntity<QueryResult> listTables() {
        log.info("GET /api/snowflake/tables");
        return ResponseEntity.ok(snowflakeService.listTables());
    }

    // -------------------------------------------------------------------------
    // GET /api/snowflake/query-history
    // -------------------------------------------------------------------------

    @GetMapping("/query-history")
    public ResponseEntity<QueryResult> queryHistory() {
        log.info("GET /api/snowflake/query-history");
        return ResponseEntity.ok(snowflakeService.recentQueryHistory());
    }

    // -------------------------------------------------------------------------
    // POST /api/snowflake/query
    // Body: { "sql": "SELECT ..." }
    // ⚠ Limité aux SELECT — protège contre les mutations accidentelles
    // -------------------------------------------------------------------------

    @PostMapping("/query")
    public ResponseEntity<?> executeQuery(@RequestBody Map<String, String> body) {
        String sql = body.get("sql");

        if (sql == null || sql.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Le champ 'sql' est requis"));
        }

        String trimmed = sql.strip().toUpperCase();
        if (!trimmed.startsWith("SELECT") && !trimmed.startsWith("WITH") && !trimmed.startsWith("SHOW")) {
            return ResponseEntity.badRequest().body(
                Map.of("error", "Seules les requêtes SELECT / WITH / SHOW sont autorisées")
            );
        }

        log.info("POST /api/snowflake/query → {}", sql.substring(0, Math.min(80, sql.length())));
        QueryResult result = snowflakeService.executeQuery(sql);
        return ResponseEntity.ok(result);
    }

    // -------------------------------------------------------------------------
    // Gestion d'erreurs globale pour ce controller
    // -------------------------------------------------------------------------

    @ExceptionHandler(SnowflakeService.SnowflakeQueryException.class)
    public ResponseEntity<Map<String, String>> handleSnowflakeError(SnowflakeService.SnowflakeQueryException ex) {
        log.error("Erreur Snowflake: {}", ex.getMessage(), ex);
        return ResponseEntity.internalServerError().body(
            Map.of("error", ex.getMessage(), "cause", ex.getCause().getMessage())
        );
    }
}
