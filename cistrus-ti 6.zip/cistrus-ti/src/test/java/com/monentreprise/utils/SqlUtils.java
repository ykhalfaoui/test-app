package com.monentreprise.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utilitaires pour la manipulation sécurisée des requêtes SQL dans les tests.
 */
public final class SqlUtils {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private SqlUtils() {
        // Constructeur privé pour empêcher l'instanciation
    }

    /**
     * Échappe une chaîne pour une utilisation sûre dans une requête SQL.
     * Remplace les apostrophes simples par des doubles apostrophes.
     * 
     * @param input La chaîne à échapper
     * @return La chaîne échappée ou "NULL" si l'entrée est nulle
     */
    public static String escape(String input) {
        if (input == null) {
            return "NULL";
        }
        return input.replace("'", "''");
    }

    /**
     * Formate une date pour l'injection SQL (format yyyy-MM-dd HH:mm:ss).
     * 
     * @param date La date à formater
     * @return La date formatée ou "NULL" si l'entrée est nulle
     */
    public static String formatDate(LocalDateTime date) {
        if (date == null) {
            return "NULL";
        }
        return date.format(DATE_FORMAT);
    }

    /**
     * Retourne la date courante formatée.
     */
    public static String now() {
        return formatDate(LocalDateTime.now());
    }

    /**
     * Attache une requête SQL au rapport Allure.
     * 
     * @param description Description de l'action (ex: "SQL: Création commande")
     * @param sql         La requête SQL exécutée
     */
    public static void logSql(String description, String sql) {
        io.qameta.allure.Allure.addAttachment(description, "text/plain", sql, ".txt");
    }
}
