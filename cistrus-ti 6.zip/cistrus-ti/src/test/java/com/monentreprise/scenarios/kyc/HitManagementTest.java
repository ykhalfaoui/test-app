package com.monentreprise.scenarios.kyc;

import com.monentreprise.citrus.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("🎯 Epic: Hit management")
@Feature("Hit management")
@Owner("equipe-compliance")
public class HitManagementTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("⚠️ IHUB DDR HIT & Client hors scope")
    @DisplayName("⚠️ Hit Hors Scope -> Not Permanent")
    @Description("DDR sur client hors scope: Le hit est rejeté (Not Permanent).")
    @Tag("kyc")
    @Tag("hit-mgmt")
    void ihub_ddr_hit_client_not_in_scope() {
        kycSteps.customerExists("Client", "Active");

        // Paramètres contextuels
        kycSteps.clientNotInScopeDDR();
        kycSteps.noReviewInProgress();

        kycSteps.ihubLaunchesDDR();

        kycSteps.verifyHitQualifiedAs("Not Permanent");
        kycSteps.verifyHitSyncedToSalesforce("Not Permanent");
    }

    @Test
    @Story("📝 IHUB DDR HIT & Client in scope & Review en cours")
    @DisplayName("📝 Hit In Scope + Review -> Not Permanent")
    @Description("Client in scope mais review déjà en cours: Pas de nouveau hit permanent.")
    @Tag("kyc")
    @Tag("hit-mgmt")
    void ihub_ddr_hit_client_in_scope_review_in_progress() {
        kycSteps.customerExists("Client", "Active");

        // Paramètres contextuels
        kycSteps.clientInScopeDDR();
        kycSteps.reviewInProgress();

        kycSteps.ihubLaunchesDDR();

        kycSteps.verifyHitQualifiedAs("Not Permanent (Doublon)");
        kycSteps.verifyHitSyncedToSalesforce("Not Permanent");
    }

    @Test
    @Story("🚨 IHUB DDR HIT & Client in scope & Pas de review")
    @DisplayName("🚨 Hit In Scope -> Positive")
    @Description("Client ciblé sans review: Hit Positif et lancement de review.")
    @Tag("kyc")
    @Tag("hit-mgmt")
    void ihub_ddr_hit_client_in_scope() {
        kycSteps.customerExists("Client", "Active");

        // Paramètres contextuels
        kycSteps.clientInScopeDDR();
        kycSteps.noReviewInProgress();

        kycSteps.ihubLaunchesDDR();

        kycSteps.verifyHitQualifiedAs("Positive");
        kycSteps.verifyHitSyncedToSalesforce("Positive");
        kycSteps.launchReviewOnCustomer();
        kycSteps.verifyRemediationBlocksCreated(7);
        kycSteps.verifyBlocksAndReviewSynced();
    }
}
