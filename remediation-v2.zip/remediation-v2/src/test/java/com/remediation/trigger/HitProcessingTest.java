package com.remediation.trigger;

import com.remediation.TestBase;
import com.remediation.sharedkernel.TraceId;
import com.remediation.sharedkernel.inbox.InboxEntry;
import com.remediation.sharedkernel.inbox.InboxRepository;
import com.remediation.trigger.api.HitService;
import com.remediation.trigger.infrastructure.kafka.HitKafkaConsumer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Tests for Hit processing in Trigger context.
 */
class HitProcessingTest extends TestBase {

    @Autowired
    private HitService hitService;

    @Autowired
    private HitKafkaConsumer kafkaConsumer;

    @Autowired
    private InboxRepository inboxRepository;

    @Test
    void shouldQualifyPositiveHit() {
        // Given - hit with high match score
        TraceId traceId = TraceId.create();
        String payload = """
            {
                "customerId": "CUST-001",
                "hitType": "SANCTIONS",
                "matchScore": "85"
            }
            """;

        // When
        hitService.processIncomingHit(traceId, payload);

        // Then - event should be published (captured in outbox)
        // Verified by checking that no exception was thrown
    }

    @Test
    void shouldQualifyNegativeHit() {
        // Given - hit with low match score
        TraceId traceId = TraceId.create();
        String payload = """
            {
                "customerId": "CUST-002",
                "hitType": "SANCTIONS",
                "matchScore": "50"
            }
            """;

        // When
        hitService.processIncomingHit(traceId, payload);

        // Then - should process without error (but not publish positive event)
        // Verified by checking that no exception was thrown
    }

    @Test
    void shouldHandleInvalidPayload() {
        // Given - invalid JSON
        TraceId traceId = TraceId.create();
        String invalidPayload = "not-json";

        // When/Then - should throw exception
        assertThatThrownBy(() -> hitService.processIncomingHit(traceId, invalidPayload))
            .isInstanceOf(RuntimeException.class);
    }

    @Test
    void shouldPreventDuplicateProcessing() {
        // Given - message with specific event ID
        UUID eventId = UUID.randomUUID();
        String payload = """
            {
                "customerId": "CUST-003",
                "hitType": "SANCTIONS",
                "matchScore": "90"
            }
            """;

        // When - process first time
        kafkaConsumer.consume(payload, eventId.toString(), null);

        // Then - inbox should have entry
        assertThat(inboxRepository.existsByEventId(eventId)).isTrue();

        // When - process second time (duplicate)
        kafkaConsumer.consume(payload, eventId.toString(), null);

        // Then - should be idempotent (only one entry)
        long count = inboxRepository.findAll().stream()
            .filter(entry -> entry.getEventId().equals(eventId))
            .count();
        assertThat(count).isEqualTo(1);
    }

    @Test
    void shouldCreateOrPropagateTraceId() {
        // Given - message without TraceId
        UUID eventId = UUID.randomUUID();
        String payload = """
            {
                "customerId": "CUST-004",
                "hitType": "SANCTIONS",
                "matchScore": "80"
            }
            """;

        // When - process without traceId header
        kafkaConsumer.consume(payload, eventId.toString(), null);

        // Then - should create new TraceId and process successfully
        InboxEntry entry = inboxRepository.findById(eventId).orElseThrow();
        assertThat(entry.getStatus()).isEqualTo(InboxEntry.Status.PROCESSED);
    }

    @Test
    void shouldMarkInboxEntryAsFailedOnError() {
        // Given - payload that will cause processing error
        UUID eventId = UUID.randomUUID();
        String payload = "{}"; // Missing required fields

        // When - process with invalid data
        try {
            kafkaConsumer.consume(payload, eventId.toString(), null);
        } catch (Exception e) {
            // Expected to fail
        }

        // Then - inbox entry should be marked as FAILED
        InboxEntry entry = inboxRepository.findById(eventId).orElseThrow();
        assertThat(entry.getStatus()).isEqualTo(InboxEntry.Status.FAILED);
        assertThat(entry.getErrorMessage()).isNotNull();
    }
}
