package com.remediation.block;

import com.remediation.TestBase;
import com.remediation.block.api.BlockReadyForReviewEvent;
import com.remediation.block.domain.Block;
import com.remediation.block.domain.BlockRepository;
import com.remediation.member.api.ReviewMemberIdentifiedEvent;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.sharedkernel.outbox.OutboxRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import java.util.concurrent.TimeUnit;

/**
 * Tests for Block provisioning logic.
 */
class BlockProvisioningTest extends TestBase {

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Autowired
    private BlockRepository blockRepository;

    @Autowired
    private OutboxRepository outboxRepository;

    @Test
    void shouldCreateBlockForNewCustomer() {
        // Given
        CustomerId customerId = CustomerId.of("CUST-NEW");
        ReviewMemberIdentifiedEvent event = new ReviewMemberIdentifiedEvent(
            TraceId.create(),
            ReviewId.create(),
            customerId,
            "PRINCIPAL"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - block should be created
        await().atMost(2, TimeUnit.SECONDS).untilAsserted(() -> {
            var blocks = blockRepository.findByCustomerId(customerId);
            assertThat(blocks).hasSize(1);
        });
    }

    @Test
    void shouldReuseExistingBlock() {
        // Given - existing block for customer
        CustomerId customerId = CustomerId.of("CUST-EXISTING");
        Block existingBlock = new Block(customerId);
        blockRepository.save(existingBlock);

        // When - member identified for same customer
        ReviewMemberIdentifiedEvent event = new ReviewMemberIdentifiedEvent(
            TraceId.create(),
            ReviewId.create(),
            customerId,
            "SPOUSE"
        );
        eventPublisher.publishEvent(event);

        // Then - should reuse existing block (not create new one)
        await().atMost(2, TimeUnit.SECONDS).untilAsserted(() -> {
            var blocks = blockRepository.findByCustomerId(customerId);
            assertThat(blocks).hasSize(1);
            assertThat(blocks.get(0).getId()).isEqualTo(existingBlock.getId());
        });
    }

    @Test
    void shouldPublishBlockReadyEvent() {
        // Given
        ReviewMemberIdentifiedEvent event = new ReviewMemberIdentifiedEvent(
            TraceId.create(),
            ReviewId.create(),
            CustomerId.of("CUST-003"),
            "PRINCIPAL"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - BlockReadyForReviewEvent should be published
        await().atMost(2, TimeUnit.SECONDS).untilAsserted(() -> {
            var blockReadyEvents = outboxRepository.findAll().stream()
                .filter(entry -> entry.getEventType().contains("BlockReadyForReviewEvent"))
                .toList();

            assertThat(blockReadyEvents).isNotEmpty();
        });
    }

    @Test
    void shouldStartReviewOnBlock() throws InterruptedException {
        // Given - create block
        CustomerId customerId = CustomerId.of("CUST-004");
        Block block = new Block(customerId);
        blockRepository.save(block);

        ReviewId reviewId = ReviewId.create();

        // When - publish member identified event
        ReviewMemberIdentifiedEvent event = new ReviewMemberIdentifiedEvent(
            TraceId.create(),
            reviewId,
            customerId,
            "PRINCIPAL"
        );
        eventPublisher.publishEvent(event);

        // Then - block should have review started
        Thread.sleep(500);
        Block updatedBlock = blockRepository.findFirstByCustomerId(customerId).orElseThrow();
        assertThat(updatedBlock.getStatus()).isEqualTo(Block.BlockStatus.IN_REVIEW);
        assertThat(updatedBlock.getActiveReviewIds()).contains(reviewId.value());
    }

    @Test
    void shouldHandleMultipleReviewsOnSameBlock() throws InterruptedException {
        // Given - existing block
        CustomerId customerId = CustomerId.of("CUST-MULTI");
        Block block = new Block(customerId);
        blockRepository.save(block);

        ReviewId review1 = ReviewId.create();
        ReviewId review2 = ReviewId.create();

        // When - two different reviews for same customer
        eventPublisher.publishEvent(new ReviewMemberIdentifiedEvent(
            TraceId.create(), review1, customerId, "PRINCIPAL"
        ));
        eventPublisher.publishEvent(new ReviewMemberIdentifiedEvent(
            TraceId.create(), review2, customerId, "PRINCIPAL"
        ));

        // Then - block should track both reviews
        Thread.sleep(500);
        Block updatedBlock = blockRepository.findFirstByCustomerId(customerId).orElseThrow();
        assertThat(updatedBlock.getActiveReviewIds()).hasSize(2);
        assertThat(updatedBlock.getActiveReviewIds())
            .contains(review1.value(), review2.value());
    }
}
