package com.remediation.review;

import com.remediation.review.domain.ReviewSaga;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for ReviewSaga state machine.
 */
class ReviewSagaTest {

    @Test
    void shouldInitializeInStartedState() {
        // Given/When
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));

        // Then
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.STARTED);
        assertThat(saga.getExpectedMemberCount()).isEqualTo(0);
        assertThat(saga.getCollectedBlockCount()).isEqualTo(0);
    }

    @Test
    void shouldSetExpectationsAndTransitionToCollecting() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));

        // When
        saga.setExpectations(5);

        // Then
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COLLECTING_BLOCKS);
        assertThat(saga.getExpectedMemberCount()).isEqualTo(5);
    }

    @Test
    void shouldCollectBlocksIdempotently() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));
        saga.setExpectations(3);
        BlockId blockId = BlockId.create();

        // When - collect same block twice
        boolean firstCollection = saga.markBlockCollected(blockId);
        boolean secondCollection = saga.markBlockCollected(blockId);

        // Then
        assertThat(firstCollection).isTrue();
        assertThat(secondCollection).isFalse(); // Duplicate ignored
        assertThat(saga.getCollectedBlockCount()).isEqualTo(1);
    }

    @Test
    void shouldCompleteWhenAllBlocksCollected() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));
        saga.setExpectations(3);

        // When - collect all expected blocks
        saga.markBlockCollected(BlockId.create());
        saga.markBlockCollected(BlockId.create());
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COLLECTING_BLOCKS);

        saga.markBlockCollected(BlockId.create());

        // Then - should auto-complete
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COMPLETED);
        assertThat(saga.isCompleted()).isTrue();
        assertThat(saga.getCollectedBlockCount()).isEqualTo(3);
    }

    @Test
    void shouldNotCollectBlocksBeforeExpectationsSet() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));
        // Expectations NOT set

        // When - try to collect block
        boolean collected = saga.markBlockCollected(BlockId.create());

        // Then - should ignore
        assertThat(collected).isFalse();
        assertThat(saga.getCollectedBlockCount()).isEqualTo(0);
    }

    @Test
    void shouldHandleFailure() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));
        saga.setExpectations(5);

        // When
        saga.fail("Test failure");

        // Then
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.FAILED);
        assertThat(saga.isFailed()).isTrue();
        assertThat(saga.getFailureReason()).isEqualTo("Test failure");
    }

    @Test
    void shouldNotCollectBlocksAfterFailure() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));
        saga.setExpectations(5);
        saga.fail("Test failure");

        // When - try to collect block after failure
        boolean collected = saga.markBlockCollected(BlockId.create());

        // Then - should ignore
        assertThat(collected).isFalse();
        assertThat(saga.getCollectedBlockCount()).isEqualTo(0);
    }

    @Test
    void shouldRejectInvalidMemberCount() {
        // Given
        ReviewSaga saga = new ReviewSaga(ReviewId.create(), CustomerId.of("CUST-001"));

        // When
        saga.setExpectations(0);

        // Then - should fail
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.FAILED);
        assertThat(saga.getFailureReason()).contains("Invalid member count");
    }
}
