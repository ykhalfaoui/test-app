/**
 * Review context orchestrates the remediation review process.
 * Responsible for:
 * - Creating review instances for positive hits
 * - Orchestrating the review saga (waiting for family composition and block collection)
 * - Tracking review progress and completion
 *
 * Dependencies: sharedkernel, trigger, member, block
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Review Context",
    allowedDependencies = {"sharedkernel", "trigger", "member", "block"}
)
package com.remediation.review;
