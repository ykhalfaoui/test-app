package com.remediation.review.domain;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Review Saga orchestrates the multi-step review process:
 * 1. Wait for family composition to complete
 * 2. Collect blocks for all family members
 * 3. Complete when all blocks are collected
 *
 * Implements state machine pattern for reliable orchestration.
 */
@Entity
@Table(name = "review_saga", indexes = {
    @Index(name = "idx_saga_review_id", columnList = "review_id"),
    @Index(name = "idx_saga_status", columnList = "status")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Slf4j
public class ReviewSaga {

    public enum SagaStatus {
        STARTED,            // Saga initiated, waiting for family composition
        COLLECTING_BLOCKS,  // Family composition complete, collecting blocks
        COMPLETED,          // All blocks collected
        FAILED              // Saga failed
    }

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "review_id", nullable = false))
    private ReviewId reviewId;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "customer_id", nullable = false))
    private CustomerId customerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private SagaStatus status;

    @Column(name = "expected_member_count", nullable = false)
    private int expectedMemberCount;

    @Column(name = "collected_block_count", nullable = false)
    private int collectedBlockCount;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "review_saga_collected_blocks",
        joinColumns = @JoinColumn(name = "saga_id")
    )
    @Column(name = "block_id")
    private Set<UUID> collectedBlockIds = new HashSet<>();

    @Column(name = "started_at", nullable = false, updatable = false)
    private Instant startedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "failure_reason", length = 1000)
    private String failureReason;

    @Version
    @Column(name = "version")
    private Long version;

    public ReviewSaga(ReviewId reviewId, CustomerId customerId) {
        this.id = UUID.randomUUID();
        this.reviewId = reviewId;
        this.customerId = customerId;
        this.status = SagaStatus.STARTED;
        this.expectedMemberCount = 0;
        this.collectedBlockCount = 0;
        this.startedAt = Instant.now();
    }

    /**
     * Sets the expected number of family members (blocks) to collect.
     * Transitions saga to COLLECTING_BLOCKS state.
     *
     * @param memberCount Total number of members including principal customer
     */
    public void setExpectations(int memberCount) {
        if (this.status != SagaStatus.STARTED) {
            log.warn("Cannot set expectations for saga in status: {}", this.status);
            return;
        }

        if (memberCount <= 0) {
            log.error("Invalid member count: {}, failing saga", memberCount);
            fail("Invalid member count: " + memberCount);
            return;
        }

        this.expectedMemberCount = memberCount;
        this.status = SagaStatus.COLLECTING_BLOCKS;

        log.info("Saga {} expects {} members for review {}",
            this.id, memberCount, this.reviewId.value());
    }

    /**
     * Marks a block as collected.
     * Implements idempotency - duplicate blocks are ignored.
     * Automatically completes saga when all blocks are collected.
     *
     * @param blockId The block that was collected
     * @return true if block was newly collected, false if already collected
     */
    public boolean markBlockCollected(BlockId blockId) {
        if (this.status != SagaStatus.COLLECTING_BLOCKS) {
            log.debug("Ignoring block {} for saga {} in status {}",
                blockId.value(), this.id, this.status);
            return false;
        }

        // Idempotency check
        if (collectedBlockIds.contains(blockId.value())) {
            log.debug("Block {} already collected for saga {}", blockId.value(), this.id);
            return false;
        }

        // Collect the block
        collectedBlockIds.add(blockId.value());
        collectedBlockCount++;

        log.info("Saga {} collected block {} ({}/{})",
            this.id, blockId.value(), collectedBlockCount, expectedMemberCount);

        // Check if saga is complete
        checkCompletion();

        return true;
    }

    /**
     * Checks if all blocks have been collected and completes the saga if so.
     */
    private void checkCompletion() {
        if (expectedMemberCount > 0 && collectedBlockCount >= expectedMemberCount) {
            this.status = SagaStatus.COMPLETED;
            this.completedAt = Instant.now();

            log.info("Saga {} completed for review {} - all {} blocks collected",
                this.id, this.reviewId.value(), collectedBlockCount);
        }
    }

    /**
     * Marks the saga as failed with a reason.
     */
    public void fail(String reason) {
        this.status = SagaStatus.FAILED;
        this.failureReason = reason != null && reason.length() > 1000
            ? reason.substring(0, 1000)
            : reason;
        this.completedAt = Instant.now();

        log.error("Saga {} failed for review {}: {}",
            this.id, this.reviewId.value(), reason);
    }

    public boolean isCompleted() {
        return status == SagaStatus.COMPLETED;
    }

    public boolean isFailed() {
        return status == SagaStatus.FAILED;
    }
}
