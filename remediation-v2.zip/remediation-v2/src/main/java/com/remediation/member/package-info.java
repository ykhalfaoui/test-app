/**
 * Member context handles family composition for reviews.
 * Responsible for:
 * - Finding all family members (relations) for a customer under review
 * - Publishing events for each identified member
 * - Notifying when family composition is complete
 *
 * Dependencies: sharedkernel, review
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Member Context",
    allowedDependencies = {"sharedkernel", "review"}
)
package com.remediation.member;
