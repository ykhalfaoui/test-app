package com.remediation.sharedkernel.inbox;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Repository for managing inbox entries.
 */
@Repository
public interface InboxRepository extends JpaRepository<InboxEntry, UUID> {

    /**
     * Check if a message with the given event ID has already been received.
     * Used for idempotency checks.
     */
    boolean existsByEventId(UUID eventId);
}
