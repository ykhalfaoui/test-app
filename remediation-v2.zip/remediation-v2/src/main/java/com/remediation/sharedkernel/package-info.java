/**
 * Shared Kernel module containing common value objects and infrastructure patterns.
 * This module has no dependencies and provides foundational types used across all contexts.
 *
 * Includes:
 * - Value objects (TraceId, CustomerId, ReviewId, BlockId, HitId)
 * - Outbox pattern for reliable event publication
 * - Inbox pattern for idempotent message consumption
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Shared Kernel",
    allowedDependencies = {}
)
package com.remediation.sharedkernel;
