package com.remediation.sharedkernel.outbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * Listens to all domain events and captures them in the outbox table
 * for reliable asynchronous publication.
 *
 * This listener runs BEFORE_COMMIT to ensure events are saved atomically
 * with the business transaction.
 */
@Component
@Order(0)
@Slf4j
public class OutboxDomainEventListener {

    private final OutboxRepository repository;
    private final ObjectMapper objectMapper;

    public OutboxDomainEventListener(OutboxRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    /**
     * Captures all domain events published within a transaction.
     *
     * @param event The domain event to capture
     */
    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void on(Object event) {
        // Skip if not a domain event or if we're already forwarding
        if (!isDomainEvent(event) || OutboxForwardingContext.isForwarding()) {
            return;
        }

        try {
            String payload = objectMapper.writeValueAsString(event);
            OutboxEntry entry = OutboxEntry.pending(event.getClass().getName(), payload);
            repository.save(entry);

            log.debug("Captured domain event in outbox: {} [id={}]",
                event.getClass().getSimpleName(), entry.getId());
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize domain event for outbox: {}",
                event.getClass().getName(), e);
            throw new IllegalStateException("Unable to serialize domain event for outbox", e);
        }
    }

    /**
     * Checks if the event is a domain event from our system.
     */
    private boolean isDomainEvent(Object event) {
        if (event == null) {
            return false;
        }
        String packageName = event.getClass().getPackageName();
        return packageName != null && packageName.startsWith("com.remediation");
    }
}
