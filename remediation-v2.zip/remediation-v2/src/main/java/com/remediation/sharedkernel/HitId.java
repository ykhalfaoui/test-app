package com.remediation.sharedkernel;

import java.util.UUID;

/**
 * Value object representing a unique hit identifier.
 */
public record HitId(UUID value) {

    public HitId {
        if (value == null) {
            throw new IllegalArgumentException("HitId cannot be null");
        }
    }

    public static HitId create() {
        return new HitId(UUID.randomUUID());
    }

    public static HitId of(UUID value) {
        return new HitId(value);
    }
}
