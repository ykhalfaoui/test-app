package com.remediation.block.domain;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Block aggregate.
 */
@Repository
public interface BlockRepository extends JpaRepository<Block, BlockId> {

    /**
     * Find all blocks for a given customer.
     */
    List<Block> findByCustomerId(CustomerId customerId);

    /**
     * Find a block by customer ID (assuming one block per customer for simplicity).
     */
    Optional<Block> findFirstByCustomerId(CustomerId customerId);
}
