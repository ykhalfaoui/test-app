package com.remediation.audit.aop;

import com.remediation.audit.domain.AuditTrail;
import com.remediation.audit.domain.AuditTrailRepository;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;

/**
 * AOP aspect that intercepts exceptions in @Auditable methods
 * and logs them to the audit trail.
 *
 * This provides automatic error tracking for critical operations.
 */
@Aspect
@Component
@Slf4j
public class ErrorLoggingAspect {

    private final AuditTrailRepository auditRepository;

    public ErrorLoggingAspect(AuditTrailRepository auditRepository) {
        this.auditRepository = auditRepository;
    }

    /**
     * Intercepts all exceptions thrown from @Auditable methods.
     * Creates an audit trail entry with error details.
     */
    @AfterThrowing(
        pointcut = "@annotation(com.remediation.audit.api.Auditable)",
        throwing = "exception"
    )
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logError(JoinPoint joinPoint, Throwable exception) {
        try {
            String methodSignature = joinPoint.getSignature().toShortString();
            String className = joinPoint.getTarget().getClass().getSimpleName();
            String methodName = joinPoint.getSignature().getName();
            String errorSource = className + "." + methodName;

            // Build details with method arguments
            StringBuilder details = new StringBuilder();
            details.append("Method: ").append(methodSignature).append("\n");

            Object[] args = joinPoint.getArgs();
            if (args != null && args.length > 0) {
                details.append("Arguments: ").append(Arrays.toString(args)).append("\n");
            }

            // Create audit entry
            AuditTrail auditEntry = AuditTrail.error(
                null, // TraceId might not be available in error context
                errorSource,
                details.toString(),
                exception.getMessage()
            );

            auditRepository.save(auditEntry);

            log.error("Error audit trail created for {}: {}",
                errorSource, exception.getMessage(), exception);

        } catch (Exception e) {
            // Never fail the business transaction due to audit logging
            log.error("Failed to create error audit trail: {}", e.getMessage(), e);
        }
    }
}
