/**
 * Audit context provides cross-cutting audit and observability features.
 * Responsible for:
 * - Listening to all domain events and creating audit trail
 * - Intercepting errors via AOP and logging them
 * - Providing audit query capabilities
 *
 * This module observes all other modules but doesn't publish events.
 * Dependencies: All modules (for observability)
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Audit Context",
    allowedDependencies = {"sharedkernel", "trigger", "review", "member", "block", "integration::salesforce"}
)
package com.remediation.audit;
