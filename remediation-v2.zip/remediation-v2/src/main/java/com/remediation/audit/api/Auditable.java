package com.remediation.audit.api;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to mark methods that should have error logging via AOP.
 * When an exception occurs in an @Auditable method, it will be logged to the audit trail.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Auditable {

    /**
     * Optional description of the auditable operation.
     */
    String value() default "";
}
