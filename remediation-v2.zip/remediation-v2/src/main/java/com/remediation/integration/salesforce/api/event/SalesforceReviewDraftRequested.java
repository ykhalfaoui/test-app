package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Request event to create a review draft in Salesforce.
 */
public record SalesforceReviewDraftRequested(
    TraceId traceId,
    ReviewId reviewId,
    String triggerType
) {
    public SalesforceReviewDraftRequested {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
        if (triggerType == null || triggerType.isBlank()) {
            throw new IllegalArgumentException("triggerType cannot be null or empty");
        }
    }
}
