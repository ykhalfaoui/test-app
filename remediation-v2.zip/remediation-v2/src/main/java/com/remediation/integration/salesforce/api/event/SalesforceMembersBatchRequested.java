package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.List;
import java.util.UUID;

/**
 * Request event to sync a batch of members to Salesforce.
 */
public record SalesforceMembersBatchRequested(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    List<String> memberIds,
    String salesforceReviewId
) {
    public SalesforceMembersBatchRequested {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (sagaId == null) throw new IllegalArgumentException("sagaId cannot be null");
        if (memberIds == null || memberIds.isEmpty()) {
            throw new IllegalArgumentException("memberIds cannot be null or empty");
        }
        if (salesforceReviewId == null || salesforceReviewId.isBlank()) {
            throw new IllegalArgumentException("salesforceReviewId cannot be null or empty");
        }
        memberIds = List.copyOf(memberIds); // Immutable
    }
}
