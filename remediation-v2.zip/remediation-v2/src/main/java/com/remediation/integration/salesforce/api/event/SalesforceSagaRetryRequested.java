package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.UUID;

/**
 * Event to trigger retry of a failed Salesforce sync saga.
 */
public record SalesforceSagaRetryRequested(
    TraceId traceId,
    UUID sagaId
) {
    public SalesforceSagaRetryRequested {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (sagaId == null) throw new IllegalArgumentException("sagaId cannot be null");
    }
}
