package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceBlocksBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceBlocksBatchRequested;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Handles Salesforce block batch sync requests.
 */
@Component
@Slf4j
public class SalesforceBlocksBatchIntegrationHandler {

    private final SalesforceClient salesforceClient;
    private final ApplicationEventPublisher eventPublisher;

    public SalesforceBlocksBatchIntegrationHandler(
        SalesforceClient salesforceClient,
        ApplicationEventPublisher eventPublisher
    ) {
        this.salesforceClient = salesforceClient;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Handles request to sync a batch of blocks to Salesforce.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceBlocksBatchRequested event) {
        log.info("Syncing block batch {} ({} items) to Salesforce review {} [TraceId: {}]",
            event.batchNumber(), event.blockIds().size(),
            event.salesforceReviewId(), event.traceId().value());

        try {
            // Call Salesforce API
            salesforceClient.bulkUpsertBlocks(
                event.salesforceReviewId(),
                event.blockIds()
            );

            // Publish success event
            SalesforceBlocksBatchProcessed responseEvent = new SalesforceBlocksBatchProcessed(
                event.traceId(),
                event.sagaId(),
                event.batchNumber(),
                event.blockIds(),
                true,
                null
            );
            eventPublisher.publishEvent(responseEvent);

            log.info("Block batch {} synced successfully [TraceId: {}]",
                event.batchNumber(), event.traceId().value());

        } catch (Exception ex) {
            log.error("Failed to sync block batch {} [TraceId: {}]: {}",
                event.batchNumber(), event.traceId().value(), ex.getMessage(), ex);

            // Publish failure event
            SalesforceBlocksBatchProcessed responseEvent = new SalesforceBlocksBatchProcessed(
                event.traceId(),
                event.sagaId(),
                event.batchNumber(),
                event.blockIds(),
                false,
                ex.getMessage()
            );
            eventPublisher.publishEvent(responseEvent);
        }
    }
}
