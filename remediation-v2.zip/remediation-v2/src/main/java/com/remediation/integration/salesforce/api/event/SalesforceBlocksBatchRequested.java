package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.List;
import java.util.UUID;

/**
 * Request event to sync a batch of blocks to Salesforce.
 */
public record SalesforceBlocksBatchRequested(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    List<String> blockIds,
    String salesforceReviewId
) {
    public SalesforceBlocksBatchRequested {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (sagaId == null) throw new IllegalArgumentException("sagaId cannot be null");
        if (blockIds == null || blockIds.isEmpty()) {
            throw new IllegalArgumentException("blockIds cannot be null or empty");
        }
        if (salesforceReviewId == null || salesforceReviewId.isBlank()) {
            throw new IllegalArgumentException("salesforceReviewId cannot be null or empty");
        }
        blockIds = List.copyOf(blockIds); // Immutable
    }
}
