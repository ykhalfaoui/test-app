package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Request event to update review status in Salesforce.
 */
public record SalesforceReviewStatusUpdateRequested(
    TraceId traceId,
    ReviewId reviewId,
    String salesforceReviewId,
    String newStatus
) {
    public SalesforceReviewStatusUpdateRequested {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
        if (salesforceReviewId == null || salesforceReviewId.isBlank()) {
            throw new IllegalArgumentException("salesforceReviewId cannot be null or empty");
        }
        if (newStatus == null || newStatus.isBlank()) {
            throw new IllegalArgumentException("newStatus cannot be null or empty");
        }
    }
}
