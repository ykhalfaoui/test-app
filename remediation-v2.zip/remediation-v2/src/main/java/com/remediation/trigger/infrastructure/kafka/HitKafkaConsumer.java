package com.remediation.trigger.infrastructure.kafka;

import com.remediation.sharedkernel.TraceId;
import com.remediation.sharedkernel.inbox.InboxEntry;
import com.remediation.sharedkernel.inbox.InboxRepository;
import com.remediation.trigger.api.HitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Kafka consumer for ingesting hit events.
 * Implements idempotent processing using the Inbox pattern.
 *
 * Configuration:
 * - kafka.enabled: Enable/disable Kafka consumer (default: false for testing)
 * - kafka.topics.hits: Kafka topic name for hits (default: "remediation.hits")
 */
@Component
@Slf4j
public class HitKafkaConsumer {

    private static final String SOURCE = "KAFKA";

    private final HitService hitService;
    private final InboxRepository inboxRepository;

    public HitKafkaConsumer(HitService hitService, InboxRepository inboxRepository) {
        this.hitService = hitService;
        this.inboxRepository = inboxRepository;
    }

    /**
     * Consumes hit events from Kafka topic.
     * Uses Inbox pattern to ensure exactly-once processing.
     *
     * @param payload Hit event payload
     * @param messageKey Kafka message key (used as event ID)
     * @param traceIdHeader Optional X-Trace-Id header for distributed tracing
     */
    @KafkaListener(
        topics = "${kafka.topics.hits:remediation.hits}",
        groupId = "${kafka.consumer.group-id:remediation-service}",
        autoStartup = "${kafka.enabled:false}"
    )
    @Transactional
    public void consume(
        @Payload String payload,
        @Header(value = KafkaHeaders.RECEIVED_KEY, required = false) String messageKey,
        @Header(value = "X-Trace-Id", required = false) String traceIdHeader
    ) {
        // 1. Extract or create TraceId for distributed tracing
        TraceId traceId = StringUtils.hasText(traceIdHeader)
            ? TraceId.of(traceIdHeader)
            : TraceId.create();

        log.info("Received Kafka message [TraceId: {}, key: {}]", traceId.value(), messageKey);

        // 2. Parse event ID from message key
        UUID eventId = parseEventId(messageKey, payload);

        // 3. Idempotency check using Inbox
        if (inboxRepository.existsByEventId(eventId)) {
            log.info("Duplicate message ignored [eventId: {}, TraceId: {}]",
                eventId, traceId.value());
            return;
        }

        // 4. Save inbox entry with RECEIVED status
        InboxEntry inboxEntry = InboxEntry.received(eventId, payload, SOURCE);
        inboxRepository.save(inboxEntry);

        try {
            // 5. Process the hit
            hitService.processIncomingHit(traceId, payload);

            // 6. Mark as successfully processed
            inboxEntry.markProcessed();
            log.info("Hit processed successfully [eventId: {}, TraceId: {}]",
                eventId, traceId.value());

        } catch (Exception ex) {
            // 7. Mark as failed with error message
            log.error("Hit processing failed [eventId: {}, TraceId: {}]: {}",
                eventId, traceId.value(), ex.getMessage(), ex);
            inboxEntry.markFailed(ex.getMessage());

            // Re-throw to trigger Kafka retry mechanism
            throw ex;
        } finally {
            // 8. Always save final inbox state
            inboxRepository.save(inboxEntry);
        }
    }

    /**
     * Parses event ID from Kafka message key.
     * Falls back to generating UUID from payload hash if key is invalid.
     */
    private UUID parseEventId(String messageKey, String payload) {
        if (messageKey != null) {
            try {
                return UUID.fromString(messageKey);
            } catch (IllegalArgumentException e) {
                log.warn("Invalid UUID in message key: {}, generating from payload", messageKey);
            }
        }

        // Fallback: generate deterministic UUID from payload
        String combined = (messageKey != null ? messageKey : "") + payload;
        return UUID.nameUUIDFromBytes(combined.getBytes(StandardCharsets.UTF_8));
    }
}
