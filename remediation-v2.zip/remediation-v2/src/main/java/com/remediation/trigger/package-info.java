/**
 * Trigger context handles incoming remediation hits from external sources (Kafka).
 * Responsible for:
 * - Consuming hit events from Kafka
 * - Idempotent message processing using Inbox pattern
 * - Qualifying hits (positive/negative)
 * - Publishing qualified hit events for downstream processing
 *
 * Dependencies: sharedkernel
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Trigger Context",
    allowedDependencies = {"sharedkernel"}
)
package com.remediation.trigger;
