package com.monentreprise.scenarios.kyc;

import com.monentreprise.citrus.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("👮 Feature: Escalade MLRO (SAR)")
@Feature("Suspicious Activity Reporting")
@Owner("equipe-lcb-ft")
public class KytEscalationTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("Escalade de Soupçon (KYT -> MLRO)")
    @DisplayName("⚖️ KYT Suspect -> MLRO -> Report (SAR)")
    @Description("Processus de déclaration de soupçon suite à une alerte KYT.")
    @Tag("kyt")
    @Tag("mlro")
    void kytToSarWorkflow() {
        kycSteps.blockIsInitialized("KYT");
        kycSteps.runKytAiAnalysis("OUTLINE");
        kycSteps.systemFailsAutoValidation();
        kycSteps.agentFlagsSuspiciousActivity();
        kycSteps.escalateToMlro();
        kycSteps.mlroDecision("CONFIRMED_SUSPICION");
        kycSteps.verifySarFiled();
        kycSteps.triggerExitProcess();
    }

    @Test
    @Story("Escalade de Soupçon (KYT -> MLRO)")
    @DisplayName("↩️ KYT Suspect -> MLRO -> Dismissal (Fausse Alerte)")
    @Description("Le MLRO considère que l'explication client est plausible. Retour au process normal.")
    @Tag("kyt")
    @Tag("mlro")
    void kytMlroDismissal() {
        kycSteps.blockIsInitialized("KYT");
        kycSteps.runKytAiAnalysis("OUTLINE");
        kycSteps.systemFailsAutoValidation();
        kycSteps.agentFlagsSuspiciousActivity();
        kycSteps.escalateToMlro();

        kycSteps.mlroDecision("NO_CASE (False Positive)");

        kycSteps.verifyNoSarFiled();
        // Le process normal reprendrait ici (Validation manuelle Agent)
    }
}
