package com.monentreprise.scenarios.salesforce;

/**
 * Disabled for Cucumber POC due to missing dependencies.
 */
public class SalesforceTest {
}
