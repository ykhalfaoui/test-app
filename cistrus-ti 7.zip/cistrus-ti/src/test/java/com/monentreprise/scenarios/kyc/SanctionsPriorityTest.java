package com.monentreprise.scenarios.kyc;

import com.monentreprise.citrus.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("🚀 Protocoles: Priority & Exceptions")
@Feature("Sanctions Fast Track")
@Owner("equipe-compliance")
public class SanctionsPriorityTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("Critical: Fast Track Sanctions (Override Open Version)")
    @DisplayName("🚨 Sanction Hit on Open Version (Fast Track)")
    @Description("Un Hit Sanction doit être injecté immédiatement, même si une version est déjà OPEN.")
    @Tag("sanctions")
    @Tag("critical")
    void sanctionsOverrideOpenVersion() {
        // GIVEN: Une revue est déjà en cours (ex: Changement Adresse)
        kycSteps.blockIsInitialized("Address");
        kycSteps.verifyVersionState("OPEN");

        // WHEN: Tentative trigger "Normal" (ex: Review KYC)
        kycSteps.triggerNewVersionAttempt();
        kycSteps.verifyNoNewVersionCreated(); // Bloqué par règle unicité

        // WHEN: Trigger CRITIQUE (Sanction UN)
        kycSteps.sanctionsHitDetected("UN Security Council");

        // THEN: Le système force l'injection
        kycSteps.verifyFastTrackInjection();
        kycSteps.verifyImmediateAssetFreeze();
    }
}
