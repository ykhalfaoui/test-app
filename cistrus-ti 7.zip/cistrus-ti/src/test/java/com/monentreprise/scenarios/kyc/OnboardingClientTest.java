package com.monentreprise.scenarios.kyc;

import com.monentreprise.citrus.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("🚀 Epic: Onboarding client")
@Feature("Onboarding client")
@Owner("equipe-kyc")
public class OnboardingClientTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("👤 Création des Remediation blocks pour un customer onboarded type Client")
    @DisplayName("✅ Onboarding Client Standard")
    @Description("À l'onboarding d'un customer type Client, il faut créer les 7 blocs de remédiation.")
    @Tag("kyc")
    @Tag("onboarding")
    void customer_onboarding_type_client() {
        kycSteps.customerNotOnboarded();
        kycSteps.customerOnboardedSuccessfully("Client");
        kycSteps.verifyRemediationBlocksCreated(7);
    }

    @Test
    @Story("🔗 Création des Remediation blocks pour un customer onboarded type Third party")
    @DisplayName("✅ Onboarding Third Party")
    @Description("À l'onboarding d'un customer type Third Party, seuls 3 blocs sont concernés.")
    @Tag("kyc")
    @Tag("onboarding")
    void customer_onboarding_type_third_party() {
        kycSteps.customerNotOnboarded();
        kycSteps.customerOnboardedSuccessfully("Third Party");
        kycSteps.verifyBlocksForThirdParty();
    }

    @Test
    @Story("🔄 Un customer switch de type Client à type Third Party")
    @DisplayName("🔄 Switch Client -> Third Party")
    @Description("Mise à jour des blocs: certains passent OUT_OF_SCOPE.")
    @Tag("kyc")
    @Tag("switch")
    void customer_switch_type_client_a_type_third_party() {
        kycSteps.customerExists("Client", "Active & Individual");
        kycSteps.customerSwitchType("Client", "Third Party");
        kycSteps.verifyBlocksUpdated();
        kycSteps.verifyOtherBlocksOutOfScope();
    }

    @Test
    @Story("🔄 Un customer switch de type Third Party à type Client")
    @DisplayName("🔄 Switch Third Party -> Client")
    @Description("Mise à jour des blocs: tous doivent être activés.")
    @Tag("kyc")
    @Tag("switch")
    void customer_switch_type_third_party_a_type_client() {
        kycSteps.customerExists("Third Party", "Active");
        kycSteps.customerSwitchType("Third Party", "Client");
        kycSteps.verifyAllBlocksInitialized();
    }

    @Test
    @Story("🚪 Un customer quitte la banque")
    @DisplayName("🚪 Départ Client (Inactive)")
    @Description("Le client passe Inactive, les blocs OUT_OF_SCOPE.")
    @Tag("kyc")
    @Tag("lifecycle")
    void customer_quitte_la_banque() {
        kycSteps.customerExists("Client", "Active");
        kycSteps.customerLeavesBank();
        kycSteps.verifyCustomerStatus("Inactive");
        kycSteps.verifyOtherBlocksOutOfScope();
    }

    @Test
    @Story("🔙 Un customer revient à la banque")
    @DisplayName("🔙 Retour Client")
    @Description("Le client redevient Active, réinitialisation des blocs.")
    @Tag("kyc")
    @Tag("lifecycle")
    void customer_revenir_la_banque() {
        kycSteps.customerExists("Client", "Inactive");
        kycSteps.customerReturnsToBank();
        kycSteps.verifyCustomerStatus("Active");
        kycSteps.verifyAllBlocksInitialized();
    }
}
