package com.monentreprise.steps.cucumber;

import com.monentreprise.steps.kyc.KycSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/**
 * Steps Cucumber pour la feature KycBlocks (anglais).
 * Gère la validation en masse des statuts des blocs KYC.
 */
public class KycCucumberSteps {

    @Autowired
    private KycSteps kycSteps;

    @Given("Les blocs sont initialisés avec les statuts suivants:")
    public void les_blocs_sont_initialises(DataTable dataTable) {
        Allure.step("📋 GIVEN: Initialisation des blocs", () -> {
            Map<String, String> blocks = dataTable.asMap(String.class, String.class);
            blocks.forEach((block, status) -> kycSteps.setBlockStatus(block, status));

            StringBuilder html = new StringBuilder();
            html.append("<table style='border-collapse:collapse;width:100%;'>");
            html.append("<tr style='background:#1565c0;color:white;'>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>📦 Bloc</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>📊 Statut initial</th>");
            html.append("</tr>");
            blocks.forEach((block, status) -> {
                html.append("<tr style='background:#e3f2fd;'>");
                html.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>").append(block).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;'>").append(status).append("</td>");
                html.append("</tr>");
            });
            html.append("</table>");
            Allure.addAttachment("📊 État initial des blocs", "text/html", html.toString(), ".html");
        });
    }

    @When("Le système effectue une mise à jour des statuts")
    public void le_systeme_effectue_une_mise_a_jour() {
        Allure.step("⚡ WHEN: Mise à jour système des statuts", () -> {
            kycSteps.simulateSystemAction();
        });
    }

    @Then("Je valide que les blocs sont dans les statuts:")
    public void je_valide_les_statuts(DataTable dataTable) {
        Allure.step("✅ THEN: Validation des statuts finaux", () -> {
            Map<String, String> expectedStatuses = dataTable.asMap(String.class, String.class);
            kycSteps.verifyBlockStatuses(expectedStatuses);

            StringBuilder html = new StringBuilder();
            html.append("<table style='border-collapse:collapse;width:100%;'>");
            html.append("<tr style='background:#2e7d32;color:white;'>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>📦 Bloc</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>📊 Statut attendu</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>✅ Résultat</th>");
            html.append("</tr>");
            expectedStatuses.forEach((block, status) -> {
                html.append("<tr style='background:#e8f5e9;'>");
                html.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>").append(block).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;'>").append(status).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;color:#2e7d32;'>✅ OK</td>");
                html.append("</tr>");
            });
            html.append("</table>");
            Allure.addAttachment("📊 Validation des statuts finaux", "text/html", html.toString(), ".html");
        });
    }
}
