package com.monentreprise.steps.cucumber;

import com.monentreprise.steps.kyc.KycSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

import static com.monentreprise.steps.cucumber.AllureReportHelper.*;

/**
 * Cucumber steps for Counterparty Onboarding scenarios.
 * Handles counterparty creation, type switching,
 * departure and return to the bank.
 */
public class OnboardingCucumberSteps {

    @Autowired
    private KycSteps kycSteps;

    // ═══════════════════════════════════════════════════════════════════════
    // BACKGROUND
    // ═══════════════════════════════════════════════════════════════════════

    @Given("the KYC system is initialized and operational")
    public void theKycSystemIsInitialized() {
        Allure.step("🔧 KYC System Initialization", () -> {
            kycSteps.logStep("⚙️ KYC system initialized and operational");
            Allure.addAttachment("📋 System Status",
                    "text/html",
                    "<div style='background:#e8f5e9;padding:10px;border-radius:5px;'>"
                            + "<b style='color:#2e7d32;'>✅ KYC System</b>: Operational<br/>"
                            + "<b style='color:#2e7d32;'>✅ Salesforce</b>: Connected<br/>"
                            + "<b style='color:#2e7d32;'>✅ iHub</b>: Connected"
                            + "</div>",
                    ".html");
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // GIVEN - Preconditions
    // ═══════════════════════════════════════════════════════════════════════

    @Given("a new counterparty of type {string} is onboarded at the bank")
    public void aNewCounterpartyIsOnboarded(String type) {
        Allure.parameter("🏢 Counterparty Type", type);
        Allure.step("📋 GIVEN: New counterparty of type " + type + " onboarded", () -> {
            kycSteps.customerOnboardedSuccessfully(type);
            kycSteps.addParameter("Counterparty Type", type);
            kycSteps.logStep("🆕 New counterparty of type " + type + " onboarded at the bank");
        });
    }

    @Given("an existing counterparty of type {string} is active")
    public void anExistingCounterpartyIsActive(String type) {
        Allure.parameter("🏢 Counterparty Type", type);
        Allure.step("📋 GIVEN: Existing counterparty of type " + type + " active", () -> {
            kycSteps.customerExists(type, "ACTIVE");
            kycSteps.logStep("👤 Existing counterparty of type " + type + " with status ACTIVE");
        });
    }

    @Given("a counterparty has left the bank")
    public void aCounterpartyHasLeftTheBank() {
        Allure.step("📋 GIVEN: Counterparty has left the bank", () -> {
            kycSteps.customerExists("CLIENT", "LEFT");
            kycSteps.logStep("🚪 Counterparty has already left the bank");
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // WHEN - Actions
    // ═══════════════════════════════════════════════════════════════════════

    @When("the onboarding notification is received")
    public void theOnboardingNotificationIsReceived() {
        Allure.step("⚡ WHEN: Onboarding notification received", () -> {
            kycSteps.logStep("📨 Onboarding notification received - Triggering block creation");
        });
    }

    @When("the counterparty switches type to {string}")
    public void theCounterpartySwitchesTypeTo(String newType) {
        Allure.parameter("🔄 New Type", newType);
        Allure.step("⚡ WHEN: Type switch to " + newType, () -> {
            kycSteps.customerSwitchType("CURRENT", newType);
            kycSteps.logStep("🔄 Counterparty type switched to " + newType);
        });
    }

    @When("the counterparty leaves the bank")
    public void theCounterpartyLeavesTheBank() {
        Allure.step("⚡ WHEN: Counterparty departure", () -> {
            kycSteps.customerLeavesBank();
            kycSteps.logStep("🚪 The counterparty leaves the bank");
        });
    }

    @When("the counterparty returns to the bank")
    public void theCounterpartyReturnsToTheBank() {
        Allure.step("⚡ WHEN: Counterparty return", () -> {
            kycSteps.customerReturnsToBank();
            kycSteps.logStep("🔙 The counterparty returns to the bank");
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // THEN - Assertions
    // ═══════════════════════════════════════════════════════════════════════

    @Then("remediation blocks are created in version {int} with the following statuses:")
    public void remediationBlocksAreCreatedInVersion(int version, DataTable dataTable) {
        Allure.parameter("📦 Version", String.valueOf(version));
        Allure.step("✅ THEN: Remediation blocks created in version " + version, () -> {
            List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
            kycSteps.verifyRemediationBlocksCreated(rows.size());

            for (Map<String, String> row : rows) {
                kycSteps.setBlockStatus(row.get("Block"), row.get("Status"));
                kycSteps.verifyBlockStatus(row.get("Block"), row.get("Status"));
            }

            Allure.addAttachment("📊 Remediation Blocks - Version " + version,
                    "text/html",
                    buildBlockStatusTable("Remediation Blocks", "#1565c0", rows, "Block", "Status"),
                    ".html");
        });
    }

    @Then("a new version of the blocks is created with the following statuses:")
    public void aNewVersionOfTheBlocksIsCreated(DataTable dataTable) {
        Allure.step("✅ THEN: New block version created", () -> {
            List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
            kycSteps.verifyBlocksUpdated();

            for (Map<String, String> row : rows) {
                kycSteps.setBlockStatus(row.get("Block"), row.get("Status"));
                kycSteps.verifyBlockStatus(row.get("Block"), row.get("Status"));
            }

            Allure.addAttachment("📊 New Block Version",
                    "text/html",
                    buildBlockStatusTable("New Block Version", "#6a1b9a", rows, "Block", "Status"),
                    ".html");
        });
    }

    @Then("the blocks are preserved and not deleted")
    public void theBlocksArePreservedAndNotDeleted() {
        Allure.step("✅ THEN: Blocks preserved after departure", () -> {
            kycSteps.logStep("🔒 Blocks are preserved - No deletion performed");
            Allure.addAttachment("📋 Block Preservation",
                    "text/html",
                    "<div style='background:#fff3e0;padding:10px;border-radius:5px;border-left:4px solid #ff9800;'>"
                            + "<b style='color:#e65100;'>⚠️ BUSINESS RULE</b><br/>"
                            + "Remediation blocks are <b>NEVER</b> deleted when a client leaves the bank.<br/>"
                            + "They are preserved for audit trail and regulatory traceability."
                            + "</div>",
                    ".html");
        });
    }

    @And("the blocks are synchronized in Salesforce")
    public void theBlocksAreSynchronizedInSalesforce() {
        Allure.step("🔄 AND: Salesforce Synchronization", () -> {
            kycSteps.verifyBlocksAndReviewSynced();
            kycSteps.logStep("☁️ Blocks successfully synchronized in Salesforce");
            Allure.addAttachment("☁️ Salesforce Sync",
                    "text/html",
                    "<div style='background:#e3f2fd;padding:10px;border-radius:5px;border-left:4px solid #1976d2;'>"
                            + "<b style='color:#1565c0;'>☁️ SALESFORCE SYNC</b><br/>"
                            + "✅ Blocks synchronized<br/>"
                            + "✅ Statuses updated<br/>"
                            + "✅ Versions aligned"
                            + "</div>",
                    ".html");
        });
    }
}
