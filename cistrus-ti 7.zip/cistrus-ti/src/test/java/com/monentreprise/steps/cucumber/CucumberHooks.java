package com.monentreprise.steps.cucumber;

import com.monentreprise.steps.kyc.KycSteps;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.qameta.allure.Allure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

import static com.monentreprise.steps.cucumber.AllureReportHelper.statusColor;
import static com.monentreprise.steps.cucumber.AllureReportHelper.statusIcon;

/**
 * Cucumber hooks for scenario lifecycle management.
 *
 * - @Before: resets all in-memory state so each scenario starts clean
 * - @After: attaches a summary report to Allure with final block states
 */
public class CucumberHooks {

    private static final Logger log = LoggerFactory.getLogger(CucumberHooks.class);

    @Autowired
    private KycSteps kycSteps;

    @Before(order = 0)
    public void resetState(Scenario scenario) {
        log.info("════════════════════════════════════════════════════════════");
        log.info("▶ Starting scenario: {}", scenario.getName());
        log.info("  Tags: {}", scenario.getSourceTagNames());
        log.info("════════════════════════════════════════════════════════════");

        kycSteps.reset();
    }

    @After(order = 0)
    public void attachSummary(Scenario scenario) {
        Map<String, String> finalStates = kycSteps.getBlockStates();

        StringBuilder html = new StringBuilder();
        html.append("<div style='font-family:Arial,sans-serif;'>");

        // Scenario header
        String headerColor = scenario.isFailed() ? "#c62828" : "#2e7d32";
        String headerIcon = scenario.isFailed() ? "❌" : "✅";
        String headerLabel = scenario.isFailed() ? "FAILED" : "PASSED";

        html.append("<div style='background:").append(headerColor)
                .append(";color:white;padding:12px;border-radius:5px 5px 0 0;'>");
        html.append("<b>").append(headerIcon).append(" Scenario: ").append(scenario.getName()).append("</b>");
        html.append("<br/>Result: <b>").append(headerLabel).append("</b>");
        html.append("</div>");

        // Tags
        if (!scenario.getSourceTagNames().isEmpty()) {
            html.append("<div style='background:#f5f5f5;padding:8px;'>");
            html.append("🏷️ Tags: ");
            for (String tag : scenario.getSourceTagNames()) {
                html.append("<span style='background:#e0e0e0;padding:2px 8px;border-radius:12px;margin:2px;display:inline-block;'>")
                        .append(tag).append("</span> ");
            }
            html.append("</div>");
        }

        // Block states summary (only if blocks were used in this scenario)
        if (!finalStates.isEmpty()) {
            html.append("<table style='border-collapse:collapse;width:100%;margin-top:8px;'>");
            html.append("<tr style='background:#37474f;color:white;'>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>📦 Block</th>");
            html.append("<th style='padding:8px;border:1px solid #ddd;'>📊 Final Status</th>");
            html.append("</tr>");

            for (Map.Entry<String, String> entry : finalStates.entrySet()) {
                html.append("<tr style='background:").append(statusColor(entry.getValue())).append(";'>");
                html.append("<td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>")
                        .append(entry.getKey()).append("</td>");
                html.append("<td style='padding:8px;border:1px solid #ddd;'>")
                        .append(statusIcon(entry.getValue())).append(" ").append(entry.getValue()).append("</td>");
                html.append("</tr>");
            }
            html.append("</table>");
        }

        html.append("</div>");

        Allure.addAttachment(headerIcon + " Scenario Summary - " + scenario.getName(),
                "text/html", html.toString(), ".html");

        log.info("════════════════════════════════════════════════════════════");
        log.info("◀ Scenario finished: {} → {}", scenario.getName(), headerLabel);
        if (!finalStates.isEmpty()) {
            log.info("  Final block states: {}", finalStates);
        }
        log.info("════════════════════════════════════════════════════════════");
    }
}
