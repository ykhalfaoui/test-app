package com.monentreprise.steps.paiements;

import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.actions.ExecuteSQLAction;
import org.citrusframework.actions.ExecuteSQLQueryAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Steps métier pour le domaine Paiements.
 * 
 * <h2>Objectif</h2>
 * Fournit un vocabulaire métier pour les tests de paiement.
 * 
 * <h2>Méthodes principales</h2>
 * <ul>
 *   <li>initierPaiement() - Démarre un paiement</li>
 *   <li>confirmerPaiement() - Simule la confirmation bancaire</li>
 *   <li>refuserPaiement() - Simule un refus</li>
 *   <li>verifierStatutPaiement() - Vérifie l'état</li>
 * </ul>
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@Component
public class PaiementSteps {

    private static final Logger log = LoggerFactory.getLogger(PaiementSteps.class);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Statuts de paiement
    public static final String STATUT_INITIATED = "INITIATED";
    public static final String STATUT_PENDING = "PENDING";
    public static final String STATUT_CONFIRMED = "CONFIRMED";
    public static final String STATUT_REFUSED = "REFUSED";
    public static final String STATUT_CANCELLED = "CANCELLED";
    public static final String STATUT_REFUNDED = "REFUNDED";

    // Modes de paiement
    public static final String MODE_CB = "CARTE_BANCAIRE";
    public static final String MODE_VIREMENT = "VIREMENT";
    public static final String MODE_PAYPAL = "PAYPAL";

    @Autowired
    @Qualifier("testDataSource")
    private DataSource dataSource;

    private TestCaseRunner runner;
    private String currentPaymentId;
    private String currentOrderId;

    /**
     * Initialise les steps avec le runner Citrus.
     */
    public PaiementSteps init(TestCaseRunner runner) {
        this.runner = runner;
        this.currentPaymentId = null;
        this.currentOrderId = null;
        return this;
    }

    /**
     * Associe une commande pour le paiement.
     */
    public PaiementSteps pourCommande(String orderId) {
        this.currentOrderId = orderId;
        runner.variable("orderId", orderId);
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ACTIONS (WHEN)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Initie un paiement pour la commande courante.
     */
    @Step("💳 Initiation paiement {montant}€ par {modePaiement}")
    public PaiementSteps initierPaiement(BigDecimal montant, String modePaiement) {
        this.currentPaymentId = "PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        runner.variable("paymentId", currentPaymentId);
        
        String now = LocalDateTime.now().format(DATE_FORMAT);
        
        Allure.step("Création enregistrement paiement", () -> {
            // Note: Dans un vrai système, ceci serait une table payments
            // Pour ce POC, on simule via un log structuré
            attachPaymentDetails(montant, modePaiement, STATUT_INITIATED);
        });
        
        Allure.parameter("💳 Paiement ID", currentPaymentId);
        Allure.parameter("💰 Montant", montant + "€");
        Allure.parameter("🏦 Mode", modePaiement);
        
        log.info("Paiement initié: {} - {}€ via {}", currentPaymentId, montant, modePaiement);
        return this;
    }

    /**
     * Simule la confirmation du paiement par la banque.
     */
    @Step("✅ Confirmation paiement (réponse bancaire positive)")
    public PaiementSteps confirmerPaiement() {
        String now = LocalDateTime.now().format(DATE_FORMAT);
        
        // Mise à jour du statut de la commande associée
        if (currentOrderId != null) {
            runner.$(ExecuteSQLAction.Builder.sql()
                .dataSource(dataSource)
                .statement("""
                    UPDATE orders 
                    SET status = 'PAID', paid_at = '%s', updated_at = '%s'
                    WHERE ref_id = '%s'
                    """.formatted(now, now, currentOrderId)));
        }
        
        Allure.addAttachment("📧 Confirmation bancaire", "text/plain", """
            ════════════════════════════════════════
            CONFIRMATION PAIEMENT
            ════════════════════════════════════════
            Transaction ID: %s
            Statut: CONFIRMED
            Date: %s
            Autorisation: AUTH-%s
            ════════════════════════════════════════
            """.formatted(currentPaymentId, now, UUID.randomUUID().toString().substring(0, 6).toUpperCase()), ".txt");
        
        log.info("Paiement confirmé: {}", currentPaymentId);
        return this;
    }

    /**
     * Simule un refus de paiement.
     */
    @Step("❌ Refus paiement - Motif: {motif}")
    public PaiementSteps refuserPaiement(String motif) {
        Allure.addAttachment("🚫 Refus bancaire", "text/plain", """
            ════════════════════════════════════════
            REFUS PAIEMENT
            ════════════════════════════════════════
            Transaction ID: %s
            Statut: REFUSED
            Motif: %s
            Code erreur: ERR-%s
            ════════════════════════════════════════
            """.formatted(currentPaymentId, motif, 
                UUID.randomUUID().toString().substring(0, 4).toUpperCase()), ".txt");
        
        log.info("Paiement refusé: {} - Motif: {}", currentPaymentId, motif);
        return this;
    }

    /**
     * Simule un remboursement.
     */
    @Step("💸 Remboursement effectué - Motif: {motif}")
    public PaiementSteps rembourser(String motif) {
        String now = LocalDateTime.now().format(DATE_FORMAT);
        
        Allure.addAttachment("💸 Remboursement", "text/plain", """
            ════════════════════════════════════════
            REMBOURSEMENT
            ════════════════════════════════════════
            Transaction origine: %s
            Statut: REFUNDED
            Motif: %s
            Date: %s
            ════════════════════════════════════════
            """.formatted(currentPaymentId, motif, now), ".txt");
        
        log.info("Remboursement effectué: {} - Motif: {}", currentPaymentId, motif);
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // VÉRIFICATIONS (THEN)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Vérifie que la commande associée est bien payée.
     */
    @Step("✓ Vérification commande payée")
    public PaiementSteps verifierCommandePayee() {
        runner.$(ExecuteSQLQueryAction.Builder.query()
            .dataSource(dataSource)
            .statement("SELECT status FROM orders WHERE ref_id = '" + currentOrderId + "'")
            .validate("status", "PAID"));
        
        log.info("Commande vérifiée payée: {}", currentOrderId);
        return this;
    }

    /**
     * Vérifie que la commande n'est pas payée.
     */
    @Step("✓ Vérification commande non payée")
    public PaiementSteps verifierCommandeNonPayee() {
        runner.$(ExecuteSQLQueryAction.Builder.query()
            .dataSource(dataSource)
            .statement("SELECT status FROM orders WHERE ref_id = '" + currentOrderId + "'")
            .validate("status", "VALIDATED")); // Reste en VALIDATED si paiement refusé
        
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    private void attachPaymentDetails(BigDecimal montant, String mode, String statut) {
        Allure.addAttachment("💳 Détails paiement", "text/plain", """
            ════════════════════════════════════════
            PAIEMENT
            ════════════════════════════════════════
            ID: %s
            Commande: %s
            Montant: %s€
            Mode: %s
            Statut: %s
            ════════════════════════════════════════
            """.formatted(currentPaymentId, currentOrderId, montant, mode, statut), ".txt");
    }

    public String getCurrentPaymentId() {
        return currentPaymentId;
    }
}
