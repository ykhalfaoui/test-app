package com.monentreprise.steps.commandes;

import com.monentreprise.utils.SqlUtils;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.actions.ExecuteSQLQueryAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.math.BigDecimal;

/**
 * Assertions métier fluentes pour les commandes.
 * 
 * <h2>Pattern Builder/Fluent</h2>
 * Permet d'enchaîner plusieurs vérifications de manière lisible.
 * 
 * <h2>Usage</h2>
 * 
 * <pre>{@code
 * commandeAssertions.pourCommande(orderId)
 *         .aLeStatut("VALIDATED")
 *         .aLeMontant(new BigDecimal("150.00"))
 *         .aPourClient("CLIENT_STANDARD")
 *         .verifier();
 * }</pre>
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@Component
public class CommandeAssertions {

    private static final Logger log = LoggerFactory.getLogger(CommandeAssertions.class);

    @Autowired
    @Qualifier("testDataSource")
    private DataSource dataSource;

    private TestCaseRunner runner;
    private String orderId;

    // Assertions à vérifier
    private String expectedStatus;
    private BigDecimal expectedAmount;
    private String expectedCustomer;
    private String expectedCustomerType;
    private Boolean shouldExist;

    /**
     * Initialise les assertions avec le runner.
     */
    public CommandeAssertions init(TestCaseRunner runner) {
        this.runner = runner;
        reset();
        return this;
    }

    /**
     * Cible une commande spécifique pour les assertions.
     */
    public CommandeAssertions pourCommande(String orderId) {
        this.orderId = orderId;
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ASSERTIONS FLUENTES
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Vérifie que la commande a le statut attendu.
     */
    public CommandeAssertions aLeStatut(String statut) {
        this.expectedStatus = statut;
        return this;
    }

    /**
     * Vérifie que la commande a le montant attendu.
     */
    public CommandeAssertions aLeMontant(BigDecimal montant) {
        this.expectedAmount = montant;
        return this;
    }

    /**
     * Vérifie que la commande appartient au client attendu.
     */
    public CommandeAssertions aPourClient(String client) {
        this.expectedCustomer = client;
        return this;
    }

    /**
     * Vérifie que la commande a le type de client attendu.
     */
    public CommandeAssertions aPourTypeClient(String typeClient) {
        this.expectedCustomerType = typeClient;
        return this;
    }

    /**
     * Vérifie que la commande existe.
     */
    public CommandeAssertions existe() {
        this.shouldExist = true;
        return this;
    }

    /**
     * Vérifie que la commande n'existe pas.
     */
    public CommandeAssertions nexistePas() {
        this.shouldExist = false;
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // EXÉCUTION DES ASSERTIONS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Exécute toutes les assertions configurées.
     */
    @Step("🔍 Vérification complète de la commande {orderId}")
    public void verifier() {
        if (orderId == null) {
            throw new IllegalStateException("Aucune commande ciblée. Appelez pourCommande() d'abord.");
        }

        StringBuilder resumeAssertions = new StringBuilder();
        resumeAssertions.append("Assertions pour commande: ").append(orderId).append("\n");

        // Vérification existence
        if (shouldExist != null) {
            verifierExistence(shouldExist);
            resumeAssertions.append("• Existence: ").append(shouldExist ? "OUI" : "NON").append("\n");
        }

        // Si la commande ne doit pas exister, on arrête là
        if (Boolean.FALSE.equals(shouldExist)) {
            attachResume(resumeAssertions.toString());
            reset();
            return;
        }

        // Vérification statut
        if (expectedStatus != null) {
            verifierStatut(expectedStatus);
            resumeAssertions.append("• Statut: ").append(expectedStatus).append("\n");
        }

        // Vérification montant
        if (expectedAmount != null) {
            verifierMontant(expectedAmount);
            resumeAssertions.append("• Montant: ").append(expectedAmount).append("€\n");
        }

        // Vérification client
        if (expectedCustomer != null) {
            verifierClient(expectedCustomer);
            resumeAssertions.append("• Client: ").append(expectedCustomer).append("\n");
        }

        // Vérification type client
        if (expectedCustomerType != null) {
            verifierTypeClient(expectedCustomerType);
            resumeAssertions.append("• Type client: ").append(expectedCustomerType).append("\n");
        }

        attachResume(resumeAssertions.toString());
        log.info("Toutes les assertions validées pour: {}", orderId);

        // Reset pour la prochaine utilisation
        reset();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // VÉRIFICATIONS UNITAIRES
    // ═══════════════════════════════════════════════════════════════════════════

    private void verifierExistence(boolean doitExister) {
        Allure.step("Vérification existence: " + (doitExister ? "OUI" : "NON"), () -> {
            String expectedCount = doitExister ? "1" : "0";
            runner.$(ExecuteSQLQueryAction.Builder.query()
                    .dataSource(dataSource)
                    .statement("SELECT COUNT(*) as cnt FROM orders WHERE ref_id = '" + SqlUtils.escape(orderId) + "'")
                    .validate("cnt", expectedCount));
        });
    }

    private void verifierStatut(String statut) {
        Allure.step("Vérification statut: " + statut, () -> {
            runner.$(ExecuteSQLQueryAction.Builder.query()
                    .dataSource(dataSource)
                    .statement("SELECT status FROM orders WHERE ref_id = '" + SqlUtils.escape(orderId) + "'")
                    .validate("status", statut));
        });
    }

    private void verifierMontant(BigDecimal montant) {
        Allure.step("Vérification montant: " + montant + "€", () -> {
            runner.$(ExecuteSQLQueryAction.Builder.query()
                    .dataSource(dataSource)
                    .statement("SELECT amount FROM orders WHERE ref_id = '" + SqlUtils.escape(orderId) + "'")
                    .validate("amount", montant.toString()));
        });
    }

    private void verifierClient(String client) {
        Allure.step("Vérification client: " + client, () -> {
            runner.$(ExecuteSQLQueryAction.Builder.query()
                    .dataSource(dataSource)
                    .statement("SELECT customer FROM orders WHERE ref_id = '" + SqlUtils.escape(orderId) + "'")
                    .validate("customer", client));
        });
    }

    private void verifierTypeClient(String typeClient) {
        Allure.step("Vérification type client: " + typeClient, () -> {
            runner.$(ExecuteSQLQueryAction.Builder.query()
                    .dataSource(dataSource)
                    .statement("SELECT customer_type FROM orders WHERE ref_id = '" + SqlUtils.escape(orderId) + "'")
                    .validate("customer_type", typeClient));
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    private void attachResume(String content) {
        Allure.addAttachment("📋 Résumé des assertions", "text/plain", content, ".txt");
    }

    private void reset() {
        this.orderId = null;
        this.expectedStatus = null;
        this.expectedAmount = null;
        this.expectedCustomer = null;
        this.expectedCustomerType = null;
        this.shouldExist = null;
    }
}
