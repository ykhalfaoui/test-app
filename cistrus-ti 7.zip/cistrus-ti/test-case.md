feture : ONboarding 

story : 
given nouveau party onboarde à la banque de type client
when notify 
then remediation block are created first version 
    block a avec le status init 
    block b avec le status init 
    ...
story : 
given nouveau party onboarde à la banque de type third party ()
when notify recieved
then remediation block are created with first version 
    block a avec le status init 
    block b avec le status init 
    ...
    block t avec le status out of scope
and block syncronized in salesforce
story : 
given when party switch to third party
then new version are create of blocks with
    block a avec le status init 
    block b avec le status init 
    ...
    block t avec le status out of scop  
and block syncronized in salesforce



given when  third party switch to client
then new version are create of blocks with
    block a avec le status init 
    block b avec le status init 
    ...
    block t avec le status init 
and block syncronized in salesforce


given existing client 
when  client or third party quitte la banque 
then les blocks sont concerver et ne sont pas supprimer


given when  client retourne à la banque àprès aoir la quitter  
hen new version are create of blocks with
    block a avec le status init 
    block b avec le status init 
    ...
    block t avec le status init 
and block syncronized in salesforce

------------

feature: Hit management 


given Party 0 'principal actor' de type client est active et digital 'dernier connxtion il y a moins de 2 mois'
    and  a des relations 
         -  avec party 1 , relation de type x 
         -  avec party 2 ,  relation de type y 
         -  avec party 3 ,  relation de type Z 
         -  avec party 4,  relation 
    and aucune revuew en cours 
when  a hit ddr ihub started
then hit est qualifié positive 
  and review created et started 
  and members created avec comme relation party 1,2,3,4 ...
  and party 0 principal actor sont block sont créer 
        -  static data avec les status under review by ihub 
        -  all other block dans status validated 'juste pour le lot 1'
        -  avec party 1  , blocks static data, name screening, doc common nouvelle version sont créer avec le status validated by system et static data  under review by ihub 
         -  avec party 2 ,  locks static data,  doc common nouvelle version sont créer avec le status validated by system et static data  under review by ihub 
         -  avec party 3 ,  locks static data,  doc common nouvelle version sont créer avec le status validated by system et static data  under review by ihub 
         -  avec party 4,  locks static data, doc common nouvelle version sont créer avec le status validated by system et static data  under review by ihub  
and  customer check created et related to the review in salesforce 
     -  review created with status 
     -  blocks members + actor pricncipal create in sf 
     -  familly syncroniseed dans salesforce 

feature: gestion de block static data 
remarque : il faut notter que si le customer est digital soir le principal ou member , le blocks static data aura le status under review ihub (bleu). si non , il n'est pas pas pris en compte dans cette review un status gris.  pour les autres blocks sont status Validated by system pour le moment par ce que ce n'est pas developer.  
les blocks impacter par chaque members dépond de type de relation.  

la suite de ce flux ,  
1. initilization de la review à la reception de la notification 126.  
2. pour le block static data , 
  - ihub envoi une notification 126 , le block static data passe au status ' Validated by Customer' 
  - ihub envoi une notification 127: block n'est pas validated by customer 
  -  ihub envoi la notificaton 86: le block static data passe à validated by customer 
  -  ihub envoi la notification 87:  le block static data passe à validate by customer ou no validate by cystomer , si seulement selon le flag ecstatic data est true ou false.  
   changement de status par kyc officer:  
  - entre temps,  un kyc officer peut changer le status manuellment: 
    - under review manuelle , qu'il va travailler sur le block 
    - escalated de compliance s'il veut de l'aide 
    - ....

----
given Party 0 'principal actor' de type client est active et 
    et review en cours 
when ddr started ' par error par example doublon de review'
then le hit est qualifiy not permenant 
   and no nouvealle review est started 
   and customer check est créer dans salesforce avec un status not perminant and message ' une reiview encours' 
