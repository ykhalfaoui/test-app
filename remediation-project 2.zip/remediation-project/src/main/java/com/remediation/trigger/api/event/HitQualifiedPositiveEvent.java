package com.remediation.trigger.api.event;

import java.util.UUID;

// Published when a hit is received and deemed positive after qualification.
public record HitQualifiedPositiveEvent(
    UUID hitId,
    String customerId
) {}
