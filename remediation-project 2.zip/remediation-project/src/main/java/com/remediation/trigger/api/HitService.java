package com.remediation.trigger.api;

public interface HitService {
    void processIncomingHit(String payload);
}
