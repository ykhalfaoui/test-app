@org.springframework.modulith.ApplicationModule(
    allowedDependencies = "review"
)
package com.remediation.trigger;