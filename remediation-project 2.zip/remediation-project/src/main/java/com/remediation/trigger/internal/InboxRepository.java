package com.remediation.trigger.internal;

import java.util.UUID;

// Represents the persistence for the Inbox pattern
public interface InboxRepository {
    boolean exists(UUID eventId);
    void save(UUID eventId);
}
