package com.remediation.integration.salesforce.api;

// Anti-Corruption Layer interface for Salesforce
public interface SalesforceClient {
    // void upsertReview(SalesforceReviewDto reviewDto);
    // void upsertBlock(SalesforceBlockDto blockDto);
}
