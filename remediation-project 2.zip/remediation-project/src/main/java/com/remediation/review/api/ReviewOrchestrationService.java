package com.remediation.review.api;

import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;

public interface ReviewOrchestrationService {
    void startReviewFromHit(HitQualifiedPositiveEvent event);
}
