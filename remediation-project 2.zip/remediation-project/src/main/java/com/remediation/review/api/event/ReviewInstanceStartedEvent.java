package com.remediation.review.api.event;

import java.util.UUID;

// Published when a review instance is successfully created.
public record ReviewInstanceStartedEvent(
    UUID reviewInstanceId,
    String customerId,
    String triggerType
) {}
