package com.remediation.review.domain;

import org.springframework.data.repository.Repository;

import java.util.Optional;
import java.util.UUID;

public interface ReviewInstanceRepository extends Repository<ReviewInstance, UUID> {
    void save(ReviewInstance reviewInstance);
    Optional<ReviewInstance> findById(UUID id);
}
