package com.remediation.review.internal;

import com.remediation.block.api.Block;
import com.remediation.block.api.BlockService;
import com.remediation.review.api.ReviewOrchestrationService;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.review.domain.ReviewInstance;
import com.remediation.review.domain.ReviewInstanceRepository;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
class ReviewOrchestrationServiceImpl implements ReviewOrchestrationService {

    private final BlockService blockService;
    private final ReviewInstanceRepository repository;
    private final ApplicationEventPublisher events;

    ReviewOrchestrationServiceImpl(BlockService blockService, ReviewInstanceRepository repository, ApplicationEventPublisher events) {
        this.blockService = blockService;
        this.repository = repository;
        this.events = events;
    }

    @Override
    @ApplicationModuleListener
    public void startReviewFromHit(HitQualifiedPositiveEvent hitEvent) {
        System.out.println("ReviewContext received HitQualifiedPositiveEvent for customer: " + hitEvent.customerId());

        // 1. Create the ReviewInstance aggregate
        var reviewInstance = new ReviewInstance(hitEvent.customerId(), "HIT");

        // 2. Find which blocks to review by querying the BlockContext
        List<Block> blocksToReview = blockService.getBlocksForCustomer(hitEvent.customerId());
        System.out.println("Found " + blocksToReview.size() + " blocks to review.");

        // 3. For each block, send a command to the BlockContext to start the review
        for (Block block : blocksToReview) {
            blockService.startReviewOnBlock(block.getId(), reviewInstance.getId());
        }

        // 4. Save the new aggregate
        repository.save(reviewInstance);

        // 5. Publish an event to notify that the review has started
        var reviewStartedEvent = new ReviewInstanceStartedEvent(reviewInstance.getId(), hitEvent.customerId(), "HIT");
        events.publishEvent(reviewStartedEvent);
    }
}
