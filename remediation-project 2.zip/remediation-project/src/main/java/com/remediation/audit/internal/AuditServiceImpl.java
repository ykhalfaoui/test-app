package com.remediation.audit.internal;

import com.remediation.audit.api.AuditService;
import org.springframework.stereotype.Service;

@Service
class AuditServiceImpl implements AuditService {

    @Override
    public void logEvent(String eventType, String entityId, Object details) {
        // In a real implementation, this would save an AuditTrail entity to the database.
        System.out.printf("[AUDIT LOG] || Event: %s || Entity ID: %s || Details: %s%n",
                eventType, entityId, details.toString());
    }

    @Override
    public void logError(Object methodSignature, Throwable error) {
        System.out.printf("[AUDIT ERROR] || Method: %s || Exception: %s%n",
                methodSignature.toString(), error.getMessage());
    }
}
