package com.remediation.audit.aop;

import com.remediation.audit.api.AuditService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ErrorLoggingAspect {

    private final AuditService auditService;

    public ErrorLoggingAspect(AuditService auditService) {
        this.auditService = auditService;
    }

    /**
     * Pointcut to intercept all public methods in all services across the application.
     */
    @AfterThrowing(pointcut = "execution(public * com.remediation..*Service.*(..))", throwing = "ex")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable ex) {
        auditService.logError(joinPoint.getSignature().toShortString(), ex);
    }
}
