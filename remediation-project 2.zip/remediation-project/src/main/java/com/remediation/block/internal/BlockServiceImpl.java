package com.remediation.block.internal;

import com.remediation.block.api.Block;
import com.remediation.block.api.BlockService;
import com.remediation.block.api.event.BlockReviewStartedEvent;
import com.remediation.block.domain.BlockRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
class BlockServiceImpl implements BlockService {

    private final BlockRepository repository;
    private final ApplicationEventPublisher events;

    BlockServiceImpl(BlockRepository repository, ApplicationEventPublisher events) {
        this.repository = repository;
        this.events = events;
    }

    @Override
    public List<Block> getBlocksForCustomer(String customerId) {
        // In a real implementation, this would fetch from the database.
        // Here, we simulate finding one block for the customer.
        System.out.println("BlockContext searching for blocks for customer: " + customerId);
        return List.of(new Block(customerId));
    }

    @Override
    public void startReviewOnBlock(UUID blockId, UUID reviewInstanceId) {
        System.out.println("BlockContext received command to start review on block: " + blockId);
        // In a real app, we would load the block from the repository.
        // Block block = repository.findById(blockId).orElseThrow();
        Block block = new Block("customer-123"); // Simulating

        block.startReview(reviewInstanceId);

        // repository.save(block);

        // Publish event
        events.publishEvent(new BlockReviewStartedEvent(blockId, reviewInstanceId));
    }
}
