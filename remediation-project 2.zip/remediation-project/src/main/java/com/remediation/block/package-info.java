@org.springframework.modulith.ApplicationModule(
    allowedDependencies = "customer"
)
package com.remediation.block;