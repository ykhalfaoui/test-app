package com.remediation.block.api;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

// Aggregate Root for the Block Context, exposed as part of the API
public class Block {

    private final UUID id;
    private final String customerId;
    private String status;
    private final Set<UUID> activeReviews = new HashSet<>();

    // Constructor for creating a new block
    public Block(String customerId) {
        this.id = UUID.randomUUID();
        this.customerId = customerId;
        this.status = "UP_TO_DATE";
    }

    public void startReview(UUID reviewInstanceId) {
        if (!"IN_REVIEW".equals(this.status)) {
            this.status = "IN_REVIEW";
        }
        this.activeReviews.add(reviewInstanceId);
        System.out.println("Block " + this.id + " is now IN_REVIEW for review " + reviewInstanceId);
    }

    public UUID getId() {
        return id;
    }

    public String getCustomerId() {
        return customerId;
    }
}