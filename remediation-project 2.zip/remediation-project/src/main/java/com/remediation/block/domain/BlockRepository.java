package com.remediation.block.domain;

import com.remediation.block.api.Block;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BlockRepository extends Repository<Block, UUID> {
    void save(Block block);
    Optional<Block> findById(UUID id);
    List<Block> findByCustomerId(String customerId);
}
