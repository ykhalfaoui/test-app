@org.springframework.modulith.ApplicationModule
package com.remediation.customer;