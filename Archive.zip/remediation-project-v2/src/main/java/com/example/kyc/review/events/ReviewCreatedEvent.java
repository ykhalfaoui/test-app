package com.example.kyc.review.events;

import org.springframework.modulith.events.Externalized;

import java.util.UUID;

/**
 * A Domain Event published when a new Review aggregate is created.
 * This event is also externalized to be consumed by the 'salesforce' module to trigger the sync saga.
 */
@Externalized("kyc.review.created")
public record ReviewCreatedEvent(
    UUID reviewId
) {}
