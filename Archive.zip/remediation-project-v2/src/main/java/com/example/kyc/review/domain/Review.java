package com.example.kyc.review.domain;

import com.example.kyc.review.events.ReviewCreatedEvent;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.AbstractAggregateRoot;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "reviews")
@Getter
@Setter
@NoArgsConstructor
public class Review extends AbstractAggregateRoot<Review> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false)
    private String hitId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReviewStatus status;

    @Column(nullable = false)
    private Instant createdAt;

    @OneToMany(mappedBy = "review", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Family> families = new ArrayList<>();

    public Review(String hitId) {
        this.hitId = hitId;
        this.status = ReviewStatus.LOCAL_PENDING;
        this.createdAt = Instant.now();

        // Register a domain event to be published on save
        registerEvent(new ReviewCreatedEvent(this.id));
    }

    public void addFamily(Family family) {
        this.families.add(family);
        family.setReview(this);
    }
}
