package com.example.kyc.hit;

import org.springframework.modulith.events.Externalized;

/**
 * Published when a Hit is successfully qualified.
 * This event is externalized to be consumed by other modules (e.g., 'review').
 */
@Externalized("kyc.hit.qualified")
public record HitQualifiedEvent(
    String hitId,
    String details
) {}
