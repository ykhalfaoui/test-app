@org.springframework.modulith.ApplicationModule(
    allowedDependencies = "infrastructure"
)
package com.example.kyc.audit;
