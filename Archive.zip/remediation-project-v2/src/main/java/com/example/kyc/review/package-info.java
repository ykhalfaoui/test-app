@org.springframework.modulith.ApplicationModule(
    allowedDependencies = {"infrastructure", "hit"}
)
package com.example.kyc.review;
