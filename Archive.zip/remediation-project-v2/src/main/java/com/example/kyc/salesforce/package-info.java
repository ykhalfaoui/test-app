@org.springframework.modulith.ApplicationModule(
    allowedDependencies = {"infrastructure", "review"}
)
package com.example.kyc.salesforce;
