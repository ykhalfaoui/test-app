package com.example.kyc.salesforce;

import com.example.kyc.review.domain.Review;
import com.example.kyc.review.domain.ReviewRepository;
import com.example.kyc.review.events.ReviewCreatedEvent;
import com.example.kyc.salesforce.outbox.EventType;
import com.example.kyc.salesforce.outbox.OutboxMessage;
import com.example.kyc.salesforce.outbox.OutboxMessageRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class SalesforceReviewSyncSaga {

    private final ReviewRepository reviewRepository;
    private final OutboxMessageRepository outboxRepository;
    private final ObjectMapper objectMapper;

    /**
     * SAGA - STEP 1: Triggered when a review is created.
     * Creates an outbox message to create the corresponding "Review" in Salesforce.
     */
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    @Transactional
    @SneakyThrows
    public void handleReviewCreation(ReviewCreatedEvent event) {
        log.info("[SAGA] Step 1: ReviewCreatedEvent received for reviewId {}. Creating SFDC Review outbox message.", event.reviewId());

        Review review = reviewRepository.findById(event.reviewId()).orElseThrow();

        // Create a JSON payload for the outbox message
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("localReviewId", review.getId().toString());
        payload.put("hitId", review.getHitId());
        payload.put("status", "Draft"); // Initial status in Salesforce

        OutboxMessage outboxMessage = new OutboxMessage(
            review.getId(),
            EventType.CREATE_SFDC_REVIEW,
            objectMapper.writeValueAsString(payload)
        );

        outboxRepository.save(outboxMessage);
    }

    /**
     * SAGA - STEP 2: Triggered when Salesforce confirms Review creation.
     * Creates outbox messages to bulk-create Members and Blocks.
     */
    @Transactional
    @SneakyThrows
    public void handleSfdcReviewCreated(UUID localReviewId, String sfdcReviewId) {
        log.info("[SAGA] Step 2: SFDC Review {} created for local review {}. Creating bulk outbox messages.", sfdcReviewId, localReviewId);

        // In a real app, you would fetch all members/blocks for the review
        // and create a detailed payload for the bulk API.
        ObjectNode membersPayload = objectMapper.createObjectNode();
        membersPayload.put("sfdcReviewId", sfdcReviewId);
        membersPayload.put("membersCount", 5); // Dummy data

        OutboxMessage membersMessage = new OutboxMessage(
            localReviewId,
            EventType.CREATE_SFDC_MEMBERS_BULK,
            objectMapper.writeValueAsString(membersPayload)
        );

        ObjectNode blocksPayload = objectMapper.createObjectNode();
        blocksPayload.put("sfdcReviewId", sfdcReviewId);
        blocksPayload.put("blocksCount", 10); // Dummy data

        OutboxMessage blocksMessage = new OutboxMessage(
            localReviewId,
            EventType.CREATE_SFDC_BLOCKS_BULK,
            objectMapper.writeValueAsString(blocksPayload)
        );

        outboxRepository.save(membersMessage);
        outboxRepository.save(blocksMessage);
    }

    /**
     * SAGA - STEP 3: Triggered when bulk creation is done.
     * Creates a final outbox message to activate the Review in Salesforce.
     */
    @Transactional
    @SneakyThrows
    public void handleBulkCreationCompleted(UUID localReviewId, String sfdcReviewId) {
        log.info("[SAGA] Step 3: Bulk creation finished for SFDC Review {}. Activating review.", sfdcReviewId);

        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("sfdcReviewId", sfdcReviewId);
        payload.put("status", "In Progress");

        OutboxMessage updateMessage = new OutboxMessage(
            localReviewId,
            EventType.UPDATE_SFDC_REVIEW_STATUS,
            objectMapper.writeValueAsString(payload)
        );

        outboxRepository.save(updateMessage);
    }
}
