package com.example.kyc.review;

import com.example.kyc.hit.HitQualifiedEvent;
import com.example.kyc.review.domain.*;
import com.example.kyc.review.events.ReviewCreatedEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReviewService {

    private final ReviewRepository reviewRepository;

    /**
     * Creates the main Review aggregate from a HitQualifiedEvent.
     * The save() operation will automatically publish the ReviewCreatedEvent
     * thanks to AbstractAggregateRoot.
     */
    @Transactional
    public Review createReviewFromHit(HitQualifiedEvent event) {
        log.info("Creating review for hitId: {}", event.hitId());
        Review review = new Review(event.hitId());
        return reviewRepository.save(review);
    }

    /**
     * Orchestrates the creation of sub-entities for a given Review.
     * This is called by an internal event listener after the Review is created.
     */
    @Transactional
    public void orchestrateSubEntityCreation(ReviewCreatedEvent event) {
        log.info("Orchestrating sub-entity creation for reviewId: {}", event.reviewId());

        Review review = reviewRepository.findById(event.reviewId())
            .orElseThrow(() -> new IllegalArgumentException("Review not found: " + event.reviewId()));

        // Simulate creating families, members, and blocks
        Family family1 = new Family("Smith");
        Member john = new Member("John", "Smith");
        john.addBlock(new Block("Address", "123 Main St"));
        family1.addMember(john);

        review.addFamily(family1);

        // Saving the review will cascade and save all sub-entities
        reviewRepository.save(review);
        log.info("Finished creating sub-entities for reviewId: {}", event.reviewId());
    }
}
