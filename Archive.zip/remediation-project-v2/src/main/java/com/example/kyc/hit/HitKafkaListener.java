package com.example.kyc.hit;

import com.example.kyc.hit.inbox.InboxMessage;
import com.example.kyc.hit.inbox.InboxMessageRepository;
import com.example.kyc.hit.inbox.MessageStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
@Slf4j
public class HitKafkaListener {

    private final InboxMessageRepository inboxRepository;
    private final HitQualificationService qualificationService;

    private static final String INCOMING_HITS_TOPIC = "incoming_hits";

    @KafkaListener(topics = INCOMING_HITS_TOPIC, groupId = "kyc-group")
    @Transactional
    public void handleIncomingHit(
        @Payload String payload,
        @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String messageId,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic
    ) {
        log.info("Received message {} from topic {}", messageId, topic);

        // Idempotency Check (Inbox Pattern)
        if (inboxRepository.existsByMessageId(messageId)) {
            log.warn("Message {} already processed. Ignoring.", messageId);
            return;
        }

        // 1. Save to Inbox
        InboxMessage inboxMessage = new InboxMessage(messageId, topic, payload);
        inboxRepository.save(inboxMessage);
        log.info("Saved message {} to inbox with status PENDING.", messageId);

        try {
            // 2. Process the message
            qualificationService.qualify(payload);

            // 3. Update status to PROCESSED
            inboxMessage.setStatus(MessageStatus.PROCESSED);
            inboxRepository.save(inboxMessage);
            log.info("Successfully processed message {}. Status set to PROCESSED.", messageId);

        } catch (Exception e) {
            log.error("Error processing message {}", messageId, e);
            inboxMessage.setStatus(MessageStatus.FAILED);
            inboxRepository.save(inboxMessage);
            // Depending on the error, you might want to throw it to trigger Kafka retries
            // or handle it gracefully here.
        }
    }
}
