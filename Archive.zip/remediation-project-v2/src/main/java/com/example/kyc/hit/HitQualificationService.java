package com.example.kyc.hit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class HitQualificationService {

    private final ApplicationEventPublisher events;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public void qualify(String payload) {
        log.info("Qualifying hit...");
        try {
            JsonNode root = objectMapper.readTree(payload);
            // Example qualification logic: check for a specific field/value
            if (root.has("type") && "positif".equalsIgnoreCase(root.get("type").asText())) {
                String hitId = root.has("hitId") ? root.get("hitId").asText() : UUID.randomUUID().toString();
                log.info("Hit {} is qualified.", hitId);

                // Publish an event for other modules to consume
                HitQualifiedEvent event = new HitQualifiedEvent(hitId, "Hit contains 'positif' type");
                events.publishEvent(event);

            } else {
                log.info("Hit does not meet qualification criteria.");
            }
        } catch (JsonProcessingException e) {
            log.error("Failed to parse hit payload", e);
        }
    }
}
