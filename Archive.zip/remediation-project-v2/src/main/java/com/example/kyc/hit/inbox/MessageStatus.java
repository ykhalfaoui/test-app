package com.example.kyc.hit.inbox;

public enum MessageStatus {
    PENDING,
    PROCESSED,
    FAILED
}
