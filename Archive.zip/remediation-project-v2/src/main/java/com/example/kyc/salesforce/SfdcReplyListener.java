package com.example.kyc.salesforce;

import com.example.kyc.salesforce.outbox.OutboxMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * This class simulates the consumption of replies from Salesforce.
 * In a real application, this would be a Kafka Listener consuming from a `sfdc_replies` topic.
 * For this simulation, it's called directly by the Outbox Poller to advance the saga.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class SfdcReplyListener {

    private final SalesforceReviewSyncSaga saga;
    private static long sfdcIdCounter = 1000;

    public void simulateSfdcReply(OutboxMessage processedMessage) {
        // This method simulates a reply being received for the message that was just sent.
        UUID localReviewId = processedMessage.getAggregateId();
        String sfdcReviewId = "SFDC-" + sfdcIdCounter++; // Generate a fake SFDC ID

        switch (processedMessage.getEventType()) {
            case CREATE_SFDC_REVIEW:
                log.info("Simulating SFDC reply: Review created with ID {}.", sfdcReviewId);
                // Trigger the next step of the saga
                saga.handleSfdcReviewCreated(localReviewId, sfdcReviewId);
                break;

            case CREATE_SFDC_MEMBERS_BULK:
            case CREATE_SFDC_BLOCKS_BULK:
                log.info("Simulating SFDC reply: Bulk operation {} completed.", processedMessage.getEventType());
                // In a real saga, you'd wait for ALL bulk operations to complete.
                // Here, we'll just simplify and assume one reply is enough to proceed.
                saga.handleBulkCreationCompleted(localReviewId, sfdcReviewId);
                break;

            case UPDATE_SFDC_REVIEW_STATUS:
                log.info("[SAGA] End: Review status updated in Salesforce. Saga complete for review {}.", localReviewId);
                break;

            default:
                log.warn("No reply simulation logic for event type: {}", processedMessage.getEventType());
                break;
        }
    }
}
