package com.example.kyc.salesforce.outbox;

public enum OutboxStatus {
    PENDING,    // Ready to be sent
    PROCESSING, // Picked up by the poller, in flight
    PROCESSED,  // Successfully sent
    FAILED      // Failed to send
}
