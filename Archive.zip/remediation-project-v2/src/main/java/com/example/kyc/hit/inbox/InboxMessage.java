package com.example.kyc.hit.inbox;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "inbox_messages")
@Getter
@Setter
@NoArgsConstructor
public class InboxMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false, unique = true)
    private String messageId;

    @Column(nullable = false)
    private String topic;

    @Lob
    @Column(nullable = false, columnDefinition = "TEXT")
    private String payload;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MessageStatus status;

    @Column(nullable = false)
    private Instant receivedAt;

    public InboxMessage(String messageId, String topic, String payload) {
        this.messageId = messageId;
        this.topic = topic;
        this.payload = payload;
        this.status = MessageStatus.PENDING;
        this.receivedAt = Instant.now();
    }
}
