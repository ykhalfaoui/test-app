package com.example.kyc.audit;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable = false)
    private Instant timestamp;

    @Column(nullable = false)
    private String eventType;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String details;

    public AuditLog(String eventType, String details) {
        this.timestamp = Instant.now();
        this.eventType = eventType;
        this.details = details;
    }
}
