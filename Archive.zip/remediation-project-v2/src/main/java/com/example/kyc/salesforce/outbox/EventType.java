package com.example.kyc.salesforce.outbox;

public enum EventType {
    // Saga Step 1
    CREATE_SFDC_REVIEW,

    // Saga Step 2
    CREATE_SFDC_MEMBERS_BULK,
    CREATE_SFDC_BLOCKS_BULK,

    // Saga Step 3
    UPDATE_SFDC_REVIEW_STATUS
}
