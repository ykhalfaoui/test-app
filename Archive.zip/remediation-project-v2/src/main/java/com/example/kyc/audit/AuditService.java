package com.example.kyc.audit;

import com.example.kyc.hit.HitQualifiedEvent;
import com.example.kyc.review.events.ReviewCreatedEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    /**
     * A generic event listener that captures all Spring application events.
     * It filters for specific, auditable events and records them.
     */
    @EventListener
    @Transactional
    public void handleAllEvents(Object event) {
        // Filter for events we want to audit
        if (isAuditable(event)) {
            log.debug("Auditing event: {}", event.getClass().getSimpleName());

            String eventType = event.getClass().getSimpleName();
            String details = event.toString();

            AuditLog auditLog = new AuditLog(eventType, details);
            auditLogRepository.save(auditLog);
        }
    }

    private boolean isAuditable(Object event) {
        // You can define auditable events by a shared interface, a package name,
        // or an explicit list as shown here.
        return event instanceof HitQualifiedEvent ||
               event instanceof ReviewCreatedEvent;
    }
}
