package com.example.kyc.salesforce;

import com.example.kyc.salesforce.outbox.OutboxMessage;
import com.example.kyc.salesforce.outbox.OutboxMessageRepository;
import com.example.kyc.salesforce.outbox.OutboxStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class OutboxPollingService {

    private final OutboxMessageRepository outboxRepository;
    private final SfdcReplyListener replyListener; // To simulate replies

    @Scheduled(fixedDelay = 10000)
    @Transactional
    public void pollAndSendOutboxMessages() {
        List<OutboxMessage> messages = outboxRepository.findByStatusOrderByCreatedAtAsc(OutboxStatus.PENDING);
        if (messages.isEmpty()) {
            return;
        }

        log.info("Found {} pending outbox messages. Processing...", messages.size());

        for (OutboxMessage message : messages) {
            message.setStatus(OutboxStatus.PROCESSING);
            outboxRepository.save(message);

            try {
                // Simulate calling Salesforce API
                log.info("-> Sending message {} (type: {}, aggregate: {}) to Salesforce...",
                    message.getId(), message.getEventType(), message.getAggregateId());

                Thread.sleep(500); // Simulate network latency

                log.info("<- Successfully sent message {}.", message.getId());
                message.setStatus(OutboxStatus.PROCESSED);
                outboxRepository.save(message);

                // Simulate receiving a reply from Salesforce via Kafka
                replyListener.simulateSfdcReply(message);

            } catch (Exception e) {
                log.error("Failed to send message {}. Error: {}", message.getId(), e.getMessage());
                message.setStatus(OutboxStatus.FAILED);
                message.setRetryCount(message.getRetryCount() + 1);
                outboxRepository.save(message);
            }
        }
    }
}
