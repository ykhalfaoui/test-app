package com.example.kyc.review.domain;

public enum ReviewStatus {
    LOCAL_PENDING,      // Created locally, not yet synced
    SYNC_IN_PROGRESS,   // Sync with Salesforce has started
    SYNC_COMPLETED,     // Fully synced with Salesforce
    FAILED
}
