package com.example.kyc.review;

import com.example.kyc.hit.HitQualifiedEvent;
import com.example.kyc.review.events.ReviewCreatedEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
@RequiredArgsConstructor
@Slf4j
public class ReviewEventListener {

    private final ReviewService reviewService;

    /**
     * Inter-Module Listener: Listens for an event from the 'hit' module.
     * This starts the business process in the 'review' module.
     * It runs in a new transaction after the original transaction (from the hit module) commits.
     */
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onHitQualified(HitQualifiedEvent event) {
        log.info("Received qualified hit event: {}. Triggering review creation.", event);
        reviewService.createReviewFromHit(event);
    }

    /**
     * Intra-Module Listener: Listens for the domain event published by the Review aggregate itself.
     * This orchestrates the next step *within* the same module (creating sub-entities).
     * It also runs after the commit of the transaction that created the review.
     */
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onReviewCreated(ReviewCreatedEvent event) {
        log.info("Received review created event: {}. Triggering sub-entity creation.", event);
        reviewService.orchestrateSubEntityCreation(event);
    }
}
