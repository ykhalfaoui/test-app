package com.example.kyc.hit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class HitQualificationServiceTest {

    @Mock
    private ApplicationEventPublisher eventPublisher;

    @InjectMocks
    private HitQualificationService hitQualificationService;

    @Captor
    private ArgumentCaptor<HitQualifiedEvent> eventCaptor;

    @Test
    void shouldPublishEventWhenHitIsPositive() {
        // Given
        String hitId = "test-hit-123";
        String payload = String.format("{\"hitId\": \"%s\", \"type\": \"positif\"}", hitId);

        // When
        hitQualificationService.qualify(payload);

        // Then
        verify(eventPublisher).publishEvent(eventCaptor.capture());
        HitQualifiedEvent publishedEvent = eventCaptor.getValue();

        assertThat(publishedEvent.hitId()).isEqualTo(hitId);
        assertThat(publishedEvent.details()).isEqualTo("Hit contains 'positif' type");
    }

    @Test
    void shouldNotPublishEventWhenHitIsNotPositive() {
        // Given
        String payload = "{\"hitId\": \"test-hit-456\", \"type\": \"negatif\"}";

        // When
        hitQualificationService.qualify(payload);

        // Then
        verify(eventPublisher, never()).publishEvent(eventCaptor.capture());
    }

    @Test
    void shouldNotPublishEventForInvalidPayload() {
        // Given
        String payload = "this is not a valid json";

        // When
        hitQualificationService.qualify(payload);

        // Then
        verify(eventPublisher, never()).publishEvent(eventCaptor.capture());
    }
}
