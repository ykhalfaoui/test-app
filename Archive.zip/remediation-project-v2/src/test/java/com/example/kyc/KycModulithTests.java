package com.example.kyc;

import com.example.kyc.review.domain.Review;
import com.example.kyc.review.domain.ReviewRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.modulith.test.ApplicationModuleTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

@ApplicationModuleTest
@SpringBootTest
@EmbeddedKafka(partitions = 1, topics = {"${kyc.topics.incoming-hits}"})
class KycModulithTests {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private ReviewRepository reviewRepository;

    @Value("${kyc.topics.incoming-hits}")
    private String incomingHitsTopic;

    @Test
    void shouldCreateReviewWhenPositiveHitIsReceived() throws Exception {
        // Arrange
        long initialReviewCount = reviewRepository.count();
        String hitId = "flow-test-123";
        String payload = String.format("{\"hitId\": \"%s\", \"type\": \"positif\"}", hitId);

        // Act: Send a message to the Kafka topic
        kafkaTemplate.send(incomingHitsTopic, hitId, payload).get(10, TimeUnit.SECONDS);

        // Assert: Verify that a new Review is eventually created in the database
        // We use Awaitility to handle the asynchronous nature of the event-driven flow
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            long currentReviewCount = reviewRepository.count();
            assertThat(currentReviewCount).isEqualTo(initialReviewCount + 1);
        });

        List<Review> reviews = reviewRepository.findAll();
        Review createdReview = reviews.get(reviews.size() - 1);
        assertThat(createdReview.getHitId()).isEqualTo(hitId);
    }
}
