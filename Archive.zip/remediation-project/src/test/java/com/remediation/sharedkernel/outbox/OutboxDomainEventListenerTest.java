package com.remediation.sharedkernel.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class OutboxDomainEventListenerTest {

    @Mock
    OutboxRepository repository;

    OutboxDomainEventListener listener;

    @BeforeEach
    void setUp() {
        listener = new OutboxDomainEventListener(repository, new ObjectMapper());
    }

    @Test
    void savesDomainEventToOutboxBeforeCommit() {
        var event = new BlockReadyForReviewEvent(
            TraceId.create(),
            new BlockId(UUID.randomUUID()),
            new ReviewId(UUID.randomUUID())
        );

        ArgumentCaptor<OutboxEntry> captor = ArgumentCaptor.forClass(OutboxEntry.class);

        listener.on(event);

        verify(repository).save(captor.capture());

        OutboxEntry entry = captor.getValue();
        assertThat(entry.getEventType()).isEqualTo(BlockReadyForReviewEvent.class.getName());
        assertThat(entry.getStatus()).isEqualTo(OutboxEntry.Status.PENDING);
        assertThat(entry.getPayload()).contains(event.reviewId().value().toString());
    }

    @Test
    void ignoresNonDomainEvents() {
        listener.on("not a domain event");

        verify(repository, never()).save(any());
    }

    @Test
    void skipsEventsForwardedFromOutbox() {
        OutboxForwardingContext.runForwarding(() -> listener.on(new BlockReadyForReviewEvent(
            TraceId.create(),
            new BlockId(UUID.randomUUID()),
            new ReviewId(UUID.randomUUID())
        )));

        verify(repository, never()).save(any());
    }
}
