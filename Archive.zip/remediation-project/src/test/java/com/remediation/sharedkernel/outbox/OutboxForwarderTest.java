package com.remediation.sharedkernel.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OutboxForwarderTest {

    @Mock
    OutboxRepository repository;

    @Mock
    ApplicationEventPublisher events;

    OutboxForwarder forwarder;

    @BeforeEach
    void setUp() {
        forwarder = new OutboxForwarder(repository, new ObjectMapper(), events);
    }

    @Test
    void forwardsPendingEntryAndMarksAsSent() {
        var originalEvent = new BlockReadyForReviewEvent(TraceId.create(), new BlockId(UUID.randomUUID()), new ReviewId(UUID.randomUUID()));
        var entry = OutboxEntry.pending(originalEvent.getClass().getName(), serialize(originalEvent));

        when(repository.findTop100ByStatusOrderByCreatedAtAsc(OutboxEntry.Status.PENDING)).thenReturn(List.of(entry));
        when(repository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        forwarder.forwardPending();

        ArgumentCaptor<Object> eventCaptor = ArgumentCaptor.forClass(Object.class);
        verify(events).publishEvent(eventCaptor.capture());
        verify(repository).save(entry);

        assertThat(eventCaptor.getValue()).isInstanceOf(BlockReadyForReviewEvent.class);
        assertThat(entry.getStatus()).isEqualTo(OutboxEntry.Status.SENT);
    }

    @Test
    void marksEntryFailedWhenPublishingThrows() {
        var originalEvent = new BlockReadyForReviewEvent(TraceId.create(), new BlockId(UUID.randomUUID()), new ReviewId(UUID.randomUUID()));
        var entry = OutboxEntry.pending(originalEvent.getClass().getName(), serialize(originalEvent));

        when(repository.findTop100ByStatusOrderByCreatedAtAsc(OutboxEntry.Status.PENDING)).thenReturn(List.of(entry));
        when(repository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
        doThrow(new RuntimeException("boom")).when(events).publishEvent(any());

        forwarder.forwardPending();

        verify(repository).save(entry);
        assertThat(entry.getStatus()).isEqualTo(OutboxEntry.Status.FAILED);
    }

    private String serialize(Object value) {
        try {
            return new ObjectMapper().writeValueAsString(value);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
