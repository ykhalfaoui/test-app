package com.remediation.block.application;

import com.remediation.block.api.BlockNotFoundException;
import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.block.domain.Block;
import com.remediation.block.domain.BlockRepository;
import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BlockServiceImplTest {

    @Mock
    BlockRepository repository;

    @Mock
    ApplicationEventPublisher events;

    BlockServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new BlockServiceImpl(repository, events);
    }

    @Test
    void provisionsNewBlockWhenCustomerHasNoBlocks() {
        var customerId = new CustomerId("customer-123");
        var reviewId = new ReviewId(java.util.UUID.randomUUID());
        var traceId = TraceId.create();
        var event = new ReviewMemberIdentifiedEvent(traceId, reviewId, customerId, "MEMBER");

        when(repository.findByCustomerId(customerId)).thenReturn(List.of());

        AtomicReference<Block> savedBlock = new AtomicReference<>();
        doAnswer(invocation -> {
            savedBlock.set(invocation.getArgument(0));
            return null;
        }).when(repository).save(any(Block.class));

        service.on(event);

        verify(repository).findByCustomerId(customerId);
        assertThat(savedBlock.get()).isNotNull();
        verify(repository).save(savedBlock.get());

        ArgumentCaptor<BlockReadyForReviewEvent> captor = ArgumentCaptor.forClass(BlockReadyForReviewEvent.class);
        verify(events).publishEvent(captor.capture());

        var readyEvent = captor.getValue();
        assertThat(readyEvent.traceId()).isEqualTo(traceId);
        assertThat(readyEvent.reviewId()).isEqualTo(reviewId);
        assertThat(readyEvent.blockId()).isEqualTo(savedBlock.get().getId());
    }

    @Test
    void reusesExistingBlocksWithoutCreatingNewOnes() {
        var customerId = new CustomerId("existing-1");
        var reviewId = new ReviewId(java.util.UUID.randomUUID());
        var traceId = TraceId.create();
        var event = new ReviewMemberIdentifiedEvent(traceId, reviewId, customerId, "MEMBER");

        var existingBlock = new Block(customerId);
        when(repository.findByCustomerId(customerId)).thenReturn(List.of(existingBlock));

        service.on(event);

        verify(repository).findByCustomerId(customerId);
        verify(repository, never()).save(any(Block.class));

        ArgumentCaptor<BlockReadyForReviewEvent> captor = ArgumentCaptor.forClass(BlockReadyForReviewEvent.class);
        verify(events).publishEvent(captor.capture());
        assertThat(captor.getValue().blockId()).isEqualTo(existingBlock.getId());
        verifyNoMoreInteractions(events);
    }

    @Test
    void startsReviewOnExistingBlock() {
        var block = new Block(new CustomerId("review-target"));
        var reviewId = new ReviewId(java.util.UUID.randomUUID());

        when(repository.findById(block.getId())).thenReturn(Optional.of(block));

        service.startReviewOnBlock(block.getId(), reviewId);

        verify(repository).findById(block.getId());
        verify(repository).save(block);
    }

    @Test
    void throwsWhenBlockDoesNotExist() {
        var blockId = new BlockId(java.util.UUID.randomUUID());
        when(repository.findById(blockId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.startReviewOnBlock(blockId, new ReviewId(java.util.UUID.randomUUID())))
            .isInstanceOf(BlockNotFoundException.class);
    }
}
