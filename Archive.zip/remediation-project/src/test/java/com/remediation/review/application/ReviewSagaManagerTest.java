package com.remediation.review.application;

import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.review.domain.ReviewInstance;
import com.remediation.review.domain.ReviewInstanceRepository;
import com.remediation.review.domain.ReviewSaga;
import com.remediation.review.domain.ReviewSagaRepository;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import com.remediation.sharedkernel.HitId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReviewSagaManagerTest {

    @Mock
    ReviewInstanceRepository reviewRepository;

    @Mock
    ReviewSagaRepository sagaRepository;

    @Mock
    ApplicationEventPublisher events;

    ReviewSagaManager manager;

    @BeforeEach
    void setUp() {
        manager = new ReviewSagaManager(reviewRepository, sagaRepository, events);
    }

    @Test
    void createsReviewAndSagaAndPublishesStartEvent() {
        var traceId = TraceId.create();
        var customerId = new CustomerId("customer-123");
        var hitEvent = new HitQualifiedPositiveEvent(traceId, new HitId(UUID.randomUUID()), customerId);

        ArgumentCaptor<ReviewInstance> reviewCaptor = ArgumentCaptor.forClass(ReviewInstance.class);
        ArgumentCaptor<ReviewSaga> sagaCaptor = ArgumentCaptor.forClass(ReviewSaga.class);
        ArgumentCaptor<ReviewInstanceStartedEvent> eventCaptor = ArgumentCaptor.forClass(ReviewInstanceStartedEvent.class);

        doAnswer(invocation -> null).when(reviewRepository).save(reviewCaptor.capture());
        doAnswer(invocation -> null).when(sagaRepository).save(sagaCaptor.capture());

        manager.on(hitEvent);

        verify(reviewRepository).save(any(ReviewInstance.class));
        verify(sagaRepository).save(any(ReviewSaga.class));
        verify(events).publishEvent(eventCaptor.capture());

        var savedReview = reviewCaptor.getValue();
        var savedSaga = sagaCaptor.getValue();
        assertThat(savedSaga.getReviewInstanceId()).isEqualTo(savedReview.getId());

        ReviewInstanceStartedEvent publishedEvent = eventCaptor.getValue();
        assertThat(publishedEvent.traceId()).isEqualTo(traceId);
        assertThat(publishedEvent.reviewId()).isEqualTo(savedReview.getId());
        assertThat(publishedEvent.customerId()).isEqualTo(customerId);
    }

    @Test
    void setsExpectationsWhenFamilyCompositionCompletes() {
        var reviewId = new ReviewId(UUID.randomUUID());
        var saga = new ReviewSaga(reviewId, new CustomerId("cust"), 0);
        when(sagaRepository.findByReviewInstanceId(reviewId)).thenReturn(Optional.of(saga));

        var event = new com.remediation.member.api.event.FamilyCompositionCompletedEvent(TraceId.create(), reviewId, 5);

        manager.on(event);

        assertThat(saga.getMembersToProcess()).isEqualTo(5);
        assertThat(saga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COLLECTING_BLOCKS);
        verify(sagaRepository).save(saga);
    }

    @Test
    void ignoresDuplicateBlockReadyEvents() {
        var reviewId = new ReviewId(UUID.randomUUID());
        var saga = new ReviewSaga(reviewId, new CustomerId("cust"), 0);
        saga.setExpectations(2);
        when(sagaRepository.findByReviewInstanceId(reviewId)).thenReturn(Optional.of(saga));

        var traceId = TraceId.create();
        var blockId = new BlockId(UUID.randomUUID());
        var blockEvent = new BlockReadyForReviewEvent(traceId, blockId, reviewId);

        manager.on(blockEvent);
        assertThat(saga.getMembersProcessed()).isEqualTo(1);

        manager.on(blockEvent);
        assertThat(saga.getMembersProcessed()).isEqualTo(1);

        verify(sagaRepository, times(1)).save(saga);
        verifyNoMoreInteractions(events);
    }
}
