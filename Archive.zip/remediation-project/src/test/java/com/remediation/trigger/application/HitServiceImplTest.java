package com.remediation.trigger.application;

import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class HitServiceImplTest {

    @Mock
    ApplicationEventPublisher events;

    HitServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new HitServiceImpl(events);
    }

    @Test
    void publishesPositiveHitEventWithTraceId() {
        TraceId traceId = TraceId.create();

        service.processIncomingHit(traceId, "{\"hit\":\"payload\"}");

        ArgumentCaptor<HitQualifiedPositiveEvent> captor = ArgumentCaptor.forClass(HitQualifiedPositiveEvent.class);
        verify(events).publishEvent(captor.capture());

        HitQualifiedPositiveEvent event = captor.getValue();
        assertThat(event.traceId()).isEqualTo(traceId);
        assertThat(event.customerId()).isNotNull();
        assertThat(event.hitId()).isNotNull();
    }
}
