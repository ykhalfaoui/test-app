package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchRequested;
import com.remediation.integration.salesforce.api.event.SalesforceReviewCreated;
import com.remediation.integration.salesforce.api.event.SalesforceReviewDraftRequested;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdated;
import com.remediation.integration.salesforce.api.event.SalesforceSagaRetryRequested;
import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.integration.salesforce.domain.SalesforceSyncSagaRepository;
import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SalesforceSyncSagaManagerTest {

    @Mock
    SalesforceSyncSagaRepository sagaRepository;

    @Mock
    ApplicationEventPublisher events;

    SalesforceSyncSagaManager manager;

    @BeforeEach
    void setUp() {
        manager = new SalesforceSyncSagaManager(sagaRepository, events);
    }

    @Test
    void startsSagaAndRequestsDraftCreation() {
        var stored = new AtomicReference<SalesforceSyncSaga>();
        doAnswer(invocation -> {
            stored.set(invocation.getArgument(0));
            return null;
        }).when(sagaRepository).save(any(SalesforceSyncSaga.class));

        var traceId = TraceId.create();
        var reviewId = new ReviewId(UUID.randomUUID());
        var event = new ReviewInstanceStartedEvent(traceId, reviewId, new CustomerId("customer"), "HIT");

        manager.on(event);

        verify(sagaRepository).save(stored.get());

        ArgumentCaptor<SalesforceReviewDraftRequested> captor = ArgumentCaptor.forClass(SalesforceReviewDraftRequested.class);
        verify(events).publishEvent(captor.capture());

        assertThat(stored.get()).isNotNull();
        assertThat(stored.get().getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.CREATING_REVIEW);
        assertThat(captor.getValue().reviewId()).isEqualTo(reviewId);
        assertThat(captor.getValue().traceId()).isEqualTo(traceId);
    }

    @Test
    void queuesMemberAndRequestsBatchWhenReviewCreated() {
        var stored = new AtomicReference<SalesforceSyncSaga>();
        doAnswer(invocation -> {
            stored.set(invocation.getArgument(0));
            return null;
        }).when(sagaRepository).save(any(SalesforceSyncSaga.class));
        when(sagaRepository.findByReviewId(any(ReviewId.class))).thenAnswer(invocation -> Optional.ofNullable(stored.get()));
        when(sagaRepository.findById(any(UUID.class))).thenAnswer(invocation -> Optional.ofNullable(stored.get()));

        var traceId = TraceId.create();
        var reviewId = new ReviewId(UUID.randomUUID());
        manager.on(new ReviewInstanceStartedEvent(traceId, reviewId, new CustomerId("customer"), "HIT"));

        manager.on(new ReviewMemberIdentifiedEvent(traceId, reviewId, new CustomerId("member-1"), "MEMBER"));
        verify(events, never()).publishEvent(any(SalesforceMembersBatchRequested.class));

        manager.on(new SalesforceReviewCreated(traceId, reviewId, "sf-review-id", true, null));

        ArgumentCaptor<SalesforceMembersBatchRequested> batchCaptor = ArgumentCaptor.forClass(SalesforceMembersBatchRequested.class);
        verify(events).publishEvent(batchCaptor.capture());
        assertThat(batchCaptor.getValue().memberIds()).containsExactly("member-1");
        assertThat(batchCaptor.getValue().salesforceReviewId()).isEqualTo("sf-review-id");
    }

    @Test
    void marksSagaCompleteOnStatusUpdate() {
        var traceId = TraceId.create();
        var reviewId = new ReviewId(UUID.randomUUID());
        var saga = new SalesforceSyncSaga(reviewId, List.of(), traceId);
        saga.reviewCreationStarted();
        saga.reviewCreated("sf-id");
        saga.enqueueMembers(List.of("member-1"));
        saga.nextMemberBatch(100).ifPresent(batch -> saga.markMemberBatchCompleted(batch.batchNumber()));

        when(sagaRepository.findByReviewId(reviewId)).thenReturn(Optional.of(saga));

        manager.on(new SalesforceReviewStatusUpdated(traceId, reviewId, "sf-id", "IN_PROGRESS", true, null));

        verify(sagaRepository).save(saga);
        verifyNoMoreInteractions(events);
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.COMPLETED);
    }

    @Test
    void schedulesRetryWhenMemberBatchFails() {
        var traceId = TraceId.create();
        var reviewId = new ReviewId(UUID.randomUUID());
        var saga = new SalesforceSyncSaga(reviewId, List.of("member-1"), traceId);
        saga.reviewCreationStarted();
        saga.reviewCreated("sf-id");
        var batch = saga.nextMemberBatch(100).orElseThrow();
        when(sagaRepository.findById(saga.getId())).thenReturn(Optional.of(saga));

        manager.on(new SalesforceMembersBatchProcessed(traceId, saga.getId(), batch.batchNumber(), false, "failure"));

        ArgumentCaptor<Object> eventCaptor = ArgumentCaptor.forClass(Object.class);
        verify(events).publishEvent(eventCaptor.capture());
        assertThat(eventCaptor.getValue()).isInstanceOf(SalesforceSagaRetryRequested.class);
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.FAILED);
    }

    @Test
    void retryEventRequeuesBatch() {
        var traceId = TraceId.create();
        var reviewId = new ReviewId(UUID.randomUUID());
        var saga = new SalesforceSyncSaga(reviewId, List.of("member-1"), traceId);
        saga.reviewCreationStarted();
        saga.reviewCreated("sf-id");
        var batch = saga.nextMemberBatch(100).orElseThrow();
        saga.markMemberBatchFailed(batch.batchNumber(), "failure");
        when(sagaRepository.findById(saga.getId())).thenReturn(Optional.of(saga));

        manager.on(new SalesforceSagaRetryRequested(traceId, saga.getId()));

        verify(sagaRepository, times(1)).save(saga);
        ArgumentCaptor<Object> eventCaptor = ArgumentCaptor.forClass(Object.class);
        verify(events).publishEvent(eventCaptor.capture());
        assertThat(eventCaptor.getValue()).isInstanceOf(SalesforceMembersBatchRequested.class);
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS);
    }
}
