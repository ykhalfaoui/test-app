package com.remediation.member.application;

import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class MemberCompositionServiceTest {

    @Mock
    ApplicationEventPublisher events;

    MemberCompositionService service;

    @BeforeEach
    void setUp() {
        service = new MemberCompositionService(events);
    }

    @Test
    void publishesMemberEventsAndCompletion() {
        var traceId = TraceId.create();
        var reviewId = new ReviewId(java.util.UUID.randomUUID());
        var reviewEvent = new ReviewInstanceStartedEvent(traceId, reviewId, new CustomerId("customer-root"), "HIT");

        service.on(reviewEvent);

        ArgumentCaptor<Object> captor = ArgumentCaptor.forClass(Object.class);
        verify(events, times(6)).publishEvent(captor.capture());

        List<Object> published = captor.getAllValues();
        assertThat(published).hasSize(6);

        List<ReviewMemberIdentifiedEvent> memberEvents = published.stream()
            .filter(ReviewMemberIdentifiedEvent.class::isInstance)
            .map(ReviewMemberIdentifiedEvent.class::cast)
            .toList();
        assertThat(memberEvents).hasSize(5);
        assertThat(memberEvents)
            .allMatch(event -> event.traceId().equals(traceId) && event.reviewId().equals(reviewId));

        var completion = published.get(published.size() - 1);
        assertThat(completion)
            .isInstanceOf(com.remediation.member.api.event.FamilyCompositionCompletedEvent.class);
        var completionEvent = (com.remediation.member.api.event.FamilyCompositionCompletedEvent) completion;
        assertThat(completionEvent.memberCount()).isEqualTo(5);
        assertThat(completionEvent.traceId()).isEqualTo(traceId);
    }
}
