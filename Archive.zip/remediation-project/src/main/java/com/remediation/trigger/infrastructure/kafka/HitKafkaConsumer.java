package com.remediation.trigger.infrastructure.kafka;


import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitService;
import com.remediation.trigger.domain.InboxEntry;
import com.remediation.trigger.domain.InboxRepository;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@Component
public class HitKafkaConsumer {

    private final HitService hitService;
    private final InboxRepository inboxRepository;

    public HitKafkaConsumer(HitService hitService, InboxRepository inboxRepository) {
        this.hitService = hitService;
        this.inboxRepository = inboxRepository;
    }

    // @KafkaListener(topics = "hits")
    @Transactional
    public void consume(String payload,
                        /* @Header("kafka_messageKey") */ String eventIdStr,
                        /* @Header("X-Trace-Id") */ String traceIdHeader) {
        
        // 1. Establish TraceId (get from header or create a new one)
        TraceId traceId = StringUtils.hasText(traceIdHeader) ? new TraceId(traceIdHeader) : TraceId.create();
        System.out.println("Received message from Kafka with TraceId: " + traceId.value());

        UUID eventId;
        try {
            eventId = UUID.fromString(eventIdStr);
        } catch (Exception e) {
            System.out.println("ERROR: Could not deserialize message. Saving to inbox with FAILED status.");
            var rawId = eventIdStr == null ? "" : eventIdStr;
            var failedEntry = InboxEntry.received(UUID.nameUUIDFromBytes((rawId + payload).getBytes(StandardCharsets.UTF_8)), payload);
            failedEntry.markFailed("Invalid event id: " + e.getMessage());
            inboxRepository.save(failedEntry);
            return;
        }

        // 2. Idempotency check
        if (inboxRepository.existsById(eventId)) {
            System.out.println("Duplicate event ignored: " + eventId);
            return;
        }

        InboxEntry entry = InboxEntry.received(eventId, payload);
        inboxRepository.save(entry);

        try {
            // 3. Process the event, passing the traceId
            hitService.processIncomingHit(traceId, payload);
            entry.markProcessed();
        } catch (RuntimeException ex) {
            entry.markFailed(ex.getMessage());
            inboxRepository.save(entry);
            throw ex;
        }

        inboxRepository.save(entry);
    }
}
