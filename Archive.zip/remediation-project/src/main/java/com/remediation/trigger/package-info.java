@org.springframework.modulith.ApplicationModule(
    allowedDependencies = {"sharedkernel", "review"}
)
package com.remediation.trigger;