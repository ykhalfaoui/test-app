package com.remediation.trigger.domain;

import org.springframework.data.repository.Repository;

import java.util.Optional;
import java.util.UUID;

public interface InboxRepository extends Repository<InboxEntry, UUID> {
    boolean existsById(UUID eventId);
    Optional<InboxEntry> findById(UUID eventId);
    InboxEntry save(InboxEntry entry);
}
