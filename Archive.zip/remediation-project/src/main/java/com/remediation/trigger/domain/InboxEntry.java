package com.remediation.trigger.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.UUID;

/**
 * Inbox pattern entity that tracks external messages processed by the trigger context.
 */
@Entity
@Table(name = "trigger_inbox")
public class InboxEntry {

    public enum InboxStatus { RECEIVED, PROCESSED, FAILED }

    @Id
    @Column(name = "event_id", nullable = false, updatable = false)
    private UUID eventId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private InboxStatus status;

    @Lob
    @Column(name = "payload", nullable = false)
    private String payload;

    @Column(name = "error_message")
    private String errorMessage;

    @Column(name = "received_at", nullable = false, updatable = false)
    private Instant receivedAt;

    @Column(name = "last_updated_at", nullable = false)
    private Instant lastUpdatedAt;

    protected InboxEntry() {
        // For JPA
    }

    private InboxEntry(UUID eventId, String payload) {
        this.eventId = eventId;
        this.payload = payload;
        this.status = InboxStatus.RECEIVED;
        var now = Instant.now();
        this.receivedAt = now;
        this.lastUpdatedAt = now;
    }

    public static InboxEntry received(UUID eventId, String payload) {
        return new InboxEntry(eventId, payload);
    }

    public UUID getEventId() {
        return eventId;
    }

    public InboxStatus getStatus() {
        return status;
    }

    public String getPayload() {
        return payload;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public Instant getReceivedAt() {
        return receivedAt;
    }

    public Instant getLastUpdatedAt() {
        return lastUpdatedAt;
    }

    public void markProcessed() {
        this.status = InboxStatus.PROCESSED;
        this.errorMessage = null;
        this.lastUpdatedAt = Instant.now();
    }

    public void markFailed(String errorMessage) {
        this.status = InboxStatus.FAILED;
        this.errorMessage = errorMessage;
        this.lastUpdatedAt = Instant.now();
    }
}
