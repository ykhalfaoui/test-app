package com.remediation.customer.domain;

// Aggregate Root for the Customer Context
public class Customer {
}
