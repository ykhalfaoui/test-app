@org.springframework.modulith.ApplicationModule(displayName = "Integration")
package com.remediation.integration;