package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

public record SalesforceReviewStatusUpdated(
    TraceId traceId,
    ReviewId reviewId,
    String salesforceReviewId,
    String appliedStatus,
    boolean success,
    String failureMessage
) {}
