package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.List;
import java.util.UUID;

public record SalesforceMembersBatchRequested(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    List<String> memberIds,
    String salesforceReviewId
) {}
