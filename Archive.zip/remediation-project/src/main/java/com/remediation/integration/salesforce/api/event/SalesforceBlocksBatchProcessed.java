package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.UUID;

public record SalesforceBlocksBatchProcessed(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    boolean success,
    String failureMessage
) {}
