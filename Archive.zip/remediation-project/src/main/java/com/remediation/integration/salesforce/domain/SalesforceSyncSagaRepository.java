package com.remediation.integration.salesforce.domain;

import com.remediation.sharedkernel.ReviewId;
import org.springframework.data.repository.Repository;
import java.util.Optional;
import java.util.UUID;

public interface SalesforceSyncSagaRepository extends Repository<SalesforceSyncSaga, UUID> {
    void save(SalesforceSyncSaga saga);
    Optional<SalesforceSyncSaga> findById(UUID id);
    Optional<SalesforceSyncSaga> findByReviewId(ReviewId reviewId);
}
