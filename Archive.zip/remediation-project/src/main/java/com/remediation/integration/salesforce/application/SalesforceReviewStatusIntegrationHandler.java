package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdateRequested;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdated;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

@Component
class SalesforceReviewStatusIntegrationHandler {

    private final SalesforceClient client;
    private final ApplicationEventPublisher events;

    SalesforceReviewStatusIntegrationHandler(SalesforceClient client, ApplicationEventPublisher events) {
        this.client = client;
        this.events = events;
    }

    @ApplicationModuleListener
    public void on(SalesforceReviewStatusUpdateRequested event) {
        try {
            client.updateReviewStatus(event.salesforceReviewId(), event.targetStatus());
            events.publishEvent(new SalesforceReviewStatusUpdated(event.traceId(), event.reviewId(), event.salesforceReviewId(), event.targetStatus(), true, null));
        } catch (RuntimeException ex) {
            events.publishEvent(new SalesforceReviewStatusUpdated(event.traceId(), event.reviewId(), event.salesforceReviewId(), event.targetStatus(), false, ex.getMessage()));
        }
    }
}
