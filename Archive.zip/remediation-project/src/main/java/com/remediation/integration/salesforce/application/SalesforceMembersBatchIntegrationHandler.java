package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchRequested;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

@Component
class SalesforceMembersBatchIntegrationHandler {

    private final SalesforceClient client;
    private final ApplicationEventPublisher events;

    SalesforceMembersBatchIntegrationHandler(SalesforceClient client, ApplicationEventPublisher events) {
        this.client = client;
        this.events = events;
    }

    @ApplicationModuleListener
    public void on(SalesforceMembersBatchRequested event) {
        try {
            client.bulkUpsertMembers(event.salesforceReviewId(), event.memberIds());
            events.publishEvent(new SalesforceMembersBatchProcessed(event.traceId(), event.sagaId(), event.batchNumber(), true, null));
        } catch (RuntimeException ex) {
            events.publishEvent(new SalesforceMembersBatchProcessed(event.traceId(), event.sagaId(), event.batchNumber(), false, ex.getMessage()));
        }
    }
}
