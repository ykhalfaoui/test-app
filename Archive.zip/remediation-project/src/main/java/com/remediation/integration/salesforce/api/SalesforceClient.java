package com.remediation.integration.salesforce.api;

import com.remediation.sharedkernel.ReviewId;

import java.util.List;

/**
 * Anti-Corruption Layer interface for Salesforce interactions.
 */
public interface SalesforceClient {

    /**
     * Creates a draft review in Salesforce and returns its external identifier.
     */
    String createReviewDraft(ReviewId reviewId, String triggerType);

    /**
     * Performs a bulk upsert of member entities for the given review.
     */
    void bulkUpsertMembers(String salesforceReviewId, List<String> memberExternalIds);

    /**
     * Performs a bulk upsert of block entities for the given review.
     */
    void bulkUpsertBlocks(String salesforceReviewId, List<String> blockExternalIds);

    /**
     * Updates the review status in Salesforce (e.g. DRAFT, IN_PROGRESS).
     */
    void updateReviewStatus(String salesforceReviewId, String status);
}
