package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.List;
import java.util.UUID;

public record SalesforceBlocksBatchRequested(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    List<String> blockIds,
    String salesforceReviewId
) {}
