package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

public record SalesforceReviewCreated(
    TraceId traceId,
    ReviewId reviewId,
    String salesforceReviewId,
    boolean success,
    String failureMessage
) {}
