package com.remediation.integration.salesforce.application;

import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.integration.salesforce.api.event.SalesforceBlocksBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceBlocksBatchRequested;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceMembersBatchRequested;
import com.remediation.integration.salesforce.api.event.SalesforceReviewCreated;
import com.remediation.integration.salesforce.api.event.SalesforceReviewDraftRequested;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdateRequested;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdated;
import com.remediation.integration.salesforce.api.event.SalesforceSagaRetryRequested;
import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.integration.salesforce.domain.SalesforceSyncSagaRepository;
import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.TraceId;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
class SalesforceSyncSagaManager {

    private static final int BATCH_SIZE = 100;

    private final SalesforceSyncSagaRepository sagaRepository;
    private final ApplicationEventPublisher events;

    SalesforceSyncSagaManager(SalesforceSyncSagaRepository sagaRepository,
                              ApplicationEventPublisher events) {
        this.sagaRepository = sagaRepository;
        this.events = events;
    }

    @ApplicationModuleListener
    @Transactional
    public void on(ReviewInstanceStartedEvent event) {
        System.out.println("[SF-SYNC] || Review started, provisioning Salesforce saga for review " + event.reviewId().value());

        var saga = new SalesforceSyncSaga(event.reviewId(), List.of(), event.traceId());
        saga.reviewCreationStarted();
        sagaRepository.save(saga);

        events.publishEvent(new SalesforceReviewDraftRequested(event.traceId(), event.reviewId(), event.triggerType()));
    }

    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceReviewCreated event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresent(saga -> {
            if (event.success()) {
                saga.reviewCreated(event.salesforceReviewId());
                sagaRepository.save(saga);
                requestNextMemberBatch(saga);
            } else {
                saga.failed(event.failureMessage());
                sagaRepository.save(saga);
                scheduleRetry(saga);
            }
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(ReviewMemberIdentifiedEvent event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresent(saga -> {
            saga.enqueueMembers(List.of(event.customerId().value()));
            sagaRepository.save(saga);
            requestNextMemberBatch(saga);
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceMembersBatchProcessed event) {
        sagaRepository.findById(event.sagaId()).ifPresent(saga -> {
            if (event.success()) {
                saga.markMemberBatchCompleted(event.batchNumber());
                sagaRepository.save(saga);
                requestNextMemberBatch(saga);
                maybeRequestBlockSync(saga);
                maybeRequestStatusUpdate(saga);
            } else {
                saga.markMemberBatchFailed(event.batchNumber(), event.failureMessage());
                sagaRepository.save(saga);
                scheduleRetry(saga);
            }
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(BlockReadyForReviewEvent event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresent(saga -> {
            saga.enqueueBlock(event.blockId().value().toString());
            sagaRepository.save(saga);
            maybeRequestBlockSync(saga);
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceBlocksBatchProcessed event) {
        sagaRepository.findById(event.sagaId()).ifPresent(saga -> {
            if (event.success()) {
                saga.markBlockBatchCompleted(event.batchNumber());
                sagaRepository.save(saga);
                maybeRequestBlockSync(saga);
                maybeRequestStatusUpdate(saga);
            } else {
                saga.markBlockBatchFailed(event.batchNumber(), event.failureMessage());
                sagaRepository.save(saga);
                scheduleRetry(saga);
            }
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceReviewStatusUpdated event) {
        sagaRepository.findByReviewId(event.reviewId()).ifPresent(saga -> {
            if (event.success()) {
                saga.completed();
            } else {
                saga.failed(event.failureMessage());
                scheduleRetry(saga);
            }
            sagaRepository.save(saga);
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceSagaRetryRequested event) {
        sagaRepository.findById(event.sagaId()).ifPresent(saga -> {
            saga.requestRetry();
            sagaRepository.save(saga);
            requestNextMemberBatch(saga);
            maybeRequestBlockSync(saga);
            maybeRequestStatusUpdate(saga);
        });
    }

    private void requestNextMemberBatch(SalesforceSyncSaga saga) {
        if (saga.getSalesforceReviewId() == null || saga.getStatus() != SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS) {
            return;
        }

        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextMemberBatch(BATCH_SIZE);
        if (batch.isPresent()) {
            sagaRepository.save(saga);
            SalesforceSyncSaga.BatchProgress progress = batch.get();
            System.out.println("[SF-SYNC] || Requesting member batch " + progress.batchNumber() + " with " + progress.items().size() + " members.");
            events.publishEvent(new SalesforceMembersBatchRequested(
                saga.getTraceId(),
                saga.getId(),
                progress.batchNumber(),
                progress.items(),
                saga.getSalesforceReviewId()
            ));
        }
    }

    private void maybeRequestBlockSync(SalesforceSyncSaga saga) {
        if (saga.getSalesforceReviewId() == null) {
            return;
        }
        if (saga.getStatus() != SalesforceSyncSaga.SyncStatus.SYNCING_BLOCKS &&
            saga.getStatus() != SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS) {
            return;
        }
        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextBlockBatch(BATCH_SIZE);
        if (batch.isPresent()) {
            sagaRepository.save(saga);
            SalesforceSyncSaga.BatchProgress progress = batch.get();
            System.out.println("[SF-SYNC] || Requesting block batch " + progress.batchNumber() + " with " + progress.items().size() + " blocks.");
            events.publishEvent(new SalesforceBlocksBatchRequested(
                saga.getTraceId(),
                saga.getId(),
                progress.batchNumber(),
                progress.items(),
                saga.getSalesforceReviewId()
            ));
        }
    }

    private void maybeRequestStatusUpdate(SalesforceSyncSaga saga) {
        if (saga.getSalesforceReviewId() == null) {
            return;
        }
        if (saga.getStatus() == SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS) {
            TraceId traceId = saga.getTraceId();
            System.out.println("[SF-SYNC] || All data synced. Requesting status update to IN_PROGRESS for review " + saga.getReviewId().value());
            events.publishEvent(new SalesforceReviewStatusUpdateRequested(
                traceId,
                saga.getReviewId(),
                saga.getSalesforceReviewId(),
                "IN_PROGRESS"
            ));
        }
    }

    private void scheduleRetry(SalesforceSyncSaga saga) {
        System.out.println("[SF-SYNC] || Scheduling retry for saga " + saga.getId());
        events.publishEvent(new SalesforceSagaRetryRequested(saga.getTraceId(), saga.getId()));
    }
}
