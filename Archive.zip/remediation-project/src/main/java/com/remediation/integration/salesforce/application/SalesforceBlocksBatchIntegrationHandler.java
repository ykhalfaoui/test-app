package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceBlocksBatchProcessed;
import com.remediation.integration.salesforce.api.event.SalesforceBlocksBatchRequested;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

@Component
class SalesforceBlocksBatchIntegrationHandler {

    private final SalesforceClient client;
    private final ApplicationEventPublisher events;

    SalesforceBlocksBatchIntegrationHandler(SalesforceClient client, ApplicationEventPublisher events) {
        this.client = client;
        this.events = events;
    }

    @ApplicationModuleListener
    public void on(SalesforceBlocksBatchRequested event) {
        try {
            client.bulkUpsertBlocks(event.salesforceReviewId(), event.blockIds());
            events.publishEvent(new SalesforceBlocksBatchProcessed(event.traceId(), event.sagaId(), event.batchNumber(), true, null));
        } catch (RuntimeException ex) {
            events.publishEvent(new SalesforceBlocksBatchProcessed(event.traceId(), event.sagaId(), event.batchNumber(), false, ex.getMessage()));
        }
    }
}
