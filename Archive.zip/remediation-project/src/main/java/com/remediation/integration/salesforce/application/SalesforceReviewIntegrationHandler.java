package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceReviewCreated;
import com.remediation.integration.salesforce.api.event.SalesforceReviewDraftRequested;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

@Component
class SalesforceReviewIntegrationHandler {

    private final SalesforceClient client;
    private final ApplicationEventPublisher events;

    SalesforceReviewIntegrationHandler(SalesforceClient client, ApplicationEventPublisher events) {
        this.client = client;
        this.events = events;
    }

    @ApplicationModuleListener
    public void on(SalesforceReviewDraftRequested event) {
        try {
            String salesforceId = client.createReviewDraft(event.reviewId(), event.triggerType());
            events.publishEvent(new SalesforceReviewCreated(event.traceId(), event.reviewId(), salesforceId, true, null));
        } catch (RuntimeException ex) {
            events.publishEvent(new SalesforceReviewCreated(event.traceId(), event.reviewId(), null, false, ex.getMessage()));
        }
    }
}
