package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.UUID;

public record SalesforceSagaRetryRequested(
    TraceId traceId,
    UUID sagaId
) {}
