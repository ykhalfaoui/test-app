package com.remediation.integration.salesforce.domain;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.UUID;

/**
 * Tracks the Salesforce integration workflow for a review. The saga keeps
 * account of the batches that still need to be synchronised, those currently
 * in-flight, and the ones already completed.
 */
public class SalesforceSyncSaga {

    public enum SyncStatus {
        NOT_STARTED,
        CREATING_REVIEW,
        SYNCING_MEMBERS,
        SYNCING_BLOCKS,
        FINALIZING_STATUS,
        COMPLETED,
        FAILED
    }

    public enum BatchStatus { PENDING, IN_FLIGHT, COMPLETED, FAILED }

    private UUID id;
    private ReviewId reviewId;
    private String salesforceReviewId;
    private TraceId traceId;
    private SyncStatus status;
    private final Queue<String> pendingMemberIds;
    private final Queue<String> pendingBlockIds;
    private final Map<Integer, BatchProgress> memberBatches;
    private final Map<Integer, BatchProgress> blockBatches;
    private int nextMemberBatchNumber;
    private int nextBlockBatchNumber;
    private Instant lastFailureAt;

    public SalesforceSyncSaga(ReviewId reviewId, List<String> initialMembers, TraceId traceId) {
        this.id = UUID.randomUUID();
        this.reviewId = reviewId;
        this.traceId = traceId;
        this.pendingMemberIds = new ArrayDeque<>(initialMembers);
        this.pendingBlockIds = new ArrayDeque<>();
        this.memberBatches = new LinkedHashMap<>();
        this.blockBatches = new LinkedHashMap<>();
        this.status = SyncStatus.NOT_STARTED;
        this.nextMemberBatchNumber = 1;
        this.nextBlockBatchNumber = 1;
    }

    // --- Review lifecycle ----------------------------------------------------

    public void reviewCreationStarted() {
        this.status = SyncStatus.CREATING_REVIEW;
    }

    public void reviewCreated(String salesforceReviewId) {
        this.salesforceReviewId = salesforceReviewId;
        this.status = SyncStatus.SYNCING_MEMBERS;
    }

    public void enqueueMembers(List<String> memberIds) {
        this.pendingMemberIds.addAll(memberIds);
        if (status == SyncStatus.FINALIZING_STATUS || status == SyncStatus.SYNCING_BLOCKS) {
            this.status = SyncStatus.SYNCING_MEMBERS;
        }
    }

    public void enqueueBlock(String blockId) {
        this.pendingBlockIds.add(blockId);
        if (status == SyncStatus.FINALIZING_STATUS || status == SyncStatus.SYNCING_MEMBERS) {
            this.status = SyncStatus.SYNCING_BLOCKS;
        }
    }

    public Optional<BatchProgress> nextMemberBatch(int batchSize) {
        if (pendingMemberIds.isEmpty()) {
            return Optional.empty();
        }
        int count = Math.min(batchSize, pendingMemberIds.size());
        List<String> batchItems = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            batchItems.add(pendingMemberIds.poll());
        }
        int batchNumber = nextMemberBatchNumber++;
        BatchProgress progress = BatchProgress.members(batchNumber, batchItems).markInFlight();
        memberBatches.put(batchNumber, progress);
        return Optional.of(progress);
    }

    public Optional<BatchProgress> nextBlockBatch(int batchSize) {
        if (pendingBlockIds.isEmpty()) {
            return Optional.empty();
        }
        int count = Math.min(batchSize, pendingBlockIds.size());
        List<String> batchItems = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            batchItems.add(pendingBlockIds.poll());
        }
        int batchNumber = nextBlockBatchNumber++;
        BatchProgress progress = BatchProgress.blocks(batchNumber, batchItems).markInFlight();
        blockBatches.put(batchNumber, progress);
        return Optional.of(progress);
    }

    public void markMemberBatchCompleted(int batchNumber) {
        memberBatches.computeIfPresent(batchNumber, (key, progress) -> progress.markCompleted());
        if (pendingMemberIds.isEmpty() && allMemberBatchesCompleted()) {
            this.status = pendingBlockIds.isEmpty() ? SyncStatus.FINALIZING_STATUS : SyncStatus.SYNCING_BLOCKS;
        }
    }

    public void markMemberBatchFailed(int batchNumber, String reason) {
        memberBatches.computeIfPresent(batchNumber, (key, progress) -> {
            pendingMemberIds.addAll(progress.items());
            return progress.markFailed(reason);
        });
        this.status = SyncStatus.FAILED;
        this.lastFailureAt = Instant.now();
    }

    public void markBlockBatchCompleted(int batchNumber) {
        blockBatches.computeIfPresent(batchNumber, (key, progress) -> progress.markCompleted());
        if (pendingBlockIds.isEmpty() && allBlockBatchesCompleted()) {
            this.status = SyncStatus.FINALIZING_STATUS;
        }
    }

    public void markBlockBatchFailed(int batchNumber, String reason) {
        blockBatches.computeIfPresent(batchNumber, (key, progress) -> {
            pendingBlockIds.addAll(progress.items());
            return progress.markFailed(reason);
        });
        this.status = SyncStatus.FAILED;
        this.lastFailureAt = Instant.now();
    }

    public void completed() {
        this.status = SyncStatus.COMPLETED;
    }

    public void failed(String reason) {
        this.status = SyncStatus.FAILED;
        this.lastFailureAt = Instant.now();
    }

    public void requestRetry() {
        if (!pendingMemberIds.isEmpty()) {
            this.status = SyncStatus.SYNCING_MEMBERS;
        } else if (!pendingBlockIds.isEmpty()) {
            this.status = SyncStatus.SYNCING_BLOCKS;
        } else {
            this.status = SyncStatus.FINALIZING_STATUS;
        }
    }

    private boolean allMemberBatchesCompleted() {
        return memberBatches.values().stream().allMatch(BatchProgress::isCompleted);
    }

    private boolean allBlockBatchesCompleted() {
        return blockBatches.values().stream().allMatch(BatchProgress::isCompleted);
    }

    // --- Getters -------------------------------------------------------------

    public UUID getId() { return id; }
    public ReviewId getReviewId() { return reviewId; }
    public SyncStatus getStatus() { return status; }
    public String getSalesforceReviewId() { return salesforceReviewId; }
    public Map<Integer, BatchProgress> getMemberBatches() { return Map.copyOf(memberBatches); }
    public Map<Integer, BatchProgress> getBlockBatches() { return Map.copyOf(blockBatches); }
    public Queue<String> getPendingMemberIds() { return new ArrayDeque<>(pendingMemberIds); }
    public Queue<String> getPendingBlockIds() { return new ArrayDeque<>(pendingBlockIds); }
    public Optional<Instant> getLastFailureAt() { return Optional.ofNullable(lastFailureAt); }
    public TraceId getTraceId() { return traceId; }

    // --- Inner type ----------------------------------------------------------

    public record BatchProgress(int batchNumber,
                                List<String> items,
                                BatchStatus status,
                                String failureMessage,
                                Instant lastUpdated,
                                BatchType type) {

        enum BatchType { MEMBERS, BLOCKS }

        BatchProgress update(BatchStatus newStatus, String error) {
            return new BatchProgress(batchNumber, items, newStatus, error, Instant.now(), type);
        }

        BatchProgress markInFlight() { return update(BatchStatus.IN_FLIGHT, null); }
        BatchProgress markCompleted() { return update(BatchStatus.COMPLETED, null); }
        BatchProgress markFailed(String reason) { return update(BatchStatus.FAILED, reason); }

        boolean isCompleted() { return status == BatchStatus.COMPLETED; }

        static BatchProgress members(int batchNumber, List<String> items) {
            return new BatchProgress(batchNumber, List.copyOf(items), BatchStatus.PENDING, null, Instant.now(), BatchType.MEMBERS);
        }

        static BatchProgress blocks(int batchNumber, List<String> items) {
            return new BatchProgress(batchNumber, List.copyOf(items), BatchStatus.PENDING, null, Instant.now(), BatchType.BLOCKS);
        }
    }
}
