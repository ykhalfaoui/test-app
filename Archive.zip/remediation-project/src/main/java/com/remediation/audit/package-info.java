@org.springframework.modulith.ApplicationModule(
    displayName = "Audit",
    allowedDependencies = {"sharedkernel", "customer", "block", "review", "trigger", "integration"}
)
package com.remediation.audit;