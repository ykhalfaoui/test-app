package com.remediation.audit.application;

import com.remediation.audit.api.AuditService;
import com.remediation.sharedkernel.TraceId;
import org.springframework.stereotype.Service;

@Service
class AuditServiceImpl implements AuditService {

    @Override
    public void logEvent(TraceId traceId, String eventType, String entityId, Object details) {
        // In a real implementation, this would save an AuditTrail entity to the database.
        System.out.printf("[AUDIT LOG | %s] || Event: %s || Entity ID: %s || Details: %s%n",
                traceId.value(), eventType, entityId, details.toString());
    }

    @Override
    public void logError(Object methodSignature, Throwable error) {
        // We could also add a TraceId here by getting it from the current Micrometer context
        System.out.printf("[AUDIT ERROR] || Method: %s || Exception: %s%n",
                methodSignature.toString(), error.getMessage());
    }
}
