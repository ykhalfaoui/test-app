package com.remediation.audit.domain;

// Represents an entry in the audit trail
// Could be a JPA Entity
public class AuditTrail {
    // private UUID id;
    // private java.time.Instant timestamp;
    // private String eventType;
    // private String entityId;
    // private String userId;
    // private String details; // Could be JSON
    // private String status;
    // private String errorMessage;
}
