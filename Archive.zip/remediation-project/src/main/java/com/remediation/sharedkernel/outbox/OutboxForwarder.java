package com.remediation.sharedkernel.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Periodically forwards pending outbox entries as Spring application events.
 */
@Component
class OutboxForwarder {

    private static final Logger log = LoggerFactory.getLogger(OutboxForwarder.class);

    private final OutboxRepository repository;
    private final ObjectMapper objectMapper;
    private final ApplicationEventPublisher events;

    OutboxForwarder(OutboxRepository repository,
                    ObjectMapper objectMapper,
                    ApplicationEventPublisher events) {
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.events = events;
    }

    @Scheduled(fixedDelayString = "${outbox.forwarder.fixed-delay:5000}", initialDelayString = "${outbox.forwarder.initial-delay:2000}")
    @Transactional
    public void forwardPending() {
        List<OutboxEntry> entries = repository.findTop100ByStatusOrderByCreatedAtAsc(OutboxEntry.Status.PENDING);
        if (entries.isEmpty()) {
            return;
        }

        for (OutboxEntry entry : entries) {
            try {
                Object event = deserialize(entry);
                OutboxForwardingContext.runForwarding(() -> events.publishEvent(event));
                entry.markSent();
            } catch (Exception ex) {
                log.error("Failed to forward outbox entry {}: {}", entry.getId(), ex.getMessage(), ex);
                entry.markFailed(ex.getMessage());
            }
            repository.save(entry);
        }
    }

    private Object deserialize(OutboxEntry entry) throws Exception {
        Class<?> eventClass = Class.forName(entry.getEventType());
        return objectMapper.readValue(entry.getPayload(), eventClass);
    }
}
