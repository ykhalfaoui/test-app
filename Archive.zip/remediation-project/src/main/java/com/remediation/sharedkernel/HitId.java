package com.remediation.sharedkernel;

import java.util.UUID;

public record HitId(UUID value) {}
