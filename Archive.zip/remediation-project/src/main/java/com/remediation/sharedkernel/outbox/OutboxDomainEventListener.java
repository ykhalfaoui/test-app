package com.remediation.sharedkernel.outbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * Listens to domain events inside the same transaction and stores them in the
 * outbox table for reliable asynchronous publication.
 */
@Component
@Order(0)
public class OutboxDomainEventListener {

    private final OutboxRepository repository;
    private final ObjectMapper objectMapper;

    OutboxDomainEventListener(OutboxRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void on(Object event) {
        if (!isDomainEvent(event) || OutboxForwardingContext.isForwarding()) {
            return;
        }
        var payload = serialize(event);
        repository.save(OutboxEntry.pending(event.getClass().getName(), payload));
    }

    private boolean isDomainEvent(Object event) {
        if (event == null) {
            return false;
        }
        var packageName = event.getClass().getPackageName();
        return packageName != null && packageName.startsWith("com.remediation");
    }

    private String serialize(Object event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Unable to serialize domain event for outbox", e);
        }
    }
}
