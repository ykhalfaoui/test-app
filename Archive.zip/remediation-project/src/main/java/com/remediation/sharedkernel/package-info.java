@org.springframework.modulith.ApplicationModule(displayName = "Shared Kernel")
package com.remediation.sharedkernel;