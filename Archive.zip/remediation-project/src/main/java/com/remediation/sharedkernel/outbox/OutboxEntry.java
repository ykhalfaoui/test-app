package com.remediation.sharedkernel.outbox;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.UUID;

/**
 * Outbox entry persisted atomically with business transactions before
 * asynchronous publication.
 */
@Entity
@Table(name = "integration_outbox")
public class OutboxEntry {

    public enum Status { PENDING, SENT, FAILED }

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @Column(name = "event_type", nullable = false, updatable = false)
    private String eventType;

    @Lob
    @Column(name = "payload", nullable = false)
    private String payload;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private Status status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "last_attempt_at")
    private Instant lastAttemptAt;

    @Column(name = "attempt_count", nullable = false)
    private int attemptCount;

    protected OutboxEntry() {
        // For JPA
    }

    private OutboxEntry(String eventType, String payload) {
        this.id = UUID.randomUUID();
        this.eventType = eventType;
        this.payload = payload;
        this.status = Status.PENDING;
        this.createdAt = Instant.now();
        this.attemptCount = 0;
    }

    public static OutboxEntry pending(String eventType, String payload) {
        return new OutboxEntry(eventType, payload);
    }

    public UUID getId() {
        return id;
    }

    public String getEventType() {
        return eventType;
    }

    public String getPayload() {
        return payload;
    }

    public Status getStatus() {
        return status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getLastAttemptAt() {
        return lastAttemptAt;
    }

    public int getAttemptCount() {
        return attemptCount;
    }

    public void markSent() {
        this.status = Status.SENT;
        this.lastAttemptAt = Instant.now();
        this.attemptCount++;
    }

    public void markFailed(String message) {
        this.status = Status.FAILED;
        this.lastAttemptAt = Instant.now();
        this.attemptCount++;
        this.payload = this.payload + String.format("%n/* ERROR: %s */", message);
    }
}
