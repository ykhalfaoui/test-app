package com.remediation.sharedkernel;

public record CustomerId(String value) {}
