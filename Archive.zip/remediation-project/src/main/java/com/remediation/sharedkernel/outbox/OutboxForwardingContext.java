package com.remediation.sharedkernel.outbox;

/**
 * Thread-local guard used to prevent re-ingesting events that have already been
 * forwarded from the outbox back into the outbox itself.
 */
final class OutboxForwardingContext {

    private static final ThreadLocal<Boolean> FORWARDING = ThreadLocal.withInitial(() -> Boolean.FALSE);

    private OutboxForwardingContext() {
    }

    static boolean isForwarding() {
        return FORWARDING.get();
    }

    static void runForwarding(Runnable runnable) {
        boolean previous = FORWARDING.get();
        FORWARDING.set(true);
        try {
            runnable.run();
        } finally {
            FORWARDING.set(previous);
        }
    }
}
