package com.remediation.sharedkernel.outbox;

import org.springframework.data.repository.Repository;

import java.util.UUID;

public interface OutboxRepository extends Repository<OutboxEntry, UUID> {
    OutboxEntry save(OutboxEntry entry);
    java.util.List<OutboxEntry> findTop100ByStatusOrderByCreatedAtAsc(OutboxEntry.Status status);
}
