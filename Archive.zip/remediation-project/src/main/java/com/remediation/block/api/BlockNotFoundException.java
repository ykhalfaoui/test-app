package com.remediation.block.api;

import com.remediation.sharedkernel.BlockId;

// Custom business exception using the new Value Object
public class BlockNotFoundException extends RuntimeException {
    public BlockNotFoundException(BlockId blockId) {
        super("Block with ID " + blockId.value() + " not found.");
    }
}
