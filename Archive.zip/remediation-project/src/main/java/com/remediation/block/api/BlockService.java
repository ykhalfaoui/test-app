package com.remediation.block.api;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.ReviewId;

public interface BlockService {
    void startReviewOnBlock(BlockId blockId, ReviewId reviewId);
}
