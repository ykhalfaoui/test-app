package com.remediation.block.domain;

import com.remediation.block.api.event.BlockCreatedEvent;
import com.remediation.block.api.event.BlockReviewStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import org.springframework.data.domain.AbstractAggregateRoot;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class Block extends AbstractAggregateRoot<Block> {

    private final com.remediation.sharedkernel.BlockId id;
    private final CustomerId customerId;
    private String status;
    private final Set<ReviewId> activeReviews = new HashSet<>();

    public Block(CustomerId customerId) {
        this.id = new com.remediation.sharedkernel.BlockId(UUID.randomUUID());
        this.customerId = customerId;
        this.status = "UP_TO_DATE";

        registerEvent(new BlockCreatedEvent(this.id, this.customerId));
    }

    public void startReview(ReviewId reviewId) {
        if (!"IN_REVIEW".equals(this.status)) {
            this.status = "IN_REVIEW";
        }
        this.activeReviews.add(reviewId);

        registerEvent(new BlockReviewStartedEvent(this.id, reviewId));
    }

    public com.remediation.sharedkernel.BlockId getId() {
        return id;
    }

    public CustomerId getCustomerId() {
        return customerId;
    }
}
