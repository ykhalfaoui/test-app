package com.remediation.block.application;

import com.remediation.audit.api.Auditable;
import com.remediation.block.api.BlockNotFoundException;
import com.remediation.block.api.BlockService;
import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.block.domain.Block;
import com.remediation.block.domain.BlockRepository;
import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
class BlockServiceImpl implements BlockService {

    private final BlockRepository repository;
    private final ApplicationEventPublisher events;

    BlockServiceImpl(BlockRepository repository, ApplicationEventPublisher events) {
        this.repository = repository;
        this.events = events;
    }

    /**
     * Listens for a member being identified to provision the necessary blocks.
     */
    @ApplicationModuleListener
    public void on(ReviewMemberIdentifiedEvent event) {
        System.out.println("[BlockContext] || Received ReviewMemberIdentifiedEvent for customer: " + event.customerId().value() + " | TraceId: " + event.traceId().value());
        
        // 1. Find existing blocks or create new ones for the customer
        List<Block> blocks = findOrCreateBlocks(event.customerId());

        // 2. For each block, publish an event so the saga knows it's ready for review, propagating the traceId
        for (Block block : blocks) {
            System.out.println("[BlockContext] || Block " + block.getId().value() + " ready for review " + event.reviewId().value());
            events.publishEvent(new BlockReadyForReviewEvent(event.traceId(), block.getId(), event.reviewId()));
        }
    }

    private List<Block> findOrCreateBlocks(CustomerId customerId) {
        System.out.println("[BlockContext] || Searching for blocks for customer: " + customerId.value());
        List<Block> existingBlocks = repository.findByCustomerId(customerId);

        if (existingBlocks.isEmpty()) {
            System.out.println("[BlockContext] || No blocks found, creating a new one.");
            Block newBlock = new Block(customerId);
            repository.save(newBlock); // This will publish BlockCreatedEvent
            return List.of(newBlock);
        }
        return existingBlocks;
    }

    @Override
    @Auditable
    public void startReviewOnBlock(BlockId blockId, ReviewId reviewId) {
        System.out.println("[BlockContext] || Command to start review on block: " + blockId.value());
        
        Block block = repository.findById(blockId).orElseThrow(() -> new BlockNotFoundException(blockId));

        block.startReview(reviewId);

        repository.save(block); // This will publish BlockReviewStartedEvent
    }
}
