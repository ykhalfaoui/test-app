package com.remediation.block.api.event;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.ReviewId;

public record BlockReviewStartedEvent(
    BlockId blockId,
    ReviewId reviewId
) {}