package com.remediation.block.api.event;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Published by the BlockContext when a block is provisioned and ready to be processed
 * as part of a specific review.
 */
public record BlockReadyForReviewEvent(
    TraceId traceId,
    BlockId blockId,
    ReviewId reviewId
) {}
