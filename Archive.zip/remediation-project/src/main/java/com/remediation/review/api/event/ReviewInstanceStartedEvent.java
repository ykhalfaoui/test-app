package com.remediation.review.api.event;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

public record ReviewInstanceStartedEvent(
    TraceId traceId,
    ReviewId reviewId,
    CustomerId customerId,
    String triggerType
) {

}
