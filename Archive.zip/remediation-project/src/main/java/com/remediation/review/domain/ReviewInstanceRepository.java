package com.remediation.review.domain;

import org.springframework.data.repository.Repository;

import com.remediation.sharedkernel.ReviewId;

import java.util.Optional;

public interface ReviewInstanceRepository extends Repository<ReviewInstance, ReviewId> {
    void save(ReviewInstance reviewInstance);
    Optional<ReviewInstance> findById(ReviewId id);
}