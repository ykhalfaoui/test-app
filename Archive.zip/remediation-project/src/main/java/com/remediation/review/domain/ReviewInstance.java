package com.remediation.review.domain;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;

import java.util.UUID;

public class ReviewInstance {

    private final ReviewId id;
    private final CustomerId customerId;
    private String status;

    public ReviewInstance(CustomerId customerId, String triggerType) {
        this.id = new ReviewId(UUID.randomUUID());
        this.customerId = customerId;
        this.status = "STARTED";
    }

    public ReviewId getId() {
        return id;
    }
}
