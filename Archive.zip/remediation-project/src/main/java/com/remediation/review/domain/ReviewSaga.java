package com.remediation.review.domain;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ReviewSaga {

    public enum SagaStatus { STARTED, COLLECTING_BLOCKS, COMPLETED, FAILED }

    private UUID id;
    private ReviewId reviewInstanceId;
    private CustomerId customerId;
    private SagaStatus status;
    private int membersToProcess;
    private int membersProcessed;
    private final Set<BlockId> processedBlocks = new HashSet<>();

    public ReviewSaga(ReviewId reviewInstanceId, CustomerId customerId, int familySize) {
        this.id = UUID.randomUUID();
        this.reviewInstanceId = reviewInstanceId;
        this.customerId = customerId;
        this.membersToProcess = familySize;
        this.membersProcessed = 0;
        this.status = SagaStatus.STARTED;
    }

    public void setExpectations(int memberCount) {
        this.membersToProcess = memberCount;
        this.status = SagaStatus.COLLECTING_BLOCKS;
    }

    public boolean markBlockCollected(BlockId blockId) {
        if (processedBlocks.contains(blockId)) {
            return false;
        }
        processedBlocks.add(blockId);
        incrementProcessedMembers();
        return true;
    }

    private void incrementProcessedMembers() {
        if (this.status == SagaStatus.FAILED || this.status == SagaStatus.COMPLETED) {
            return;
        }

        this.membersProcessed++;

        if (this.membersToProcess > 0 && this.membersProcessed >= this.membersToProcess) {
            this.status = SagaStatus.COMPLETED;
        }
    }

    public ReviewId getReviewInstanceId() { return reviewInstanceId; }
    public SagaStatus getStatus() { return status; }
    public int getMembersToProcess() { return membersToProcess; }
    public int getMembersProcessed() { return membersProcessed; }
    public Set<BlockId> getProcessedBlocks() { return Set.copyOf(processedBlocks); }
}
