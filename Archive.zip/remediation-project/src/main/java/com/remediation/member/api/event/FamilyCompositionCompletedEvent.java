package com.remediation.member.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

public record FamilyCompositionCompletedEvent(
    TraceId traceId,
    ReviewId reviewId,
    int memberCount
) {}
