@org.springframework.modulith.ApplicationModule(
    displayName = "Member Composition",
    allowedDependencies = {"sharedkernel", "review"}
)
package com.remediation.member;