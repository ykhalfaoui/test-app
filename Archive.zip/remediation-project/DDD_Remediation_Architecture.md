# Architecture DDD pour la Remédiation des Données Client (Version 4)

Cette version intègre un module transverse pour l'audit, la traçabilité et la gestion centralisée des erreurs.

## 1. Bounded Contexts

Un contexte d'audit est ajouté. Il a la particularité d'écouter les événements de tous les autres contextes métier sans jamais les modifier.

```plantuml
@startuml
!theme plain
skinparam componentStyle uml2

[Kafka] <<External>> as K
[Salesforce] <<External>> as SF

node "Remediation Application" {
    component [TriggerContext] <<BC>> as Trigger
    component [BlockContext] <<BC>> as Block
    component [ReviewContext] <<BC>> as Review
    component [CustomerContext] <<BC>> as Customer
    component [IntegrationContext] <<BC>> as Integration
    component [AuditContext] <<BC>> as Audit
}

K -> Trigger
Integration -> SF

' Business contexts dependencies
Customer ..> Block
Trigger ..> Review
Review ..> Block
Block ..> Integration
Review ..> Integration

' Audit context listens to everyone
Block ..> Audit
Review ..> Audit
Customer ..> Audit
Trigger ..> Audit

@enduml
```

| Bounded Context | Responsabilités |
| :--- | :--- |
| **CustomerContext** | Gérer l'identité et les relations du client. |
| **BlockContext** | Gérer le portefeuille de blocs de données d'un client. |
| **TriggerContext** | Recevoir les déclencheurs via Kafka (Inbox). |
| **ReviewContext** | Orchestrer le processus de revue. |
| **IntegrationContext**| (ACL) Traduire les événements internes en appels API pour Salesforce. |
| **AuditContext** | **(Transverse)** Créer une piste d'audit immuable et centraliser le logging des erreurs via AOP. |

---

## 2. `AuditContext` : Traçabilité et Erreurs

Ce module est un observateur passif qui garantit la traçabilité complète de l'application.

### 2.1. Piste d'Audit via les Événements

Le contexte possède un écouteur d'événements qui souscrit à tous les événements métier importants.

```java
// Dans AuditContext
@Component
class AuditEventConsumer {

    private final AuditService auditService;

    // Exemple d'écouteur
    @ApplicationModuleListener
    void on(ReviewInstanceStartedEvent event) {
        auditService.logEvent("ReviewStarted", event.getReviewId(), event.getDetails());
    }

    @ApplicationModuleListener
    void on(BlockCompletedEvent event) {
        auditService.logEvent("BlockCompleted", event.getBlockId(), event.getDetails());
    }
    
    // ... autres écouteurs
}
```

L'entité `AuditTrail` stocke ces informations de manière persistante.

```plantuml
@startuml
entity AuditTrail {
  +UUID id
  +Instant timestamp
  +String eventType
  +String entityId
  +String userId
  +JsonNode details
  +Status status
  +String errorMessage
}
@enduml
```

### 2.2. Logging des Erreurs par AOP

Un Aspect intercepte toutes les exceptions non gérées dans les couches de service pour créer une entrée d'audit de type `FAILURE`.

```plantuml
@startuml

package "ReviewContext" {
  class ReviewService {
    +startReview()
  }
}

package "AuditContext" {
  aspect ErrorLoggingAspect {
    +logAfterThrowing(JoinPoint, Throwable)
  }
  class AuditService {
    +logError(...)
  }
}

ReviewService .. ErrorLoggingAspect : intercepté par
ErrorLoggingAspect ..> AuditService : délègue à

@enduml
```

*   **Définition de l'Aspect (AOP)** :

    ```java
    // Dans AuditContext
    @Aspect
    @Component
    public class ErrorLoggingAspect {

        private final AuditService auditService;

        @AfterThrowing(pointcut = "execution(* com.remediation..*Service.*(..))", throwing = "ex")
        public void logAfterThrowing(JoinPoint joinPoint, Throwable ex) {
            // Logique pour extraire les informations de la méthode interceptée
            auditService.logError(joinPoint.getSignature(), ex);
        }
    }
    ```

Cette approche centralise la gestion des erreurs et de l'audit, enlevant cette responsabilité aux modules métier.


---

## 3. Parcours de bout en bout : nouveau Hit qualifié positif

Ce scénario illustre la chaîne complète, du message Kafka entrant jusqu'à la synchronisation finale dans Salesforce, en expliquant où interviennent Inbox et Outbox.

### 3.1 Ingestion du hit (TriggerContext)

1. **Kafka → Inbox**  
   `HitKafkaConsumer` reçoit un message et le persiste dans `trigger_inbox` (`InboxEntry.received(...)`) dans la même transaction que la qualification.  
   En cas d'échec (ex: mauvaise désérialisation), l'entrée reste en `FAILED` pour replay manuel.  
2. **Qualification du hit**  
   `HitService.processIncomingHit` produit `HitQualifiedPositiveEvent`.  
3. **Outbox**  
   L'`OutboxDomainEventListener` intercepte `HitQualifiedPositiveEvent` avant commit, sérialise le payload et l'insère dans `integration_outbox (Status=PENDING)`.

### 3.2 Démarrage de la revue (ReviewContext)

4. **Publication `HitQualifiedPositiveEvent`**  
   Après le commit, Spring Modulith délivre l'événement à `ReviewSagaManager`.  
5. **Review start**  
   Le manager crée `ReviewInstance` + `ReviewSaga`, puis publie `ReviewInstanceStartedEvent` (capté par l'outbox).  
6. **Impact Outbox**  
   L'outbox contient désormais les événements suivants : `HitQualifiedPositiveEvent`, `ReviewInstanceStartedEvent`.

### 3.3 Composition familiale & blocs (MemberContext / BlockContext)

7. **Member composition**  
   `MemberCompositionService` consomme `ReviewInstanceStartedEvent`, compose la famille (5 membres), et publie pour chacun `ReviewMemberIdentifiedEvent` + un `FamilyCompositionCompletedEvent`.  
   *Tous* ces événements sont interceptés par l'outbox avant commit.
8. **Création des blocs**  
   `BlockService.on(ReviewMemberIdentifiedEvent)` crée un bloc si nécessaire puis publie `BlockReadyForReviewEvent` (un par bloc).  
   Là encore, chaque événement est sérialisé dans l'outbox (statut `PENDING`).

### 3.4 Traitement des événements par contexte (post-commit)

9. **Delivery applicatif**  
   Après commit, les événements Spring sont distribués :  
   - `ReviewSagaManager` met à jour l'état de sa saga (`COLLECTING_BLOCKS`, progression, etc.).  
   - `AuditEventConsumer` trace chaque étape.  
   - Le module intégration Salesforce reste, lui, découplé via l'outbox (cf. ci-dessous).

---

## 4. Synchronisation Salesforce (IntegrationContext)

### 4.1 Forwarder Outbox → commandes d'intégration

Un composant (à implémenter) parcourt `integration_outbox` pour chaque entrée `PENDING`, désérialise l'événement métier et publie l'événement d'intégration spécifique :

| Événement métier | Événement integration | Action Salesforce |
| :--- | :--- | :--- |
| `HitQualifiedPositiveEvent` (optionnel) | — | Trace de monitoring uniquement. |
| `ReviewInstanceStartedEvent` | `SalesforceReviewDraftRequested` | Créer la review en **draft**. |
| `ReviewMemberIdentifiedEvent` | `SalesforceMembersBatchRequested` (batch de N) | Bulk upsert des membres. |
| `BlockReadyForReviewEvent` | `SalesforceBlocksBatchRequested` (batch de N) | Bulk upsert des blocs. |
| `FamilyCompositionCompletedEvent` | (utilisé pour estimer les batches restants) | — |
| (Quand tous les batches sont OK) | `SalesforceReviewStatusUpdateRequested` | Passer la review en **IN_PROGRESS**. |

Le forwarder marque chaque OutboxEntry en `SENT` (ou `FAILED` + retry) après publication.

### 4.2 Orchestration via `SalesforceSyncSaga`

```plantuml
@startuml
participant ReviewSagaManager
participant OutboxForwarder
participant SalesforceSyncSagaManager
participant SalesforceClient

ReviewSagaManager -> OutboxForwarder : ReviewInstanceStartedEvent (PENDING)
OutboxForwarder -> SalesforceSyncSagaManager : SalesforceReviewDraftRequested
SalesforceSyncSagaManager -> SalesforceClient : createReviewDraft()
SalesforceClient --> SalesforceSyncSagaManager : sfReviewId
SalesforceSyncSagaManager -> SalesforceSyncSagaManager : reviewCreated(sfReviewId)

loop batches members
  OutboxForwarder -> SalesforceSyncSagaManager : SalesforceMembersBatchRequested
  SalesforceSyncSagaManager -> SalesforceClient : bulkUpsertMembers(...)
  SalesforceClient --> SalesforceSyncSagaManager : ok/ko
  SalesforceSyncSagaManager -> SalesforceSyncSagaManager : markBatchCompleted()
end

loop batches blocks
  OutboxForwarder -> SalesforceSyncSagaManager : SalesforceBlocksBatchRequested
  SalesforceSyncSagaManager -> SalesforceClient : bulkUpsertBlocks(...)
  SalesforceClient --> SalesforceSyncSagaManager : ok/ko
  SalesforceSyncSagaManager -> SalesforceSyncSagaManager : markBatchCompleted()
end

SalesforceSyncSagaManager -> SalesforceClient : updateReviewStatus(IN_PROGRESS)
SalesforceClient --> SalesforceSyncSagaManager : ok
SalesforceSyncSagaManager -> SalesforceSyncSagaManager : completed()
@enduml
```

Points clés :
- La saga stocke l'état (reviewId, sfReviewId, traceId), les lots traités et ceux en échec.  
- En cas d'échec (`FAILED`), les IDs sont remis en file d'attente pour un retry.  
- Le forwarder rejoue les entrées `FAILED` de l'outbox jusqu'à succès ou intervention opérateur.

### 4.3 Accès aux données selon DDD

- **Pas de repository cross-context** : l’intégration Salesforce utilise des façades (`BlockReadService`, `MemberReadService`…) exposées par les contextes métier.  
- Les événements ne véhiculent que des IDs + `TraceId`. L’ACL reconstitue le payload complet côté intégration.  
- Les commandes Salesforce sont encapsulées dans `SalesforceClient`.

---

## 5. Synthèse des patterns utilisés

| Pattern | Rôle dans le flux |
| :--- | :--- |
| **Inbox (TriggerContext)** | Garantir l’idempotence des messages Kafka entrants (qualification de hit). |
| **Domain Events + Application Events** | Propager les changements entre bounded contexts (Spring Modulith). |
| **Outbox** | Capturer toute intention de synchronisation externe dans la transaction métier. |
| **Saga (Review + Salesforce)** | Coordonner les étapes et conserver l’état long terme. |
| **ACL Salesforce** | Adapter les modèles métiers aux contraintes Salesforce (draft, bulk, status). |
| **Audit** | Observer chaque étape pour traçabilité / erreurs via AOP. |

Cette architecture garantit :
- Une **traçabilité de bout en bout** (TraceId propagé).  
- Une **rejouabilité** en cas de panne (Inbox/Outbox).  
- Une **séparation stricte des responsabilités** suivant DDD + Spring Modulith.
