# Remediation System V2

A production-ready, event-driven remediation system built with Domain-Driven Design (DDD) and modern architectural patterns.

## Architecture Overview

### Core Patterns
- **Domain-Driven Design (DDD)** with bounded contexts
- **Event-Driven Architecture** using Spring Modulith
- **Saga Pattern** for long-running orchestration
- **Inbox Pattern** for idempotent message consumption
- **Outbox Pattern** for reliable event publication
- **Anti-Corruption Layer** for external integrations
- **Aspect-Oriented Programming (AOP)** for cross-cutting concerns

### Bounded Contexts

```
┌─────────────────────────────────────────────────────────────────┐
│                        REMEDIATION SYSTEM                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐  │
│  │   Trigger    │─────▶│    Review    │─────▶│   Member     │  │
│  │   Context    │      │   Context    │      │   Context    │  │
│  └──────────────┘      └──────────────┘      └──────────────┘  │
│         │                      │                      │          │
│         │                      │                      ▼          │
│         │                      │              ┌──────────────┐  │
│         │                      └─────────────▶│    Block     │  │
│         │                                     │   Context    │  │
│         │                                     └──────────────┘  │
│         │                                             │          │
│         ▼                                             │          │
│  ┌──────────────┐                                    │          │
│  │ Shared Kernel│◀───────────────────────────────────┘          │
│  └──────────────┘                                               │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐      ┌──────────────┐                        │
│  │    Audit     │      │  Salesforce  │                        │
│  │   Context    │      │ Integration  │                        │
│  └──────────────┘      └──────────────┘                        │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

## Business Flow

### 1. Hit Ingestion (Trigger Context)
```
Kafka → Inbox → Qualify → HitQualifiedPositiveEvent → Outbox
```

### 2. Review Orchestration (Review Context)
```
HitQualifiedPositiveEvent → Create ReviewInstance + ReviewSaga
                          → Publish ReviewInstanceStartedEvent
```

### 3. Family Composition (Member Context)
```
ReviewInstanceStartedEvent → Find Family Members
                           → Publish ReviewMemberIdentifiedEvent (N times)
                           → Publish FamilyCompositionCompletedEvent
```

### 4. Block Provisioning (Block Context)
```
ReviewMemberIdentifiedEvent → Find or Create Block
                            → Publish BlockReadyForReviewEvent
```

### 5. Saga Completion (Review Context)
```
FamilyCompositionCompletedEvent → Set Saga Expectations
BlockReadyForReviewEvent → Mark Block Collected
                        → Complete Saga when all blocks collected
```

### 6. Salesforce Synchronization (Integration Context)
```
Outbox → ReviewInstanceStartedEvent → Create SF Review (DRAFT)
      → ReviewMemberIdentifiedEvent → Batch Members (100 max)
      → BlockReadyForReviewEvent → Batch Blocks (100 max)
      → All Synced → Update SF Review (ONGOING)
```

## Key Features

### ✅ Reliability
- **Inbox Pattern**: Exactly-once message consumption from Kafka
- **Outbox Pattern**: Atomic event publication with business transactions
- **Optimistic Locking**: Prevents lost updates in concurrent scenarios
- **Saga Pattern**: Reliable multi-step orchestration with state management

### ✅ Observability
- **Distributed Tracing**: TraceId propagated through all events
- **Comprehensive Audit Trail**: All events and errors logged
- **Structured Logging**: SLF4J with proper log levels
- **Metrics Ready**: Micrometer integration for monitoring

### ✅ Resilience
- **Idempotency**: Duplicate messages safely ignored
- **Retry Logic**: Exponential backoff for transient failures
- **Circuit Breaker Ready**: Easy to add for external integrations
- **Transaction Management**: Proper @Transactional boundaries

### ✅ Maintainability
- **Clean Architecture**: Clear separation of concerns
- **Spring Modulith**: Enforced module boundaries
- **Type Safety**: Records for value objects
- **Documentation**: Comprehensive JavaDoc and comments

## Getting Started

### Prerequisites
- Java 17+
- Maven 3.8+
- (Optional) Docker for Kafka

### Build
```bash
cd remediation-v2
mvn clean install
```

### Run
```bash
mvn spring-boot:run
```

### Access H2 Console
```
URL: http://localhost:8080/h2-console
JDBC URL: jdbc:h2:mem:remediation
Username: sa
Password: (empty)
```

## Testing the Flow

### 1. Simulate a Hit (without Kafka)
Create a test that directly calls `HitService`:

```java
@Test
void testCompleteRemediationFlow() {
    TraceId traceId = TraceId.create();
    String payload = """
        {
            "customerId": "CUST-001",
            "hitType": "SANCTIONS",
            "matchScore": "85"
        }
        """;

    hitService.processIncomingHit(traceId, payload);

    // Verify review created, saga completed, blocks provisioned
}
```

### 2. Query Audit Trail
```sql
SELECT * FROM audit_trail WHERE trace_id = 'your-trace-id' ORDER BY timestamp;
```

### 3. Check Saga Status
```sql
SELECT * FROM review_saga WHERE status = 'COMPLETED';
```

## Module Structure

```
src/main/java/com/remediation/
├── sharedkernel/           # Common value objects, Inbox/Outbox
│   ├── TraceId, CustomerId, ReviewId, BlockId, HitId
│   ├── outbox/            # Outbox pattern implementation
│   └── inbox/             # Inbox pattern implementation
│
├── trigger/               # Hit ingestion from Kafka
│   ├── api/              # Public events & interfaces
│   ├── domain/           # InboxEntry
│   ├── application/      # HitServiceImpl
│   └── infrastructure/   # HitKafkaConsumer
│
├── review/               # Review orchestration
│   ├── api/              # ReviewInstanceStartedEvent
│   ├── domain/           # ReviewInstance, ReviewSaga
│   └── application/      # ReviewSagaManager
│
├── member/               # Family composition
│   ├── api/              # ReviewMemberIdentifiedEvent, FamilyCompositionCompletedEvent
│   └── application/      # MemberCompositionService
│
├── block/                # Block provisioning
│   ├── api/              # BlockReadyForReviewEvent
│   ├── domain/           # Block
│   └── application/      # BlockProvisioningService
│
├── audit/                # Audit & observability
│   ├── api/              # @Auditable annotation
│   ├── domain/           # AuditTrail
│   ├── application/      # AuditEventListener
│   └── aop/              # ErrorLoggingAspect
│
└── integration/          # External integrations
    └── salesforce/       # Salesforce sync (to be completed)
        ├── api/          # Salesforce client interface
        ├── domain/       # SalesforceSyncSaga
        └── application/  # Salesforce handlers & saga manager
```

## Key Design Decisions

### 1. Why Spring Modulith?
- Enforces module boundaries in a modular monolith
- Enables event-driven communication between contexts
- Provides testing support for modules
- Can be split into microservices later if needed

### 2. Why Saga Pattern?
- Reviews involve multiple steps across contexts
- Need to track progress and handle failures
- State machine provides clear visibility
- Supports compensation logic if needed

### 3. Why Inbox/Outbox?
- Ensures exactly-once processing from Kafka
- Atomic event publication with business transactions
- Survives system crashes and restarts
- Provides audit trail of all events

### 4. Why AOP for Error Logging?
- Cross-cutting concern applied consistently
- Doesn't clutter business logic
- Centralized error handling
- Easy to add/remove from methods

## Production Checklist

- [ ] Replace H2 with PostgreSQL/MySQL
- [ ] Configure Kafka properly
- [ ] Implement actual Salesforce client
- [ ] Add comprehensive integration tests
- [ ] Configure proper logging (ELK stack)
- [ ] Add metrics export (Prometheus)
- [ ] Implement circuit breaker (Resilience4j)
- [ ] Add API rate limiting
- [ ] Configure proper retry policies
- [ ] Implement dead letter queue
- [ ] Add health checks
- [ ] Configure proper security (Spring Security)
- [ ] Add API documentation (OpenAPI/Swagger)
- [ ] Performance tuning (connection pools, caching)
- [ ] Load testing

## Contributing

This is a reference implementation showcasing best practices for:
- Event-driven architecture
- Domain-Driven Design
- Saga pattern implementation
- Reliable messaging patterns
- Comprehensive audit trails

## License

MIT License - feel free to use this as a reference or starting point for your projects.

## Credits

Built with:
- Spring Boot 3.2.0
- Spring Modulith 1.1.2
- Java 17
- Hibernate/JPA
- SLF4J/Logback
- Jackson
- H2 Database
