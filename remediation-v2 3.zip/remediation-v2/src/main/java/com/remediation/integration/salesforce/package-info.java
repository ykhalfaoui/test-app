/**
 * Salesforce Integration context provides Anti-Corruption Layer for Salesforce sync.
 * Responsible for:
 * - Orchestrating batched synchronization of reviews, members, and blocks to Salesforce
 * - Managing SalesforceSyncSaga for reliable multi-step integration
 * - Implementing retry logic for transient failures
 * - Respecting Salesforce API constraints (batch sizes, rate limits)
 *
 * Dependencies: sharedkernel, review, member, block
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Salesforce Integration",
    allowedDependencies = {"sharedkernel", "review", "member", "block"}
)
package com.remediation.integration.salesforce;
