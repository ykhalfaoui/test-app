package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdateRequested;
import com.remediation.integration.salesforce.api.event.SalesforceReviewStatusUpdated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Handles Salesforce review status update requests.
 */
@Component
@Slf4j
public class SalesforceReviewStatusIntegrationHandler {

    private final SalesforceClient salesforceClient;
    private final ApplicationEventPublisher eventPublisher;

    public SalesforceReviewStatusIntegrationHandler(
        SalesforceClient salesforceClient,
        ApplicationEventPublisher eventPublisher
    ) {
        this.salesforceClient = salesforceClient;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Handles request to update Salesforce review status.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceReviewStatusUpdateRequested event) {
        log.info("Updating Salesforce review {} status to {} [TraceId: {}]",
            event.salesforceReviewId(), event.newStatus(), event.traceId().value());

        try {
            // Call Salesforce API
            salesforceClient.updateReviewStatus(
                event.salesforceReviewId(),
                event.newStatus()
            );

            // Publish success event
            SalesforceReviewStatusUpdated responseEvent = new SalesforceReviewStatusUpdated(
                event.traceId(),
                event.reviewId(),
                true,
                null
            );
            eventPublisher.publishEvent(responseEvent);

            log.info("Salesforce review {} status updated to {} [TraceId: {}]",
                event.salesforceReviewId(), event.newStatus(), event.traceId().value());

        } catch (Exception ex) {
            log.error("Failed to update Salesforce review {} status [TraceId: {}]: {}",
                event.salesforceReviewId(), event.traceId().value(), ex.getMessage(), ex);

            // Publish failure event
            SalesforceReviewStatusUpdated responseEvent = new SalesforceReviewStatusUpdated(
                event.traceId(),
                event.reviewId(),
                false,
                ex.getMessage()
            );
            eventPublisher.publishEvent(responseEvent);
        }
    }
}
