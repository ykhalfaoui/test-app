package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.List;
import java.util.UUID;

/**
 * Response event when a blocks batch has been processed.
 */
public record SalesforceBlocksBatchProcessed(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    List<String> blockIds,
    boolean success,
    String failureMessage
) {
    public SalesforceBlocksBatchProcessed {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (sagaId == null) throw new IllegalArgumentException("sagaId cannot be null");
        if (blockIds == null) throw new IllegalArgumentException("blockIds cannot be null");
        blockIds = List.copyOf(blockIds); // Immutable
    }
}
