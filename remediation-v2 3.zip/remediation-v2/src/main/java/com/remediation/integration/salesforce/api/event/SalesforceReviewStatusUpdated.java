package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Response event when review status has been updated in Salesforce.
 */
public record SalesforceReviewStatusUpdated(
    TraceId traceId,
    ReviewId reviewId,
    boolean success,
    String failureMessage
) {
    public SalesforceReviewStatusUpdated {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
    }
}
