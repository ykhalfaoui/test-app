package com.remediation.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Async configuration for inbox processing.
 *
 * Configures dedicated ThreadPool for async inbox processing with:
 * - Core pool size: 10 threads (always ready)
 * - Max pool size: 50 threads (burst capacity)
 * - Queue capacity: 500 tasks (buffer)
 * - CallerRunsPolicy: Backpressure mechanism
 *
 * CallerRunsPolicy is critical:
 * When queue is full, the calling thread (Kafka consumer) will execute the task.
 * This naturally slows down Kafka consumption, providing backpressure.
 *
 * Note: @EnableAsync is already configured in Application.java
 */
@Configuration
@Slf4j
public class AsyncConfig {

    /**
     * Dedicated ThreadPool for inbox processing.
     *
     * Sizing rationale:
     * - CorePoolSize (10): Handles normal load (10 concurrent hits processing)
     * - MaxPoolSize (50): Handles burst traffic (50 concurrent hits)
     * - QueueCapacity (500): Buffer for spikes before backpressure kicks in
     * - CallerRunsPolicy: When overwhelmed, slows down Kafka consumer (backpressure)
     *
     * Total capacity: 50 threads + 500 queued = 550 concurrent tasks
     * If > 550 tasks: Kafka consumer thread processes directly (slows consumption)
     */
    @Bean("inboxProcessorExecutor")
    public Executor inboxProcessorExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        // Core threads (always alive)
        executor.setCorePoolSize(10);

        // Max threads (created on demand)
        executor.setMaxPoolSize(50);

        // Queue capacity before rejecting
        executor.setQueueCapacity(500);

        // Thread naming for debugging
        executor.setThreadNamePrefix("inbox-proc-");

        // CRITICAL: CallerRunsPolicy for backpressure
        // When queue is full, the calling thread (Kafka consumer) executes the task
        // This naturally slows down Kafka consumption
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());

        // Graceful shutdown
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(60);

        // Thread keep-alive time
        executor.setKeepAliveSeconds(60);
        executor.setAllowCoreThreadTimeOut(false);

        executor.initialize();

        log.info("Initialized inboxProcessorExecutor: core={}, max={}, queue={}, policy=CallerRunsPolicy",
            executor.getCorePoolSize(), executor.getMaxPoolSize(), executor.getQueueCapacity());

        return executor;
    }
}
