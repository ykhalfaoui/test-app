package com.remediation.review.domain;

import com.remediation.sharedkernel.ReviewId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * Repository for ReviewSaga entities.
 */
@Repository
public interface ReviewSagaRepository extends JpaRepository<ReviewSaga, UUID> {

    /**
     * Find a saga by its associated review ID.
     */
    Optional<ReviewSaga> findByReviewId(ReviewId reviewId);
}
