package com.remediation.review.api;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Domain event published when a review instance is started.
 * Triggers family composition and block provisioning.
 *
 * @param traceId Distributed trace identifier
 * @param reviewId Unique identifier for the review
 * @param customerId Principal customer being reviewed
 * @param triggerType Type of trigger that initiated the review (e.g., "HIT", "PERIODIC_REVIEW")
 */
public record ReviewInstanceStartedEvent(
    TraceId traceId,
    ReviewId reviewId,
    CustomerId customerId,
    String triggerType
) {
    public ReviewInstanceStartedEvent {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
        if (customerId == null) throw new IllegalArgumentException("customerId cannot be null");
        if (triggerType == null || triggerType.isBlank()) {
            throw new IllegalArgumentException("triggerType cannot be null or empty");
        }
    }
}
