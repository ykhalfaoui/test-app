package com.remediation.member.application;

import com.remediation.member.api.FamilyCompositionCompletedEvent;
import com.remediation.member.api.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.annotation.Order;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Service responsible for composing the family (finding all related members)
 * for a customer under review.
 *
 * In production, this would query a customer relationship database.
 * For now, it simulates finding family members.
 */
@Service
@Slf4j
public class MemberCompositionService {

    private final ApplicationEventPublisher eventPublisher;

    public MemberCompositionService(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    /**
     * Composes the family when a review is started.
     * Publishes an event for each member found, including the principal customer.
     *
     * This listener has @Order(10) to ensure it runs after ReviewSagaManager creates the saga.
     */
    @ApplicationModuleListener
    @Transactional
    @Order(10) // Run after saga creation
    public void on(ReviewInstanceStartedEvent event) {
        log.info("Starting family composition for review {} [customerId: {}, TraceId: {}]",
            event.reviewId().value(), event.customerId().value(), event.traceId().value());

        // Find all family members (in production, this would query a database)
        List<FamilyMember> familyMembers = findFamilyMembers(event.customerId());

        log.info("Found {} family members for customer {}",
            familyMembers.size(), event.customerId().value());

        // Publish an event for each member
        for (FamilyMember member : familyMembers) {
            ReviewMemberIdentifiedEvent memberEvent = new ReviewMemberIdentifiedEvent(
                event.traceId(),
                event.reviewId(),
                member.customerId(),
                member.memberType()
            );

            eventPublisher.publishEvent(memberEvent);

            log.debug("Published ReviewMemberIdentifiedEvent for member {} [type: {}, TraceId: {}]",
                member.customerId().value(), member.memberType(), event.traceId().value());
        }

        // Publish completion event with total count
        FamilyCompositionCompletedEvent completedEvent = new FamilyCompositionCompletedEvent(
            event.traceId(),
            event.reviewId(),
            familyMembers.size()
        );

        eventPublisher.publishEvent(completedEvent);

        log.info("Family composition completed for review {} - {} total members [TraceId: {}]",
            event.reviewId().value(), familyMembers.size(), event.traceId().value());
    }

    /**
     * Simulates finding family members for a customer.
     * In production, this would query customer relationship data.
     *
     * Always includes the principal customer as the first member.
     */
    private List<FamilyMember> findFamilyMembers(CustomerId principalCustomerId) {
        List<FamilyMember> members = new ArrayList<>();

        // 1. Always include the principal customer
        members.add(new FamilyMember(principalCustomerId, "PRINCIPAL"));

        // 2. Simulate finding related members (in production: database query)
        // For demo: create 2-4 related members
        int relationCount = 2 + (int) (Math.random() * 3); // 2 to 4 relations

        for (int i = 1; i <= relationCount; i++) {
            String relationType = determineRelationType(i);
            CustomerId relationId = CustomerId.of(principalCustomerId.value() + "_REL" + i);
            members.add(new FamilyMember(relationId, relationType));
        }

        return members;
    }

    /**
     * Determines the type of relation based on index.
     */
    private String determineRelationType(int index) {
        return switch (index % 4) {
            case 1 -> "SPOUSE";
            case 2 -> "DEPENDENT";
            case 3 -> "BENEFICIARY";
            default -> "RELATED_PARTY";
        };
    }

    /**
     * Internal record representing a family member.
     */
    private record FamilyMember(CustomerId customerId, String memberType) {}
}
