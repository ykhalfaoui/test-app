package com.remediation.sharedkernel.inbox;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Inbox pattern entity for idempotent message consumption.
 * Each external message (e.g., from Kafka) is recorded here to ensure
 * exactly-once processing semantics.
 */
@Entity
@Table(name = "inbox", indexes = {
    @Index(name = "idx_inbox_status", columnList = "status"),
    @Index(name = "idx_inbox_received_at", columnList = "received_at")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class InboxEntry {

    public enum Status {
        RECEIVED,   // Message received but not yet processed
        PROCESSED,  // Successfully processed
        FAILED,     // Processing failed (temporary)
        DLQ         // Dead Letter Queue (permanent failure after max retries)
    }

    @Id
    @Column(name = "event_id", updatable = false, nullable = false)
    private UUID eventId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;

    @Lob
    @Column(name = "payload", nullable = false)
    private String payload;

    @Column(name = "source", length = 100)
    private String source;

    @Column(name = "trace_id", length = 100)
    private String traceId;

    @Column(name = "retry_count", nullable = false)
    private int retryCount;

    @Column(name = "next_retry_at")
    private Instant nextRetryAt;

    @Column(name = "error_message", length = 2000)
    private String errorMessage;

    @Column(name = "received_at", nullable = false, updatable = false)
    private Instant receivedAt;

    @Column(name = "last_updated_at", nullable = false)
    private Instant lastUpdatedAt;

    @Version
    @Column(name = "version")
    private Long version;

    private InboxEntry(UUID eventId, String payload, String source) {
        this.eventId = eventId;
        this.payload = payload;
        this.source = source;
        this.status = Status.RECEIVED;
        this.retryCount = 0;
        Instant now = Instant.now();
        this.receivedAt = now;
        this.lastUpdatedAt = now;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public static InboxEntry received(UUID eventId, String payload, String source) {
        return new InboxEntry(eventId, payload, source);
    }

    public void markProcessed() {
        this.status = Status.PROCESSED;
        this.errorMessage = null;
        this.nextRetryAt = null;
        this.lastUpdatedAt = Instant.now();
    }

    public void markFailed(String errorMessage, int maxRetries) {
        this.retryCount++;
        this.errorMessage = errorMessage != null && errorMessage.length() > 2000
            ? errorMessage.substring(0, 2000)
            : errorMessage;
        this.lastUpdatedAt = Instant.now();

        if (this.retryCount >= maxRetries) {
            // Move to Dead Letter Queue after max retries
            this.status = Status.DLQ;
            this.nextRetryAt = null;
        } else {
            // Schedule retry with exponential backoff
            this.status = Status.RECEIVED; // Keep in RECEIVED for retry
            this.nextRetryAt = calculateNextRetry(this.retryCount);
        }
    }

    /**
     * Calculate next retry time with exponential backoff.
     * Retry delays: 1s, 2s, 4s, 8s, 16s
     */
    private Instant calculateNextRetry(int retryCount) {
        long delaySeconds = (long) Math.pow(2, retryCount);
        return Instant.now().plusSeconds(delaySeconds);
    }

    /**
     * Check if this entry should be retried now.
     */
    public boolean shouldRetryNow() {
        return status == Status.RECEIVED
            && retryCount > 0
            && nextRetryAt != null
            && Instant.now().isAfter(nextRetryAt);
    }

    /**
     * Check if this entry is ready for first-time processing.
     */
    public boolean isReadyForProcessing() {
        return status == Status.RECEIVED && retryCount == 0;
    }

    public boolean isProcessed() {
        return status == Status.PROCESSED;
    }

    public boolean isFailed() {
        return status == Status.FAILED;
    }

    public boolean isDLQ() {
        return status == Status.DLQ;
    }
}
