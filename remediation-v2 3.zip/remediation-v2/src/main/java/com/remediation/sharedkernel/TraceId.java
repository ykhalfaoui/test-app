package com.remediation.sharedkernel;

import java.util.UUID;

/**
 * TraceId for distributed tracing across the entire system.
 * Propagated through all events and commands for end-to-end request correlation.
 */
public record TraceId(String value) {

    public TraceId {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("TraceId cannot be null or empty");
        }
    }

    public static TraceId create() {
        return new TraceId(UUID.randomUUID().toString());
    }

    public static TraceId of(String value) {
        return new TraceId(value);
    }
}
