package com.remediation.sharedkernel.outbox;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Repository for managing outbox entries.
 */
@Repository
public interface OutboxRepository extends JpaRepository<OutboxEntry, UUID> {

    /**
     * Finds pending entries to be forwarded, ordered by creation time.
     * Limits results for batch processing.
     */
    List<OutboxEntry> findTop100ByStatusOrderByCreatedAtAsc(OutboxEntry.Status status);
}
