package com.remediation.sharedkernel.inbox;

import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * InboxProcessor - Async processing of inbox entries with intelligent retry.
 *
 * Processing Modes:
 * 1. Immediate async: Triggered by InboxEntryReceivedEvent (low latency ~100ms)
 * 2. Scheduled retry: Polls failed entries ready for retry (exponential backoff)
 * 3. Orphan recovery: Safety net for entries missed due to crashes
 *
 * Retry Strategy:
 * - Retry delays: 1s, 2s, 4s, 8s, 16s (exponential backoff)
 * - Max retries: 5
 * - After max retries: Move to Dead Letter Queue (DLQ)
 *
 * This prevents head-of-line blocking: each entry is processed independently.
 */
@Component
@Slf4j
public class InboxProcessor {

    private final InboxRepository inboxRepository;
    private final HitService hitService;
    private final ApplicationEventPublisher eventPublisher;
    private final int maxRetries;
    private final int retryBatchSize;
    private final int orphanBatchSize;

    public InboxProcessor(
        InboxRepository inboxRepository,
        HitService hitService,
        ApplicationEventPublisher eventPublisher,
        @Value("${inbox.processor.max-retries:5}") int maxRetries,
        @Value("${inbox.processor.retry-batch-size:100}") int retryBatchSize,
        @Value("${inbox.processor.orphan-batch-size:50}") int orphanBatchSize
    ) {
        this.inboxRepository = inboxRepository;
        this.hitService = hitService;
        this.eventPublisher = eventPublisher;
        this.maxRetries = maxRetries;
        this.retryBatchSize = retryBatchSize;
        this.orphanBatchSize = orphanBatchSize;
    }

    /**
     * Process inbox entry immediately when saved.
     * Triggered by InboxEntryReceivedEvent after inbox save.
     *
     * Uses @Async with dedicated ThreadPool for parallel processing.
     * TransactionalEventListener ensures event is published after commit.
     */
    @Async("inboxProcessorExecutor")
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onInboxEntryReceived(InboxEntryReceivedEvent event) {
        log.debug("Received async trigger for inbox entry [eventId: {}]", event.eventId());
        processEntry(event.eventId());
    }

    /**
     * Process a single inbox entry.
     * Each entry is processed in its own transaction for isolation.
     *
     * On success: Mark as PROCESSED
     * On failure: Increment retry, schedule next retry, or move to DLQ
     */
    @Transactional
    protected void processEntry(UUID eventId) {
        InboxEntry entry = inboxRepository.findById(eventId).orElse(null);

        if (entry == null) {
            log.warn("Inbox entry not found [eventId: {}]", eventId);
            return;
        }

        // Skip if already processed or in DLQ
        if (entry.isProcessed() || entry.isDLQ()) {
            log.debug("Inbox entry already processed or in DLQ [eventId: {}, status: {}]",
                eventId, entry.getStatus());
            return;
        }

        // Extract traceId for distributed tracing
        TraceId traceId = StringUtils.hasText(entry.getTraceId())
            ? TraceId.of(entry.getTraceId())
            : TraceId.create();

        log.info("Processing inbox entry [eventId: {}, TraceId: {}, retryCount: {}]",
            eventId, traceId.value(), entry.getRetryCount());

        try {
            // Process the hit (business logic)
            hitService.processIncomingHit(traceId, entry.getPayload());

            // Mark as successfully processed
            entry.markProcessed();
            inboxRepository.save(entry);

            log.info("Inbox entry processed successfully [eventId: {}, TraceId: {}]",
                eventId, traceId.value());

        } catch (Exception ex) {
            // Mark as failed with retry scheduling
            log.error("Inbox entry processing failed [eventId: {}, TraceId: {}, retry: {}/{}]: {}",
                eventId, traceId.value(), entry.getRetryCount() + 1, maxRetries, ex.getMessage());

            entry.markFailed(ex.getMessage(), maxRetries);
            inboxRepository.save(entry);

            if (entry.isDLQ()) {
                log.error("Inbox entry moved to DLQ after {} retries [eventId: {}, TraceId: {}]",
                    maxRetries, eventId, traceId.value());
                // TODO: Send alert/notification for DLQ entries
            } else {
                log.info("Inbox entry scheduled for retry at {} [eventId: {}, retry: {}/{}]",
                    entry.getNextRetryAt(), eventId, entry.getRetryCount(), maxRetries);
            }

            // Don't re-throw: we've handled the failure by scheduling retry or DLQ
        }
    }

    /**
     * Scheduled retry processor.
     * Polls for entries ready for retry and triggers async processing.
     *
     * Runs every 5 seconds to check for entries whose nextRetryAt has passed.
     */
    @Scheduled(
        fixedDelayString = "${inbox.processor.retry-delay:5000}",
        initialDelayString = "${inbox.processor.retry-initial-delay:10000}",
        timeUnit = TimeUnit.MILLISECONDS
    )
    public void processRetries() {
        Pageable pageable = PageRequest.of(0, retryBatchSize);
        List<InboxEntry> entries = inboxRepository.findReadyForRetry(Instant.now(), pageable);

        if (entries.isEmpty()) {
            return;
        }

        log.info("Found {} entries ready for retry", entries.size());

        for (InboxEntry entry : entries) {
            // Trigger async processing (same flow as immediate processing)
            eventPublisher.publishEvent(new InboxEntryReceivedEvent(entry.getEventId()));
        }
    }

    /**
     * Orphan recovery - Safety net.
     * Finds entries that have been RECEIVED for too long without processing.
     *
     * This catches:
     * - Entries where async trigger failed
     * - Entries missed due to application crashes/restarts
     * - Any other edge cases
     *
     * Runs every 30 seconds.
     */
    @Scheduled(
        fixedDelayString = "${inbox.processor.orphan-delay:30000}",
        initialDelayString = "${inbox.processor.orphan-initial-delay:60000}",
        timeUnit = TimeUnit.MILLISECONDS
    )
    public void recoverOrphans() {
        // Find entries RECEIVED more than 1 minute ago with no retries
        Instant threshold = Instant.now().minus(Duration.ofMinutes(1));
        Pageable pageable = PageRequest.of(0, orphanBatchSize);
        List<InboxEntry> orphans = inboxRepository.findOrphaned(threshold, pageable);

        if (orphans.isEmpty()) {
            return;
        }

        log.warn("Found {} orphaned inbox entries (received > 1min ago, retry=0)", orphans.size());

        for (InboxEntry entry : orphans) {
            log.warn("Recovering orphaned entry [eventId: {}, receivedAt: {}]",
                entry.getEventId(), entry.getReceivedAt());

            // Trigger async processing
            eventPublisher.publishEvent(new InboxEntryReceivedEvent(entry.getEventId()));
        }
    }

    /**
     * Monitoring metrics - runs every 10 seconds.
     * Logs current inbox statistics for observability.
     */
    @Scheduled(
        fixedDelayString = "${inbox.processor.metrics-delay:10000}",
        initialDelayString = "${inbox.processor.metrics-initial-delay:30000}",
        timeUnit = TimeUnit.MILLISECONDS
    )
    public void recordMetrics() {
        long received = inboxRepository.countByStatus(InboxEntry.Status.RECEIVED);
        long processed = inboxRepository.countByStatus(InboxEntry.Status.PROCESSED);
        long dlq = inboxRepository.countByStatus(InboxEntry.Status.DLQ);

        if (received > 0 || dlq > 0) {
            log.info("Inbox metrics - RECEIVED: {}, PROCESSED: {}, DLQ: {}", received, processed, dlq);
        }

        // Alert if too many in DLQ
        if (dlq > 100) {
            log.error("ALERT: Too many entries in DLQ ({}). Manual intervention required!", dlq);
            // TODO: Send alert to ops team
        }

        // Alert if inbox backlog growing
        if (received > 1000) {
            log.warn("WARNING: Large inbox backlog ({}). System may be overloaded!", received);
            // TODO: Send warning to ops team
        }
    }
}
