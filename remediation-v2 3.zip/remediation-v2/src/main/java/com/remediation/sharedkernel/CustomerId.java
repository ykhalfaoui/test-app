package com.remediation.sharedkernel;

/**
 * Value object representing a unique customer identifier.
 */
public record CustomerId(String value) {

    public CustomerId {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("CustomerId cannot be null or empty");
        }
    }

    public static CustomerId of(String value) {
        return new CustomerId(value);
    }
}
