package com.remediation.sharedkernel.outbox;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Outbox pattern entity for reliable event publication.
 * Events are first saved to this table atomically with business transactions,
 * then forwarded asynchronously to the event bus.
 */
@Entity
@Table(name = "outbox", indexes = {
    @Index(name = "idx_outbox_status_created", columnList = "status,created_at")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class OutboxEntry {

    public enum Status {
        PENDING,  // Waiting to be forwarded
        SENT,     // Successfully published
        FAILED    // Failed after retries
    }

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Column(name = "event_type", nullable = false, length = 500)
    private String eventType;

    @Lob
    @Column(name = "payload", nullable = false)
    private String payload;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "last_attempt_at")
    private Instant lastAttemptAt;

    @Column(name = "attempt_count", nullable = false)
    private int attemptCount;

    @Column(name = "error_message", length = 2000)
    private String errorMessage;

    @Version
    @Column(name = "version")
    private Long version;

    private OutboxEntry(String eventType, String payload) {
        this.id = UUID.randomUUID();
        this.eventType = eventType;
        this.payload = payload;
        this.status = Status.PENDING;
        this.createdAt = Instant.now();
        this.attemptCount = 0;
    }

    public static OutboxEntry pending(String eventType, String payload) {
        return new OutboxEntry(eventType, payload);
    }

    public void markSent() {
        this.status = Status.SENT;
        this.lastAttemptAt = Instant.now();
        this.attemptCount++;
        this.errorMessage = null;
    }

    public void markFailed(String errorMessage) {
        this.status = Status.FAILED;
        this.lastAttemptAt = Instant.now();
        this.attemptCount++;
        this.errorMessage = errorMessage != null && errorMessage.length() > 2000
            ? errorMessage.substring(0, 2000)
            : errorMessage;
    }

    public void retry() {
        if (this.status == Status.FAILED) {
            this.status = Status.PENDING;
            this.errorMessage = null;
        }
    }
}
