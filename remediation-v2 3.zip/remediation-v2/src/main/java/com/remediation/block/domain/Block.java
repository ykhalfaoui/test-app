package com.remediation.block.domain;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

/**
 * Block aggregate representing a data block for a customer.
 * Blocks contain customer data that needs to be reviewed during remediation.
 *
 * Key characteristics:
 * - Blocks are customer-scoped, not review-scoped
 * - A single block can be used in multiple reviews
 * - Status transitions: UP_TO_DATE → IN_REVIEW
 */
@Entity
@Table(name = "block", indexes = {
    @Index(name = "idx_block_customer", columnList = "customer_id"),
    @Index(name = "idx_block_status", columnList = "status")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Block {

    public enum BlockStatus {
        UP_TO_DATE,  // Block data is current
        IN_REVIEW,   // Block is being reviewed
        OUTDATED     // Block data needs refresh
    }

    @EmbeddedId
    @AttributeOverride(name = "value", column = @Column(name = "id"))
    private BlockId id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "customer_id", nullable = false))
    private CustomerId customerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private BlockStatus status;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "block_active_reviews",
        joinColumns = @JoinColumn(name = "block_id")
    )
    @Column(name = "review_id")
    private Set<java.util.UUID> activeReviewIds = new HashSet<>();

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "last_updated_at", nullable = false)
    private Instant lastUpdatedAt;

    @Version
    @Column(name = "version")
    private Long version;

    public Block(CustomerId customerId) {
        this.id = BlockId.create();
        this.customerId = customerId;
        this.status = BlockStatus.UP_TO_DATE;
        Instant now = Instant.now();
        this.createdAt = now;
        this.lastUpdatedAt = now;
    }

    /**
     * Starts a review on this block.
     * Adds the review to active reviews and transitions to IN_REVIEW status.
     */
    public void startReview(ReviewId reviewId) {
        if (reviewId == null) {
            throw new IllegalArgumentException("reviewId cannot be null");
        }

        activeReviewIds.add(reviewId.value());

        if (this.status == BlockStatus.UP_TO_DATE) {
            this.status = BlockStatus.IN_REVIEW;
        }

        this.lastUpdatedAt = Instant.now();
    }

    /**
     * Completes a review on this block.
     * Removes the review from active reviews.
     */
    public void completeReview(ReviewId reviewId) {
        activeReviewIds.remove(reviewId.value());

        // Return to UP_TO_DATE if no more active reviews
        if (activeReviewIds.isEmpty() && this.status == BlockStatus.IN_REVIEW) {
            this.status = BlockStatus.UP_TO_DATE;
        }

        this.lastUpdatedAt = Instant.now();
    }

    /**
     * Returns defensive copy of active review IDs.
     */
    public Set<java.util.UUID> getActiveReviewIds() {
        return new HashSet<>(activeReviewIds);
    }
}
