package com.remediation.trigger.application;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.HitId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitQualifiedPositiveEvent;
import com.remediation.trigger.api.HitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of HitService for processing incoming hits.
 * Qualifies hits and publishes appropriate events.
 */
@Service
@Slf4j
class HitServiceImpl implements HitService {

    private final ApplicationEventPublisher eventPublisher;
    private final ObjectMapper objectMapper;

    HitServiceImpl(ApplicationEventPublisher eventPublisher, ObjectMapper objectMapper) {
        this.eventPublisher = eventPublisher;
        this.objectMapper = objectMapper;
    }

    @Override
    @Transactional
    public void processIncomingHit(TraceId traceId, String payload) {
        log.info("Processing incoming hit [TraceId: {}]", traceId.value());

        try {
            // Parse the hit payload
            JsonNode hitData = objectMapper.readTree(payload);
            String customerId = hitData.path("customerId").asText();
            String hitType = hitData.path("hitType").asText("UNKNOWN");
            String matchScore = hitData.path("matchScore").asText("0");

            if (customerId.isBlank()) {
                log.warn("Hit payload missing customerId, skipping [TraceId: {}]", traceId.value());
                return;
            }

            // Qualify the hit based on business rules
            boolean isPositive = qualifyHit(hitType, matchScore);

            if (isPositive) {
                log.info("Hit qualified as POSITIVE for customer {} [TraceId: {}]",
                    customerId, traceId.value());

                HitQualifiedPositiveEvent event = new HitQualifiedPositiveEvent(
                    traceId,
                    HitId.create(),
                    CustomerId.of(customerId),
                    hitType
                );

                eventPublisher.publishEvent(event);
            } else {
                log.info("Hit qualified as NEGATIVE for customer {} [TraceId: {}]",
                    customerId, traceId.value());
                // Could publish HitQualifiedNegativeEvent if needed
            }

        } catch (Exception e) {
            log.error("Failed to process hit [TraceId: {}]: {}",
                traceId.value(), e.getMessage(), e);
            throw new RuntimeException("Hit processing failed", e);
        }
    }

    /**
     * Business logic to qualify a hit as positive or negative.
     * In real implementation, this would involve complex rules and scoring.
     */
    private boolean qualifyHit(String hitType, String matchScore) {
        try {
            int score = Integer.parseInt(matchScore);
            // Simple rule: score > 75 is positive
            return score > 75;
        } catch (NumberFormatException e) {
            log.warn("Invalid match score: {}, defaulting to positive", matchScore);
            return true;
        }
    }
}
