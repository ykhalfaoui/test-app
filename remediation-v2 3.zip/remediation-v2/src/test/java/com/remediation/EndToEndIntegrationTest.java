package com.remediation;

import com.remediation.audit.domain.AuditTrailRepository;
import com.remediation.block.domain.Block;
import com.remediation.block.domain.BlockRepository;
import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.integration.salesforce.domain.SalesforceSyncSagaRepository;
import com.remediation.review.domain.ReviewInstance;
import com.remediation.review.domain.ReviewInstanceRepository;
import com.remediation.review.domain.ReviewSaga;
import com.remediation.review.domain.ReviewSagaRepository;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.sharedkernel.inbox.InboxEntry;
import com.remediation.sharedkernel.inbox.InboxRepository;
import com.remediation.sharedkernel.outbox.OutboxEntry;
import com.remediation.sharedkernel.outbox.OutboxRepository;
import com.remediation.trigger.api.HitService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import java.util.concurrent.TimeUnit;

/**
 * Comprehensive end-to-end integration test covering the complete remediation flow:
 * Hit → Review → Members → Blocks → Salesforce Sync
 *
 * This test verifies that all bounded contexts work together correctly.
 */
class EndToEndIntegrationTest extends TestBase {

    @Autowired
    private HitService hitService;

    @Autowired
    private InboxRepository inboxRepository;

    @Autowired
    private OutboxRepository outboxRepository;

    @Autowired
    private ReviewInstanceRepository reviewRepository;

    @Autowired
    private ReviewSagaRepository reviewSagaRepository;

    @Autowired
    private BlockRepository blockRepository;

    @Autowired
    private SalesforceSyncSagaRepository salesforceSagaRepository;

    @Autowired
    private AuditTrailRepository auditTrailRepository;

    @Test
    void shouldCompleteEntireRemediationFlow() throws InterruptedException {
        // Given - a positive hit
        TraceId traceId = TraceId.create();
        CustomerId customerId = CustomerId.of("CUST-E2E-001");
        String payload = String.format("""
            {
                "customerId": "%s",
                "hitType": "SANCTIONS",
                "matchScore": "95"
            }
            """, customerId.value());

        // When - process the hit
        hitService.processIncomingHit(traceId, payload);

        // ========== STEP 1: Verify Hit Processing ==========
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> {
            // Inbox entry should be created and processed
            List<InboxEntry> inboxEntries = inboxRepository.findAll();
            assertThat(inboxEntries).isNotEmpty();
            assertThat(inboxEntries.stream()
                .anyMatch(InboxEntry::isProcessed)).isTrue();
        });

        // ========== STEP 2: Verify Review Creation ==========
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            // Review instance should be created
            List<ReviewInstance> reviews = reviewRepository.findByCustomerId(customerId);
            assertThat(reviews).hasSize(1);

            ReviewInstance review = reviews.get(0);
            assertThat(review.getStatus()).isIn(
                ReviewInstance.ReviewStatus.STARTED,
                ReviewInstance.ReviewStatus.IN_PROGRESS,
                ReviewInstance.ReviewStatus.READY
            );

            // Review saga should be created
            ReviewSaga reviewSaga = reviewSagaRepository.findByReviewId(review.getId()).orElseThrow();
            assertThat(reviewSaga).isNotNull();
        });

        // ========== STEP 3: Verify Family Composition ==========
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            ReviewInstance review = reviewRepository.findByCustomerId(customerId).get(0);
            ReviewSaga reviewSaga = reviewSagaRepository.findByReviewId(review.getId()).orElseThrow();

            // Saga should have expectations set (family composition completed)
            assertThat(reviewSaga.getExpectedMemberCount()).isGreaterThan(0);
            assertThat(reviewSaga.getStatus()).isIn(
                ReviewSaga.SagaStatus.COLLECTING_BLOCKS,
                ReviewSaga.SagaStatus.COMPLETED
            );
        });

        // ========== STEP 4: Verify Block Provisioning ==========
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            // Blocks should be created for principal and relations
            List<Block> allBlocks = blockRepository.findAll();
            assertThat(allBlocks).isNotEmpty();

            // Should have blocks for the principal customer
            List<Block> customerBlocks = blockRepository.findByCustomerId(customerId);
            assertThat(customerBlocks).hasSize(1);

            // Total blocks should match member count (principal + relations)
            ReviewInstance review = reviewRepository.findByCustomerId(customerId).get(0);
            ReviewSaga reviewSaga = reviewSagaRepository.findByReviewId(review.getId()).orElseThrow();
            assertThat(allBlocks).hasSizeGreaterThanOrEqualTo(reviewSaga.getExpectedMemberCount());
        });

        // ========== STEP 5: Verify Review Saga Completion ==========
        await().atMost(10, TimeUnit.SECONDS).untilAsserted(() -> {
            ReviewInstance review = reviewRepository.findByCustomerId(customerId).get(0);
            ReviewSaga reviewSaga = reviewSagaRepository.findByReviewId(review.getId()).orElseThrow();

            // Review saga should be completed
            assertThat(reviewSaga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COMPLETED);
            assertThat(reviewSaga.isCompleted()).isTrue();

            // All expected blocks should be collected
            assertThat(reviewSaga.getCollectedBlockCount())
                .isEqualTo(reviewSaga.getExpectedMemberCount());

            // Review should be marked as READY
            ReviewInstance completedReview = reviewRepository.findById(review.getId()).orElseThrow();
            assertThat(completedReview.getStatus()).isEqualTo(ReviewInstance.ReviewStatus.READY);
        });

        // ========== STEP 6: Verify Salesforce Sync Creation ==========
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            ReviewInstance review = reviewRepository.findByCustomerId(customerId).get(0);

            // Salesforce saga should be created
            SalesforceSyncSaga sfSaga = salesforceSagaRepository
                .findByReviewId(review.getId()).orElseThrow();
            assertThat(sfSaga).isNotNull();

            // Should have Salesforce review ID
            assertThat(sfSaga.getSalesforceReviewId()).isNotNull();
            assertThat(sfSaga.getSalesforceReviewId()).startsWith("SF-");
        });

        // ========== STEP 7: Verify Salesforce Sync Completion ==========
        await().atMost(15, TimeUnit.SECONDS).untilAsserted(() -> {
            ReviewInstance review = reviewRepository.findByCustomerId(customerId).get(0);
            SalesforceSyncSaga sfSaga = salesforceSagaRepository
                .findByReviewId(review.getId()).orElseThrow();

            // Salesforce saga should complete (or be in final stages)
            assertThat(sfSaga.getStatus()).isIn(
                SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS,
                SalesforceSyncSaga.SyncStatus.SYNCING_BLOCKS,
                SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS,
                SalesforceSyncSaga.SyncStatus.COMPLETED
            );
        });

        // ========== STEP 8: Verify Outbox Processing ==========
        await().atMost(10, TimeUnit.SECONDS).untilAsserted(() -> {
            // Multiple events should have been forwarded
            List<OutboxEntry> sentEvents = outboxRepository.findAll().stream()
                .filter(entry -> entry.getStatus() == OutboxEntry.Status.SENT)
                .toList();

            assertThat(sentEvents).hasSizeGreaterThan(10); // Should have many events

            // Should include key event types
            boolean hasHitEvent = sentEvents.stream()
                .anyMatch(e -> e.getEventType().contains("HitQualifiedPositiveEvent"));
            boolean hasReviewEvent = sentEvents.stream()
                .anyMatch(e -> e.getEventType().contains("ReviewInstanceStartedEvent"));
            boolean hasMemberEvent = sentEvents.stream()
                .anyMatch(e -> e.getEventType().contains("ReviewMemberIdentifiedEvent"));
            boolean hasBlockEvent = sentEvents.stream()
                .anyMatch(e -> e.getEventType().contains("BlockReadyForReviewEvent"));

            assertThat(hasHitEvent).isTrue();
            assertThat(hasReviewEvent).isTrue();
            assertThat(hasMemberEvent).isTrue();
            assertThat(hasBlockEvent).isTrue();
        });

        // ========== STEP 9: Verify Audit Trail ==========
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            // Audit trail should capture all events
            var auditEntries = auditTrailRepository.findByTraceIdOrderByTimestampAsc(
                traceId.value()
            );

            assertThat(auditEntries).hasSizeGreaterThan(5);

            // Should have events from different contexts
            var eventTypes = auditEntries.stream()
                .map(audit -> audit.getEventType())
                .toList();

            assertThat(eventTypes).contains("HitQualifiedPositiveEvent");
        });

        // ========== FINAL VERIFICATION ==========
        // Verify complete state
        ReviewInstance finalReview = reviewRepository.findByCustomerId(customerId).get(0);
        ReviewSaga finalReviewSaga = reviewSagaRepository
            .findByReviewId(finalReview.getId()).orElseThrow();
        SalesforceSyncSaga finalSfSaga = salesforceSagaRepository
            .findByReviewId(finalReview.getId()).orElseThrow();

        System.out.println("\n========== END-TO-END TEST SUMMARY ==========");
        System.out.println("TraceId: " + traceId.value());
        System.out.println("Customer: " + customerId.value());
        System.out.println("Review Status: " + finalReview.getStatus());
        System.out.println("Review Saga Status: " + finalReviewSaga.getStatus());
        System.out.println("Review Saga Progress: " + finalReviewSaga.getCollectedBlockCount() +
            "/" + finalReviewSaga.getExpectedMemberCount() + " blocks");
        System.out.println("Salesforce Saga Status: " + finalSfSaga.getStatus());
        System.out.println("Salesforce Review ID: " + finalSfSaga.getSalesforceReviewId());
        System.out.println("Total Blocks Created: " + blockRepository.findAll().size());
        System.out.println("Total Outbox Events: " + outboxRepository.findAll().size());
        System.out.println("Total Audit Entries: " + auditTrailRepository.findAll().size());
        System.out.println("=============================================\n");
    }

    @Test
    void shouldHandleMultipleConcurrentHits() throws InterruptedException {
        // Given - multiple hits for different customers
        TraceId trace1 = TraceId.create();
        TraceId trace2 = TraceId.create();
        TraceId trace3 = TraceId.create();

        // When - process hits concurrently
        hitService.processIncomingHit(trace1, """
            {"customerId": "CUST-CONCURRENT-1", "hitType": "SANCTIONS", "matchScore": "85"}
            """);

        hitService.processIncomingHit(trace2, """
            {"customerId": "CUST-CONCURRENT-2", "hitType": "PEP", "matchScore": "90"}
            """);

        hitService.processIncomingHit(trace3, """
            {"customerId": "CUST-CONCURRENT-3", "hitType": "ADVERSE_MEDIA", "matchScore": "95"}
            """);

        // Then - all reviews should complete independently
        await().atMost(15, TimeUnit.SECONDS).untilAsserted(() -> {
            List<ReviewSaga> allSagas = reviewSagaRepository.findAll();
            assertThat(allSagas).hasSizeGreaterThanOrEqualTo(3);

            // All sagas should eventually complete
            long completedCount = allSagas.stream()
                .filter(ReviewSaga::isCompleted)
                .count();
            assertThat(completedCount).isGreaterThanOrEqualTo(3);
        });
    }

    @Test
    void shouldMaintainDataConsistency() throws InterruptedException {
        // Given
        TraceId traceId = TraceId.create();
        CustomerId customerId = CustomerId.of("CUST-CONSISTENCY");

        // When
        hitService.processIncomingHit(traceId, String.format("""
            {"customerId": "%s", "hitType": "SANCTIONS", "matchScore": "88"}
            """, customerId.value()));

        // Wait for processing
        Thread.sleep(5000);

        // Then - verify referential integrity
        List<ReviewInstance> reviews = reviewRepository.findByCustomerId(customerId);
        if (!reviews.isEmpty()) {
            ReviewInstance review = reviews.get(0);

            // Review must have a saga
            assertThat(reviewSagaRepository.findByReviewId(review.getId())).isPresent();

            // Review must have a Salesforce saga
            assertThat(salesforceSagaRepository.findByReviewId(review.getId())).isPresent();

            // All blocks referenced in saga should exist
            ReviewSaga saga = reviewSagaRepository.findByReviewId(review.getId()).orElseThrow();
            saga.getProcessedBlocks().forEach(blockId -> {
                assertThat(blockRepository.existsById(com.remediation.sharedkernel.BlockId.of(blockId)))
                    .isTrue();
            });
        }
    }
}
