package com.remediation.sharedkernel.outbox;

import com.remediation.TestBase;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitQualifiedPositiveEvent;
import com.remediation.sharedkernel.HitId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import java.util.concurrent.TimeUnit;

/**
 * Tests for the Outbox pattern implementation.
 */
class OutboxPatternTest extends TestBase {

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Autowired
    private OutboxRepository outboxRepository;

    @Test
    void shouldCaptureEventInOutbox() {
        // Given
        HitQualifiedPositiveEvent event = new HitQualifiedPositiveEvent(
            TraceId.create(),
            HitId.create(),
            CustomerId.of("CUST-001"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - event should be captured in outbox
        await().atMost(2, TimeUnit.SECONDS).untilAsserted(() -> {
            var outboxEntries = outboxRepository.findTop100ByStatusOrderByCreatedAtAsc(
                OutboxEntry.Status.PENDING
            );
            assertThat(outboxEntries)
                .isNotEmpty()
                .anyMatch(entry -> entry.getEventType().contains("HitQualifiedPositiveEvent"));
        });
    }

    @Test
    void shouldForwardPendingEvents() throws InterruptedException {
        // Given - publish an event
        HitQualifiedPositiveEvent event = new HitQualifiedPositiveEvent(
            TraceId.create(),
            HitId.create(),
            CustomerId.of("CUST-002"),
            "SANCTIONS"
        );
        eventPublisher.publishEvent(event);

        // Wait for outbox to capture
        Thread.sleep(500);

        // When - wait for forwarder to process (runs every 100ms in test)
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> {
            var sentEntries = outboxRepository.findAll().stream()
                .filter(entry -> entry.getStatus() == OutboxEntry.Status.SENT)
                .toList();

            // Then - event should be marked as SENT
            assertThat(sentEntries).isNotEmpty();
        });
    }

    @Test
    void shouldPreventInfiniteLoop() {
        // Given - outbox forwarder is running
        int initialCount = outboxRepository.findAll().size();

        // When - forwarder processes events multiple times
        await().atMost(2, TimeUnit.SECONDS).pollInterval(500, TimeUnit.MILLISECONDS)
            .untilAsserted(() -> {
                // Then - no exponential growth of events (would indicate infinite loop)
                int currentCount = outboxRepository.findAll().size();
                assertThat(currentCount).isLessThan(initialCount + 100); // Reasonable limit
            });
    }
}
