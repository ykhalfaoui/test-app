package com.remediation.sharedkernel.inbox;

import com.remediation.TestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for the Inbox pattern implementation.
 */
class InboxPatternTest extends TestBase {

    @Autowired
    private InboxRepository inboxRepository;

    @Test
    void shouldCreateInboxEntry() {
        // Given
        UUID eventId = UUID.randomUUID();
        String payload = "{\"test\": \"data\"}";

        // When
        InboxEntry entry = InboxEntry.received(eventId, payload, "TEST");
        inboxRepository.save(entry);

        // Then
        InboxEntry found = inboxRepository.findById(eventId).orElseThrow();
        assertThat(found.getEventId()).isEqualTo(eventId);
        assertThat(found.getStatus()).isEqualTo(InboxEntry.Status.RECEIVED);
        assertThat(found.getPayload()).isEqualTo(payload);
        assertThat(found.getSource()).isEqualTo("TEST");
    }

    @Test
    void shouldMarkAsProcessed() {
        // Given
        UUID eventId = UUID.randomUUID();
        InboxEntry entry = InboxEntry.received(eventId, "{}", "TEST");
        inboxRepository.save(entry);

        // When
        entry.markProcessed();
        inboxRepository.save(entry);

        // Then
        InboxEntry found = inboxRepository.findById(eventId).orElseThrow();
        assertThat(found.getStatus()).isEqualTo(InboxEntry.Status.PROCESSED);
        assertThat(found.isProcessed()).isTrue();
    }

    @Test
    void shouldMarkAsFailed() {
        // Given
        UUID eventId = UUID.randomUUID();
        InboxEntry entry = InboxEntry.received(eventId, "{}", "TEST");
        inboxRepository.save(entry);

        // When
        entry.markFailed("Test error");
        inboxRepository.save(entry);

        // Then
        InboxEntry found = inboxRepository.findById(eventId).orElseThrow();
        assertThat(found.getStatus()).isEqualTo(InboxEntry.Status.FAILED);
        assertThat(found.isFailed()).isTrue();
        assertThat(found.getErrorMessage()).isEqualTo("Test error");
    }

    @Test
    void shouldDetectDuplicates() {
        // Given
        UUID eventId = UUID.randomUUID();
        InboxEntry entry = InboxEntry.received(eventId, "{}", "TEST");
        inboxRepository.save(entry);

        // When/Then - checking for duplicate
        boolean exists = inboxRepository.existsByEventId(eventId);
        assertThat(exists).isTrue();

        boolean notExists = inboxRepository.existsByEventId(UUID.randomUUID());
        assertThat(notExists).isFalse();
    }
}
