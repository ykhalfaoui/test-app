package com.remediation.review;

import com.remediation.TestBase;
import com.remediation.block.api.BlockReadyForReviewEvent;
import com.remediation.member.api.FamilyCompositionCompletedEvent;
import com.remediation.review.domain.ReviewInstance;
import com.remediation.review.domain.ReviewInstanceRepository;
import com.remediation.review.domain.ReviewSaga;
import com.remediation.review.domain.ReviewSagaRepository;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.HitId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitQualifiedPositiveEvent;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import java.util.concurrent.TimeUnit;

/**
 * Integration tests for Review context orchestration.
 */
class ReviewSagaIntegrationTest extends TestBase {

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Autowired
    private ReviewInstanceRepository reviewRepository;

    @Autowired
    private ReviewSagaRepository sagaRepository;

    @Test
    void shouldCreateReviewAndSagaOnPositiveHit() {
        // Given
        TraceId traceId = TraceId.create();
        HitQualifiedPositiveEvent event = new HitQualifiedPositiveEvent(
            traceId,
            HitId.create(),
            CustomerId.of("CUST-001"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - review and saga should be created
        await().atMost(2, TimeUnit.SECONDS).untilAsserted(() -> {
            assertThat(reviewRepository.findAll()).isNotEmpty();
            assertThat(sagaRepository.findAll()).isNotEmpty();
        });
    }

    @Test
    void shouldSetSagaExpectationsOnFamilyCompletion() throws InterruptedException {
        // Given - create review and saga
        ReviewId reviewId = ReviewId.create();
        ReviewInstance review = new ReviewInstance(CustomerId.of("CUST-002"), "TEST");
        reviewRepository.save(review);

        ReviewSaga saga = new ReviewSaga(review.getId(), CustomerId.of("CUST-002"));
        sagaRepository.save(saga);

        // When - publish family composition completed
        FamilyCompositionCompletedEvent event = new FamilyCompositionCompletedEvent(
            TraceId.create(),
            review.getId(),
            3
        );
        eventPublisher.publishEvent(event);

        // Then - saga should have expectations set
        Thread.sleep(500);
        ReviewSaga updatedSaga = sagaRepository.findByReviewId(review.getId()).orElseThrow();
        assertThat(updatedSaga.getExpectedMemberCount()).isEqualTo(3);
        assertThat(updatedSaga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COLLECTING_BLOCKS);
    }

    @Test
    void shouldCollectBlocksAndComplete() throws InterruptedException {
        // Given - saga expecting 2 blocks
        ReviewId reviewId = ReviewId.create();
        ReviewInstance review = new ReviewInstance(CustomerId.of("CUST-003"), "TEST");
        reviewRepository.save(review);

        ReviewSaga saga = new ReviewSaga(review.getId(), CustomerId.of("CUST-003"));
        saga.setExpectations(2);
        sagaRepository.save(saga);

        // When - publish block ready events
        eventPublisher.publishEvent(new BlockReadyForReviewEvent(
            TraceId.create(),
            BlockId.create(),
            review.getId()
        ));
        eventPublisher.publishEvent(new BlockReadyForReviewEvent(
            TraceId.create(),
            BlockId.create(),
            review.getId()
        ));

        // Then - saga should complete
        Thread.sleep(500);
        ReviewSaga completedSaga = sagaRepository.findByReviewId(review.getId()).orElseThrow();
        assertThat(completedSaga.getStatus()).isEqualTo(ReviewSaga.SagaStatus.COMPLETED);
        assertThat(completedSaga.isCompleted()).isTrue();

        // Review should be marked as READY
        ReviewInstance completedReview = reviewRepository.findById(review.getId()).orElseThrow();
        assertThat(completedReview.getStatus()).isEqualTo(ReviewInstance.ReviewStatus.READY);
    }
}
