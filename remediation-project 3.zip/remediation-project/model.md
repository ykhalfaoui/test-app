classDiagram
    direction LR

    class Customer {
        <<Aggregate Root>>
        +CustomerId
        +CustomerType
        +List~Relation~ relations
    }

    class Relation {
        <<Entity>>
        +RelatedCustomerId
        +Role
    }

    class Hit {
        <<Aggregate Root>>
        +HitId
        +CustomerId
        +Source
        +Status
    }

    class ReviewInstance {
        <<Aggregate Root>>
        +ReviewInstanceId
        +MainCustomerId
        +Status
        +List~ReviewMember~ members
    }

    class ReviewMember {
        <<Entity>>
        +CustomerId
        +Role
        +List~BlockId~ blocksToReview
    }

    class Block {
        <<Aggregate Root>>
        +BlockId
        +CustomerId
        +BlockType
        +Status
        +Version
        +InputData
    }

    Customer "1" -- "0..*" Relation : contains
    ReviewInstance "1" -- "1..*" ReviewMember : contains