# Projet de Remédiation des Données Client

Ce projet est une implémentation de référence pour un service de remédiation des données client (KYC/KYT), basée sur une architecture modulaire et événementielle.

## Concepts Métier Clés

- **Client**: L'entité centrale, une personne ou une organisation.
- **Block**: Une unité de données homogène appartenant à un client (ex: données statiques, documents, KYC) qui possède son propre cycle de vie.
- **Review (Revue)**: Le processus de remédiation actif pour un client et ses relations, déclenché par un événement.
- **Trigger (Déclencheur)**: Un événement externe (un "Hit") ou interne (un schedule) qui peut initier une `Review`.

---

## Architecture

Le projet suit les principes du **Domain-Driven Design (DDD)** et est structuré comme un **Monolithe Modulaire** avec [Spring Modulith](https://spring.io/projects/spring-modulith).

### Vue d'ensemble des Modules (Bounded Contexts)

L'application est décomposée en plusieurs modules, chacun représentant un Bounded Context avec des responsabilités claires.

```plantuml
@startuml
!theme plain
skinparam componentStyle uml2

[Kafka] <<External>> as K
[Salesforce] <<External>> as SF

node "Remediation Application" {
    component [TriggerContext] <<BC>> as Trigger
    component [BlockContext] <<BC>> as Block
    component [ReviewContext] <<BC>> as Review
    component [CustomerContext] <<BC>> as Customer
    component [IntegrationContext] <<BC>> as Integration
    component [AuditContext] <<BC>> as Audit
}

K -> Trigger : (Hits)
Integration -> SF : API Calls

' Business contexts dependencies
Customer ..> Block : publishes events
Trigger ..> Review : publishes events
Review ..> Block : sends commands
Block ..> Integration : publishes events
Review ..> Integration : publishes events

' Audit context listens to everyone
Block ..> Audit
Review ..> Audit
Customer ..> Audit
Trigger ..> Audit

@enduml
```

| Module | Responsabilités |
| :--- | :--- |
| **CustomerContext** | Gérer l'identité et les relations du client. |
| **BlockContext** | Gérer le portefeuille de blocs de données d'un client, leur cycle de vie et leur versioning. |
| **TriggerContext** | Recevoir les déclencheurs (ex: via Kafka) et initier les processus. |
| **ReviewContext** | Orchestrer le processus de revue en réponse à un déclencheur. |
| **IntegrationContext**| (ACL) Isoler la communication avec les systèmes externes (ex: Salesforce). |
| **AuditContext** | **(Transverse)** Créer une piste d'audit et centraliser le logging des erreurs. |

### Structure d'un Module

Chaque module suit une **Architecture Hexagonale** (Ports & Adapters) avec la structure de packages suivante :

- `api/`: Contient les interfaces de service publiques du module (les "ports entrants") et les DTOs/événements exposés.
- `domain/`: Le cœur métier. Contient les agrégats, les entités, et les interfaces de repository (les "ports sortants").
- `application/`: Contient l'implémentation des cas d'usage qui orchestrent le domaine.
- `infrastructure/`: Contient l'implémentation technique des ports (ex: consommateurs Kafka, clients REST, implémentations de repository JPA).

---

## Patterns de Conception Clés

- **Communication Événementielle**: Les modules communiquent principalement via des événements de domaine asynchrones pour un découplage maximal.
- **Inbox/Outbox Patterns**: Utilisés pour garantir une communication fiable et idempotente avec les systèmes externes (Kafka, Salesforce).
- **Publication d'Événements par l'Agrégat**: Les agrégats utilisent le pattern `@DomainEvents` de Spring Data pour être la source de vérité de leurs propres changements d'état, renforçant ainsi la pureté du modèle de domaine.

---

## Documentation Détaillée

Pour une description complète et détaillée de l'architecture, des diagrammes de séquence, des flux événementiels et des décisions de conception, veuillez consulter le document :

**[>> DDD_Remediation_Architecture.md <<](DDD_Remediation_Architecture.md)**
