# Architecture DDD pour la Remédiation des Données Client (Version 4)

Cette version intègre un module transverse pour l'audit, la traçabilité et la gestion centralisée des erreurs.

## 1. Bounded Contexts

Un contexte d'audit est ajouté. Il a la particularité d'écouter les événements de tous les autres contextes métier sans jamais les modifier.

```plantuml
@startuml
!theme plain
skinparam componentStyle uml2

[Kafka] <<External>> as K
[Salesforce] <<External>> as SF

node "Remediation Application" {
    component [TriggerContext] <<BC>> as Trigger
    component [BlockContext] <<BC>> as Block
    component [ReviewContext] <<BC>> as Review
    component [CustomerContext] <<BC>> as Customer
    component [IntegrationContext] <<BC>> as Integration
    component [AuditContext] <<BC>> as Audit
}

K -> Trigger
Integration -> SF

' Business contexts dependencies
Customer ..> Block
Trigger ..> Review
Review ..> Block
Block ..> Integration
Review ..> Integration

' Audit context listens to everyone
Block ..> Audit
Review ..> Audit
Customer ..> Audit
Trigger ..> Audit

@enduml
```

| Bounded Context | Responsabilités |
| :--- | :--- |
| **CustomerContext** | Gérer l'identité et les relations du client. |
| **BlockContext** | Gérer le portefeuille de blocs de données d'un client. |
| **TriggerContext** | Recevoir les déclencheurs via Kafka (Inbox). |
| **ReviewContext** | Orchestrer le processus de revue. |
| **IntegrationContext**| (ACL) Traduire les événements internes en appels API pour Salesforce. |
| **AuditContext** | **(Transverse)** Créer une piste d'audit immuable et centraliser le logging des erreurs via AOP. |

---

## 2. `AuditContext` : Traçabilité et Erreurs

Ce module est un observateur passif qui garantit la traçabilité complète de l'application.

### 2.1. Piste d'Audit via les Événements

Le contexte possède un écouteur d'événements qui souscrit à tous les événements métier importants.

```java
// Dans AuditContext
@Component
class AuditEventConsumer {

    private final AuditService auditService;

    // Exemple d'écouteur
    @ApplicationModuleListener
    void on(ReviewInstanceStartedEvent event) {
        auditService.logEvent("ReviewStarted", event.getReviewId(), event.getDetails());
    }

    @ApplicationModuleListener
    void on(BlockCompletedEvent event) {
        auditService.logEvent("BlockCompleted", event.getBlockId(), event.getDetails());
    }
    
    // ... autres écouteurs
}
```

L'entité `AuditTrail` stocke ces informations de manière persistante.

```plantuml
@startuml
entity AuditTrail {
  +UUID id
  +Instant timestamp
  +String eventType
  +String entityId
  +String userId
  +JsonNode details
  +Status status
  +String errorMessage
}
@enduml
```

### 2.2. Logging des Erreurs par AOP

Un Aspect intercepte toutes les exceptions non gérées dans les couches de service pour créer une entrée d'audit de type `FAILURE`.

```plantuml
@startuml

package "ReviewContext" {
  class ReviewService {
    +startReview()
  }
}

package "AuditContext" {
  aspect ErrorLoggingAspect {
    +logAfterThrowing(JoinPoint, Throwable)
  }
  class AuditService {
    +logError(...)
  }
}

ReviewService .. ErrorLoggingAspect : intercepté par
ErrorLoggingAspect ..> AuditService : délègue à

@enduml
```

*   **Définition de l'Aspect (AOP)** :

    ```java
    // Dans AuditContext
    @Aspect
    @Component
    public class ErrorLoggingAspect {

        private final AuditService auditService;

        @AfterThrowing(pointcut = "execution(* com.remediation..*Service.*(..))", throwing = "ex")
        public void logAfterThrowing(JoinPoint joinPoint, Throwable ex) {
            // Logique pour extraire les informations de la méthode interceptée
            auditService.logError(joinPoint.getSignature(), ex);
        }
    }
    ```

Cette approche centralise la gestion des erreurs et de l'audit, enlevant cette responsabilité aux modules métier.