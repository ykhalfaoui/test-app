package com.remediation.trigger.infrastructure.kafka;

package com.remediation.trigger.infrastructure.kafka;

import com.remediation.trigger.api.HitService;
import com.remediation.trigger.internal.InboxRepository;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class HitKafkaConsumer {

    private final HitService hitService;
    private final InboxRepository inboxRepository;

    public HitKafkaConsumer(HitService hitService, InboxRepository inboxRepository) {
        this.hitService = hitService;
        this.inboxRepository = inboxRepository;
    }

    // @KafkaListener(topics = "hits")
    public void consume(String payload, /* @Header(KafkaHeaders.MESSAGE_KEY) */ String eventId) {
        System.out.println("Received hit event from Kafka: " + payload);
        UUID id = UUID.fromString(eventId);

        // 1. Inbox Pattern: check for duplicates
        if (inboxRepository.exists(id)) {
            System.out.println("Duplicate event ignored: " + eventId);
            return;
        }

        // 2. Process the event via the application service
        hitService.processIncomingHit(payload);

        // 3. Mark as processed
        inboxRepository.save(id);
    }
}
