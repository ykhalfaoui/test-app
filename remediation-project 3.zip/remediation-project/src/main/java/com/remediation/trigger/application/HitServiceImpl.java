package com.remediation.trigger.application;

import com.remediation.trigger.api.HitService;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
class HitServiceImpl implements HitService {

    private final ApplicationEventPublisher events;

    HitServiceImpl(ApplicationEventPublisher events) {
        this.events = events;
    }

    @Override
    public void processIncomingHit(String payload) {
        // 1. Parse and validate payload (omitted for brevity)
        String customerId = "customer-123"; // Extracted from payload

        // 2. Qualify the hit
        boolean isPositive = qualify(payload);

        // 3. If positive, publish an event for other modules to consume
        if (isPositive) {
            var event = new HitQualifiedPositiveEvent(UUID.randomUUID(), customerId);
            events.publishEvent(event);
        }
    }

    private boolean qualify(String payload) {
        // Business logic to determine if a hit is positive
        // For this example, we'll assume it's always positive
        System.out.println("Qualifying hit: " + payload);
        return true;
    }
}
