@org.springframework.modulith.ApplicationModule(
    displayName = "Integration - Salesforce",
    allowedDependencies = {"block", "review"}
)
package com.remediation.integration.salesforce;