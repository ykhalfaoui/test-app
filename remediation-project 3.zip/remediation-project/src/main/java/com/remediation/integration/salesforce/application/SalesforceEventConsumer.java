package com.remediation.integration.salesforce.application;

import org.springframework.stereotype.Component;

@Component
public class SalesforceEventConsumer {

    // Listens to events from BlockContext and ReviewContext

    /*
    @ApplicationModuleListener
    void on(ReviewClosedEvent event) {
        // 1. Translate the internal domain event to a Salesforce DTO
        // 2. Call the SalesforceClient to upsert the data
    }
    */
}
