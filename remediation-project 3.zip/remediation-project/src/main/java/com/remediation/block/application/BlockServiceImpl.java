package com.remediation.block.application;

package com.remediation.block.application;

import com.remediation.block.api.Block;
import com.remediation.block.api.BlockService;
import com.remediation.block.domain.BlockRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
class BlockServiceImpl implements BlockService {

    private final BlockRepository repository;

    // The ApplicationEventPublisher is no longer needed here!
    BlockServiceImpl(BlockRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Block> getBlocksForCustomer(String customerId) {
        System.out.println("BlockContext searching for blocks for customer: " + customerId);
        List<Block> existingBlocks = repository.findByCustomerId(customerId);

        // If no blocks exist, create a new one as part of this process.
        // The Block's constructor now automatically registers a BlockCreatedEvent.
        if (existingBlocks.isEmpty()) {
            System.out.println("No blocks found, creating a new one.");
            Block newBlock = new Block(customerId);
            repository.save(newBlock); // Saving publishes the BlockCreatedEvent
            return List.of(newBlock);
        }
        return existingBlocks;
    }

    @Override
    public void startReviewOnBlock(UUID blockId, UUID reviewInstanceId) {
        System.out.println("BlockContext received command to start review on block: " + blockId);
        
        // 1. Load the aggregate
        Block block = repository.findById(blockId).orElseThrow(() -> new IllegalStateException("Block not found!"));

        // 2. Call the business method. The aggregate registers the event internally.
        block.startReview(reviewInstanceId);

        // 3. Save the aggregate. Spring Data will now publish the registered events automatically.
        repository.save(block);
    }
}
