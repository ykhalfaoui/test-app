package com.remediation.block.api.event;

import java.util.UUID;

// Published when a block review process has been initiated.
public record BlockReviewStartedEvent(
    UUID blockId,
    UUID reviewInstanceId
) {}
