package com.remediation.block.api;

import java.util.List;
import java.util.UUID;

public interface BlockService {
    List<Block> getBlocksForCustomer(String customerId);
    void startReviewOnBlock(UUID blockId, UUID reviewInstanceId);
}
