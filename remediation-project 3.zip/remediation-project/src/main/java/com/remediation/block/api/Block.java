package com.remediation.block.api;

package com.remediation.block.api;

import com.remediation.block.api.event.BlockCreatedEvent;
import com.remediation.block.api.event.BlockReviewStartedEvent;
import org.springframework.data.domain.AbstractAggregateRoot;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

// Aggregate Root for the Block Context, now extending AbstractAggregateRoot for event publication
public class Block extends AbstractAggregateRoot<Block> {

    private final UUID id;
    private final String customerId;
    private String status;
    private final Set<UUID> activeReviews = new HashSet<>();

    public Block(String customerId) {
        this.id = UUID.randomUUID();
        this.customerId = customerId;
        this.status = "UP_TO_DATE";

        // Register a domain event upon creation
        registerEvent(new BlockCreatedEvent(this.id, this.customerId));
    }

    public void startReview(UUID reviewInstanceId) {
        if (!"IN_REVIEW".equals(this.status)) {
            this.status = "IN_REVIEW";
        }
        this.activeReviews.add(reviewInstanceId);
        System.out.println("Block " + this.id + " is now IN_REVIEW for review " + reviewInstanceId);

        // Register a domain event for this state change
        registerEvent(new BlockReviewStartedEvent(this.id, reviewInstanceId));
    }

    public UUID getId() {
        return id;
    }

    public String getCustomerId() {
        return customerId;
    }
}
