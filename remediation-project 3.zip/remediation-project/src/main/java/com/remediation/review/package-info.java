@org.springframework.modulith.ApplicationModule(
    allowedDependencies = "block"
)
package com.remediation.review;