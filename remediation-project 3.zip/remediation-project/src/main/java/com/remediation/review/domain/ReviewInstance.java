package com.remediation.review.domain;

import java.util.UUID;

// Aggregate Root for the Review Context
public class ReviewInstance {

    private final UUID id;
    private final String customerId;
    private String status;

    public ReviewInstance(String customerId, String triggerType) {
        this.id = UUID.randomUUID();
        this.customerId = customerId;
        this.status = "STARTED";
        System.out.println("ReviewInstance " + this.id + " created for customer " + customerId);
    }

    public UUID getId() {
        return id;
    }
}
