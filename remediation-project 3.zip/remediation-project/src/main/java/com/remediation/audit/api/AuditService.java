package com.remediation.audit.api;

public interface AuditService {
    void logEvent(String eventType, String entityId, Object details);
    void logError(Object methodSignature, Throwable error);
}
