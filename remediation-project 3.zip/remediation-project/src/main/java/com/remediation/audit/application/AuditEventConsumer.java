package com.remediation.audit.application;

import com.remediation.audit.api.AuditService;
import com.remediation.block.api.event.BlockReviewStartedEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

@Component
class AuditEventConsumer {

    private final AuditService auditService;

    AuditEventConsumer(AuditService auditService) {
        this.auditService = auditService;
    }

    @ApplicationModuleListener
    void on(HitQualifiedPositiveEvent event) {
        auditService.logEvent("HitQualifiedPositive", event.hitId().toString(), event);
    }

    @ApplicationModuleListener
    void on(ReviewInstanceStartedEvent event) {
        auditService.logEvent("ReviewInstanceStarted", event.reviewInstanceId().toString(), event);
    }

    @ApplicationModuleListener
    void on(BlockReviewStartedEvent event) {
        auditService.logEvent("BlockReviewStarted", event.blockId().toString(), event);
    }
}