package com.remediation.integration.salesforce;

import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for SalesforceSyncSaga state machine.
 */
class SalesforceSyncSagaTest {

    @Test
    void shouldInitializeInNotStartedState() {
        // Given/When
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());

        // Then
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.NOT_STARTED);
        assertThat(saga.getSalesforceReviewId()).isNull();
    }

    @Test
    void shouldTransitionThroughReviewCreation() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());

        // When
        saga.reviewCreationStarted();
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.CREATING_REVIEW);

        saga.reviewCreated("SF-12345");

        // Then
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS);
        assertThat(saga.getSalesforceReviewId()).isEqualTo("SF-12345");
    }

    @Test
    void shouldEnqueueMembersWithoutDuplicates() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");

        // When
        saga.enqueueMember("MEMBER-001");
        saga.enqueueMember("MEMBER-002");
        saga.enqueueMember("MEMBER-001"); // Duplicate

        // Then
        assertThat(saga.getPendingMemberIds()).hasSize(2);
    }

    @Test
    void shouldCreateMemberBatches() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");

        saga.enqueueMember("MEMBER-001");
        saga.enqueueMember("MEMBER-002");
        saga.enqueueMember("MEMBER-003");

        // When
        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextMemberBatch(2);

        // Then
        assertThat(batch).isPresent();
        assertThat(batch.get().items()).hasSize(2);
        assertThat(batch.get().batchNumber()).isEqualTo(1);
        assertThat(saga.getPendingMemberIds()).hasSize(1); // One remaining
    }

    @Test
    void shouldTrackBatchCompletion() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");
        saga.enqueueMember("MEMBER-001");
        saga.enqueueMember("MEMBER-002");

        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextMemberBatch(2);
        int batchNumber = batch.get().batchNumber();

        // When
        saga.markMemberBatchCompleted(batchNumber);

        // Then
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS);
    }

    @Test
    void shouldTransitionToBlocksWhenBlocksPending() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");

        saga.enqueueMember("MEMBER-001");
        saga.enqueueBlock("BLOCK-001"); // Block already pending

        Optional<SalesforceSyncSaga.BatchProgress> memberBatch = saga.nextMemberBatch(10);
        saga.markMemberBatchCompleted(memberBatch.get().batchNumber());

        // Then - should transition to SYNCING_BLOCKS
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.SYNCING_BLOCKS);
    }

    @Test
    void shouldHandleBatchFailureAndRequeue() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");
        saga.enqueueMember("MEMBER-001");
        saga.enqueueMember("MEMBER-002");

        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextMemberBatch(2);
        List<String> batchItems = batch.get().items();

        // When
        saga.markMemberBatchFailed(batch.get().batchNumber(), batchItems, "Test error");

        // Then
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.FAILED);
        assertThat(saga.isFailed()).isTrue();
        assertThat(saga.getPendingMemberIds()).hasSize(2); // Items re-queued
    }

    @Test
    void shouldRetryFromFailedState() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");
        saga.enqueueMember("MEMBER-001");

        Optional<SalesforceSyncSaga.BatchProgress> batch = saga.nextMemberBatch(1);
        saga.markMemberBatchFailed(batch.get().batchNumber(), batch.get().items(), "Test");

        // When
        saga.retry();

        // Then
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS);
        assertThat(saga.getRetryCount()).isEqualTo(1);
    }

    @Test
    void shouldHandleLateArrivingMembers() {
        // Given - saga already syncing blocks
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");
        saga.enqueueMember("MEMBER-001");

        Optional<SalesforceSyncSaga.BatchProgress> batch1 = saga.nextMemberBatch(10);
        saga.markMemberBatchCompleted(batch1.get().batchNumber());
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS);

        // When - late member arrives
        saga.enqueueMember("LATE-MEMBER");

        // Then - should return to SYNCING_MEMBERS
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS);
    }

    @Test
    void shouldCompleteFullLifecycle() {
        // Given
        SalesforceSyncSaga saga = new SalesforceSyncSaga(ReviewId.create(), TraceId.create());

        // 1. Create review
        saga.reviewCreationStarted();
        saga.reviewCreated("SF-12345");

        // 2. Sync members
        saga.enqueueMember("MEMBER-001");
        Optional<SalesforceSyncSaga.BatchProgress> memberBatch = saga.nextMemberBatch(10);
        saga.markMemberBatchCompleted(memberBatch.get().batchNumber());

        // 3. Sync blocks
        saga.enqueueBlock("BLOCK-001");
        Optional<SalesforceSyncSaga.BatchProgress> blockBatch = saga.nextBlockBatch(10);
        saga.markBlockBatchCompleted(blockBatch.get().batchNumber());

        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS);

        // 4. Complete
        saga.complete();

        // Then
        assertThat(saga.getStatus()).isEqualTo(SalesforceSyncSaga.SyncStatus.COMPLETED);
        assertThat(saga.isCompleted()).isTrue();
    }
}
