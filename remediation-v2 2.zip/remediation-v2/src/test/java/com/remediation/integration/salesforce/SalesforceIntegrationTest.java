package com.remediation.integration.salesforce;

import com.remediation.TestBase;
import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.integration.salesforce.domain.SalesforceSyncSagaRepository;
import com.remediation.review.api.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import java.util.concurrent.TimeUnit;

/**
 * Integration tests for Salesforce synchronization.
 */
class SalesforceIntegrationTest extends TestBase {

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Autowired
    private SalesforceSyncSagaRepository sagaRepository;

    @Test
    void shouldCreateSalesforceSagaOnReviewStart() {
        // Given
        ReviewInstanceStartedEvent event = new ReviewInstanceStartedEvent(
            TraceId.create(),
            ReviewId.create(),
            CustomerId.of("CUST-001"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - Salesforce saga should be created
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> {
            var sagas = sagaRepository.findByReviewId(event.reviewId());
            assertThat(sagas).isPresent();
            assertThat(sagas.get().getStatus())
                .isIn(SalesforceSyncSaga.SyncStatus.CREATING_REVIEW,
                      SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS);
        });
    }

    @Test
    void shouldCreateSalesforceReview() {
        // Given
        ReviewInstanceStartedEvent event = new ReviewInstanceStartedEvent(
            TraceId.create(),
            ReviewId.create(),
            CustomerId.of("CUST-002"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Then - Salesforce review should be created
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            var saga = sagaRepository.findByReviewId(event.reviewId()).orElseThrow();
            assertThat(saga.getSalesforceReviewId()).isNotNull();
            assertThat(saga.getSalesforceReviewId()).startsWith("SF-");
        });
    }

    @Test
    void shouldSyncMembersInBatches() throws InterruptedException {
        // Given
        ReviewInstanceStartedEvent event = new ReviewInstanceStartedEvent(
            TraceId.create(),
            ReviewId.create(),
            CustomerId.of("CUST-003"),
            "SANCTIONS"
        );

        // When
        eventPublisher.publishEvent(event);

        // Wait for members to be enqueued
        Thread.sleep(2000);

        // Then - saga should have processed member batches
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() -> {
            var saga = sagaRepository.findByReviewId(event.reviewId()).orElseThrow();

            // Should have progressed from SYNCING_MEMBERS
            assertThat(saga.getStatus())
                .isIn(SalesforceSyncSaga.SyncStatus.SYNCING_MEMBERS,
                      SalesforceSyncSaga.SyncStatus.SYNCING_BLOCKS,
                      SalesforceSyncSaga.SyncStatus.FINALIZING_STATUS,
                      SalesforceSyncSaga.SyncStatus.COMPLETED);
        });
    }
}
