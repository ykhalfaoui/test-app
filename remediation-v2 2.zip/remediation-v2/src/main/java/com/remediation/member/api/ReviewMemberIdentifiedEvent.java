package com.remediation.member.api;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;

/**
 * Domain event published when a review member (family relation) is identified.
 * Each member requires blocks to be provisioned.
 *
 * @param traceId Distributed trace identifier
 * @param reviewId The review this member belongs to
 * @param customerId The customer ID of the member (could be principal or relation)
 * @param memberType Type of member (e.g., "PRINCIPAL", "SPOUSE", "DEPENDENT", "BENEFICIARY")
 */
public record ReviewMemberIdentifiedEvent(
    TraceId traceId,
    ReviewId reviewId,
    CustomerId customerId,
    String memberType
) {
    public ReviewMemberIdentifiedEvent {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (reviewId == null) throw new IllegalArgumentException("reviewId cannot be null");
        if (customerId == null) throw new IllegalArgumentException("customerId cannot be null");
        if (memberType == null || memberType.isBlank()) {
            throw new IllegalArgumentException("memberType cannot be null or empty");
        }
    }
}
