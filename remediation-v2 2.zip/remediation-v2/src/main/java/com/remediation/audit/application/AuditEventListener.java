package com.remediation.audit.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.remediation.audit.domain.AuditTrail;
import com.remediation.audit.domain.AuditTrailRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;

/**
 * Listens to ALL domain events and creates audit trail entries.
 * This provides a complete audit log of all activities in the system.
 *
 * Uses REQUIRES_NEW propagation to ensure audit entries are saved
 * even if the original transaction rolls back.
 */
@Component
@Slf4j
public class AuditEventListener {

    private final AuditTrailRepository auditRepository;
    private final ObjectMapper objectMapper;

    public AuditEventListener(
        AuditTrailRepository auditRepository,
        ObjectMapper objectMapper
    ) {
        this.auditRepository = auditRepository;
        this.objectMapper = objectMapper;
    }

    /**
     * Listens to all domain events and creates audit entries.
     * Extracts traceId from event if available.
     */
    @ApplicationModuleListener
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void onDomainEvent(Object event) {
        if (event == null || !isDomainEvent(event)) {
            return;
        }

        try {
            String traceId = extractTraceId(event);
            String entityId = extractEntityId(event);
            String eventType = event.getClass().getSimpleName();
            String details = serializeEvent(event);

            AuditTrail auditEntry = AuditTrail.event(traceId, eventType, entityId, details);
            auditRepository.save(auditEntry);

            log.debug("Audit trail created for event: {} [traceId: {}, entityId: {}]",
                eventType, traceId, entityId);

        } catch (Exception e) {
            // Never fail the business transaction due to audit logging
            log.error("Failed to create audit trail for event {}: {}",
                event.getClass().getName(), e.getMessage(), e);
        }
    }

    /**
     * Checks if the event is a domain event from our system.
     */
    private boolean isDomainEvent(Object event) {
        String packageName = event.getClass().getPackageName();
        return packageName != null &&
            packageName.startsWith("com.remediation") &&
            !event.getClass().getName().contains(".audit.");
    }

    /**
     * Extracts traceId from event using reflection.
     * Many events have a traceId() method (records).
     */
    private String extractTraceId(Object event) {
        try {
            Method traceIdMethod = event.getClass().getMethod("traceId");
            Object traceIdObj = traceIdMethod.invoke(event);
            if (traceIdObj != null) {
                Method valueMethod = traceIdObj.getClass().getMethod("value");
                return (String) valueMethod.invoke(traceIdObj);
            }
        } catch (Exception e) {
            // TraceId not available, that's okay
        }
        return null;
    }

    /**
     * Extracts entity ID from common ID fields in events.
     */
    private String extractEntityId(Object event) {
        try {
            // Try common ID method names
            for (String methodName : new String[]{"reviewId", "blockId", "hitId", "customerId"}) {
                try {
                    Method idMethod = event.getClass().getMethod(methodName);
                    Object idObj = idMethod.invoke(event);
                    if (idObj != null) {
                        Method valueMethod = idObj.getClass().getMethod("value");
                        Object value = valueMethod.invoke(idObj);
                        return value != null ? value.toString() : null;
                    }
                } catch (NoSuchMethodException ignored) {
                    // Try next method name
                }
            }
        } catch (Exception e) {
            // Entity ID not available
        }
        return null;
    }

    /**
     * Serializes event to JSON for audit details.
     */
    private String serializeEvent(Object event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            return "Failed to serialize: " + e.getMessage();
        }
    }
}
