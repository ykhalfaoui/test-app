package com.remediation.audit.domain;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Audit Trail entity that records all significant events and errors in the system.
 * Provides immutable audit log for compliance and debugging.
 */
@Entity
@Table(name = "audit_trail", indexes = {
    @Index(name = "idx_audit_trace_id", columnList = "trace_id"),
    @Index(name = "idx_audit_event_type", columnList = "event_type"),
    @Index(name = "idx_audit_entity_id", columnList = "entity_id"),
    @Index(name = "idx_audit_timestamp", columnList = "timestamp")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class AuditTrail {

    public enum AuditType {
        EVENT,      // Domain event occurred
        ERROR,      // Error occurred
        COMMAND     // Command executed
    }

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Column(name = "trace_id", length = 100)
    private String traceId;

    @Enumerated(EnumType.STRING)
    @Column(name = "audit_type", nullable = false, length = 20)
    private AuditType auditType;

    @Column(name = "event_type", nullable = false, length = 500)
    private String eventType;

    @Column(name = "entity_id", length = 100)
    private String entityId;

    @Lob
    @Column(name = "details")
    private String details;

    @Column(name = "error_message", length = 2000)
    private String errorMessage;

    @Column(name = "timestamp", nullable = false, updatable = false)
    private Instant timestamp;

    private AuditTrail(
        String traceId,
        AuditType auditType,
        String eventType,
        String entityId,
        String details,
        String errorMessage
    ) {
        this.id = UUID.randomUUID();
        this.traceId = traceId;
        this.auditType = auditType;
        this.eventType = eventType;
        this.entityId = entityId;
        this.details = details;
        this.errorMessage = errorMessage != null && errorMessage.length() > 2000
            ? errorMessage.substring(0, 2000)
            : errorMessage;
        this.timestamp = Instant.now();
    }

    public static AuditTrail event(String traceId, String eventType, String entityId, String details) {
        return new AuditTrail(traceId, AuditType.EVENT, eventType, entityId, details, null);
    }

    public static AuditTrail error(String traceId, String errorSource, String details, String errorMessage) {
        return new AuditTrail(traceId, AuditType.ERROR, errorSource, null, details, errorMessage);
    }

    public static AuditTrail command(String traceId, String commandType, String entityId, String details) {
        return new AuditTrail(traceId, AuditType.COMMAND, commandType, entityId, details, null);
    }
}
