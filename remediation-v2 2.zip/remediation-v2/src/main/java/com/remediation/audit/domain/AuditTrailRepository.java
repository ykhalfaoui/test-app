package com.remediation.audit.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Repository for AuditTrail entities.
 */
@Repository
public interface AuditTrailRepository extends JpaRepository<AuditTrail, UUID> {

    /**
     * Find all audit entries for a given trace ID.
     */
    List<AuditTrail> findByTraceIdOrderByTimestampAsc(String traceId);

    /**
     * Find all audit entries for a given event type.
     */
    List<AuditTrail> findByEventTypeOrderByTimestampDesc(String eventType);

    /**
     * Find all errors in the system.
     */
    List<AuditTrail> findByAuditTypeOrderByTimestampDesc(AuditTrail.AuditType auditType);
}
