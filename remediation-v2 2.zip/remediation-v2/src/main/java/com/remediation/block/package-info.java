/**
 * Block context manages data blocks for customers under review.
 * Responsible for:
 * - Creating or finding blocks for review members
 * - Publishing events when blocks are ready for review
 * - Managing block lifecycle (UP_TO_DATE, IN_REVIEW)
 *
 * Dependencies: sharedkernel, member
 */
@org.springframework.modulith.ApplicationModule(
    displayName = "Block Context",
    allowedDependencies = {"sharedkernel", "member"}
)
package com.remediation.block;
