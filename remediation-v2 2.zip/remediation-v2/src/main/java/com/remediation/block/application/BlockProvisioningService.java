package com.remediation.block.application;

import com.remediation.block.api.BlockReadyForReviewEvent;
import com.remediation.block.domain.Block;
import com.remediation.block.domain.BlockRepository;
import com.remediation.member.api.ReviewMemberIdentifiedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service responsible for provisioning blocks for review members.
 * Listens to ReviewMemberIdentifiedEvent and ensures blocks exist for each member.
 *
 * Key behavior:
 * - Reuses existing blocks if available
 * - Creates new blocks if none exist
 * - Publishes BlockReadyForReviewEvent for saga tracking
 */
@Service
@Slf4j
public class BlockProvisioningService {

    private final BlockRepository blockRepository;
    private final ApplicationEventPublisher eventPublisher;

    public BlockProvisioningService(
        BlockRepository blockRepository,
        ApplicationEventPublisher eventPublisher
    ) {
        this.blockRepository = blockRepository;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Provisions blocks when a review member is identified.
     * Finds or creates blocks for the member's customer ID.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(ReviewMemberIdentifiedEvent event) {
        log.info("Provisioning block for review member [customerId: {}, reviewId: {}, memberType: {}, TraceId: {}]",
            event.customerId().value(), event.reviewId().value(),
            event.memberType(), event.traceId().value());

        // Find or create block for this customer
        Block block = findOrCreateBlock(event.customerId());

        // Start review on the block
        block.startReview(event.reviewId());
        blockRepository.save(block);

        log.info("Block {} ready for review {} [customerId: {}, TraceId: {}]",
            block.getId().value(), event.reviewId().value(),
            event.customerId().value(), event.traceId().value());

        // Publish event to notify saga
        BlockReadyForReviewEvent readyEvent = new BlockReadyForReviewEvent(
            event.traceId(),
            block.getId(),
            event.reviewId()
        );

        eventPublisher.publishEvent(readyEvent);

        log.debug("Published BlockReadyForReviewEvent for block {} [TraceId: {}]",
            block.getId().value(), event.traceId().value());
    }

    /**
     * Finds an existing block for the customer, or creates a new one if none exists.
     * Implements idempotency - multiple calls for same customer return same block.
     */
    private Block findOrCreateBlock(com.remediation.sharedkernel.CustomerId customerId) {
        return blockRepository.findFirstByCustomerId(customerId)
            .orElseGet(() -> {
                log.info("Creating new block for customer {}", customerId.value());
                Block newBlock = new Block(customerId);
                return blockRepository.save(newBlock);
            });
    }
}
