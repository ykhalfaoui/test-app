package com.remediation.sharedkernel.inbox;

import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * InboxProcessor - Async processing of inbox entries (Slow Path).
 *
 * Responsibilities:
 * 1. Poll inbox for RECEIVED entries (@Scheduled)
 * 2. Process each entry via HitService
 * 3. Mark as PROCESSED or FAILED
 * 4. Handle retries for failed entries
 *
 * This separates message consumption (fast) from business logic processing (slow).
 *
 * Configuration:
 * - inbox.processor.fixed-delay: Delay between processing runs (default: 1000ms)
 * - inbox.processor.initial-delay: Initial delay before first run (default: 2000ms)
 * - inbox.processor.batch-size: Max entries to process per run (default: 100)
 */
@Component
@Slf4j
public class InboxProcessor {

    private final InboxRepository inboxRepository;
    private final HitService hitService;
    private final int batchSize;

    public InboxProcessor(
        InboxRepository inboxRepository,
        HitService hitService
    ) {
        this.inboxRepository = inboxRepository;
        this.hitService = hitService;
        this.batchSize = 100; // Could be configurable via @Value
    }

    /**
     * Process pending inbox entries asynchronously.
     * Runs periodically to decouple consumption from processing.
     */
    @Scheduled(
        fixedDelayString = "${inbox.processor.fixed-delay:1000}",
        initialDelayString = "${inbox.processor.initial-delay:2000}",
        timeUnit = TimeUnit.MILLISECONDS
    )
    public void processPendingEntries() {
        // Fetch batch of RECEIVED entries
        Pageable pageable = PageRequest.of(0, batchSize);
        List<InboxEntry> entries = inboxRepository.findByStatusOrderByReceivedAtAsc(
            InboxEntry.Status.RECEIVED,
            pageable
        );

        if (entries.isEmpty()) {
            return;
        }

        log.debug("Processing {} inbox entries", entries.size());

        int successCount = 0;
        int failureCount = 0;

        for (InboxEntry entry : entries) {
            try {
                processEntry(entry);
                successCount++;
            } catch (Exception ex) {
                log.error("Failed to process inbox entry [eventId: {}]: {}",
                    entry.getEventId(), ex.getMessage(), ex);
                failureCount++;
            }
        }

        if (successCount > 0 || failureCount > 0) {
            log.info("Inbox processing complete: {} successful, {} failed",
                successCount, failureCount);
        }
    }

    /**
     * Process a single inbox entry.
     * Each entry is processed in its own transaction for isolation.
     */
    @Transactional
    protected void processEntry(InboxEntry entry) {
        // Extract traceId for distributed tracing
        TraceId traceId = StringUtils.hasText(entry.getTraceId())
            ? TraceId.of(entry.getTraceId())
            : TraceId.create();

        log.info("Processing inbox entry [eventId: {}, TraceId: {}]",
            entry.getEventId(), traceId.value());

        try {
            // Process the hit (business logic)
            hitService.processIncomingHit(traceId, entry.getPayload());

            // Mark as successfully processed
            entry.markProcessed();
            inboxRepository.save(entry);

            log.info("Inbox entry processed successfully [eventId: {}, TraceId: {}]",
                entry.getEventId(), traceId.value());

        } catch (Exception ex) {
            // Mark as failed with error message
            log.error("Inbox entry processing failed [eventId: {}, TraceId: {}]: {}",
                entry.getEventId(), traceId.value(), ex.getMessage(), ex);

            entry.markFailed(ex.getMessage());
            inboxRepository.save(entry);

            // Re-throw to rollback transaction and trigger retry later
            throw ex;
        }
    }
}
