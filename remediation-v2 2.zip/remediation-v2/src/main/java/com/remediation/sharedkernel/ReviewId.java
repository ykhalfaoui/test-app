package com.remediation.sharedkernel;

import java.util.UUID;

/**
 * Value object representing a unique review identifier.
 */
public record ReviewId(UUID value) {

    public ReviewId {
        if (value == null) {
            throw new IllegalArgumentException("ReviewId cannot be null");
        }
    }

    public static ReviewId create() {
        return new ReviewId(UUID.randomUUID());
    }

    public static ReviewId of(UUID value) {
        return new ReviewId(value);
    }
}
