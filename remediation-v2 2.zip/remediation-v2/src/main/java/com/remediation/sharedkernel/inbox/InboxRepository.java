package com.remediation.sharedkernel.inbox;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Repository for managing inbox entries.
 */
@Repository
public interface InboxRepository extends JpaRepository<InboxEntry, UUID> {

    /**
     * Check if a message with the given event ID has already been received.
     * Used for idempotency checks.
     */
    boolean existsByEventId(UUID eventId);

    /**
     * Find inbox entries by status, ordered by receivedAt (oldest first).
     * Used by InboxProcessor to fetch entries for async processing.
     *
     * @param status The status to filter by (typically RECEIVED)
     * @param pageable Pagination info (limit batch size)
     * @return List of inbox entries matching the status
     */
    List<InboxEntry> findByStatusOrderByReceivedAtAsc(InboxEntry.Status status, Pageable pageable);
}
