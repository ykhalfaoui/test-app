package com.remediation.sharedkernel;

import java.util.UUID;

/**
 * Value object representing a unique block identifier.
 */
public record BlockId(UUID value) {

    public BlockId {
        if (value == null) {
            throw new IllegalArgumentException("BlockId cannot be null");
        }
    }

    public static BlockId create() {
        return new BlockId(UUID.randomUUID());
    }

    public static BlockId of(UUID value) {
        return new BlockId(value);
    }
}
