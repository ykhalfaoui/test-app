package com.remediation.sharedkernel.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Periodically forwards pending outbox entries as Spring application events.
 * Uses a scheduled task to poll the outbox table and republish events.
 *
 * Configuration:
 * - outbox.forwarder.fixed-delay: Delay between forwarding runs (default 5000ms)
 * - outbox.forwarder.initial-delay: Initial delay before first run (default 2000ms)
 */
@Component
@Slf4j
public class OutboxForwarder {

    private final OutboxRepository repository;
    private final ObjectMapper objectMapper;
    private final ApplicationEventPublisher eventPublisher;

    public OutboxForwarder(OutboxRepository repository,
                          ObjectMapper objectMapper,
                          ApplicationEventPublisher eventPublisher) {
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Forwards pending outbox entries to the event bus.
     * Processes up to 100 entries per run.
     */
    @Scheduled(
        fixedDelayString = "${outbox.forwarder.fixed-delay:5000}",
        initialDelayString = "${outbox.forwarder.initial-delay:2000}",
        timeUnit = TimeUnit.MILLISECONDS
    )
    @Transactional
    public void forwardPending() {
        List<OutboxEntry> entries = repository.findTop100ByStatusOrderByCreatedAtAsc(
            OutboxEntry.Status.PENDING
        );

        if (entries.isEmpty()) {
            return;
        }

        log.debug("Forwarding {} pending outbox entries", entries.size());

        int successCount = 0;
        int failureCount = 0;

        for (OutboxEntry entry : entries) {
            try {
                // Deserialize the event
                Object event = deserialize(entry);

                // Publish within forwarding context to prevent re-capture
                OutboxForwardingContext.runForwarding(() -> eventPublisher.publishEvent(event));

                // Mark as sent
                entry.markSent();
                successCount++;

                log.trace("Forwarded outbox entry: {} [id={}]",
                    entry.getEventType(), entry.getId());

            } catch (Exception ex) {
                log.error("Failed to forward outbox entry {} [type={}]: {}",
                    entry.getId(), entry.getEventType(), ex.getMessage(), ex);
                entry.markFailed(ex.getMessage());
                failureCount++;
            }

            repository.save(entry);
        }

        if (successCount > 0 || failureCount > 0) {
            log.info("Outbox forwarding complete: {} successful, {} failed",
                successCount, failureCount);
        }
    }

    /**
     * Deserializes an outbox entry back to its original event object.
     */
    private Object deserialize(OutboxEntry entry) throws Exception {
        Class<?> eventClass = Class.forName(entry.getEventType());
        return objectMapper.readValue(entry.getPayload(), eventClass);
    }
}
