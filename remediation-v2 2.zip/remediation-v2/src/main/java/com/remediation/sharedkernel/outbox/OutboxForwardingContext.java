package com.remediation.sharedkernel.outbox;

/**
 * ThreadLocal context to prevent infinite loops when forwarding outbox events.
 * When the forwarder publishes events, we mark the thread as "forwarding" to prevent
 * those events from being captured back into the outbox.
 */
public final class OutboxForwardingContext {

    private static final ThreadLocal<Boolean> FORWARDING = ThreadLocal.withInitial(() -> Boolean.FALSE);

    private OutboxForwardingContext() {
        // Utility class
    }

    /**
     * Check if current thread is forwarding outbox events.
     */
    public static boolean isForwarding() {
        return Boolean.TRUE.equals(FORWARDING.get());
    }

    /**
     * Execute a runnable in forwarding context.
     * Ensures the flag is cleaned up even if exceptions occur.
     */
    public static void runForwarding(Runnable action) {
        FORWARDING.set(Boolean.TRUE);
        try {
            action.run();
        } finally {
            FORWARDING.remove();
        }
    }
}
