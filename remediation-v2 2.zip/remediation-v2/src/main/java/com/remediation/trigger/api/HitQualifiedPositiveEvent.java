package com.remediation.trigger.api;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.HitId;
import com.remediation.sharedkernel.TraceId;

/**
 * Domain event published when a hit is qualified as positive.
 * Indicates that remediation process should be initiated for the customer.
 *
 * @param traceId Distributed trace identifier
 * @param hitId Unique identifier for the hit
 * @param customerId Customer associated with the hit
 * @param hitType Type of hit (e.g., "SANCTIONS", "PEP", "ADVERSE_MEDIA")
 */
public record HitQualifiedPositiveEvent(
    TraceId traceId,
    HitId hitId,
    CustomerId customerId,
    String hitType
) {
    public HitQualifiedPositiveEvent {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (hitId == null) throw new IllegalArgumentException("hitId cannot be null");
        if (customerId == null) throw new IllegalArgumentException("customerId cannot be null");
        if (hitType == null || hitType.isBlank()) {
            throw new IllegalArgumentException("hitType cannot be null or empty");
        }
    }
}
