package com.remediation.trigger.api;

import com.remediation.sharedkernel.TraceId;

/**
 * Public API for the Trigger context.
 * Provides operations for processing incoming hits.
 */
public interface HitService {

    /**
     * Processes an incoming hit event.
     *
     * @param traceId Distributed trace identifier
     * @param payload Hit payload from external source
     */
    void processIncomingHit(TraceId traceId, String payload);
}
