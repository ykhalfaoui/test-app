package com.remediation.integration.salesforce.api;

import com.remediation.sharedkernel.ReviewId;

import java.util.List;

/**
 * Anti-Corruption Layer interface for Salesforce API.
 * Isolates our domain model from Salesforce's data model.
 *
 * Production implementation would use Salesforce REST API or Bulk API.
 */
public interface SalesforceClient {

    /**
     * Creates a review draft in Salesforce with DRAFT status.
     *
     * @param reviewId Internal review ID
     * @param triggerType Type of trigger (e.g., "HIT", "PERIODIC_REVIEW")
     * @return Salesforce review ID
     * @throws SalesforceException if creation fails
     */
    String createReviewDraft(ReviewId reviewId, String triggerType);

    /**
     * Bulk upserts members to a Salesforce review.
     *
     * @param salesforceReviewId Salesforce review ID
     * @param memberIds List of member customer IDs
     * @throws SalesforceException if upsert fails
     */
    void bulkUpsertMembers(String salesforceReviewId, List<String> memberIds);

    /**
     * Bulk upserts blocks to a Salesforce review.
     *
     * @param salesforceReviewId Salesforce review ID
     * @param blockIds List of block IDs
     * @throws SalesforceException if upsert fails
     */
    void bulkUpsertBlocks(String salesforceReviewId, List<String> blockIds);

    /**
     * Updates the status of a review in Salesforce.
     *
     * @param salesforceReviewId Salesforce review ID
     * @param status New status (e.g., "ONGOING", "COMPLETED")
     * @throws SalesforceException if update fails
     */
    void updateReviewStatus(String salesforceReviewId, String status);

    /**
     * Exception thrown when Salesforce operations fail.
     */
    class SalesforceException extends RuntimeException {
        public SalesforceException(String message) {
            super(message);
        }

        public SalesforceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
