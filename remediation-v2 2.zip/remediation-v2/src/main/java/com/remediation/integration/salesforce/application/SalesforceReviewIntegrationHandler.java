package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.api.SalesforceClient;
import com.remediation.integration.salesforce.api.event.SalesforceReviewCreated;
import com.remediation.integration.salesforce.api.event.SalesforceReviewDraftRequested;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Handles Salesforce review creation requests.
 * Calls Salesforce API and publishes response events.
 */
@Component
@Slf4j
public class SalesforceReviewIntegrationHandler {

    private final SalesforceClient salesforceClient;
    private final ApplicationEventPublisher eventPublisher;

    public SalesforceReviewIntegrationHandler(
        SalesforceClient salesforceClient,
        ApplicationEventPublisher eventPublisher
    ) {
        this.salesforceClient = salesforceClient;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Handles request to create Salesforce review draft.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(SalesforceReviewDraftRequested event) {
        log.info("Creating Salesforce review draft for review {} [TraceId: {}]",
            event.reviewId().value(), event.traceId().value());

        try {
            // Call Salesforce API
            String salesforceReviewId = salesforceClient.createReviewDraft(
                event.reviewId(),
                event.triggerType()
            );

            // Publish success event
            SalesforceReviewCreated responseEvent = new SalesforceReviewCreated(
                event.traceId(),
                event.reviewId(),
                true,
                salesforceReviewId,
                null
            );
            eventPublisher.publishEvent(responseEvent);

            log.info("Salesforce review created successfully: {} [TraceId: {}]",
                salesforceReviewId, event.traceId().value());

        } catch (Exception ex) {
            log.error("Failed to create Salesforce review for {} [TraceId: {}]: {}",
                event.reviewId().value(), event.traceId().value(), ex.getMessage(), ex);

            // Publish failure event
            SalesforceReviewCreated responseEvent = new SalesforceReviewCreated(
                event.traceId(),
                event.reviewId(),
                false,
                null,
                ex.getMessage()
            );
            eventPublisher.publishEvent(responseEvent);
        }
    }
}
