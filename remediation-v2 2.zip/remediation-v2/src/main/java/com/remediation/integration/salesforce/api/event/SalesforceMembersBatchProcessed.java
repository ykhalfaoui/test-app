package com.remediation.integration.salesforce.api.event;

import com.remediation.sharedkernel.TraceId;

import java.util.List;
import java.util.UUID;

/**
 * Response event when a members batch has been processed.
 */
public record SalesforceMembersBatchProcessed(
    TraceId traceId,
    UUID sagaId,
    int batchNumber,
    List<String> memberIds,
    boolean success,
    String failureMessage
) {
    public SalesforceMembersBatchProcessed {
        if (traceId == null) throw new IllegalArgumentException("traceId cannot be null");
        if (sagaId == null) throw new IllegalArgumentException("sagaId cannot be null");
        if (memberIds == null) throw new IllegalArgumentException("memberIds cannot be null");
        memberIds = List.copyOf(memberIds); // Immutable
    }
}
