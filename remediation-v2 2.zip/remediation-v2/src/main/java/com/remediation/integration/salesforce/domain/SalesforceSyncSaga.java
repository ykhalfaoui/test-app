package com.remediation.integration.salesforce.domain;

import com.remediation.sharedkernel.ReviewId;
import com.remediation.sharedkernel.TraceId;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.*;

/**
 * Salesforce Sync Saga orchestrates the multi-step Salesforce synchronization process.
 *
 * Flow:
 * 1. NOT_STARTED → CREATING_REVIEW (create SF review with DRAFT status)
 * 2. CREATING_REVIEW → SYNCING_MEMBERS (batch members in groups of 100)
 * 3. SYNCING_MEMBERS → SYNCING_BLOCKS (batch blocks in groups of 100)
 * 4. SYNCING_BLOCKS → FINALIZING_STATUS (update SF review to ONGOING)
 * 5. FINALIZING_STATUS → COMPLETED
 *
 * Implements:
 * - Batch management with configurable batch size
 * - Retry logic for transient failures
 * - Idempotent batch processing
 */
@Entity
@Table(name = "salesforce_sync_saga", indexes = {
    @Index(name = "idx_sf_saga_review_id", columnList = "review_id"),
    @Index(name = "idx_sf_saga_status", columnList = "status")
})
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Slf4j
public class SalesforceSyncSaga {

    public enum SyncStatus {
        NOT_STARTED,        // Saga created but not yet started
        CREATING_REVIEW,    // Creating review in Salesforce
        SYNCING_MEMBERS,    // Syncing members in batches
        SYNCING_BLOCKS,     // Syncing blocks in batches
        FINALIZING_STATUS,  // Updating review status to ONGOING
        COMPLETED,          // All sync complete
        FAILED              // Sync failed (can be retried)
    }

    public enum BatchStatus {
        PENDING,    // Batch waiting to be processed
        IN_FLIGHT,  // Batch currently being processed
        COMPLETED,  // Batch successfully processed
        FAILED      // Batch failed (will be retried)
    }

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "review_id", nullable = false))
    private ReviewId reviewId;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "trace_id", nullable = false, length = 100))
    private TraceId traceId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private SyncStatus status;

    @Column(name = "salesforce_review_id", length = 100)
    private String salesforceReviewId;

    // Member tracking
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "sf_saga_pending_members",
        joinColumns = @JoinColumn(name = "saga_id")
    )
    @Column(name = "member_id")
    @OrderColumn(name = "position")
    private List<String> pendingMemberIds = new ArrayList<>();

    @Column(name = "next_member_batch_number")
    private int nextMemberBatchNumber = 1;

    // Block tracking
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "sf_saga_pending_blocks",
        joinColumns = @JoinColumn(name = "saga_id")
    )
    @Column(name = "block_id")
    @OrderColumn(name = "position")
    private List<String> pendingBlockIds = new ArrayList<>();

    @Column(name = "next_block_batch_number")
    private int nextBlockBatchNumber = 1;

    // Batch progress tracking (stored as JSON or separate table in production)
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "sf_saga_batch_progress",
        joinColumns = @JoinColumn(name = "saga_id")
    )
    @MapKeyColumn(name = "batch_key", length = 50)
    @Column(name = "batch_status", length = 20)
    private Map<String, String> batchStatusMap = new HashMap<>();

    @Column(name = "started_at", updatable = false)
    private Instant startedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "last_failure_at")
    private Instant lastFailureAt;

    @Column(name = "failure_reason", length = 2000)
    private String failureReason;

    @Column(name = "retry_count")
    private int retryCount = 0;

    @Version
    @Column(name = "version")
    private Long version;

    public SalesforceSyncSaga(ReviewId reviewId, TraceId traceId) {
        this.id = UUID.randomUUID();
        this.reviewId = reviewId;
        this.traceId = traceId;
        this.status = SyncStatus.NOT_STARTED;
        this.startedAt = Instant.now();
    }

    // ========== Review Lifecycle ==========

    /**
     * Transitions saga to CREATING_REVIEW status.
     */
    public void reviewCreationStarted() {
        if (this.status != SyncStatus.NOT_STARTED) {
            log.warn("Cannot start review creation from status: {}", this.status);
            return;
        }
        this.status = SyncStatus.CREATING_REVIEW;
        log.info("Saga {} starting review creation", this.id);
    }

    /**
     * Records successful review creation and transitions to SYNCING_MEMBERS.
     */
    public void reviewCreated(String salesforceReviewId) {
        if (this.status != SyncStatus.CREATING_REVIEW) {
            log.warn("Cannot complete review creation from status: {}", this.status);
            return;
        }
        this.salesforceReviewId = salesforceReviewId;
        this.status = SyncStatus.SYNCING_MEMBERS;
        log.info("Saga {} review created in Salesforce: {}", this.id, salesforceReviewId);
    }

    // ========== Member Management ==========

    /**
     * Enqueues members for batch processing.
     * Can be called multiple times as late-arriving members are discovered.
     */
    public void enqueueMember(String memberId) {
        if (memberId == null || memberId.isBlank()) {
            return;
        }

        // Prevent duplicates
        if (pendingMemberIds.contains(memberId)) {
            log.debug("Member {} already queued for saga {}", memberId, this.id);
            return;
        }

        pendingMemberIds.add(memberId);

        // If we've moved past member syncing, go back
        if (this.status == SyncStatus.SYNCING_BLOCKS || this.status == SyncStatus.FINALIZING_STATUS) {
            this.status = SyncStatus.SYNCING_MEMBERS;
            log.info("Saga {} returned to SYNCING_MEMBERS for late-arriving member", this.id);
        }

        log.debug("Saga {} enqueued member {} (total pending: {})",
            this.id, memberId, pendingMemberIds.size());
    }

    /**
     * Creates the next batch of members to sync.
     * Returns empty if no members are pending.
     */
    public Optional<BatchProgress> nextMemberBatch(int batchSize) {
        if (pendingMemberIds.isEmpty()) {
            return Optional.empty();
        }

        int count = Math.min(batchSize, pendingMemberIds.size());
        List<String> batchItems = new ArrayList<>(pendingMemberIds.subList(0, count));
        pendingMemberIds.subList(0, count).clear();

        int batchNumber = nextMemberBatchNumber++;
        String batchKey = "MEMBER_" + batchNumber;

        BatchProgress progress = new BatchProgress(
            batchKey,
            batchNumber,
            batchItems,
            BatchStatus.IN_FLIGHT,
            "MEMBER"
        );

        batchStatusMap.put(batchKey, BatchStatus.IN_FLIGHT.name());

        log.info("Saga {} created member batch {} with {} items",
            this.id, batchNumber, batchItems.size());

        return Optional.of(progress);
    }

    /**
     * Marks a member batch as completed.
     */
    public void markMemberBatchCompleted(int batchNumber) {
        String batchKey = "MEMBER_" + batchNumber;
        batchStatusMap.put(batchKey, BatchStatus.COMPLETED.name());

        log.info("Saga {} member batch {} completed", this.id, batchNumber);

        // Transition to blocks if all member batches complete
        if (pendingMemberIds.isEmpty() && allMemberBatchesCompleted()) {
            if (pendingBlockIds.isEmpty()) {
                this.status = SyncStatus.FINALIZING_STATUS;
                log.info("Saga {} transitioning to FINALIZING_STATUS (no blocks)", this.id);
            } else {
                this.status = SyncStatus.SYNCING_BLOCKS;
                log.info("Saga {} transitioning to SYNCING_BLOCKS", this.id);
            }
        }
    }

    /**
     * Marks a member batch as failed and re-queues items.
     */
    public void markMemberBatchFailed(int batchNumber, List<String> items, String reason) {
        String batchKey = "MEMBER_" + batchNumber;
        batchStatusMap.put(batchKey, BatchStatus.FAILED.name());

        // Re-queue failed items
        pendingMemberIds.addAll(0, items);

        this.status = SyncStatus.FAILED;
        this.failureReason = reason;
        this.lastFailureAt = Instant.now();

        log.error("Saga {} member batch {} failed: {}", this.id, batchNumber, reason);
    }

    // ========== Block Management ==========

    /**
     * Enqueues blocks for batch processing.
     */
    public void enqueueBlock(String blockId) {
        if (blockId == null || blockId.isBlank()) {
            return;
        }

        // Prevent duplicates
        if (pendingBlockIds.contains(blockId)) {
            log.debug("Block {} already queued for saga {}", blockId, this.id);
            return;
        }

        pendingBlockIds.add(blockId);

        // If we've moved to finalizing, go back
        if (this.status == SyncStatus.FINALIZING_STATUS) {
            this.status = SyncStatus.SYNCING_BLOCKS;
            log.info("Saga {} returned to SYNCING_BLOCKS for late-arriving block", this.id);
        }

        log.debug("Saga {} enqueued block {} (total pending: {})",
            this.id, blockId, pendingBlockIds.size());
    }

    /**
     * Creates the next batch of blocks to sync.
     */
    public Optional<BatchProgress> nextBlockBatch(int batchSize) {
        if (pendingBlockIds.isEmpty()) {
            return Optional.empty();
        }

        int count = Math.min(batchSize, pendingBlockIds.size());
        List<String> batchItems = new ArrayList<>(pendingBlockIds.subList(0, count));
        pendingBlockIds.subList(0, count).clear();

        int batchNumber = nextBlockBatchNumber++;
        String batchKey = "BLOCK_" + batchNumber;

        BatchProgress progress = new BatchProgress(
            batchKey,
            batchNumber,
            batchItems,
            BatchStatus.IN_FLIGHT,
            "BLOCK"
        );

        batchStatusMap.put(batchKey, BatchStatus.IN_FLIGHT.name());

        log.info("Saga {} created block batch {} with {} items",
            this.id, batchNumber, batchItems.size());

        return Optional.of(progress);
    }

    /**
     * Marks a block batch as completed.
     */
    public void markBlockBatchCompleted(int batchNumber) {
        String batchKey = "BLOCK_" + batchNumber;
        batchStatusMap.put(batchKey, BatchStatus.COMPLETED.name());

        log.info("Saga {} block batch {} completed", this.id, batchNumber);

        // Transition to finalizing if all block batches complete
        if (pendingBlockIds.isEmpty() && allBlockBatchesCompleted()) {
            this.status = SyncStatus.FINALIZING_STATUS;
            log.info("Saga {} transitioning to FINALIZING_STATUS", this.id);
        }
    }

    /**
     * Marks a block batch as failed and re-queues items.
     */
    public void markBlockBatchFailed(int batchNumber, List<String> items, String reason) {
        String batchKey = "BLOCK_" + batchNumber;
        batchStatusMap.put(batchKey, BatchStatus.FAILED.name());

        // Re-queue failed items
        pendingBlockIds.addAll(0, items);

        this.status = SyncStatus.FAILED;
        this.failureReason = reason;
        this.lastFailureAt = Instant.now();

        log.error("Saga {} block batch {} failed: {}", this.id, batchNumber, reason);
    }

    // ========== Saga Completion ==========

    /**
     * Marks the saga as completed.
     */
    public void complete() {
        this.status = SyncStatus.COMPLETED;
        this.completedAt = Instant.now();
        log.info("Saga {} completed successfully", this.id);
    }

    /**
     * Marks the saga as failed.
     */
    public void fail(String reason) {
        this.status = SyncStatus.FAILED;
        this.failureReason = reason;
        this.lastFailureAt = Instant.now();
        log.error("Saga {} failed: {}", this.id, reason);
    }

    /**
     * Retries the saga from failed state.
     */
    public void retry() {
        if (this.status != SyncStatus.FAILED) {
            log.warn("Cannot retry saga {} from status {}", this.id, this.status);
            return;
        }

        this.retryCount++;
        this.failureReason = null;

        // Determine which state to return to
        if (!pendingMemberIds.isEmpty()) {
            this.status = SyncStatus.SYNCING_MEMBERS;
        } else if (!pendingBlockIds.isEmpty()) {
            this.status = SyncStatus.SYNCING_BLOCKS;
        } else {
            this.status = SyncStatus.FINALIZING_STATUS;
        }

        log.info("Saga {} retry #{} - returning to status {}",
            this.id, this.retryCount, this.status);
    }

    // ========== Helper Methods ==========

    private boolean allMemberBatchesCompleted() {
        return batchStatusMap.entrySet().stream()
            .filter(e -> e.getKey().startsWith("MEMBER_"))
            .allMatch(e -> BatchStatus.COMPLETED.name().equals(e.getValue()));
    }

    private boolean allBlockBatchesCompleted() {
        return batchStatusMap.entrySet().stream()
            .filter(e -> e.getKey().startsWith("BLOCK_"))
            .allMatch(e -> BatchStatus.COMPLETED.name().equals(e.getValue()));
    }

    public boolean isCompleted() {
        return status == SyncStatus.COMPLETED;
    }

    public boolean isFailed() {
        return status == SyncStatus.FAILED;
    }

    // ========== Inner Record ==========

    /**
     * Represents a batch of items (members or blocks) to be synced.
     */
    public record BatchProgress(
        String batchKey,
        int batchNumber,
        List<String> items,
        BatchStatus status,
        String type
    ) {
        public BatchProgress {
            items = List.copyOf(items); // Immutable
        }
    }
}
