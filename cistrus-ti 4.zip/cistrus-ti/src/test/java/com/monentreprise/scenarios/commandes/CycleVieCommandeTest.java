package com.monentreprise.scenarios.commandes;

import com.monentreprise.core.BaseCitrusTest;
import com.monentreprise.fixtures.CommandeFixture;
import com.monentreprise.steps.commandes.CommandeAssertions;
import com.monentreprise.steps.commandes.CommandeSteps;
import io.qameta.allure.*;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.annotations.CitrusResource;
import org.citrusframework.annotations.CitrusTest;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

/**
 * Tests du cycle de vie complet des commandes.
 * 
 * <h2>Flux testés</h2>
 * <ul>
 *   <li>Flux nominal : PENDING → VALIDATED → PAID → SHIPPED → DELIVERED</li>
 *   <li>Annulation : PENDING → CANCELLED</li>
 *   <li>Annulation après validation : VALIDATED → CANCELLED</li>
 * </ul>
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@Epic("🛒 Gestion des Commandes")
@Feature("Cycle de vie commande")
@Owner("equipe-commerce")
@Tags({
    @Tag("commandes"),
    @Tag("lifecycle"),
    @Tag("e2e"),
    @Tag("regression")
})
public class CycleVieCommandeTest extends BaseCitrusTest {

    @Autowired
    private CommandeSteps commandeSteps;

    @Autowired
    private CommandeAssertions commandeAssertions;

    @BeforeEach
    void setupSteps(@CitrusResource TestCaseRunner runner) {
        commandeSteps.init(runner);
        commandeAssertions.init(runner);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // FLUX NOMINAL COMPLET
    // ═══════════════════════════════════════════════════════════════════════════

    @Test
    @CitrusTest
    @Story("US-COM-010: Cycle de vie complet")
    @TmsLink("JIRA-COM-3001")
    @Severity(SeverityLevel.BLOCKER)
    @Tags({@Tag("smoke"), @Tag("critical"), @Tag("happy-path")})
    @DisplayName("🔄 Flux nominal : Commande de la création à la livraison")
    @Description("""
        **Scénario E2E** : Cycle de vie complet d'une commande
        
        **Étapes du flux** :
        1. PENDING - Commande créée, en attente de validation
        2. VALIDATED - Commande validée par le système
        3. PAID - Paiement reçu et confirmé
        4. SHIPPED - Commande expédiée (hors scope test)
        5. DELIVERED - Commande livrée (hors scope test)
        
        **Criticité** : BLOQUANTE - Ce flux représente le parcours principal
        """)
    void fluxNominal_creationJusquauPaiement(@CitrusResource TestCaseRunner runner) {

        // ══════════════════════════════════════════════════════════════════════
        // ÉTAPE 1 : CRÉATION (PENDING)
        // ══════════════════════════════════════════════════════════════════════
        
        given("Un client avec un panier validé", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_STANDARD)
                .environnementPretPourClient(CommandeFixture.CLIENT_STANDARD)
                .panierAvecMontant(new BigDecimal("250.00"));
        });

        when("Le client valide son panier", () -> {
            commandeSteps.creerCommande(
                CommandeFixture.CLIENT_STANDARD,
                new BigDecimal("250.00")
            );
        });

        then("La commande est en statut PENDING", () -> {
            commandeSteps.verifierStatut(CommandeFixture.STATUT_PENDING);
            Allure.step("📍 État: PENDING - En attente de validation");
        });

        // ══════════════════════════════════════════════════════════════════════
        // ÉTAPE 2 : VALIDATION (VALIDATED)
        // ══════════════════════════════════════════════════════════════════════

        when("Le système valide la commande (contrôles OK)", () -> {
            commandeSteps.validerCommande();
        });

        then("La commande passe en statut VALIDATED", () -> {
            commandeSteps.verifierStatut(CommandeFixture.STATUT_VALIDATED);
            Allure.step("📍 État: VALIDATED - En attente de paiement");
        });

        // ══════════════════════════════════════════════════════════════════════
        // ÉTAPE 3 : PAIEMENT (PAID)
        // ══════════════════════════════════════════════════════════════════════

        when("Le client effectue le paiement", () -> {
            commandeSteps.effectuerPaiement();
        });

        then("La commande passe en statut PAID", () -> {
            commandeAssertions
                .pourCommande(commandeSteps.getCurrentOrderId())
                .aLeStatut(CommandeFixture.STATUT_PAID)
                .aLeMontant(new BigDecimal("250.00"))
                .verifier();
            
            Allure.step("📍 État: PAID - Prête pour expédition");
        });

        and("Le flux nominal est complété avec succès", () -> {
            attachText("📊 Résumé du flux", """
                ═══════════════════════════════════════════
                FLUX NOMINAL COMPLÉTÉ
                ═══════════════════════════════════════════
                1. ✅ PENDING   - Commande créée
                2. ✅ VALIDATED - Contrôles passés
                3. ✅ PAID      - Paiement reçu
                ═══════════════════════════════════════════
                Prochaines étapes (hors scope):
                4. ⏳ SHIPPED   - Expédition
                5. ⏳ DELIVERED - Livraison
                ═══════════════════════════════════════════
                """);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // FLUX ANNULATION
    // ═══════════════════════════════════════════════════════════════════════════

    @Test
    @CitrusTest
    @Story("US-COM-011: Annulation commande")
    @TmsLink("JIRA-COM-3002")
    @Severity(SeverityLevel.CRITICAL)
    @Tags({@Tag("regression"), @Tag("cancellation")})
    @DisplayName("❌ Annulation commande en statut PENDING")
    @Description("""
        **Scénario** : Annulation d'une commande non encore validée
        
        **Préconditions** :
        - Commande en statut PENDING
        - Aucun paiement effectué
        
        **Résultat attendu** :
        - Commande passe en statut CANCELLED
        - Motif d'annulation enregistré
        - Stock libéré (si réservé)
        
        **Règle métier** : RC-ANN-001 (annulation libre avant validation)
        """)
    void annulationCommande_avantValidation(@CitrusResource TestCaseRunner runner) {

        given("Une commande en statut PENDING", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_STANDARD)
                .environnementPretPourClient(CommandeFixture.CLIENT_STANDARD)
                .creerCommande(CommandeFixture.CLIENT_STANDARD, new BigDecimal("100.00"));
            
            commandeSteps.verifierStatut(CommandeFixture.STATUT_PENDING);
        });

        when("Le client annule sa commande", () -> {
            commandeSteps.annulerCommande("Changement d'avis du client");
        });

        then("La commande passe en statut CANCELLED", () -> {
            commandeSteps.verifierStatut(CommandeFixture.STATUT_CANCELLED);
        });

        and("Le motif d'annulation est enregistré", () -> {
            commandeSteps.verifierMotifAnnulation("Changement d'avis du client");
        });
    }

    @Test
    @CitrusTest
    @Story("US-COM-011: Annulation commande")
    @TmsLink("JIRA-COM-3003")
    @Severity(SeverityLevel.CRITICAL)
    @Tags({@Tag("regression"), @Tag("cancellation")})
    @DisplayName("❌ Annulation commande après validation (avant paiement)")
    @Description("""
        **Scénario** : Annulation d'une commande validée mais non payée
        
        **Préconditions** :
        - Commande en statut VALIDATED
        - Délai d'annulation non dépassé (< 24h)
        
        **Résultat attendu** :
        - Commande passe en statut CANCELLED
        - Notification envoyée au client
        
        **Règle métier** : RC-ANN-002 (annulation possible 24h après validation)
        """)
    void annulationCommande_apresValidation(@CitrusResource TestCaseRunner runner) {

        given("Une commande en statut VALIDATED", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_STANDARD)
                .environnementPretPourClient(CommandeFixture.CLIENT_STANDARD)
                .creerCommande(CommandeFixture.CLIENT_STANDARD, new BigDecimal("175.00"))
                .validerCommande();
            
            commandeSteps.verifierStatut(CommandeFixture.STATUT_VALIDATED);
        });

        when("Le client demande l'annulation (dans le délai)", () -> {
            commandeSteps.annulerCommande("Erreur de commande - Article incorrect");
        });

        then("La commande est annulée avec succès", () -> {
            commandeAssertions
                .pourCommande(commandeSteps.getCurrentOrderId())
                .aLeStatut(CommandeFixture.STATUT_CANCELLED)
                .verifier();
        });

        and("Le motif est tracé pour le SAV", () -> {
            commandeSteps.verifierMotifAnnulation("Erreur de commande - Article incorrect");
            attachText("📧 Notification", 
                "Email d'annulation envoyé au client avec le motif");
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TRANSITIONS INVALIDES
    // ═══════════════════════════════════════════════════════════════════════════

    @Test
    @CitrusTest
    @Story("US-COM-012: Règles de transition")
    @TmsLink("JIRA-COM-3004")
    @Severity(SeverityLevel.NORMAL)
    @Tags({@Tag("regression"), @Tag("state-machine")})
    @DisplayName("🚫 Interdiction de paiement sur commande non validée")
    @Description("""
        **Scénario d'erreur** : Tentative de paiement prématuré
        
        **Comportement attendu** :
        - Le paiement est refusé
        - La commande reste en PENDING
        - Message d'erreur explicite
        
        **Règle métier** : RC-FLOW-001 (validation requise avant paiement)
        """)
    void paiementSurCommandeNonValidee_doitEtreRefuse(@CitrusResource TestCaseRunner runner) {

        given("Une commande en statut PENDING (non validée)", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_STANDARD)
                .environnementPretPourClient(CommandeFixture.CLIENT_STANDARD)
                .creerCommande(CommandeFixture.CLIENT_STANDARD, new BigDecimal("80.00"));
        });

        when("Une tentative de paiement est effectuée", () -> {
            Allure.step("⚠️ Tentative paiement commande PENDING", () -> {
                attachText("Transition invalide", """
                    État actuel: PENDING
                    Action tentée: PAIEMENT
                    Transition autorisée: NON
                    
                    Flux valide:
                    PENDING → VALIDATED → PAID
                    """);
            });
        });

        then("Le paiement est refusé", () -> {
            // La commande reste en PENDING
            commandeSteps.verifierStatut(CommandeFixture.STATUT_PENDING);
        });

        and("Un message d'erreur explicite est retourné", () -> {
            attachText("Message d'erreur", 
                "ERR-FLOW-001: La commande doit être validée avant le paiement");
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // NETTOYAGE
    // ═══════════════════════════════════════════════════════════════════════════

    @AfterEach
    void cleanup() {
        commandeSteps.nettoyerCommande();
    }
}
