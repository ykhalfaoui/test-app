package com.monentreprise.scenarios.kyc;

import com.monentreprise.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("📮 Feature: Communication Client")
@Feature("Outreach & Blocking Process")
@Owner("equipe-front")
public class ClientCommunicationTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("Timeline Complète : Demande -> Rappels -> Blocage -> Exit")
    @DisplayName("📧 Cycle complet Communication Client (Digital)")
    @Tag("outreach")
    void communicationLifecycleComplete() {
        kycSteps.agentNeedsClientInfo();
        kycSteps.sendInitialCommunication("Messagerie Sécurisée");
        kycSteps.waitPeriod(1);
        kycSteps.sendReminder(1);
        kycSteps.waitPeriod(2);
        kycSteps.agentReceivesNotificationBeforeDeadline();
        kycSteps.sendReminder(2);
        kycSteps.agentManuallySetsStatusBlocked();
        kycSteps.freezeAccounts();
        kycSteps.waitPeriod(3);
        kycSteps.triggerExitProcess();
    }

    @Test
    @Story("Timeline : Réponse Client (Sauvetage)")
    @DisplayName("↩️ Récuperation Client après T1")
    @Description("Le client répond au premier rappel. Le processus reprend sans blocage des comptes.")
    @Tag("outreach")
    @Tag("recovery")
    void clientRecovers() {
        kycSteps.agentNeedsClientInfo();
        kycSteps.sendInitialCommunication("Lettre");

        kycSteps.waitPeriod(1);
        kycSteps.sendReminder(1);

        // WHEN: Le client répond
        kycSteps.clientRespondsToReminder();

        // THEN: Le processus reprend
        kycSteps.processResumes();
    }
}
