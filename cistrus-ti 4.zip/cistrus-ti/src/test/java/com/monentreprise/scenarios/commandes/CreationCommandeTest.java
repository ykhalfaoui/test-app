package com.monentreprise.scenarios.commandes;

import com.monentreprise.core.BaseCitrusTest;
import com.monentreprise.fixtures.CommandeFixture;
import com.monentreprise.steps.commandes.CommandeAssertions;
import com.monentreprise.steps.commandes.CommandeSteps;
import io.qameta.allure.*;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.annotations.CitrusResource;
import org.citrusframework.annotations.CitrusTest;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

/**
 * Tests E2E pour la création de commandes.
 * 
 * <h2>Couverture fonctionnelle</h2>
 * <ul>
 *   <li>Scénario nominal : Client standard crée une commande</li>
 *   <li>Variations : Client VIP, Client Entreprise</li>
 *   <li>Cas d'erreur : Montant invalide, Client bloqué</li>
 * </ul>
 * 
 * <h2>User Stories associées</h2>
 * <ul>
 *   <li>US-COM-001 : Création de commande client</li>
 *   <li>US-COM-002 : Validation des montants</li>
 *   <li>US-COM-003 : Gestion des clients VIP</li>
 * </ul>
 * 
 * @author Équipe QA
 * @since 1.0.0
 * @see CommandeSteps
 * @see CommandeFixture
 */
@Epic("🛒 Gestion des Commandes")
@Feature("Création de commande")
@Owner("equipe-commerce")
@Tags({
    @Tag("commandes"),
    @Tag("creation"),
    @Tag("regression")
})
public class CreationCommandeTest extends BaseCitrusTest {

    @Autowired
    private CommandeSteps commandeSteps;

    @Autowired
    private CommandeAssertions commandeAssertions;

    @BeforeEach
    void setupSteps(@CitrusResource TestCaseRunner runner) {
        commandeSteps.init(runner);
        commandeAssertions.init(runner);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SCÉNARIO NOMINAL
    // ═══════════════════════════════════════════════════════════════════════════

    @Test
    @CitrusTest
    @Story("US-COM-001: Création commande client standard")
    @TmsLink("JIRA-COM-1234")
    @Severity(SeverityLevel.BLOCKER)
    @Tags({@Tag("smoke"), @Tag("critical"), @Tag("sprint-42")})
    @DisplayName("✅ Scénario nominal : Client standard crée une commande avec succès")
    @Description("""
        **Scénario métier** : Création de commande client standard
        
        **Préconditions** :
        - Client authentifié avec profil STANDARD
        - Panier validé avec montant > 0
        
        **Résultat attendu** :
        - Commande créée en statut 'PENDING' (En attente de paiement)
        - Montant correctement enregistré
        
        **Règle métier** : RC-COM-001 (délai validation 24h)
        """)
    void clientStandard_creeCommande_statutEnAttente(@CitrusResource TestCaseRunner runner) {

        // ══════════════════════════════════════════════════════════════════════
        // CONTEXTE MÉTIER
        // ══════════════════════════════════════════════════════════════════════
        
        given("Un client standard authentifié", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_STANDARD);
        });

        and("Un panier validé de 150€", () -> {
            commandeSteps.panierAvecMontant(new BigDecimal("150.00"));
        });

        given("L'environnement est prêt", () -> {
            commandeSteps.environnementPretPourClient(CommandeFixture.CLIENT_STANDARD);
        });

        // ══════════════════════════════════════════════════════════════════════
        // ACTION
        // ══════════════════════════════════════════════════════════════════════

        when("Le client valide sa commande", () -> {
            commandeSteps.creerCommande(
                CommandeFixture.CLIENT_STANDARD,
                new BigDecimal("150.00")
            );
        });

        // ══════════════════════════════════════════════════════════════════════
        // RÉSULTAT ATTENDU
        // ══════════════════════════════════════════════════════════════════════

        then("La commande est créée en statut 'En attente de paiement'", () -> {
            commandeSteps.verifierStatut(CommandeFixture.STATUT_PENDING);
        });

        and("Le montant est correctement enregistré", () -> {
            commandeSteps.verifierMontant(new BigDecimal("150.00"));
        });

        and("Le type de client est associé à la commande", () -> {
            commandeSteps.verifierTypeClient(CommandeFixture.CLIENT_STANDARD);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // VARIATIONS CLIENT
    // ═══════════════════════════════════════════════════════════════════════════

    @Test
    @CitrusTest
    @Story("US-COM-003: Gestion des clients VIP")
    @TmsLink("JIRA-COM-1235")
    @Severity(SeverityLevel.CRITICAL)
    @Tags({@Tag("regression"), @Tag("vip")})
    @DisplayName("✅ Client VIP crée une commande avec montant élevé")
    @Description("""
        **Scénario métier** : Client VIP - Commande montant élevé
        
        **Spécificité** : Les clients VIP peuvent passer des commandes 
        avec des montants supérieurs au plafond standard (>1000€).
        
        **Règle métier** : RC-COM-003 (plafond VIP = 10000€)
        """)
    void clientVIP_creeCommande_montantEleve(@CitrusResource TestCaseRunner runner) {

        given("Un client VIP authentifié", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_VIP)
                .environnementPretPourClient(CommandeFixture.CLIENT_VIP);
        });

        and("Un panier de 2500€ (au-dessus du plafond standard)", () -> {
            commandeSteps.panierAvecMontant(new BigDecimal("2500.00"));
        });

        when("Le client VIP valide sa commande", () -> {
            commandeSteps.creerCommande(
                CommandeFixture.CLIENT_VIP,
                new BigDecimal("2500.00")
            );
        });

        then("La commande est créée avec succès", () -> {
            commandeAssertions
                .pourCommande(commandeSteps.getCurrentOrderId())
                .aLeStatut(CommandeFixture.STATUT_PENDING)
                .aLeMontant(new BigDecimal("2500.00"))
                .aPourTypeClient(CommandeFixture.CLIENT_VIP)
                .verifier();
        });
    }

    @Test
    @CitrusTest
    @Story("US-COM-004: Commandes entreprise")
    @TmsLink("JIRA-COM-1236")
    @Severity(SeverityLevel.NORMAL)
    @Tags({@Tag("regression"), @Tag("b2b")})
    @DisplayName("✅ Client Entreprise crée une commande B2B")
    @Description("""
        **Scénario métier** : Commande client entreprise (B2B)
        
        **Spécificité** : Les clients entreprise ont des conditions 
        de paiement différées (30 jours).
        
        **Règle métier** : RC-COM-004 (paiement différé B2B)
        """)
    void clientEntreprise_creeCommande_B2B(@CitrusResource TestCaseRunner runner) {

        given("Un client entreprise authentifié", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(CommandeFixture.CLIENT_ENTREPRISE)
                .environnementPretPourClient(CommandeFixture.CLIENT_ENTREPRISE);
        });

        when("Le client entreprise passe une commande", () -> {
            commandeSteps.creerCommande(
                CommandeFixture.CLIENT_ENTREPRISE,
                new BigDecimal("5000.00")
            );
        });

        then("La commande B2B est créée en attente de validation", () -> {
            commandeSteps.verifierStatut(CommandeFixture.STATUT_PENDING);
            commandeSteps.verifierTypeClient(CommandeFixture.CLIENT_ENTREPRISE);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TESTS PARAMÉTRÉS
    // ═══════════════════════════════════════════════════════════════════════════

    @ParameterizedTest(name = "Commande {1} - {0}€ → statut {2}")
    @CsvSource({
        "150.00, CLIENT_STANDARD, PENDING",
        "2500.00, CLIENT_VIP, PENDING",
        "5000.00, CLIENT_ENTREPRISE, PENDING",
        "50.00, CLIENT_STANDARD, PENDING"
    })
    @CitrusTest
    @Story("US-COM-001: Création commande - Variations")
    @TmsLink("JIRA-COM-1237")
    @Severity(SeverityLevel.NORMAL)
    @Tags({@Tag("regression"), @Tag("parametized")})
    @DisplayName("📊 Test paramétré : Création commande selon type client et montant")
    void testCreationCommandeParametree(
            BigDecimal montant,
            String typeClient,
            String statutAttendu,
            @CitrusResource TestCaseRunner runner) {

        addBusinessParameter("Type client", typeClient);
        addBusinessParameter("Montant", montant + "€");
        addBusinessParameter("Statut attendu", statutAttendu);

        given("Un client " + typeClient + " authentifié", () -> {
            commandeSteps
                .genererNouvelleReference()
                .clientAuthentifie(typeClient)
                .environnementPretPourClient(typeClient);
        });

        when("Le client crée une commande de " + montant + "€", () -> {
            commandeSteps.creerCommande(typeClient, montant);
        });

        then("La commande est en statut " + statutAttendu, () -> {
            commandeSteps.verifierStatut(statutAttendu);
            commandeSteps.verifierMontant(montant);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // NETTOYAGE
    // ═══════════════════════════════════════════════════════════════════════════

    @AfterEach
    void cleanup() {
        // Nettoyage optionnel - les données dynamiques évitent les conflits
        // commandeSteps.nettoyerCommande();
    }
}
