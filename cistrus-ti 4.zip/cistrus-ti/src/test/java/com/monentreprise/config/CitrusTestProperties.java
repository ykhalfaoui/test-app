package com.monentreprise.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Propriétés de configuration pour les tests d'intégration Citrus.
 * Permet de surcharger l'infrastructure et les données de test par
 * environnement.
 * 
 * Prefix: "citrus"
 */
@Data
@ConfigurationProperties(prefix = "citrus")
public class CitrusTestProperties {

    /** Configuration de l'infrastructure (Base de données, etc.) */
    private Infra infra = new Infra();

    /** Configuration des données de test (Clients, Montants...) */
    private TestData testData = new TestData();

    @Data
    public static class Infra {
        private DataSourceConfig datasource = new DataSourceConfig();
    }

    @Data
    public static class DataSourceConfig {
        private String url = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=Oracle";
        private String username = "sa";
        private String password = "";
        private String driverClassName = "org.h2.Driver";
    }

    @Data
    public static class TestData {
        /** Identifiants des clients de test */
        private Clients clients = new Clients();
    }

    @Data
    public static class Clients {
        private String standard = "CLIENT_STANDARD";
        private String vip = "CLIENT_VIP";
        private String entreprise = "CLIENT_ENTREPRISE";
        private String bloque = "CLIENT_BLOQUE";
    }
}
