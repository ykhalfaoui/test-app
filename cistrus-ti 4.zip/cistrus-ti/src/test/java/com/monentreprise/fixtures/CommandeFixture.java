package com.monentreprise.fixtures;

import lombok.Builder;
import lombok.Data;
import org.springframework.stereotype.Component;
import com.monentreprise.config.CitrusTestProperties;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Fixture pour générer des données de test pour les commandes.
 * 
 * <h2>Pattern Builder</h2>
 * Permet de créer des objets de test avec des valeurs par défaut sensées,
 * tout en permettant la personnalisation.
 * 
 * <h2>Usage</h2>
 * 
 * <pre>{@code
 * // Commande standard avec valeurs par défaut
 * CommandeTestData commande = CommandeFixture.uneCommande().build();
 * 
 * // Commande personnalisée
 * CommandeTestData commandeVip = CommandeFixture.uneCommande()
 *         .pourClientVIP()
 *         .avecMontant(new BigDecimal("5000.00"))
 *         .enStatut("VALIDATED")
 *         .build();
 * }</pre>
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@Component
public class CommandeFixture {

    // ═══════════════════════════════════════════════════════════════════════════
    // CONSTANTES MÉTIER
    // ═══════════════════════════════════════════════════════════════════════════

    // Modifiables dynamiquement via properties
    public static String CLIENT_STANDARD = "CLIENT_STANDARD";
    public static String CLIENT_VIP = "CLIENT_VIP";
    public static String CLIENT_ENTREPRISE = "CLIENT_ENTREPRISE";
    public static String CLIENT_BLOQUE = "CLIENT_BLOQUE";

    @Autowired
    private CitrusTestProperties properties;

    @PostConstruct
    public void init() {
        if (properties != null && properties.getTestData() != null && properties.getTestData().getClients() != null) {
            CLIENT_STANDARD = properties.getTestData().getClients().getStandard();
            CLIENT_VIP = properties.getTestData().getClients().getVip();
            CLIENT_ENTREPRISE = properties.getTestData().getClients().getEntreprise();
            CLIENT_BLOQUE = properties.getTestData().getClients().getBloque();
        }
    }

    public static final String STATUT_PENDING = "PENDING";
    public static final String STATUT_VALIDATED = "VALIDATED";
    public static final String STATUT_PAID = "PAID";
    public static final String STATUT_SHIPPED = "SHIPPED";
    public static final String STATUT_DELIVERED = "DELIVERED";
    public static final String STATUT_CANCELLED = "CANCELLED";
    public static final String STATUT_REJECTED = "REJECTED";

    public static final BigDecimal MONTANT_MINIMUM = new BigDecimal("0.01");
    public static final BigDecimal MONTANT_STANDARD = new BigDecimal("150.00");
    public static final BigDecimal MONTANT_VIP_SEUIL = new BigDecimal("1000.00");
    public static final BigDecimal MONTANT_MAXIMUM = new BigDecimal("99999.99");

    // ═══════════════════════════════════════════════════════════════════════════
    // BUILDER FACTORY
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Point d'entrée pour créer une nouvelle fixture de commande.
     */
    public static CommandeBuilder uneCommande() {
        return new CommandeBuilder();
    }

    /**
     * Crée une commande nominale standard (cas de test le plus courant).
     */
    public static CommandeTestData commandeNominale() {
        return uneCommande()
                .pourClientStandard()
                .avecMontant(MONTANT_STANDARD)
                .enStatut(STATUT_PENDING)
                .build();
    }

    /**
     * Crée une commande VIP avec montant élevé.
     */
    public static CommandeTestData commandeVIP() {
        return uneCommande()
                .pourClientVIP()
                .avecMontant(new BigDecimal("2500.00"))
                .enStatut(STATUT_PENDING)
                .build();
    }

    /**
     * Crée une commande avec montant invalide (négatif).
     */
    public static CommandeTestData commandeMontantNegatif() {
        return uneCommande()
                .pourClientStandard()
                .avecMontant(new BigDecimal("-50.00"))
                .enStatut(STATUT_PENDING)
                .build();
    }

    /**
     * Crée une commande avec montant zéro.
     */
    public static CommandeTestData commandeMontantZero() {
        return uneCommande()
                .pourClientStandard()
                .avecMontant(BigDecimal.ZERO)
                .enStatut(STATUT_PENDING)
                .build();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BUILDER CLASS
    // ═══════════════════════════════════════════════════════════════════════════

    public static class CommandeBuilder {
        private String refId;
        private String customer;
        private String customerType;
        private String status;
        private BigDecimal amount;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private String cancellationReason;

        private CommandeBuilder() {
            // Valeurs par défaut
            this.refId = "CMD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            this.customer = CLIENT_STANDARD;
            this.customerType = CLIENT_STANDARD;
            this.status = STATUT_PENDING;
            this.amount = MONTANT_STANDARD;
            this.createdAt = LocalDateTime.now();
            this.updatedAt = LocalDateTime.now();
        }

        public CommandeBuilder avecReference(String refId) {
            this.refId = refId;
            return this;
        }

        public CommandeBuilder pourClient(String customer) {
            this.customer = customer;
            this.customerType = customer;
            return this;
        }

        public CommandeBuilder pourClientStandard() {
            return pourClient(CLIENT_STANDARD);
        }

        public CommandeBuilder pourClientVIP() {
            return pourClient(CLIENT_VIP);
        }

        public CommandeBuilder pourClientEntreprise() {
            return pourClient(CLIENT_ENTREPRISE);
        }

        public CommandeBuilder pourClientBloque() {
            return pourClient(CLIENT_BLOQUE);
        }

        public CommandeBuilder avecMontant(BigDecimal amount) {
            this.amount = amount;
            return this;
        }

        public CommandeBuilder enStatut(String status) {
            this.status = status;
            return this;
        }

        public CommandeBuilder avecMotifAnnulation(String motif) {
            this.cancellationReason = motif;
            this.status = STATUT_CANCELLED;
            return this;
        }

        public CommandeBuilder creeeLe(LocalDateTime date) {
            this.createdAt = date;
            this.updatedAt = date;
            return this;
        }

        public CommandeTestData build() {
            return CommandeTestData.builder()
                    .refId(refId)
                    .customer(customer)
                    .customerType(customerType)
                    .status(status)
                    .amount(amount)
                    .createdAt(createdAt)
                    .updatedAt(updatedAt)
                    .cancellationReason(cancellationReason)
                    .build();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // DATA CLASS
    // ═══════════════════════════════════════════════════════════════════════════

    @Data
    @Builder
    public static class CommandeTestData {
        private String refId;
        private String customer;
        private String customerType;
        private String status;
        private BigDecimal amount;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private String cancellationReason;

        /**
         * Génère la requête SQL d'insertion pour cette commande.
         */
        public String toInsertSQL() {
            return String.format(
                    "INSERT INTO orders (ref_id, customer, customer_type, status, amount, created_at, updated_at%s) " +
                            "VALUES ('%s', '%s', '%s', '%s', %s, '%s', '%s'%s)",
                    cancellationReason != null ? ", cancellation_reason" : "",
                    refId, customer, customerType, status, amount,
                    createdAt.toString(), updatedAt.toString(),
                    cancellationReason != null ? ", '" + cancellationReason + "'" : "");
        }

        /**
         * Retourne une représentation lisible pour les logs/rapports.
         */
        public String toReadableString() {
            return String.format(
                    "Commande[ref=%s, client=%s, montant=%s€, statut=%s]",
                    refId, customer, amount, status);
        }
    }
}
