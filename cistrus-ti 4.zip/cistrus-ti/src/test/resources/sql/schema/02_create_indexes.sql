-- ═══════════════════════════════════════════════════════════════════════════
-- INDEX POUR OPTIMISATION DES REQUÊTES DE TEST
-- Version: 1.0.0
-- ═══════════════════════════════════════════════════════════════════════════

-- Index sur le statut des commandes (filtrage fréquent)
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- Index sur le type de client
CREATE INDEX IF NOT EXISTS idx_orders_customer_type ON orders(customer_type);

-- Index sur la date de création (pour les requêtes temporelles)
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);

-- Index composite pour les recherches par client + statut
CREATE INDEX IF NOT EXISTS idx_orders_customer_status ON orders(customer, status);

-- Index sur les lignes de commande par commande
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- Index sur l'historique par commande
CREATE INDEX IF NOT EXISTS idx_status_history_order_id ON order_status_history(order_id);

-- Index sur les clients par type
CREATE INDEX IF NOT EXISTS idx_customers_type ON customers(type);

-- Index sur les clients par statut
CREATE INDEX IF NOT EXISTS idx_customers_status ON customers(status);
