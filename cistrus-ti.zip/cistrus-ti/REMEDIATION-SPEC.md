# 📚 Functional Specifications: KYC Remediation, Review & Compliance Rules

Cette documentation décrit les règles métier et les protocoles de conformité avancés (Sanctions, LCB-FT, SAR).

---

## 🏗️ Data Model: Les Blocs de Données

### 1. Typologie des Blocs & Logique Spécifique
| Bloc | Code | Description & Logique de Validation |
|------|------|-------------------------------------|
| 🆔 **Static Data** | `SD` | **Délégation** vers Système Externe + Validation Client (Self-care). |
| 🕵️ **Name Screening** | `NS` | **Split Logic**: <br>1. **Sanctions/Terrorisme**: Hard Hit -> Fast Track. <br>2. **PEP/SIP**: Soft Hit -> Standard Review. |
| 📁 **Documents** | `DOC` | **Délégation Matrice**. Vérification automatique présence/validité. |
| 🔍 **KYT** | `KYT` | **IA Model**. <br>1. `INLINE`: OK. <br>2. `OUTLINE`: Alert -> Agent -> **Escalade MLRO** si suspect. |
| 💰 **KYC (Funds)** | `KYC` | Vérification origine des fonds (Source of Wealth). |
| 🏠 **Tax & Address** | `TAX` | Résidence fiscale (CRS/FATCA). |
| 🧠 **Knowledge** | `KNW` | Connaissance client (ESG/MiFID). |

---

## 🚀 Protocoles "Priority & Exceptions" (Règle d'Or)

Certains événements critiques doivent contourner les règles standards de cycle de vie.

### 1. Fast Track Sanctions (Embargo)
> **Problème**: La règle "Une seule version OPEN" bloque les mises à jour en cours de revue.
> **Solution**: Un Hit sur une liste de Sanctions (UN, OFAC, UE) **force** l'injection de l'alerte.

*   **Trigger**: Hit Sanction Confirmé.
*   **Action**: Si une version est `OPEN`, l'alerte Sanction est injectée dedans. Si aucune version, création immédiate.
*   **Conséquence**: Passage immédiat statut `URGENT_REVIEW` et Blocage temporaire préventif.

### 2. Distinction PEP vs Sanction
*   **PEP (Personne Exposée Politiquement)**:
    *   Risque modéré.
    *   Nécessite EDD (Enhanced Due Diligence) et Validation Senior Management.
    *   *Pas de blocage de compte automatique*.
*   **Sanction / Adverse Media (Grave)**:
    *   Risque Critique.
    *   **Gel des avoirs immédiat** (Asset Freeze).
    *   Signalement Autorités.

---

## 🔄 Lifecycle: States vs Statuses

### Version States (Cycle de Vie Technique)
*   **`OPEN`**: Work in Progress.
*   **`LOCKED`**: 4-Eyes Check.
*   **`FINALIZED`**: Archivé.

### Business Statuses (Résultat Métier)
Ajout des statuts réglementaires :
*   `INITIALIZED` / `REVIEW_IN_PROGRESS`
*   `PENDING_CLIENT` / `PENDING_COMPLIANCE`
*   **`ESCALATED_TO_MLRO`**: En attente décision Déclaration de Soupçon.
*   `VALIDATED_AUTO` / `VALIDATED_AGENT` / `VALIDATED_BY_CLIENT`
*   `BLOCKED` / `EXIT_CONFIRMED`

---

## 📅 Revues Périodiques & Grappes

*   **Périodicité**: High (1 an), Medium (3 ans), Low (7 ans).
*   **UBO (Beneficial Owners)**: Les bénéficiaires effectifs (>25%) sont inclus dans la grappe de revue et sont soumis à un screening renforcé.

---

## 📮 Communication Client (Outreach)

1.  **T0**: Envoi.
2.  **T1**: Rappel.
3.  **T2 (Action Manuelle)**: Agent passe statut `BLOCKED` + Dernière relance.
4.  **T3**: Clôture (Exit).

---

## 👮 Feature: Escalade MLRO (SAR)

Si l'analyse KYT ou Comportementale révèle un soupçon de blanchiment :
1.  L'agent qualifie le bloc en `SUSPICIOUS`.
2.  Le workflow route le dossier vers le **MLRO (Money Laundering Reporting Officer)**.
3.  Statut: `ESCALATED_TO_MLRO`.
4.  Décision MLRO:
    *   **No Case**: Retour à la normale (Fausse alerte).
    *   **SAR Filed**: Déclaration Tracfin/Autorité effectuée + Exit Client probable.
