package com.monentreprise.scenarios.kyc;

import com.monentreprise.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("🤖 Feature: Logiques Spécifiques par Bloc")
@Feature("Block Automation & Delegation")
@Owner("equipe-data")
public class SpecificBlockLogicTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("KYT: Analyse Comportementale IA")
    @DisplayName("🤖 KYT Inline (Validation Auto)")
    @Tag("kyt")
    void kytInline() {
        kycSteps.blockIsInitialized("KYT");
        kycSteps.runKytAiAnalysis("INLINE");
        kycSteps.systemValidatesBlock();
    }

    @Test
    @Story("KYT: Analyse Comportementale IA")
    @DisplayName("🤖 KYT Outline (Revue Manuelle)")
    @Tag("kyt")
    void kytOutline() {
        kycSteps.blockIsInitialized("KYT");
        kycSteps.runKytAiAnalysis("OUTLINE");
        kycSteps.systemFailsAutoValidation();
    }

    @Test
    @Story("Static Data: Délégation Client")
    @DisplayName("🆔 Static Data: Validation Client (Self-care)")
    @Tag("static-data")
    void staticDataClientConsolidated() {
        kycSteps.blockIsInitialized("Static Data");
        kycSteps.delegateToExternalSystem("Portail Client");
        kycSteps.externalSystemReturns("Données confirmées par client");
        kycSteps.logStep("THEN Status -> VALIDATED_BY_CLIENT");
    }

    @Test
    @Story("Documents: Validation Externe")
    @DisplayName("❌ Document Rejeté par Système")
    @Description("Le système externe rejette le document (Qualité insuffisante).")
    @Tag("documents")
    void documentRejected() {
        kycSteps.blockIsInitialized("Documents");
        kycSteps.delegateToExternalSystem("Matrice Doc System");
        kycSteps.externalSystemReturns("Rejected"); // Retour technique
        kycSteps.systemRejectsDocument("Illisible / Périmé");
        kycSteps.systemFailsAutoValidation(); // Retour Agent
    }

    @Test
    @Story("Name Screening: Provider Externe")
    @DisplayName("🕵️ Screening: No Match")
    @Tag("screening")
    void screeningNoMatch() {
        kycSteps.blockIsInitialized("Name Screening");
        kycSteps.callScreeningProvider();
        kycSteps.externalSystemReturns("No Match");
        kycSteps.systemValidatesBlock();
    }

    @Test
    @Story("Name Screening: Provider Externe")
    @DisplayName("🕵️ Screening: Hit PEP (Soft Hit)")
    @Description("Hit PEP détecté -> Pas de gel, mais EDD.")
    @Tag("screening")
    @Tag("pep")
    void screeningPepHit() {
        kycSteps.blockIsInitialized("Name Screening");
        kycSteps.callScreeningProvider();
        kycSteps.externalSystemReturns("Potential Match");

        kycSteps.pepHitDetected("WorldCheck PEP List");
        kycSteps.enhancedDueDiligenceTriggered();
        kycSteps.verifyNoAssetFreeze(); // Différence avec Sanctions
    }

    @Test
    @Story("Cycle de Vie: Version State")
    @DisplayName("🛡️ Protection Unicité (Version OPEN)")
    @Tag("architecture")
    void versionStateLock() {
        kycSteps.blockIsInitialized("KYC");
        kycSteps.verifyVersionState("OPEN");
        kycSteps.triggerNewVersionAttempt();
        kycSteps.verifyNoNewVersionCreated();
        kycSteps.finalizeVersion();
        kycSteps.verifyVersionState("FINALIZED");
    }
}
