package com.monentreprise.scenarios.kyc;

import com.monentreprise.core.BaseCitrusTest;
import com.monentreprise.steps.kyc.KycSteps;
import io.qameta.allure.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Epic("🏗️ Data Model: Les Blocs de Données")
@Feature("Lifecycle: Machine à États")
@Owner("equipe-transverse")
public class BlockLifecycleTest extends BaseCitrusTest {

    @Autowired
    private KycSteps kycSteps;

    @Test
    @Story("Validation Automatique")
    @DisplayName("✅ Validation Auto par Système")
    @Description("Le système valide le bloc sans intervention humaine (Règles métier OK).")
    @Tag("lifecycle")
    @Tag("automation")
    void autoValidation() {
        kycSteps.blockIsInitialized("Static Data");
        kycSteps.systemStartsAutoValidation();
        kycSteps.systemValidatesBlock();
    }

    @Test
    @Story("Revue Manuelle et Escalade Compliance")
    @DisplayName("👮 Revue Agent -> Compliance -> Validation")
    @Description("Échec auto -> Agent demande avis Compliance -> Validation manuelle.")
    @Tag("lifecycle")
    @Tag("manual")
    void manualReviewWithCompliance() {
        kycSteps.blockIsInitialized("KYT");
        kycSteps.systemStartsAutoValidation();
        kycSteps.systemFailsAutoValidation(); // -> MANUAL_REVIEW

        kycSteps.agentRequestsComplianceOpinion(); // -> PENDING_COMPLIANCE
        kycSteps.complianceResponds();

        kycSteps.agentValidatesBlock(); // -> VALIDATED_AGENT
    }

    @Test
    @Story("Processus 4-Eyes Check")
    @DisplayName("🔒 Verrouillage pour 4-Eyes Check")
    @Description("Avant finalisation, le bloc est verrouillé pour contrôle qualité.")
    @Tag("lifecycle")
    @Tag("quality")
    void fourEyesCheckLock() {
        kycSteps.blockIsInitialized("KYC (Wealth)");
        kycSteps.agentValidatesBlock();

        kycSteps.trigger4EyesCheck();
        kycSteps.blockIsLocked(); // Status LOCKED
    }
}
