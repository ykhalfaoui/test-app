package com.remediation.sharedkernel;

import java.util.UUID;

public record ReviewId(UUID value) {}
