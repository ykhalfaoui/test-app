package com.remediation.sharedkernel;

import java.util.UUID;

/**
 * A Value Object representing a unique ID for tracing a request across multiple modules.
 */
public record TraceId(String value) {
    public static TraceId create() {
        return new TraceId(UUID.randomUUID().toString());
    }
}
