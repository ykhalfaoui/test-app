package com.remediation.member.application;

import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.sharedkernel.CustomerId;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;

@Service
class MemberCompositionService {

    private final ApplicationEventPublisher events;

    MemberCompositionService(ApplicationEventPublisher events) {
        this.events = events;
    }

    /**
     * Listens for the start of a review to begin composing the family.
     */
    @ApplicationModuleListener
    public void on(ReviewInstanceStartedEvent event) {
        System.out.println("[MemberContext] || Received ReviewInstanceStartedEvent. Composing family for review: " + event.reviewId().value() + " | TraceId: " + event.traceId().value());

        // In a real app, this would involve complex logic and API calls to find relations
        int familySize = 5; // Simulate finding 5 members

        for (int i = 0; i < familySize; i++) {
            var memberId = new CustomerId("customer-" + i);
            // Propagate the traceId
            var memberEvent = new ReviewMemberIdentifiedEvent(event.traceId(), event.reviewId(), memberId, "MEMBER");
            System.out.println("[MemberContext] || Publishing " + memberEvent);
            events.publishEvent(memberEvent);
        }

        // Publish a final event when composition is done, also with the traceId
        events.publishEvent(new com.remediation.member.api.event.FamilyCompositionCompletedEvent(event.traceId(), event.reviewId(), familySize));
    }
}
