package com.remediation.audit.api;

import com.remediation.sharedkernel.TraceId;

public interface AuditService {
    void logEvent(TraceId traceId, String eventType, String entityId, Object details);
    void logError(Object methodSignature, Throwable error);
}
