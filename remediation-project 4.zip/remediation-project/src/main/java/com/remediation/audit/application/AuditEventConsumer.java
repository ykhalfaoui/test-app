package com.remediation.audit.application;

import com.remediation.audit.api.AuditService;
import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.block.api.event.BlockReviewStartedEvent;
import com.remediation.member.api.event.FamilyCompositionCompletedEvent;
import com.remediation.member.api.event.ReviewMemberIdentifiedEvent;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

@Component
class AuditEventConsumer {

    private final AuditService auditService;

    AuditEventConsumer(AuditService auditService) {
        this.auditService = auditService;
    }

    @ApplicationModuleListener
    void on(HitQualifiedPositiveEvent event) {
        auditService.logEvent(event.traceId(), "HitQualifiedPositive", event.hitId().value().toString(), event);
    }

    @ApplicationModuleListener
    void on(ReviewInstanceStartedEvent event) {
        auditService.logEvent(event.traceId(), "ReviewInstanceStarted", event.reviewId().value().toString(), event);
    }

    @ApplicationModuleListener
    void on(FamilyCompositionCompletedEvent event) {
        auditService.logEvent(event.traceId(), "FamilyCompositionCompleted", event.reviewId().value().toString(), event);
    }

    @ApplicationModuleListener
    void on(ReviewMemberIdentifiedEvent event) {
        auditService.logEvent(event.traceId(), "ReviewMemberIdentified", event.customerId().value(), event);
    }

    @ApplicationModuleListener
    void on(BlockReadyForReviewEvent event) {
        auditService.logEvent(event.traceId(), "BlockReadyForReview", event.blockId().value().toString(), event);
    }
}
