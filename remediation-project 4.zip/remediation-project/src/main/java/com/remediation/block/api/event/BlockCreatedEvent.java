package com.remediation.block.api.event;

import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;

public record BlockCreatedEvent(
    BlockId blockId,
    CustomerId customerId
) {}
