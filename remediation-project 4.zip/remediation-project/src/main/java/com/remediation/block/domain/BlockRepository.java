package com.remediation.block.domain;

package com.remediation.block.domain;

import com.remediation.block.api.Block;
import com.remediation.sharedkernel.BlockId;
import com.remediation.sharedkernel.CustomerId;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

public interface BlockRepository extends Repository<Block, BlockId> {
    void save(Block block);
    Optional<Block> findById(BlockId id);
    List<Block> findByCustomerId(CustomerId customerId);
}
