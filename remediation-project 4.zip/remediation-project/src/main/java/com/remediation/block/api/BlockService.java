package com.remediation.block.api;

package com.remediation.block.api;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;

import java.util.List;

public interface BlockService {
    List<Block> getBlocksForCustomer(CustomerId customerId);
    void startReviewOnBlock(BlockId blockId, ReviewId reviewId);
}
