@org.springframework.modulith.ApplicationModule(
    allowedDependencies = {"sharedkernel", "member"} // Now depends on member module
)
package com.remediation.block;