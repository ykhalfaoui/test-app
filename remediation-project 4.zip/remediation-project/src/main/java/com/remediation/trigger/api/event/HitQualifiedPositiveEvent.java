package com.remediation.trigger.api.event;

package com.remediation.trigger.api.event;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.HitId;
import com.remediation.sharedkernel.TraceId;

public record HitQualifiedPositiveEvent(
    TraceId traceId,
    HitId hitId,
    CustomerId customerId
) {}
