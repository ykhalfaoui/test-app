package com.remediation.trigger.application;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.HitId;
import com.remediation.sharedkernel.TraceId;
import com.remediation.trigger.api.HitService;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
class HitServiceImpl implements HitService {

    private final ApplicationEventPublisher events;

    HitServiceImpl(ApplicationEventPublisher events) {
        this.events = events;
    }

    @Override
    public void processIncomingHit(TraceId traceId, String payload) {
        // 1. Parse and validate payload
        var customerId = new CustomerId("customer-123");

        // 2. Qualify the hit
        boolean isPositive = qualify(payload);

        // 3. If positive, publish an event with the traceId
        if (isPositive) {
            var event = new HitQualifiedPositiveEvent(traceId, new HitId(UUID.randomUUID()), customerId);
            System.out.println("[TriggerContext] || Publishing HitQualifiedPositiveEvent with TraceId: " + traceId.value());
            events.publishEvent(event);
        }
    }

    private boolean qualify(String payload) {
        System.out.println("Qualifying hit: " + payload);
        return true;
    }
}
