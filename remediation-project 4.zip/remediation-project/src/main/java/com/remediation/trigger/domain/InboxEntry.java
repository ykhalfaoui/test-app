package com.remediation.trigger.domain;

import java.util.UUID;

// Entity representing a message in the inbox
public class InboxEntry {
    public enum InboxStatus { PROCESSED, FAILED_DESERIALIZATION }

    private UUID eventId;
    private InboxStatus status;
    private String payload;
    private String errorMessage;

    // Constructors, getters...
}
