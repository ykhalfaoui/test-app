package com.remediation.trigger.domain;

package com.remediation.trigger.domain;

import java.util.Optional;
import java.util.UUID;

public interface InboxRepository {
    boolean existsById(UUID eventId);
    void save(InboxEntry entry);
}
