package com.remediation.trigger.api;

import com.remediation.sharedkernel.TraceId;

public interface HitService {
    void processIncomingHit(TraceId traceId, String payload);
}
