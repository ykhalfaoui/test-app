@org.springframework.modulith.ApplicationModule(
    allowedDependencies = {"sharedkernel", "block"} // Depends on block for BlockReadyForReviewEvent
)
package com.remediation.review;