package com.remediation.review.domain;

import com.remediation.sharedkernel.ReviewId;
import org.springframework.data.repository.Repository;
import java.util.Optional;
import java.util.UUID;

public interface ReviewSagaRepository extends Repository<ReviewSaga, UUID> {
    void save(ReviewSaga saga);
    Optional<ReviewSaga> findByReviewInstanceId(ReviewId reviewInstanceId);
}