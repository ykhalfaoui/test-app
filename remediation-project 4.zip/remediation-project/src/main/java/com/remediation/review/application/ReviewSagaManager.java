package com.remediation.review.application;

import com.remediation.block.api.event.BlockReadyForReviewEvent;
import com.remediation.review.api.event.ReviewMemberRequiresBlocksEvent;
import com.remediation.review.domain.ReviewInstance;
import com.remediation.review.domain.ReviewInstanceRepository;
import com.remediation.review.domain.ReviewSaga;
import com.remediation.review.domain.ReviewSagaRepository;
import com.remediation.sharedkernel.CustomerId;
import com.remediation.trigger.api.event.HitQualifiedPositiveEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class ReviewSagaManager {

    private final ReviewInstanceRepository reviewRepository;
    private final ReviewSagaRepository sagaRepository;
    private final ApplicationEventPublisher events;

    ReviewSagaManager(ReviewInstanceRepository reviewRepository, ReviewSagaRepository sagaRepository, ApplicationEventPublisher events) {
        this.reviewRepository = reviewRepository;
        this.sagaRepository = sagaRepository;
        this.events = events;
    }

    @ApplicationModuleListener
    @Transactional
    public void on(HitQualifiedPositiveEvent hitEvent) {
        System.out.println("[SAGA] || Received Hit, creating ReviewInstance for customer: " + hitEvent.customerId().value());

        // 1. Create the main ReviewInstance aggregate
        var reviewInstance = new ReviewInstance(hitEvent.customerId(), "HIT");
        reviewRepository.save(reviewInstance);

        // 2. Create and persist the Saga state machine, waiting for family composition
        var saga = new ReviewSaga(reviewInstance.getId(), hitEvent.customerId(), 0); // Family size is unknown at this point
        sagaRepository.save(saga);

        // 3. Publish the event that will trigger the MemberContext to compose the family
        events.publishEvent(new ReviewInstanceStartedEvent(reviewInstance.getId(), hitEvent.customerId(), "HIT"));
    }

    /**
     * Listens for the completion of the family composition to set expectations.
     */
    @ApplicationModuleListener
    @Transactional
    public void on(com.remediation.member.api.event.FamilyCompositionCompletedEvent event) {
        System.out.println("[SAGA] || Family composition completed for review: " + event.reviewId().value());
        sagaRepository.findByReviewInstanceId(event.reviewId()).ifPresent(saga -> {
            saga.setExpectations(event.memberCount());
            sagaRepository.save(saga);
        });
    }

    @ApplicationModuleListener
    @Transactional
    public void on(BlockReadyForReviewEvent blockReadyEvent) {
        System.out.println("[SAGA] || Received BlockReadyForReviewEvent for review: " + blockReadyEvent.reviewId().value() + " | TraceId: " + blockReadyEvent.traceId().value());
        
        var saga = sagaRepository.findByReviewInstanceId(blockReadyEvent.reviewId()).orElse(null);
        if (saga == null || saga.getStatus() != ReviewSaga.SagaStatus.COLLECTING_BLOCKS) {
            return; // Saga not found or not in the right state
        }

        System.out.println("[SAGA] || Creating ReviewTarget for Block: " + blockReadyEvent.blockId().value());

        saga.incrementProcessedMembers();
        System.out.println("[SAGA] || Progress: " + saga.getMembersProcessed() + "/" + saga.getMembersToProcess());

        if (saga.getStatus() == ReviewSaga.SagaStatus.COMPLETED) {
            System.out.println("[SAGA] || Review process " + saga.getReviewInstanceId().value() + " is complete!");
        }
        
        sagaRepository.save(saga);
    }
}
