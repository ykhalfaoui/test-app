package com.remediation.review.domain;

import com.remediation.sharedkernel.CustomerId;
import com.remediation.sharedkernel.ReviewId;

import java.util.UUID;

public class ReviewSaga {

    public enum SagaStatus { STARTED, COLLECTING_BLOCKS, COMPLETED, FAILED }

    private UUID id;
    private ReviewId reviewInstanceId;
    private CustomerId customerId;
    private SagaStatus status;
    private int membersToProcess;
    private int membersProcessed;

    public ReviewSaga(ReviewId reviewInstanceId, CustomerId customerId, int familySize) {
        this.id = UUID.randomUUID();
        this.reviewInstanceId = reviewInstanceId;
        this.customerId = customerId;
        this.membersToProcess = familySize;
        this.membersProcessed = 0;
        this.status = SagaStatus.STARTED;
    }

    public void setExpectations(int memberCount) {
        this.membersToProcess = memberCount;
        this.status = SagaStatus.COLLECTING_BLOCKS;
    }

    public void incrementProcessedMembers() {
        this.membersProcessed++;
        if (this.membersProcessed >= this.membersToProcess) {
            this.status = SagaStatus.COMPLETED;
        }
    }

    public ReviewId getReviewInstanceId() { return reviewInstanceId; }
    public SagaStatus getStatus() { return status; }
    public int getMembersToProcess() { return membersToProcess; }
    public int getMembersProcessed() { return membersProcessed; }
}