package com.remediation.review.domain;

import com.remediation.review.api.ReviewId;
import org.springframework.data.repository.Repository;

import java.util.Optional;

public interface ReviewInstanceRepository extends Repository<ReviewInstance, ReviewId> {
    void save(ReviewInstance reviewInstance);
    Optional<ReviewInstance> findById(ReviewId id);
}