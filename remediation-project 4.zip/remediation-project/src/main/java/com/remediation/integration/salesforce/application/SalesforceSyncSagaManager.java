package com.remediation.integration.salesforce.application;

import com.remediation.integration.salesforce.domain.SalesforceSyncSaga;
import com.remediation.integration.salesforce.domain.SalesforceSyncSagaRepository;
import com.remediation.review.api.event.ReviewInstanceStartedEvent;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
class SalesforceSyncSagaManager {

    private static final int BATCH_SIZE = 100;

    private final SalesforceSyncSagaRepository sagaRepository;
    // private final SalesforceClient salesforceClient;

    SalesforceSyncSagaManager(SalesforceSyncSagaRepository sagaRepository) {
        this.sagaRepository = sagaRepository;
    }

    @ApplicationModuleListener
    @Transactional
    public void on(ReviewInstanceStartedEvent event) {
        System.out.println("[SF-SAGA] || Received ReviewInstanceStartedEvent, starting Salesforce sync for review: " + event.reviewId().value());

        List<String> membersToSync = List.of("customer-1", "customer-2", "... up to 500");

        var saga = new SalesforceSyncSaga(event.reviewId(), membersToSync);
        sagaRepository.save(saga);

        continueSaga(saga.getId());
    }

    @Transactional
    public void continueSaga(UUID sagaId) {
        sagaRepository.findById(sagaId).ifPresent(saga -> {
            switch (saga.getStatus()) {
                case NOT_STARTED:
                    System.out.println("[SF-SAGA] || Step: Creating review in Salesforce...");
                    saga.reviewCreationStarted();
                    // String sfId = salesforceClient.createDraftReview(...);
                    // saga.reviewCreated(sfId);
                    saga.reviewCreated("sf-review-id-123"); // Simulate success
                    break;

                case SYNCING_MEMBERS:
                    List<String> batch = saga.getNextBatch(BATCH_SIZE);
                    if (batch.isEmpty()) {
                        System.out.println("[SF-SAGA] || All members synced.");
                        break; // Should have been caught by markBatchAsSynced, but as a safeguard.
                    }

                    System.out.println("[SF-SAGA] || Step: Syncing a batch of " + batch.size() + " members...");
                    try {
                        // salesforceClient.bulkCreateMembers(batch);
                        System.out.println("[SF-SAGA] || Batch sync successful.");
                        saga.markBatchAsSynced(batch);
                    } catch (Exception e) {
                        System.out.println("[SF-SAGA] || ERROR: Batch sync failed. Will retry later.");
                        saga.failed("Batch sync failed: " + e.getMessage());
                    }
                    break;

                case FINALIZING_STATUS:
                    System.out.println("[SF-SAGA] || Step: Finalizing review status in Salesforce...");
                    // salesforceClient.updateReviewStatus(..., "ACTIVE");
                    saga.completed();
                    break;

                case COMPLETED, FAILED:
                    System.out.println("[SF-SAGA] || Process finished with status: " + saga.getStatus());
                    return; // Stop processing
            }

            sagaRepository.save(saga);

            // If the saga is not finished, trigger the next step
            if (saga.getStatus() != SalesforceSyncSaga.SyncStatus.COMPLETED && saga.getStatus() != SalesforceSyncSaga.SyncStatus.FAILED) {
                // In a real app, this would be an asynchronous call to avoid long-running transactions
                // For example: applicationEventPublisher.publishEvent(new ContinueSagaCommand(sagaId));
                continueSaga(sagaId);
            }
        });
    }
}
