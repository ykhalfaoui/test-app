@org.springframework.modulith.ApplicationModule(
    displayName = "Integration - Salesforce",
    allowedDependencies = {"sharedkernel", "review"} // Now depends on review to listen to its events
)
package com.remediation.integration.salesforce;