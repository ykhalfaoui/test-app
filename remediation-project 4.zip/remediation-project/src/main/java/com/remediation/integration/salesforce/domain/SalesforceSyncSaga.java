package com.remediation.integration.salesforce.domain;

package com.remediation.integration.salesforce.domain;

import com.remediation.sharedkernel.ReviewId;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SalesforceSyncSaga {

    public enum SyncStatus { NOT_STARTED, CREATING_REVIEW, SYNCING_MEMBERS, FINALIZING_STATUS, COMPLETED, FAILED }

    private UUID id;
    private ReviewId reviewId;
    private String salesforceReviewId;
    private SyncStatus status;
    private List<String> pendingMemberIds; // The list of members we still need to sync

    public SalesforceSyncSaga(ReviewId reviewId, List<String> allMemberIds) {
        this.id = UUID.randomUUID();
        this.reviewId = reviewId;
        this.pendingMemberIds = new ArrayList<>(allMemberIds); // Copy the list
        this.status = SyncStatus.NOT_STARTED;
    }

    // --- Methods to advance the saga's state ---

    public void reviewCreationStarted() { this.status = SyncStatus.CREATING_REVIEW; }
    
    public void reviewCreated(String salesforceReviewId) {
        this.salesforceReviewId = salesforceReviewId;
        this.status = SyncStatus.SYNCING_MEMBERS;
    }

    public List<String> getNextBatch(int batchSize) {
        if (pendingMemberIds.isEmpty()) {
            return List.of();
        }
        return pendingMemberIds.stream().limit(batchSize).toList();
    }

    public void markBatchAsSynced(List<String> syncedBatch) {
        this.pendingMemberIds.removeAll(syncedBatch);
        if (this.pendingMemberIds.isEmpty()) {
            this.status = SyncStatus.FINALIZING_STATUS;
        }
    }

    public void completed() { this.status = SyncStatus.COMPLETED; }

    public void failed(String reason) {
        this.status = SyncStatus.FAILED;
        // We could also store the reason for the failure
    }

    // --- Getters ---
    public UUID getId() { return id; }
    public ReviewId getReviewId() { return reviewId; }
    public SyncStatus getStatus() { return status; }
}
