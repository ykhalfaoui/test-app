# KYC — Modulith Docs (Blocks SCD2, Module Communications, Sequences)

This folder contains PlantUML diagrams and a short guide to explain:
- **SCD2 block splitting** (how versions are created/reused),
- **Inter-module communications** with **Spring Modulith** (events after commit),
- **Key sequences** from hit qualification to review closure and integration.

## Files
- `blocks-splitting.puml` — Activity diagram for `ensureOpenVersion(partyId, kind)`.
- `modules-communications.puml` — Component view showing modules and event flows.
- `seq-hit-review-targets.puml` — Hit → Review start → Targets created.
- `seq-block-finalize-review-progress.puml` — Block finalized → Review progresses → Close.
- `seq-concurrent-targets.puml` — Two targets in parallel on different block kinds.
- `seq-integration-outbox-retry.puml` — Outbox + retry pattern for Salesforce.

## Rendering
Use the PlantUML VS Code extension, IntelliJ plugin, or CLI:
```bash
# with plantuml.jar and Graphviz installed
java -jar plantuml.jar *.puml
# renders PNGs/SVGs next to source files
```

## Design choices (cheat sheet)
- **Ownership:** a `Party` owns at most one `Block` per `kind` (UNIQUE(party, kind)).
- **SCD2:** exactly one current version per block (`validTo IS NULL`), enforced by DB index.
- **Coalescing:** if a version is **IN_REVIEW/PENDING_AGENT**, reuse it; don’t create duplicates.
- **Events after commit:** `@ApplicationModuleListener` with JPA event publication, optional republish on restart.
- **Idempotent targets:** `ReviewTarget` key = `(reviewId, targetPartyId, blockKind)`.
- **Integration:** outbox + retry + DLQ; never block domain tx on external calls.

## Where this fits in the blueprint
- *Architecture* → *Modules & Interactions* → include `modules-communications.puml`.
- *Domain mechanics* → *Blocks Versioning (SCD2)* → include `blocks-splitting.puml`.
- *Runtime behavior* → *Key Sequences* → include the four sequence diagrams.


## Module Decomposition
- Guide: [modules-decomposition.md](./modules-decomposition.md)
- Diagram: [modules-decomposition.puml](./modules-decomposition.puml)
