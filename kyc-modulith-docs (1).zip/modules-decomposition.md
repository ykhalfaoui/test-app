# Découpage des modules (Spring Modulith) — Lignes directrices

> **TL;DR** : Commencer simple (un module `blocks` avec des politiques par *kind*). Extraire en sous-modules **uniquement** quand un *kind* justifie des dépendances/SLA/volumétrie/équipe distincts. Éviter les cycles, garder des **événements génériques**, et vérifier l’archi avec **Modulith**.

## 1. Objectifs
- **Cohésion** : chaque module porte une responsabilité claire (Party, Blocks SCD2, Hits, Review, Relations, Integration, Audit, Kyc360).
- **Couplage faible** : échanges par **événements après commit** (Modulith).
- **Évolutivité** : permettre d’extraire un *kind* “lourd” (ex. `DOCUMENTS`) sans refactor massif.

## 2. Options de découpage
### Option A — Un seul module `blocks` (recommandé au départ)
- `blocks/core` : `Block`, `BlockVersion`, SCD2, `BlockService`, events.
- `blocks/policy` : interface `BlockKindPolicy` + implémentations (`NameScreeningPolicy`, `DocumentsPolicy`, …).
- Avantages : simplicité, pas de cycles, dev rapide.
- Limites : si un *kind* nécessite des lib lourdes ou des SLA très différents.

### Option B — Hybride (core + plugins)
- `blocks-core` : modèle SCD2 + `BlockKindPolicy` (interface), **aucune** dépendance métier “kind” spécifique.
- `blocks-documents` : impl `BlockKindPolicy("DOCUMENTS")` (+ deps fichiers/antivirus).
- `blocks-screening` : impl `BlockKindPolicy("NAME_SCREENING")` (+ SDK provider).
- Avantages : isolation des deps, déploiement ciblé (si besoin), responsabilités nettes.
- Limites : complexité de build, gouvernance des interfaces.

### Option C — Modules totalement séparés (à éviter au début)
- Seulement si équipes/systèmes séparés et invariants très différents.
- Risque de duplication de la logique SCD2 et de prolifération d’événements.

## 3. Critères de bascule A ➜ B
- **Dépendances spécifiques** (SDK screening, parsers PDF, moteurs AML).
- **SLA / sécurité** différenciés (PII très sensible, chiffrement spécifique).
- **Volumétrie/stockage** (blobs, lifecycle management).
- **Organisation** (équipe dédiée, cadence de release).
- **Taille/complexité** (> ~1–2k LOC ou tests trop lents).

## 4. Règles d’implémentation
- `Block` appartient à un `Party` ; **UNIQUE(partyId, kind)**.
- `BlockVersion` suit **SCD2** ; **une seule courante** (`validTo IS NULL`) garantie en base.
- **Idempotence** : `ReviewTarget` = `(reviewId, targetPartyId, blockKind)`.
- **Politique par kind** via `BlockKindPolicy` (statut initial, validation, mapping d’intégration).
- **Événements génériques** : `BlockReviewRequested`, `BlockVersionFinalized`, `HitQualified`, `ReviewStarted/Closed`.
- **Modulith** : utiliser `@ApplicationModuleListener` et vérifier l’archi (`ApplicationModules.verify()`).
- **Pas de cycles** : `blocks-core` ne dépend pas de plugins ; plugins **implémentent** l’interface uniquement.

## 5. Anti‑patterns à éviter
- Enum de *kind* figée dans 5 modules différents → préférez des **String** + policies.
- Listeners qui appellent en synchrone d’autres modules (couplage fort) → préférez **événements**.
- Répéter la logique SCD2 par *kind* → centraliser dans `blocks-core`.
- `try/catch` vides dans les listeners → utiliser **retry + outbox/DLQ**, relancer si non récupérable.

## 6. Vérification & Doc automatisées
### Test de vérification d’architecture
```java
@Test
void verify_modules() {
  ApplicationModules.of(App.class).verify();
}
```
### Génération de doc (diagrams & canvas)
```java
var modules = ApplicationModules.of(App.class);
new Documenter(modules).writeDocumentation();
```

## 7. Diagrammes
- **Component (communications)** : `modules-communications.puml`
- **Décomposition (A vs Hybride)** : `modules-decomposition.puml`

---

# Module Decomposition (Spring Modulith) — Guidelines (EN)

## 1. Goals
- **Cohesion** per module (Party, Blocks SCD2, Hits, Review, Relations, Integration, Audit, Kyc360).
- **Loose coupling** via **after‑commit events** (Modulith).
- **Evolvability**: extract heavy kinds (e.g., `DOCUMENTS`) without large refactor.

## 2. Options
- **Option A — Single `blocks` module** (start here): SCD2 core + `BlockKindPolicy` implementations inside.
- **Option B — Hybrid (core + plugins)**: `blocks-core` (SCD2 + interface), `blocks-documents`, `blocks-screening`… implementing the policy.
- **Option C — Fully split modules** only for strong org/runtime boundaries; avoid early.

## 3. Switch criteria (A ➜ B)
Distinct deps, SLA/security, storage/volume, team ownership, or size/complexity thresholds.

## 4. Rules
Ownership, SCD2 invariants, idempotent targets, policy-per-kind, generic events, Modulith verification, no cycles from core to plugins.

## 5. Anti‑patterns
Enum scattering, synchronous cross-module calls, duplicated SCD2 logic, swallowed exceptions.

## 6. Tooling
`ApplicationModules.verify()` and `Documenter` to generate diagrams/canvas.

See also: `modules-communications.puml`, `modules-decomposition.puml`.
