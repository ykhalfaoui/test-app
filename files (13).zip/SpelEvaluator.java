package com.crok4it.audit.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Responsabilité unique : évaluer une expression SpEL sur les arguments d'un join point.
 *
 * PATTERNS SUPPORTÉS :
 *   #payload.reviewId    → par nom de paramètre Java (-parameters requis)
 *   #root[0].id          → par index (toujours disponible)
 *   'salesforce'         → littéral string
 *
 * SÉCURITÉ : toute exception SpEL retourne null sans propager.
 * PERFORMANCE : les expressions sont compilées et cachées après le premier appel.
 */
@Component
class SpelEvaluator {

    private static final Logger log = LoggerFactory.getLogger(SpelEvaluator.class);

    private final ExpressionParser parser = new SpelExpressionParser();
    private final ConcurrentHashMap<String, Expression> cache = new ConcurrentHashMap<>();

    /**
     * Évalue une expression SpEL.
     *
     * @param expression  expression SpEL, null ou blank retourne null
     * @param joinPoint   contexte AOP avec les arguments
     * @return            résultat toString(), ou null si expression vide / erreur
     */
    String evaluate(String expression, ProceedingJoinPoint joinPoint) {
        if (!StringUtils.hasText(expression)) return null;

        try {
            var ctx = buildContext(joinPoint);
            var expr = cache.computeIfAbsent(expression, parser::parseExpression);
            Object result = expr.getValue(ctx);
            return result != null ? result.toString() : null;
        } catch (Exception e) {
            log.warn("SpEL eval failed '{}' on '{}': {}",
                    expression, joinPoint.getSignature().getName(), e.getMessage());
            return null;
        }
    }

    private StandardEvaluationContext buildContext(ProceedingJoinPoint jp) {
        Object[] args   = jp.getArgs();
        var ctx = new StandardEvaluationContext();

        // #root[0], #root[1] — accès par index, toujours disponible
        ctx.setRootObject(args);

        // #paramName — accès par nom, nécessite -parameters à la compilation
        // spring-boot-starter-parent l'active depuis Boot 3.2
        Method method = ((MethodSignature) jp.getSignature()).getMethod();
        var params = method.getParameters();
        for (int i = 0; i < params.length && i < args.length; i++) {
            ctx.setVariable(params[i].getName(), args[i]);
        }

        return ctx;
    }
}
