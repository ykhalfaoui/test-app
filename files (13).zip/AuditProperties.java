package com.crok4it.audit.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration externalisée du module audit.
 *
 * application.yml :
 * audit:
 *   stacktrace-max-length: 4000
 *   enabled: true
 */
@ConfigurationProperties(prefix = "audit")
public class AuditProperties {

    /** Longueur max de la stacktrace capturée (caractères). */
    private int stacktraceMaxLength = 4000;

    /** Désactive tout le module sans retirer les dépendances. */
    private boolean enabled = true;

    public int getStacktraceMaxLength() { return stacktraceMaxLength; }
    public void setStacktraceMaxLength(int v) { this.stacktraceMaxLength = v; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { this.enabled = v; }
}
