package com.crok4it.audit.annotation;

import java.lang.annotation.*;

/**
 * Marque un point d'entrée de flux pour l'audit automatique.
 *
 * SpEL — variables disponibles dans les expressions :
 *   #nomParam        → par nom de paramètre (ex: #payload.reviewId)
 *   #root[0], #root[1] → par index (ex: #root[0].id)
 *   'valeur'         → littéral string (ex: "'salesforce'")
 *
 * Exemples :
 * {@code
 * @Auditable(action = "REVIEW_SYNC", entityId = "#payload.reviewId")
 * public void sync(ReviewPayload payload) {}
 *
 * @Auditable(action = "BLOCK", entityId = "#root[0]")
 * public void block(String memberId) {}
 * }
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Auditable {

    /** Nom de l'action — ex: "REVIEW_SYNC", "MEMBER_BLOCK". */
    String action();

    /** Type d'entité — ex: "Review", "Member". */
    String entityType() default "";

    /** SpEL → identifiant de l'entité. */
    String entityId() default "";

    /** SpEL → identifiant de corrélation métier. */
    String correlationId() default "";

    /** SpEL ou littéral → module source — ex: "'salesforce'". */
    String module() default "";

    /** Sérialise les arguments d'entrée en JSON. Désactiver si données sensibles. */
    boolean captureArgs() default false;

    /** Re-propage l'exception après audit. False = avale l'exception (prudence). */
    boolean rethrowException() default true;
}
