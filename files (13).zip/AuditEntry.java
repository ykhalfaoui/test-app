package com.crok4it.audit.entity;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Entrée d'audit — persistée dans une transaction REQUIRES_NEW indépendante
 * de la transaction métier appelante.
 *
 * Lombok gère le builder, les getters et les constructeurs.
 * @PrePersist assigne l'id et le timestamp si absents.
 */
@Entity
@Table(
    name = "audit_entry",
    indexes = {
        @Index(name = "idx_ae_entity",      columnList = "entity_type,entity_id"),
        @Index(name = "idx_ae_action",      columnList = "action"),
        @Index(name = "idx_ae_trace",       columnList = "trace_id"),
        @Index(name = "idx_ae_correlation", columnList = "correlation_id"),
        @Index(name = "idx_ae_status",      columnList = "status"),
        @Index(name = "idx_ae_created",     columnList = "created_at")
    }
)
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditEntry {

    @Id
    @Column(updatable = false, nullable = false, length = 36)
    private String id;

    @Column(nullable = false, length = 100)
    private String action;

    @Column(length = 100)
    private String entityType;

    @Column(length = 255)
    private String entityId;

    @Column(length = 255)
    private String correlationId;

    @Column(length = 100)
    private String module;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AuditStatus status;

    @Column(columnDefinition = "TEXT")
    private String inputPayload;

    @Column(length = 255)
    private String errorClass;

    @Column(columnDefinition = "TEXT")
    private String errorMessage;

    @Column(columnDefinition = "TEXT")
    private String stacktrace;

    @Column(length = 64)
    private String traceId;

    @Column(length = 32)
    private String spanId;

    @Column(length = 500)
    private String methodSignature;

    private Long durationMs;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void prePersist() {
        if (id == null)        id = UUID.randomUUID().toString();
        if (createdAt == null) createdAt = Instant.now();
    }

    public enum AuditStatus { SUCCESS, ERROR }
}
