package com.crok4it.audit;

import com.crok4it.audit.annotation.Auditable;
import com.crok4it.audit.entity.AuditEntry;
import com.crok4it.audit.repository.AuditEntryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class AuditableAspectTest {

    @Autowired AuditEntryRepository repo;
    @Autowired Target target;

    @BeforeEach void clean() { repo.deleteAll(); }

    // ── SpEL ──────────────────────────────────────────────────────────────

    @Nested @DisplayName("SpEL")
    class SpelTests {

        @Test @DisplayName("par nom de paramètre")
        void byParamName() {
            target.byName(new Payload("r-1", "m-1"));
            var e = single();
            assertThat(e.getEntityId()).isEqualTo("r-1");
            assertThat(e.getCorrelationId()).isEqualTo("m-1");
            assertThat(e.getModule()).isEqualTo("salesforce");
        }

        @Test @DisplayName("par index #root[0]")
        void byIndex() {
            target.byIndex("entity-42", "corr-7");
            assertThat(single().getEntityId()).isEqualTo("entity-42");
        }

        @Test @DisplayName("expression invalide → null, pas de crash")
        void badSpel_noException() {
            assertThatNoException().isThrownBy(() -> target.badSpel(new Payload("r", "m")));
            assertThat(single().getEntityId()).isNull();
            assertThat(single().getStatus()).isEqualTo(AuditEntry.AuditStatus.SUCCESS);
        }
    }

    // ── Erreurs ───────────────────────────────────────────────────────────

    @Nested @DisplayName("Erreurs")
    class ErrorTests {

        @Test @DisplayName("exception → ERROR + errorClass + stacktrace")
        void exception_capturedAsError() {
            assertThatThrownBy(() -> target.failing("e-1"))
                    .isInstanceOf(IllegalStateException.class);

            var e = single();
            assertThat(e.getStatus()).isEqualTo(AuditEntry.AuditStatus.ERROR);
            assertThat(e.getErrorClass()).isEqualTo("java.lang.IllegalStateException");
            assertThat(e.getErrorMessage()).isEqualTo("boom");
            assertThat(e.getStacktrace()).isNotBlank();
        }

        @Test @DisplayName("REQUIRES_NEW — audit ERROR persisté malgré rollback TX métier")
        void requiresNew_persistedDespiteRollback() {
            assertThatThrownBy(() -> target.failingWithTx("e-tx"))
                    .isInstanceOf(RuntimeException.class);

            // La TX métier a rollback, l'audit doit quand même exister
            assertThat(repo.findAll()).hasSize(1)
                    .first()
                    .satisfies(e -> assertThat(e.getStatus()).isEqualTo(AuditEntry.AuditStatus.ERROR));
        }

        @Test @DisplayName("rethrowException=false avale l'exception")
        void noRethrow_exceptionSwallowed() {
            assertThatNoException().isThrownBy(() -> target.silentFail("e-silent"));
            assertThat(single().getStatus()).isEqualTo(AuditEntry.AuditStatus.ERROR);
        }
    }

    // ── Succès ────────────────────────────────────────────────────────────

    @Nested @DisplayName("Succès")
    class SuccessTests {

        @Test @DisplayName("SUCCESS + traceId + durationMs + methodSignature")
        void success_allFieldsSet() {
            target.byName(new Payload("r", "m"));
            var e = single();
            assertThat(e.getStatus()).isEqualTo(AuditEntry.AuditStatus.SUCCESS);
            assertThat(e.getDurationMs()).isNotNull().isGreaterThanOrEqualTo(0);
            assertThat(e.getMethodSignature()).contains("byName");
            assertThat(e.getCreatedAt()).isNotNull();
            // traceId peut être null si pas de bridge Micrometer en test
        }

        @Test @DisplayName("captureArgs=true → inputPayload JSON")
        void captureArgs() {
            target.withArgs(new Payload("r-cap", "m-cap"));
            assertThat(single().getInputPayload()).contains("r-cap");
        }
    }

    // ── Limitation AOP ────────────────────────────────────────────────────

    @Nested @DisplayName("AOP proxy")
    class AopTests {

        @Test @DisplayName("self-invocation (this.xxx) — aspect NON déclenché — comportement attendu")
        void selfInvocation_notIntercepted() {
            target.callsSelf(); // appelle this.byName() — bypasse le proxy
            assertThat(repo.findAll()).isEmpty(); // aucune entrée — normal
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    AuditEntry single() {
        var all = repo.findAll();
        assertThat(all).hasSize(1);
        return all.get(0);
    }

    // ── Service de test ───────────────────────────────────────────────────

    @Service
    static class Target {

        @Auditable(action = "BY_NAME", entityId = "#payload.reviewId",
                   correlationId = "#payload.memberId", module = "'salesforce'")
        public void byName(Payload payload) {}

        @Auditable(action = "BY_INDEX", entityId = "#root[0]", correlationId = "#root[1]")
        public void byIndex(String entityId, String correlationId) {}

        @Auditable(action = "BAD_SPEL", entityId = "#payload.nonExistent")
        public void badSpel(Payload payload) {}

        @Auditable(action = "FAILING", entityId = "#root[0]")
        public void failing(String id) { throw new IllegalStateException("boom"); }

        @Auditable(action = "FAILING_TX", entityId = "#root[0]")
        @Transactional
        public void failingWithTx(String id) { throw new RuntimeException("rollback"); }

        @Auditable(action = "SILENT", entityId = "#root[0]", rethrowException = false)
        public void silentFail(String id) { throw new RuntimeException("swallowed"); }

        @Auditable(action = "WITH_ARGS", entityId = "#payload.reviewId", captureArgs = true)
        public void withArgs(Payload payload) {}

        /** Self-invocation — l'aspect NE sera PAS déclenché sur byName(). */
        public void callsSelf() { this.byName(new Payload("x", "y")); }
    }

    record Payload(String reviewId, String memberId) {}
}
