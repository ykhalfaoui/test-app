package com.crok4it.audit.service;

import com.crok4it.audit.entity.AuditEntry;
import com.crok4it.audit.repository.AuditEntryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Port de sortie pour la persistance de l'audit.
 *
 * Interface séparée de l'implémentation pour permettre :
 *   - Remplacement par une implémentation async (ApplicationEventPublisher)
 *   - Remplacement par Elasticsearch, MongoDB, etc.
 *   - Mock facile dans les tests sans Spring context complet
 *
 * Implémentation par défaut : JpaAuditWriter (ci-dessous).
 * Pour remplacer, déclarer un bean de type AuditWriter dans ta config.
 */
public interface AuditWriter {
    void write(AuditEntry entry);
}

/**
 * Implémentation JPA par défaut — actif seulement si aucun autre AuditWriter n'est déclaré.
 *
 * REQUIRES_NEW garantit que l'audit est sauvegardé même si la TX métier rollback.
 * Les erreurs de persistance sont loguées mais ne propagent jamais vers le flux métier.
 */
@Component
@ConditionalOnMissingBean(AuditWriter.class)
class JpaAuditWriter implements AuditWriter {

    private static final Logger log = LoggerFactory.getLogger(JpaAuditWriter.class);

    private final AuditEntryRepository repository;

    JpaAuditWriter(AuditEntryRepository repository) {
        this.repository = repository;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void write(AuditEntry entry) {
        try {
            repository.save(entry);
            log.debug("audit saved action={} entity={}/{} status={} trace={}",
                    entry.getAction(), entry.getEntityType(), entry.getEntityId(),
                    entry.getStatus(), entry.getTraceId());
        } catch (Exception e) {
            log.error("audit write failed action={} entity={} — {}",
                    entry.getAction(), entry.getEntityId(), e.getMessage(), e);
            // Ne jamais propager — l'audit ne doit pas casser le flux métier
        }
    }
}
