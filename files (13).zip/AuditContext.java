package com.crok4it.audit.aspect;

import com.crok4it.audit.annotation.Auditable;
import com.crok4it.audit.config.AuditProperties;
import com.crok4it.audit.entity.AuditEntry;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Responsabilité unique : construire un AuditEntry à partir du contexte d'exécution.
 *
 * Reçoit les informations brutes (joinPoint, exception, durée, résultats SpEL)
 * et produit un AuditEntry prêt à persister.
 *
 * Séparé de l'aspect pour être testable indépendamment sans Spring AOP.
 */
@Component
class AuditContext {

    private static final Logger log = LoggerFactory.getLogger(AuditContext.class);

    private final Tracer tracer;
    private final ObjectMapper objectMapper;
    private final AuditProperties properties;

    AuditContext(Tracer tracer, ObjectMapper objectMapper, AuditProperties properties) {
        this.tracer         = tracer;
        this.objectMapper   = objectMapper;
        this.properties     = properties;
    }

    /** Construit une entrée SUCCESS. */
    AuditEntry success(ProceedingJoinPoint jp, Auditable ann, SpelResult spel, long durationMs) {
        return base(jp, ann, spel, durationMs)
                .status(AuditEntry.AuditStatus.SUCCESS)
                .build();
    }

    /** Construit une entrée ERROR avec les détails de l'exception. */
    AuditEntry error(ProceedingJoinPoint jp, Auditable ann, SpelResult spel, Throwable ex, long durationMs) {
        return base(jp, ann, spel, durationMs)
                .status(AuditEntry.AuditStatus.ERROR)
                .errorClass(ex.getClass().getName())
                .errorMessage(ex.getMessage())
                .stacktrace(extractStacktrace(ex))
                .build();
    }

    /** Partie commune aux deux cas. */
    private AuditEntry.AuditEntryBuilder base(ProceedingJoinPoint jp, Auditable ann,
                                               SpelResult spel, long durationMs) {
        Span span = tracer.currentSpan();
        return AuditEntry.builder()
                .action(ann.action())
                .entityType(emptyToNull(ann.entityType()))
                .entityId(spel.entityId())
                .correlationId(spel.correlationId())
                .module(spel.module())
                .inputPayload(serializeArgs(ann, jp))
                .traceId(span != null ? span.context().traceId() : null)
                .spanId(span  != null ? span.context().spanId()  : null)
                .methodSignature(signature(jp))
                .durationMs(durationMs);
    }

    private String serializeArgs(Auditable ann, ProceedingJoinPoint jp) {
        if (!ann.captureArgs()) return null;
        try {
            return objectMapper.writeValueAsString(jp.getArgs());
        } catch (Exception e) {
            log.debug("cannot serialize args for action={}: {}", ann.action(), e.getMessage());
            return "{\"error\":\"serialization_failed\"}";
        }
    }

    private String extractStacktrace(Throwable ex) {
        var sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        String s = sw.toString();
        int max = properties.getStacktraceMaxLength();
        return s.length() > max ? s.substring(0, max) + "\n...[truncated]" : s;
    }

    private String signature(ProceedingJoinPoint jp) {
        MethodSignature ms = (MethodSignature) jp.getSignature();
        return ms.getDeclaringTypeName() + "." + ms.getName();
    }

    private String emptyToNull(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    /**
     * Résultat de l'évaluation SpEL pour un appel donné.
     * Record Java 17 — immuable, zéro boilerplate.
     */
    record SpelResult(String entityId, String correlationId, String module) {}
}
