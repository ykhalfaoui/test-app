package com.crok4it.audit.repository;

import com.crok4it.audit.entity.AuditEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;

public interface AuditEntryRepository extends JpaRepository<AuditEntry, String> {

    List<AuditEntry> findByEntityTypeAndEntityId(String entityType, String entityId);

    List<AuditEntry> findByCorrelationId(String correlationId);

    List<AuditEntry> findByTraceId(String traceId);

    @Query("SELECT a FROM AuditEntry a WHERE a.status = 'ERROR' AND a.createdAt >= :since ORDER BY a.createdAt DESC")
    List<AuditEntry> findErrorsSince(@Param("since") Instant since);
}
