package com.crok4it.audit.config;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

/**
 * Auto-configuration du module audit.
 *
 * Activée automatiquement si spring-boot-starter-aop est sur le classpath.
 * Enregistrer dans META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
 * si le module est utilisé comme librairie externe.
 *
 * PRÉREQUIS VÉRIFIÉS ICI :
 *   - spring-boot-starter-aop → AspectJ sur le classpath
 *   - spring-boot-starter-data-jpa → JPA disponible
 *
 * PRÉREQUIS À VÉRIFIER DANS LE PROJET :
 *   - Compilation avec -parameters (spring-boot-starter-parent ≥ 3.2 = automatique)
 *   - Table audit_entry créée (schema.sql fourni)
 */
@AutoConfiguration
@ConditionalOnClass(name = "org.aspectj.lang.annotation.Aspect")
@EnableConfigurationProperties(AuditProperties.class)
@ComponentScan(basePackages = "com.crok4it.audit")
public class AuditAutoConfiguration {
    // Tous les beans sont déclarés par @Component dans leurs classes respectives.
    // Cette classe active uniquement le scan et les properties.
}
