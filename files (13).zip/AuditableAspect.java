package com.crok4it.audit.aspect;

import com.crok4it.audit.annotation.Auditable;
import com.crok4it.audit.config.AuditProperties;
import com.crok4it.audit.service.AuditWriter;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Aspect AOP — orchestration pure, aucune logique métier ici.
 *
 * Ordre d'exécution :
 *   1. Évaluation SpEL AVANT proceed() (état initial des args)
 *   2. proceed() — méthode réelle
 *   3. SUCCESS → AuditContext.success() → AuditWriter.write()
 *      ERROR   → AuditContext.error()   → AuditWriter.write() → rethrow si configuré
 *
 * Désactivable via : audit.enabled=false
 */
@Aspect
@Component
@ConditionalOnProperty(name = "audit.enabled", havingValue = "true", matchIfMissing = true)
public class AuditableAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditableAspect.class);

    private final SpelEvaluator spel;
    private final AuditContext  context;
    private final AuditWriter   writer;

    public AuditableAspect(SpelEvaluator spel, AuditContext context, AuditWriter writer) {
        this.spel    = spel;
        this.context = context;
        this.writer  = writer;
    }

    @Around("@annotation(auditable)")
    public Object audit(ProceedingJoinPoint jp, Auditable auditable) throws Throwable {
        // SpEL évalué AVANT proceed() — capture l'état initial des arguments
        var spelResult = new AuditContext.SpelResult(
                spel.evaluate(auditable.entityId(),      jp),
                spel.evaluate(auditable.correlationId(), jp),
                spel.evaluate(auditable.module(),        jp)
        );

        long start = System.currentTimeMillis();

        try {
            Object result = jp.proceed();
            long duration = System.currentTimeMillis() - start;

            safeWrite(context.success(jp, auditable, spelResult, duration));
            return result;

        } catch (Throwable ex) {
            long duration = System.currentTimeMillis() - start;

            safeWrite(context.error(jp, auditable, spelResult, ex, duration));

            if (auditable.rethrowException()) throw ex;
            return null;
        }
    }

    /** L'audit ne doit jamais casser le flux métier. */
    private void safeWrite(com.crok4it.audit.entity.AuditEntry entry) {
        try {
            writer.write(entry);
        } catch (Exception e) {
            log.error("unexpected audit write failure action={}: {}",
                    entry.getAction(), e.getMessage(), e);
        }
    }
}
