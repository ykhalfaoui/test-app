-- ═══════════════════════════════════════════════════════════════════════════
-- DONNÉES DE RÉFÉRENCE POUR LES TESTS
-- Version: 1.0.0
-- Description: Jeux de données stables pour les tests d'intégration
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────────────────────────────────────────────────────────────────────────
-- CLIENTS DE TEST
-- ───────────────────────────────────────────────────────────────────────────

-- Client standard actif
INSERT INTO customers (id, name, type, email, status, order_limit) VALUES
    ('CLIENT_STANDARD', 'Client Test Standard', 'CLIENT_STANDARD', 'standard@test.com', 'ACTIVE', 1000.00);

-- Client VIP avec plafond élevé
INSERT INTO customers (id, name, type, email, status, order_limit) VALUES
    ('CLIENT_VIP', 'Client Test VIP', 'CLIENT_VIP', 'vip@test.com', 'ACTIVE', 10000.00);

-- Client entreprise (B2B)
INSERT INTO customers (id, name, type, email, status, order_limit) VALUES
    ('CLIENT_ENTREPRISE', 'Entreprise Test SARL', 'CLIENT_ENTREPRISE', 'b2b@test.com', 'ACTIVE', 50000.00);

-- Client bloqué (pour tests de sécurité)
INSERT INTO customers (id, name, type, email, status, order_limit) VALUES
    ('CLIENT_BLOQUE', 'Client Bloqué Test', 'CLIENT_STANDARD', 'blocked@test.com', 'BLOCKED', 0.00);

-- Client suspendu (temporairement inactif)
INSERT INTO customers (id, name, type, email, status, order_limit) VALUES
    ('CLIENT_SUSPENDU', 'Client Suspendu Test', 'CLIENT_STANDARD', 'suspended@test.com', 'SUSPENDED', 1000.00);

-- ═══════════════════════════════════════════════════════════════════════════
-- NOTE: Les commandes de test sont créées dynamiquement par les tests
-- avec des UUIDs uniques pour éviter les conflits en exécution parallèle.
-- ═══════════════════════════════════════════════════════════════════════════
