package com.monentreprise.steps.commandes;

import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.actions.ExecuteSQLAction;
import org.citrusframework.actions.ExecuteSQLQueryAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.math.BigDecimal;
import com.monentreprise.utils.SqlUtils;
import java.util.UUID;

/**
 * Steps métier pour le domaine Commandes.
 * 
 * <h2>Objectif</h2>
 * Fournit un vocabulaire métier pour les tests, masquant la complexité
 * technique (SQL, API calls) derrière des méthodes expressives.
 * 
 * <h2>Bénéfices</h2>
 * <ul>
 * <li>Tests lisibles par le métier</li>
 * <li>Maintenance centralisée des requêtes SQL</li>
 * <li>Réutilisation entre tests</li>
 * <li>Rapports Allure propres (pas de SQL visible)</li>
 * </ul>
 * 
 * <h2>Usage</h2>
 * 
 * <pre>{@code
 * @Autowired
 * private CommandeSteps commandeSteps;
 * 
 * void monTest(TestCaseRunner runner) {
 *     commandeSteps.init(runner);
 *     commandeSteps.creerCommande("CLIENT_STANDARD", new BigDecimal("150.00"));
 *     commandeSteps.verifierStatut("PENDING");
 * }
 * }</pre>
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@Component
public class CommandeSteps {

    private static final Logger log = LoggerFactory.getLogger(CommandeSteps.class);

    @Autowired
    @Qualifier("testDataSource")
    private DataSource dataSource;

    private TestCaseRunner runner;
    private String currentOrderId;
    private String currentCustomer;

    // ═══════════════════════════════════════════════════════════════════════════
    // INITIALISATION
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Initialise les steps avec le runner Citrus.
     * À appeler au début de chaque test.
     */
    public CommandeSteps init(TestCaseRunner runner) {
        this.runner = runner;
        this.currentOrderId = null;
        this.currentCustomer = null;
        return this;
    }

    /**
     * Génère un nouvel ID de commande unique.
     */
    public CommandeSteps genererNouvelleReference() {
        this.currentOrderId = "CMD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        runner.variable("orderId", currentOrderId);
        Allure.parameter("📦 Référence commande", currentOrderId);
        log.debug("Nouvelle référence générée: {}", currentOrderId);
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PRÉCONDITIONS (GIVEN)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Prépare l'environnement pour un type de client donné.
     */
    @Step("🔧 Préparation environnement pour client {typeClient}")
    public CommandeSteps environnementPretPourClient(String typeClient) {
        this.currentCustomer = typeClient;
        runner.variable("customer", typeClient);

        Allure.step("Initialisation schéma base de données", () -> {
            runner.$(ExecuteSQLAction.Builder.sql()
                    .dataSource(dataSource)
                    .sqlResource("classpath:sql/schema/01_create_tables.sql"));
        });

        Allure.step("Nettoyage données de test précédentes", () -> {
            runner.$(ExecuteSQLAction.Builder.sql()
                    .dataSource(dataSource)
                    .statement("DELETE FROM order_items WHERE order_id LIKE 'CMD-TEST-%'")
                    .statement("DELETE FROM orders WHERE ref_id LIKE 'CMD-TEST-%'"));
        });

        log.info("Environnement prêt pour client: {}", typeClient);
        return this;
    }

    /**
     * Simule un client authentifié.
     */
    @Step("👤 Client {typeClient} authentifié")
    public CommandeSteps clientAuthentifie(String typeClient) {
        this.currentCustomer = typeClient;
        runner.variable("customer", typeClient);
        runner.variable("customerType", typeClient);

        Allure.parameter("👤 Type client", typeClient);
        log.info("Client authentifié: {}", typeClient);
        return this;
    }

    /**
     * Simule un panier avec un montant donné.
     */
    @Step("🛒 Panier préparé avec montant {montant}€")
    public CommandeSteps panierAvecMontant(BigDecimal montant) {
        runner.variable("orderAmount", montant.toString());
        Allure.parameter("💰 Montant panier", montant + "€");
        log.info("Panier préparé: {}€", montant);
        return this;
    }

    /**
     * Simule un panier avec plusieurs articles.
     */
    @Step("🛒 Panier avec {nbArticles} articles pour {montant}€")
    public CommandeSteps panierAvecArticles(int nbArticles, BigDecimal montant) {
        runner.variable("orderAmount", montant.toString());
        runner.variable("itemCount", String.valueOf(nbArticles));
        Allure.parameter("📦 Nombre d'articles", nbArticles);
        Allure.parameter("💰 Montant total", montant + "€");
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ACTIONS (WHEN)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Crée une nouvelle commande.
     */
    @Step("📦 Création commande pour client {typeClient} - Montant: {montant}€")
    public CommandeSteps creerCommande(String typeClient, BigDecimal montant) {
        if (currentOrderId == null) {
            genererNouvelleReference();
        }

        String now = SqlUtils.now();
        String sql = """
                INSERT INTO orders (ref_id, customer, customer_type, status, amount, created_at, updated_at)
                VALUES ('${orderId}', '%s', '%s', 'PENDING', %s, '%s', '%s')
                """.formatted(SqlUtils.escape(typeClient), SqlUtils.escape(typeClient), montant, now, now);

        SqlUtils.logSql("SQL: Création commande", sql);

        runner.$(ExecuteSQLAction.Builder.sql()
                .dataSource(dataSource)
                .statement(sql));

        attachOrderDetails(typeClient, montant, "PENDING");
        log.info("Commande créée: {} - {}€ - Client: {}", currentOrderId, montant, typeClient);
        return this;
    }

    /**
     * Valide une commande existante (change le statut).
     */
    @Step("✅ Validation de la commande")
    public CommandeSteps validerCommande() {

        String now = SqlUtils.now();
        String sql = """
                UPDATE orders
                SET status = 'VALIDATED', validated_at = '%s', updated_at = '%s'
                WHERE ref_id = '${orderId}'
                """.formatted(now, now);

        SqlUtils.logSql("SQL: Validation commande", sql);

        runner.$(ExecuteSQLAction.Builder.sql()
                .dataSource(dataSource)
                .statement(sql));

        log.info("Commande validée: {}", currentOrderId);
        return this;
    }

    /**
     * Annule une commande.
     */
    @Step("❌ Annulation de la commande - Motif: {motif}")
    public CommandeSteps annulerCommande(String motif) {

        String now = SqlUtils.now();
        String sql = """
                UPDATE orders
                SET status = 'CANCELLED', cancellation_reason = '%s', cancelled_at = '%s', updated_at = '%s'
                WHERE ref_id = '${orderId}'
                """.formatted(SqlUtils.escape(motif), now, now);

        SqlUtils.logSql("SQL: Annulation commande", sql);

        runner.$(ExecuteSQLAction.Builder.sql()
                .dataSource(dataSource)
                .statement(sql));

        Allure.addAttachment("Motif d'annulation", "text/plain", motif, ".txt");
        log.info("Commande annulée: {} - Motif: {}", currentOrderId, motif);
        return this;
    }

    /**
     * Simule un paiement réussi.
     */
    @Step("💳 Paiement effectué")
    public CommandeSteps effectuerPaiement() {

        String now = SqlUtils.now();
        String sql = """
                UPDATE orders
                SET status = 'PAID', paid_at = '%s', updated_at = '%s'
                WHERE ref_id = '${orderId}'
                """.formatted(now, now);

        SqlUtils.logSql("SQL: Paiement commande", sql);

        runner.$(ExecuteSQLAction.Builder.sql()
                .dataSource(dataSource)
                .statement(sql));

        log.info("Paiement effectué pour commande: {}", currentOrderId);
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // VÉRIFICATIONS (THEN)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Vérifie que la commande existe avec le statut attendu.
     */
    @Step("✓ Vérification statut commande: {statutAttendu}")
    public CommandeSteps verifierStatut(String statutAttendu) {
        runner.$(ExecuteSQLQueryAction.Builder.query()
                .dataSource(dataSource)
                .statement("SELECT status FROM orders WHERE ref_id = '${orderId}'")
                .validate("status", statutAttendu));

        log.info("Statut vérifié: {} = {}", currentOrderId, statutAttendu);
        return this;
    }

    /**
     * Vérifie le montant de la commande.
     */
    @Step("✓ Vérification montant: {montantAttendu}€")
    public CommandeSteps verifierMontant(BigDecimal montantAttendu) {
        runner.$(ExecuteSQLQueryAction.Builder.query()
                .dataSource(dataSource)
                .statement("SELECT amount FROM orders WHERE ref_id = '${orderId}'")
                .validate("amount", montantAttendu.toString()));

        log.info("Montant vérifié: {} = {}€", currentOrderId, montantAttendu);
        return this;
    }

    /**
     * Vérifie que la commande n'existe pas.
     */
    @Step("✓ Vérification commande inexistante")
    public CommandeSteps verifierCommandeInexistante() {
        runner.$(ExecuteSQLQueryAction.Builder.query()
                .dataSource(dataSource)
                .statement("SELECT COUNT(*) as cnt FROM orders WHERE ref_id = '${orderId}'")
                .validate("cnt", "0"));

        log.info("Commande vérifiée inexistante: {}", currentOrderId);
        return this;
    }

    /**
     * Vérifie le type de client associé à la commande.
     */
    @Step("✓ Vérification type client: {typeAttendu}")
    public CommandeSteps verifierTypeClient(String typeAttendu) {
        runner.$(ExecuteSQLQueryAction.Builder.query()
                .dataSource(dataSource)
                .statement("SELECT customer_type FROM orders WHERE ref_id = '${orderId}'")
                .validate("customer_type", typeAttendu));

        return this;
    }

    /**
     * Vérifie que le motif d'annulation est présent.
     */
    @Step("✓ Vérification motif annulation présent")
    public CommandeSteps verifierMotifAnnulation(String motifAttendu) {
        runner.$(ExecuteSQLQueryAction.Builder.query()
                .dataSource(dataSource)
                .statement("SELECT cancellation_reason FROM orders WHERE ref_id = '${orderId}'")
                .validate("cancellation_reason", motifAttendu));

        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // NETTOYAGE
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Nettoie la commande courante après le test.
     */
    @Step("🧹 Nettoyage commande de test")
    public CommandeSteps nettoyerCommande() {
        if (currentOrderId != null) {
            runner.$(ExecuteSQLAction.Builder.sql()
                    .dataSource(dataSource)
                    .statement("DELETE FROM order_items WHERE order_id = '${orderId}'")
                    .statement("DELETE FROM orders WHERE ref_id = '${orderId}'"));

            log.info("Commande nettoyée: {}", currentOrderId);
        }
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HELPERS INTERNES
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Attache les détails de la commande au rapport Allure.
     */
    private void attachOrderDetails(String client, BigDecimal montant, String statut) {
        String details = """
                ╔══════════════════════════════════════╗
                ║     DÉTAILS COMMANDE                 ║
                ╠══════════════════════════════════════╣
                ║ Référence : %s
                ║ Client    : %s
                ║ Montant   : %s€
                ║ Statut    : %s
                ╚══════════════════════════════════════╝
                """.formatted(currentOrderId, client, montant, statut);

        Allure.addAttachment("📋 Détails commande", "text/plain", details, ".txt");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GETTERS
    // ═══════════════════════════════════════════════════════════════════════════

    public String getCurrentOrderId() {
        return currentOrderId;
    }

    public String getCurrentCustomer() {
        return currentCustomer;
    }
}
