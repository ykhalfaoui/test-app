package com.monentreprise.citrus.core;

import com.monentreprise.citrus.core.config.CitrusTestConfig;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StepResult;
import org.citrusframework.TestCaseRunner;
import org.citrusframework.annotations.CitrusResource;
import org.citrusframework.context.TestContext;
import org.citrusframework.junit.jupiter.CitrusExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.sql.DataSource;
import java.util.UUID;

/**
 * Classe de base pour tous les tests Citrus.
 * 
 * <h2>Fonctionnalités</h2>
 * <ul>
 * <li>Configuration Spring + Citrus automatique</li>
 * <li>Helpers BDD (given/when/then)</li>
 * <li>Gestion des données dynamiques</li>
 * <li>Intégration Allure pour le reporting métier</li>
 * </ul>
 * 
 * <h2>Usage</h2>
 * 
 * <pre>{@code
 * public class MonTest extends BaseCitrusTest {
 *     &#64;Test @CitrusTest
 *     void monScenario(@CitrusResource TestCaseRunner runner) {
 *         given("Une précondition", () -> { ... });
 *         when("Une action", () -> { ... });
 *         then("Un résultat attendu", () -> { ... });
 *     }
 * }
 * }</pre>
 * 
 * @author Équipe QA
 * @since 1.0.0
 */
@ExtendWith({ CitrusExtension.class, SpringExtension.class })
@ContextConfiguration(classes = CitrusTestConfig.class)
public abstract class BaseCitrusTest {

    protected final Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    @Qualifier("testDataSource")
    protected DataSource dataSource;

    @CitrusResource
    protected TestContext testContext;

    /**
     * Initialisation avant chaque test.
     * Génère un ID de corrélation unique pour le traçage.
     */
    @BeforeEach
    void initTestContext() {
        String correlationId = generateCorrelationId();
        Allure.parameter("🔗 Correlation ID", correlationId);
        log.info("══════════════════════════════════════════════════════════");
        log.info("▶ Démarrage test - Correlation ID: {}", correlationId);
        log.info("══════════════════════════════════════════════════════════");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BDD STEP HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Étape GIVEN - Définit le contexte/précondition du test.
     * 
     * @param description Description métier de la précondition
     * @param action      Action à exécuter
     */
    protected void given(String description, ThrowingRunnable action) {
        executeStep("📋 GIVEN", description, action);
    }

    /**
     * Étape WHEN - Définit l'action principale du test.
     * 
     * @param description Description métier de l'action
     * @param action      Action à exécuter
     */
    protected void when(String description, ThrowingRunnable action) {
        executeStep("⚡ WHEN", description, action);
    }

    /**
     * Étape THEN - Définit le résultat attendu/assertion.
     * 
     * @param description Description métier du résultat attendu
     * @param action      Action à exécuter (assertions)
     */
    protected void then(String description, ThrowingRunnable action) {
        executeStep("✅ THEN", description, action);
    }

    /**
     * Étape AND - Complète l'étape précédente.
     * 
     * @param description Description métier complémentaire
     * @param action      Action à exécuter
     */
    protected void and(String description, ThrowingRunnable action) {
        executeStep("   ➕ AND", description, action);
    }

    /**
     * Étape BUT - Définit une exception/condition négative.
     * 
     * @param description Description métier de l'exception
     * @param action      Action à exécuter
     */
    protected void but(String description, ThrowingRunnable action) {
        executeStep("   ⚠️ BUT", description, action);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ALLURE HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Ajoute un paramètre métier au rapport Allure.
     */
    protected void addBusinessParameter(String name, Object value) {
        Allure.parameter(name, String.valueOf(value));
    }

    /**
     * Ajoute une pièce jointe texte au rapport.
     */
    protected void attachText(String name, String content) {
        Allure.addAttachment(name, "text/plain", content, ".txt");
    }

    /**
     * Ajoute une pièce jointe JSON au rapport.
     */
    protected void attachJson(String name, String jsonContent) {
        Allure.addAttachment(name, "application/json", jsonContent, ".json");
    }

    /**
     * Ajoute une pièce jointe SQL au rapport.
     */
    protected void attachSql(String name, String sqlContent) {
        Allure.addAttachment(name, "text/x-sql", sqlContent, ".sql");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // DATA HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Génère un UUID unique pour les données de test.
     * Évite les conflits lors de l'exécution parallèle.
     */
    protected String generateUniqueId() {
        return UUID.randomUUID().toString();
    }

    /**
     * Génère un UUID court (8 caractères) pour les références.
     */
    protected String generateShortId() {
        return UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    /**
     * Génère un ID de corrélation pour le traçage.
     */
    protected String generateCorrelationId() {
        return "TEST-" + System.currentTimeMillis() + "-" + generateShortId();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // INTERNAL
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Exécute une étape avec gestion d'erreur et reporting Allure.
     */
    private void executeStep(String prefix, String description, ThrowingRunnable action) {
        String fullStepName = prefix + ": " + description;
        log.info("→ {}", fullStepName);

        Allure.step(fullStepName, () -> {
            try {
                action.run();
                log.info("  ✓ Succès");
            } catch (AssertionError e) {
                log.error("  ✗ Assertion échouée: {}", e.getMessage());
                attachText("Détail de l'échec", e.getMessage());
                throw e;
            } catch (Exception e) {
                log.error("  ✗ Erreur technique: {}", e.getMessage(), e);
                attachText("Stack trace", getStackTrace(e));
                throw new RuntimeException("Erreur dans l'étape: " + fullStepName, e);
            }
        });
    }

    /**
     * Récupère la stack trace sous forme de String.
     */
    private String getStackTrace(Throwable t) {
        StringBuilder sb = new StringBuilder();
        sb.append(t.toString()).append("\n");
        for (StackTraceElement element : t.getStackTrace()) {
            sb.append("\tat ").append(element).append("\n");
        }
        if (t.getCause() != null) {
            sb.append("Caused by: ").append(getStackTrace(t.getCause()));
        }
        return sb.toString();
    }

    /**
     * Interface fonctionnelle pour les actions pouvant lever des exceptions.
     */
    @FunctionalInterface
    protected interface ThrowingRunnable {
        void run() throws Exception;
    }
}
