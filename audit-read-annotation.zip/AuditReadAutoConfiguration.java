package com.bil.remediation.audit.config;

import com.bil.remediation.audit.internal.AuditReadAspect;
import com.bil.remediation.audit.port.AuditWritePort;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Auto-configuration for the {@code @AuditRead} infrastructure.
 *
 * <p>Registers {@link AuditReadAspect} only when an {@link AuditWritePort}
 * bean is present in the context. This keeps the module self-contained:
 * if you provide your own {@link AuditWritePort} implementation, the aspect
 * picks it up automatically.</p>
 *
 * <h3>Minimal wiring required</h3>
 * <pre>{@code
 * @Bean
 * public AuditWritePort auditWritePort(AuditRepository repo) {
 *     return audit -> repo.save(audit);  // plug your existing JPA repo here
 * }
 * }</pre>
 */
@AutoConfiguration
@EnableAspectJAutoProxy
public class AuditReadAutoConfiguration {

    /**
     * Registers the AOP aspect.
     * Only active when an {@link AuditWritePort} bean is present.
     */
    @Bean
    @ConditionalOnBean(AuditWritePort.class)
    @ConditionalOnMissingBean(AuditReadAspect.class)
    public AuditReadAspect auditReadAspect(AuditWritePort auditWritePort,
                                            ObjectMapper objectMapper) {
        return new AuditReadAspect(auditWritePort, objectMapper);
    }
}
