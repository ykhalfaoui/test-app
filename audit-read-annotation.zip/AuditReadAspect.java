package com.bil.remediation.audit.internal;

import com.bil.remediation.audit.api.AuditRead;
import com.bil.remediation.audit.domain.entity.Audit;
import com.bil.remediation.audit.domain.entity.AuditId;
import com.bil.remediation.audit.domain.entity.Severity;
import com.bil.remediation.audit.port.AuditWritePort;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

/**
 * AOP aspect that intercepts methods annotated with {@link AuditRead}
 * and persists an {@link Audit} entry via {@link AuditWritePort}.
 *
 * <h3>Actor resolution</h3>
 * <ol>
 *   <li>Spring Security {@code Authentication.getName()}</li>
 *   <li>Fallback → {@code "SYSTEM"} (batch / scheduled jobs / unauthenticated)</li>
 * </ol>
 *
 * <h3>Status mapping</h3>
 * <ul>
 *   <li>Normal return           → {@code Severity.INFO}</li>
 *   <li>Return value is null or Optional.empty() → {@code Severity.INFO} + entityStatus="NOT_FOUND"</li>
 *   <li>Exception thrown        → {@code Severity.ERROR} + errorCode=exception class name</li>
 * </ul>
 *
 * <h3>Thread safety</h3>
 * Stateless — safe for concurrent use.
 */
@Aspect
public class AuditReadAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditReadAspect.class);

    private static final String SYSTEM_ACTOR    = "SYSTEM";
    private static final String STATUS_FOUND    = "FOUND";
    private static final String STATUS_NOT_FOUND = "NOT_FOUND";
    private static final String MDC_CORRELATION  = "correlationId";

    private final AuditWritePort auditWritePort;
    private final ObjectMapper   objectMapper;

    public AuditReadAspect(AuditWritePort auditWritePort, ObjectMapper objectMapper) {
        this.auditWritePort = auditWritePort;
        this.objectMapper   = objectMapper;
    }

    @Around("@annotation(auditRead)")
    public Object audit(ProceedingJoinPoint joinPoint, AuditRead auditRead) throws Throwable {

        // --- Pre-execution resolution ---
        String action        = AuditReadResolver.resolveAction(auditRead, joinPoint);
        String entityType    = AuditReadResolver.resolveEntityType(auditRead, joinPoint);
        String entityId      = AuditReadResolver.resolveEntityIdOnArgs(auditRead, joinPoint);
        String comment       = AuditReadResolver.resolveComment(auditRead, joinPoint);
        String correlationId = MDC.get(MDC_CORRELATION);
        String actor         = resolveActor();
        String payload       = auditRead.capturePayload() ? serializePayload(joinPoint.getArgs()) : null;

        Object result;
        try {
            result = joinPoint.proceed();
        } catch (Throwable ex) {
            // --- Error path ---
            persistAudit(Audit.builder()
                    .id(generateId())
                    .actionType(action)
                    .entityType(entityType)
                    .entityId(entityId)
                    .severity(Severity.ERROR)
                    .userId(actor)
                    .correlationId(correlationId)
                    .entityStatus("ERROR")
                    .errorCode(ex.getClass().getSimpleName())
                    .comment(comment)
                    .jsonPayload(payload)
                    .occurredOn(LocalDateTime.now())
                    .build());
            throw ex;
        }

        // --- Post-execution resolution (entityId on #result) ---
        String resolvedEntityId = entityId != null
                ? entityId
                : AuditReadResolver.resolveEntityIdOnResult(auditRead, joinPoint, result);

        String entityStatus = isNotFound(result) ? STATUS_NOT_FOUND : STATUS_FOUND;

        persistAudit(Audit.builder()
                .id(generateId())
                .actionType(action)
                .entityType(entityType)
                .entityId(resolvedEntityId)
                .severity(Severity.INFO)
                .userId(actor)
                .correlationId(correlationId)
                .entityStatus(entityStatus)
                .comment(comment)
                .jsonPayload(payload)
                .occurredOn(LocalDateTime.now())
                .build());

        return result;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private String resolveActor() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated()
                && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return SYSTEM_ACTOR;
    }

    private boolean isNotFound(Object result) {
        if (result == null) return true;
        if (result instanceof Optional<?> opt) return opt.isEmpty();
        return false;
    }

    private String serializePayload(Object[] args) {
        if (args == null || args.length == 0) return null;
        try {
            return objectMapper.writeValueAsString(args[0]);
        } catch (JsonProcessingException e) {
            log.warn("[AuditRead] Failed to serialize payload: {}", e.getMessage());
            return null;
        }
    }

    private void persistAudit(Audit audit) {
        try {
            auditWritePort.save(audit);
        } catch (Exception e) {
            // Audit must never break the business flow
            log.error("[AuditRead] Failed to persist audit entry action={} error={}",
                    audit.getActionType(), e.getMessage(), e);
        }
    }

    private AuditId generateId() {
        return new AuditId(UUID.randomUUID().toString());
    }
}
