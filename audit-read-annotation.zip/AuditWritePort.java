package com.bil.remediation.audit.port;

import com.bil.remediation.audit.domain.entity.Audit;

/**
 * Output port for audit persistence.
 *
 * <p>Implement this interface to plug in your existing {@code AuditRepository}
 * (JPA, MongoDB, log appender, etc.) without touching the aspect.</p>
 *
 * <p>The default implementation {@code JpaAuditWriteAdapter} is registered
 * conditionally via {@code @ConditionalOnMissingBean} — override it freely.</p>
 */
public interface AuditWritePort {

    /**
     * Persists an audit entry.
     *
     * @param audit the audit entry to save — never {@code null}
     */
    void save(Audit audit);
}
