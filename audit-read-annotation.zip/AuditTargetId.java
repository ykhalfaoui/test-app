package com.bil.remediation.audit.api;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a field in a Value Object / Query as the entity identifier
 * to be captured in the audit trail.
 *
 * <p>Usage on a record field:</p>
 * <pre>{@code
 * public record GetReviewQuery(@AuditTargetId ReviewId reviewId, String requestedBy) {}
 * }</pre>
 *
 * <p>The {@link AuditReadAspect} will resolve the value via reflection.
 * If multiple fields are annotated, their values are concatenated with ",".</p>
 *
 * <p>A SpEL expression on {@link AuditRead#entityId()} always takes priority
 * over this annotation.</p>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface AuditTargetId {
}
