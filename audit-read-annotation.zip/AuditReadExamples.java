package com.bil.remediation.review.application;

// =============================================================================
// EXEMPLES D'UTILISATION — @AuditRead
// =============================================================================
// Ce fichier illustre tous les cas d'usage. Ne pas commiter tel quel.
// =============================================================================

import com.bil.remediation.audit.api.AuditRead;
import com.bil.remediation.audit.api.AuditTargetId;

// -----------------------------------------------------------------------------
// 1. Value Object / Query avec @AuditTargetId
// -----------------------------------------------------------------------------

record ReviewId(String value) {}

record GetReviewQuery(
    @AuditTargetId ReviewId reviewId,   // ← sera capturé automatiquement
    String requestedBy
) {}

record FindReviewMembersQuery(
    @AuditTargetId ReviewId reviewId,
    @AuditTargetId String memberId      // ← si plusieurs → "abc,def"
) {}

// -----------------------------------------------------------------------------
// 2. Cas 1 — Zéro configuration
// -----------------------------------------------------------------------------
class ReviewService {

    @AuditRead
    public Object getReview(GetReviewQuery query) {
        // → actionType   = "ReviewService.getReview"
        // → entityType   = "REVIEW"   (depuis package com.bil.remediation.review.*)
        // → entityId     = query.reviewId.value  (via @AuditTargetId)
        // → userId       = SecurityContext ou "SYSTEM"
        // → severity     = INFO (SUCCESS) / ERROR (exception)
        // → entityStatus = "FOUND" ou "NOT_FOUND" (si retour null / Optional.empty())
        return null;
    }

    // -----------------------------------------------------------------------------
    // 3. Cas 2 — SpEL sur les args
    // -----------------------------------------------------------------------------
    @AuditRead(
        entityId = "#query.reviewId.value"   // SpEL explicite sur arg nommé
    )
    public Object getReviewExplicitId(GetReviewQuery query) {
        return null;
    }

    // -----------------------------------------------------------------------------
    // 4. Cas 3 — SpEL sur le résultat (#result évalué post-exécution)
    // -----------------------------------------------------------------------------
    @AuditRead(
        entityId = "#result.id.value"        // SpEL sur la valeur de retour
    )
    public Object getReviewById(GetReviewQuery query) {
        return null;
    }

    // -----------------------------------------------------------------------------
    // 5. Cas 4 — Override partiel : entityType seulement
    // -----------------------------------------------------------------------------
    @AuditRead(
        entityType = "REVIEW_MEMBER"         // override la convention package
    )
    public Object getReviewMembers(FindReviewMembersQuery query) {
        // → actionType = "ReviewService.getReviewMembers"
        // → entityType = "REVIEW_MEMBER"  (override)
        // → entityId   = "reviewId,memberId" (deux champs @AuditTargetId)
        return null;
    }

    // -----------------------------------------------------------------------------
    // 6. Cas 5 — Override total + payload
    // -----------------------------------------------------------------------------
    @AuditRead(
        action         = "ReviewService.exportReviewReport",
        entityType     = "REVIEW",
        entityId       = "#query.reviewId.value",
        comment        = "#query.requestedBy",
        capturePayload = true                // sérialise query en JSON → AUDT_PAYLOAD
    )
    public byte[] exportReviewReport(GetReviewQuery query) {
        return new byte[0];
    }

    // -----------------------------------------------------------------------------
    // 7. Cas 6 — Service système sans SecurityContext (batch / scheduler)
    // -----------------------------------------------------------------------------
    @AuditRead(
        action     = "ReviewBatchService.processReviews",
        entityType = "REVIEW"
    )
    public Object processBatchReviews(GetReviewQuery query) {
        // → userId = "SYSTEM"  (pas de SecurityContext → fallback automatique)
        return null;
    }
}

/*
 * =============================================================================
 * RÉSULTAT EN BASE (table existante AUDIT)
 * =============================================================================
 *
 * AUDT_ACTION_TYPE    = "ReviewService.getReview"
 * AUDT_ENTITY_TYPE    = "REVIEW"
 * AUDT_ENTITY_ID      = "abc-123"
 * AUDT_USER_ID        = "john.doe@bil.com"  ou  "SYSTEM"
 * AUDT_CORRELATION_ID = "f47ac10b-..."  (depuis MDC)
 * AUDT_SEVERITY       = "INFO"  ou  "ERROR"
 * AUDT_ENTITY_STATUS  = "FOUND"  /  "NOT_FOUND"  /  "ERROR"
 * AUDT_ERROR_CODE     = null  ou  "ReviewNotFoundException"
 * AUDT_COMMENT        = null  ou  valeur SpEL
 * AUDT_PAYLOAD        = null  ou  JSON sérialisé (si capturePayload=true)
 * AUDT_OCCURRED_ON    = 2025-05-29T10:30:00
 *
 * =============================================================================
 * WIRING MINIMAL (dans votre module audit)
 * =============================================================================
 *
 * @Bean
 * public AuditWritePort auditWritePort(AuditRepository auditRepository) {
 *     return audit -> auditRepository.save(audit);
 * }
 *
 * =============================================================================
 * COMPILER FLAG REQUIS pour les noms de paramètres SpEL (#query, #id...)
 * =============================================================================
 *
 * Maven :
 * <plugin>
 *   <groupId>org.apache.maven.plugins</groupId>
 *   <artifactId>maven-compiler-plugin</artifactId>
 *   <configuration>
 *     <parameters>true</parameters>
 *   </configuration>
 * </plugin>
 *
 * Gradle :
 * tasks.withType(JavaCompile) {
 *     options.compilerArgs << '-parameters'
 * }
 *
 * =============================================================================
 */
