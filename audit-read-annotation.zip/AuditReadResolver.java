package com.bil.remediation.audit.internal;

import com.bil.remediation.audit.api.AuditRead;
import com.bil.remediation.audit.api.AuditTargetId;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Stateless resolver that extracts audit metadata from a {@link ProceedingJoinPoint}
 * and its {@link AuditRead} annotation.
 *
 * <p>All methods are pure functions — no Spring beans, easy to unit test.</p>
 *
 * <h3>Resolution rules</h3>
 * <pre>
 * action     : explicit @AuditRead.action()  >  ClassName.methodName
 * entityType : explicit @AuditRead.entityType() > package convention > null
 * entityId   : SpEL on args                  > @AuditTargetId reflection > null
 *              (SpEL on #result is deferred to post-execution)
 * </pre>
 */
public class AuditReadResolver {

    /**
     * Package segment pattern: extracts the domain segment after "remediation."
     * e.g. com.bil.remediation.review.query.GetReviewQuery → "REVIEW"
     *      com.bil.remediation.party.query.FindPartyQuery  → "PARTY"
     */
    private static final Pattern REMEDIATION_PKG_PATTERN =
            Pattern.compile("remediation\\.([a-zA-Z0-9_]+)\\.");

    private AuditReadResolver() {}

    // -------------------------------------------------------------------------
    // Action
    // -------------------------------------------------------------------------

    /**
     * Resolves the audit action string.
     * Format: {@code "ClassName.methodName"} unless overridden.
     */
    public static String resolveAction(AuditRead annotation, ProceedingJoinPoint joinPoint) {
        String explicit = annotation.action();
        if (!explicit.isBlank()) {
            return explicit;
        }
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        return className + "." + methodName;
    }

    // -------------------------------------------------------------------------
    // EntityType
    // -------------------------------------------------------------------------

    /**
     * Resolves the entity type string.
     *
     * <p>Convention: extracts the package segment immediately after {@code remediation.}
     * from the first method argument's class package, uppercased.</p>
     *
     * <p>Examples:</p>
     * <ul>
     *   <li>{@code com.bil.remediation.review.query.GetReviewQuery}  → {@code "REVIEW"}</li>
     *   <li>{@code com.bil.remediation.party.query.FindPartyQuery}   → {@code "PARTY"}</li>
     *   <li>{@code com.bil.remediation.block.query.GetBlockQuery}    → {@code "BLOCK"}</li>
     * </ul>
     */
    public static String resolveEntityType(AuditRead annotation, ProceedingJoinPoint joinPoint) {
        String explicit = annotation.entityType();
        if (!explicit.isBlank()) {
            return explicit;
        }
        Object[] args = joinPoint.getArgs();
        if (args == null || args.length == 0 || args[0] == null) {
            return null;
        }
        String packageName = args[0].getClass().getPackageName();
        Matcher matcher = REMEDIATION_PKG_PATTERN.matcher(packageName);
        if (matcher.find()) {
            return matcher.group(1).toUpperCase();
        }
        // fallback: simple class name without "Query" / "Command" suffix
        return stripQuerySuffix(args[0].getClass().getSimpleName()).toUpperCase();
    }

    // -------------------------------------------------------------------------
    // EntityId — pre-execution (args only)
    // -------------------------------------------------------------------------

    /**
     * Resolves the entity ID before method execution (args-only context).
     *
     * <p>If the SpEL expression references {@code #result}, returns {@code null}
     * — it will be resolved post-execution by
     * {@link #resolveEntityIdOnResult(AuditRead, ProceedingJoinPoint, Object)}.</p>
     */
    public static String resolveEntityIdOnArgs(AuditRead annotation, ProceedingJoinPoint joinPoint) {
        String spel = annotation.entityId();

        // SpEL provided but needs #result → defer
        if (!spel.isBlank() && SpelAuditEvaluator.isResultExpression(spel)) {
            return null;
        }

        // SpEL provided on args
        if (!spel.isBlank()) {
            return SpelAuditEvaluator.evaluateOnArgs(spel, joinPoint);
        }

        // Fallback: @AuditTargetId reflection
        return resolveByAuditTargetId(joinPoint.getArgs());
    }

    /**
     * Resolves the entity ID after method execution (result available).
     * Only called when {@link AuditRead#entityId()} contains {@code #result}.
     */
    public static String resolveEntityIdOnResult(AuditRead annotation,
                                                  ProceedingJoinPoint joinPoint,
                                                  Object result) {
        String spel = annotation.entityId();
        if (!spel.isBlank() && SpelAuditEvaluator.isResultExpression(spel)) {
            return SpelAuditEvaluator.evaluateOnResult(spel, joinPoint, result);
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Comment
    // -------------------------------------------------------------------------

    public static String resolveComment(AuditRead annotation, ProceedingJoinPoint joinPoint) {
        return SpelAuditEvaluator.evaluateOnArgs(annotation.comment(), joinPoint);
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    /**
     * Scans all args for fields annotated with {@link AuditTargetId} via reflection.
     * If multiple annotated fields are found, their values are joined with ",".
     */
    private static String resolveByAuditTargetId(Object[] args) {
        if (args == null) return null;
        List<String> ids = new ArrayList<>();
        for (Object arg : args) {
            if (arg == null) continue;
            collectAuditTargetIds(arg, arg.getClass(), ids);
        }
        return ids.isEmpty() ? null : String.join(",", ids);
    }

    private static void collectAuditTargetIds(Object instance, Class<?> clazz, List<String> ids) {
        if (clazz == null || clazz == Object.class) return;
        for (Field field : clazz.getDeclaredFields()) {
            if (field.isAnnotationPresent(AuditTargetId.class)) {
                try {
                    field.setAccessible(true);
                    Object value = field.get(instance);
                    if (value != null) {
                        ids.add(value.toString());
                    }
                } catch (IllegalAccessException ignored) {
                    // skip inaccessible field
                }
            }
        }
        // Walk up the hierarchy (supports inheritance)
        collectAuditTargetIds(instance, clazz.getSuperclass(), ids);
    }

    private static String stripQuerySuffix(String className) {
        for (String suffix : List.of("Query", "Command", "Request", "Criteria")) {
            if (className.endsWith(suffix) && className.length() > suffix.length()) {
                return className.substring(0, className.length() - suffix.length());
            }
        }
        return className;
    }
}
