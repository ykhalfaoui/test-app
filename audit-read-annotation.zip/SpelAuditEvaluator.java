package com.bil.remediation.audit.internal;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe SpEL evaluator with expression cache.
 *
 * <p>Supports two evaluation phases:</p>
 * <ul>
 *   <li><b>Before</b> execution — args only ({@code #paramName})</li>
 *   <li><b>After</b> execution  — args + {@code #result}</li>
 * </ul>
 *
 * <p>Requires {@code -parameters} compiler flag or Spring's parameter name discoverer
 * for named parameter binding (e.g. {@code #query.reviewId.value}).</p>
 */
public class SpelAuditEvaluator {

    private static final ExpressionParser PARSER = new SpelExpressionParser();
    private static final ConcurrentHashMap<String, Expression> CACHE = new ConcurrentHashMap<>();

    private SpelAuditEvaluator() {}

    /**
     * Evaluates a SpEL expression against method args only (pre-execution context).
     *
     * @param expression SpEL expression string
     * @param joinPoint  current join point
     * @return resolved String value, or {@code null} if expression is blank or evaluation fails
     */
    public static String evaluateOnArgs(String expression, ProceedingJoinPoint joinPoint) {
        if (expression == null || expression.isBlank()) {
            return null;
        }
        try {
            EvaluationContext ctx = buildContext(joinPoint, null);
            return evaluate(expression, ctx);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Evaluates a SpEL expression against method args + return value (post-execution context).
     *
     * @param expression SpEL expression string
     * @param joinPoint  current join point
     * @param result     method return value, bound as {@code #result}
     * @return resolved String value, or {@code null} if expression is blank or evaluation fails
     */
    public static String evaluateOnResult(String expression, ProceedingJoinPoint joinPoint, Object result) {
        if (expression == null || expression.isBlank()) {
            return null;
        }
        try {
            EvaluationContext ctx = buildContext(joinPoint, result);
            return evaluate(expression, ctx);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Returns true if the expression references {@code #result}, meaning
     * it must be evaluated post-execution.
     */
    public static boolean isResultExpression(String expression) {
        return expression != null && expression.contains("#result");
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private static EvaluationContext buildContext(ProceedingJoinPoint joinPoint, Object result) {
        StandardEvaluationContext ctx = new StandardEvaluationContext();

        // Bind named parameters: #query, #id, etc.
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        String[] paramNames = signature.getParameterNames(); // requires -parameters flag
        Object[] args = joinPoint.getArgs();

        if (paramNames != null) {
            for (int i = 0; i < paramNames.length; i++) {
                ctx.setVariable(paramNames[i], args[i]);
            }
        }

        // Also bind positional: #p0, #p1, ...
        for (int i = 0; i < args.length; i++) {
            ctx.setVariable("p" + i, args[i]);
        }

        // Bind return value
        if (result != null) {
            ctx.setVariable("result", result);
        }

        return ctx;
    }

    private static String evaluate(String expression, EvaluationContext ctx) {
        Expression expr = CACHE.computeIfAbsent(expression, PARSER::parseExpression);
        Object value = expr.getValue(ctx);
        return value != null ? value.toString() : null;
    }
}
