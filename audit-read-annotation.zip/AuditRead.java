package com.bil.remediation.audit.api;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a service method for automatic read audit trail capture.
 *
 * <p>All fields are optional — the aspect resolves sensible defaults automatically:</p>
 * <ul>
 *   <li>{@code action}     → {@code "ClassName.methodName"} (e.g. {@code "ReviewService.getReview"})</li>
 *   <li>{@code entityType} → extracted from the arg's package segment after {@code remediation.}
 *                            (e.g. {@code com.bil.remediation.review.query.GetReviewQuery} → {@code "REVIEW"})</li>
 *   <li>{@code entityId}   → field annotated with {@link AuditTargetId} in the first arg, via reflection</li>
 *   <li>{@code severity}   → {@code "INFO"} on success, {@code "ERROR"} on exception</li>
 * </ul>
 *
 * <h3>Examples</h3>
 *
 * <pre>{@code
 * // 1 — Zero config
 * @AuditRead
 * public ReviewDto getReview(GetReviewQuery query) { ... }
 * // → action="ReviewService.getReview", entityType="REVIEW", entityId=<@AuditTargetId field>
 *
 * // 2 — SpEL on arg
 * @AuditRead(entityId = "#query.reviewId.value")
 * public ReviewDto getReview(GetReviewQuery query) { ... }
 *
 * // 3 — SpEL on result
 * @AuditRead(entityId = "#result.id.value")
 * public ReviewDto getReview(GetReviewQuery query) { ... }
 *
 * // 4 — Full override
 * @AuditRead(
 *     action     = "ReviewService.getReviewWithMembers",
 *     entityType = "REVIEW_MEMBER",
 *     entityId   = "#query.reviewId.value",
 *     capturePayload = true
 * )
 * public ReviewDto getReviewWithMembers(GetReviewQuery query) { ... }
 * }</pre>
 *
 * <h3>Resolution priority</h3>
 * <pre>
 * action     : explicit > ClassName.methodName
 * entityType : explicit > package convention > null
 * entityId   : SpEL     > @AuditTargetId reflection > null
 * </pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface AuditRead {

    /**
     * Audit action stored in {@code AUDT_ACTION_TYPE}.
     * Defaults to {@code "ClassName.methodName"} when blank.
     */
    String action() default "";

    /**
     * Entity type stored in {@code AUDT_ENTITY_TYPE}.
     * Defaults to package-convention resolution when blank.
     */
    String entityType() default "";

    /**
     * SpEL expression to resolve the entity identifier stored in {@code AUDT_ENTITY_ID}.
     * <ul>
     *   <li>Use {@code #paramName} to access method arguments (requires {@code -parameters} compiler flag
     *       or Spring's {@code LocalVariableTableParameterNameDiscoverer}).</li>
     *   <li>Use {@code #result} to access the method return value (evaluated after execution).</li>
     * </ul>
     * When blank, resolution falls back to {@link AuditTargetId} reflection on args.
     */
    String entityId() default "";

    /**
     * SpEL expression to resolve a comment stored in {@code AUDT_COMMENT}.
     * Example: {@code "#query.reason"}.
     */
    String comment() default "";

    /**
     * When {@code true}, serializes the first method argument as JSON
     * into {@code AUDT_PAYLOAD}. Defaults to {@code false}.
     */
    boolean capturePayload() default false;
}
