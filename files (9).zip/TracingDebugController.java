package com.crok4it.tracing.debug;

import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Endpoints de diagnostic pour vérifier que le tracing fonctionne.
 * DÉSACTIVÉ EN PRODUCTION via app.debug.tracing.enabled=false
 *
 * HOW TO USE :
 * GET /debug/tracing/http          → vérifie HTTP
 * GET /debug/tracing/async         → vérifie @Async / ContextPropagatingTaskDecorator
 * GET /debug/tracing/mdc           → inspecte le MDC courant
 */
@RestController
@RequestMapping("/debug/tracing")
@ConditionalOnProperty(name = "app.debug.tracing.enabled", havingValue = "true")
public class TracingDebugController {

    private static final Logger log = LoggerFactory.getLogger(TracingDebugController.class);

    private final Tracer tracer;
    private final ObservationRegistry observationRegistry;
    private final Executor asyncExecutor;

    public TracingDebugController(Tracer tracer,
                                  ObservationRegistry observationRegistry,
                                  Executor asyncExecutor) {
        this.tracer            = tracer;
        this.observationRegistry = observationRegistry;
        this.asyncExecutor     = asyncExecutor;
    }

    /**
     * Test 1 — Vérification HTTP basique.
     * ATTENDU : traceId et spanId non vides dans la réponse ET dans les logs.
     */
    @GetMapping("/http")
    public Map<String, String> testHttpTracing() {
        Span current = tracer.currentSpan();
        log.info("[DEBUG] HTTP trace check");

        Map<String, String> result = new HashMap<>();
        result.put("traceId",    current != null ? current.context().traceId() : "VIDE — PROBLÈME");
        result.put("spanId",     current != null ? current.context().spanId()  : "VIDE — PROBLÈME");
        result.put("mdc_traceId", MDC.get("traceId") != null ? MDC.get("traceId") : "VIDE — pattern logging manquant");
        result.put("status",     current != null ? "OK" : "KO — micrometer-tracing-bridge absent ou mal configuré");
        return result;
    }

    /**
     * Test 2 — Vérification de la propagation @Async / ContextPropagatingTaskDecorator.
     * ATTENDU : le traceId dans le thread async doit être IDENTIQUE à celui du thread HTTP.
     * Si différent ou vide → ContextPropagatingTaskDecorator non appliqué.
     */
    @GetMapping("/async")
    public Map<String, Object> testAsyncPropagation() throws Exception {
        Span parentSpan = tracer.currentSpan();
        String httpTraceId = parentSpan != null ? parentSpan.context().traceId() : "AUCUN";

        log.info("[DEBUG] Thread HTTP — traceId={}", httpTraceId);

        CompletableFuture<Map<String, String>> asyncResult = CompletableFuture.supplyAsync(() -> {
            Span asyncSpan = tracer.currentSpan();
            String asyncTraceId = asyncSpan != null ? asyncSpan.context().traceId() : "VIDE";
            String asyncMdc     = MDC.get("traceId");

            log.info("[DEBUG] Thread ASYNC — traceId={}", asyncTraceId);

            Map<String, String> r = new HashMap<>();
            r.put("async_traceId",     asyncTraceId);
            r.put("async_mdc_traceId", asyncMdc != null ? asyncMdc : "VIDE");
            r.put("thread_name",       Thread.currentThread().getName());
            return r;
        }, asyncExecutor);

        Map<String, Object> result = new HashMap<>();
        result.put("http_traceId",  httpTraceId);
        result.put("async_result",  asyncResult.get());
        result.put("propagated",    httpTraceId.equals(asyncResult.get().get("async_traceId")));
        result.put("diagnostic",
            httpTraceId.equals(asyncResult.get().get("async_traceId"))
                ? "OK — ContextPropagatingTaskDecorator fonctionne"
                : "KO — ContextPropagatingTaskDecorator manquant ou executor non configuré");
        return result;
    }

    /**
     * Test 3 — Inspection du MDC courant.
     * Utile pour vérifier que le pattern de log est bien configuré.
     */
    @GetMapping("/mdc")
    public Map<String, Object> inspectMdc() {
        Map<String, Object> result = new HashMap<>();
        result.put("mdc_context",       MDC.getCopyOfContextMap());
        result.put("current_traceId",   MDC.get("traceId"));
        result.put("current_spanId",    MDC.get("spanId"));

        Span current = tracer.currentSpan();
        result.put("tracer_traceId",
            current != null ? current.context().traceId() : "null — pas de span actif");

        result.put("observation_current",
            observationRegistry.getCurrentObservation() != null
                ? observationRegistry.getCurrentObservation().getContextView().getName()
                : "null — pas d'observation active");
        return result;
    }
}
