package com.crok4it.tracing.scheduler;

import io.micrometer.observation.annotation.Observed;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.modulith.events.IncompleteEventPublications;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Replay des événements Modulith non complétés (IncompleteEventPublications).
 * Protégé par ShedLock pour éviter les exécutions concurrentes en multi-pods.
 *
 * POURQUOI @Observed :
 * Même raison que OutboxDispatcher — thread @Scheduled sans contexte parent.
 * @Observed crée un span racine avec un traceId unique par exécution du job.
 *
 * NOTE SUR spring.modulith.events.republication-interval :
 * Si tu utilises le scheduler natif de Modulith, tu perds le contrôle sur ShedLock.
 * Dans ce cas, utilise un aspect AOP sur resubmitIncompletePublicationsOlderThan()
 * à la place de ce scheduler custom — voir TracingAspect.java.
 */
@Component
public class EventReplayJob {

    private static final Logger log = LoggerFactory.getLogger(EventReplayJob.class);

    private final IncompleteEventPublications incompleteEventPublications;

    public EventReplayJob(IncompleteEventPublications incompleteEventPublications) {
        this.incompleteEventPublications = incompleteEventPublications;
    }

    @Scheduled(fixedDelayString = "${app.modulith.replay-interval:60000}")
    @SchedulerLock(
        name = "modulith-event-replay",
        lockAtMostFor  = "PT55S",
        lockAtLeastFor = "PT10S"
    )
    @Observed(
        name = "modulith.event.replay",
        contextualName = "modulith-incomplete-publications-replay",
        lowCardinalityKeyValues = {
            "scheduler", "shedlock",
            "component", "modulith"
        }
    )
    public void replayIncompleteEvents() {
        log.info("Replay des événements incomplets démarré — traceId={}",
                 org.slf4j.MDC.get("traceId"));

        incompleteEventPublications
            .resubmitIncompletePublicationsOlderThan(Duration.ofMinutes(1));

        log.debug("Replay terminé");
    }
}
