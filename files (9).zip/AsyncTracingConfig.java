package com.crok4it.tracing.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.core.task.support.ContextPropagatingTaskDecorator;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Propagation du contexte Micrometer (traceId/spanId/MDC) vers les threads @Async
 * et @ApplicationModuleListener (qui sont @Async par nature en Modulith).
 *
 * POURQUOI : Le TraceContext de Micrometer est stocké en ThreadLocal.
 * Dès qu'on change de thread (@Async, Modulith listener), le contexte est perdu.
 * ContextPropagatingTaskDecorator capture le contexte du thread appelant
 * et le restaure dans le thread de destination avant chaque exécution.
 *
 * IMPORTANT : Pas auto-configuré par Boot 3.4 — obligatoire de le déclarer.
 */
@Configuration
@EnableAsync
public class AsyncTracingConfig implements AsyncConfigurer {

    @Override
    public Executor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        // Dimensionner selon vos pods K8s (2 CPU / 2Gi)
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("modulith-async-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);

        // ← Point clé : capture TraceContext avant le switch de thread
        executor.setTaskDecorator(new ContextPropagatingTaskDecorator());

        executor.initialize();
        return executor;
    }
}
