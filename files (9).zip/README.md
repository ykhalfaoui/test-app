# Tracing asynchrone — Spring Boot 3.4 / Modulith 1.4 / Kafka / Micrometer

## Contexte du problème

Micrometer Tracing stocke le `TraceContext` en **ThreadLocal**. Dès qu'on change de thread, le contexte est perdu. Dans un microservice avec Kafka inbox/outbox, Modulith events et ShedLock, cela crée 4 points de rupture :

| Vecteur | Problème | Solution |
|---|---|---|
| `@KafkaListener` | Thread Kafka consumer, pas de context parent | `observationEnabled=true` (natif) |
| `@ApplicationModuleListener` | Thread `@Async`, contexte non propagé | `ContextPropagatingTaskDecorator` |
| `@Scheduled` (outbox, ShedLock) | Thread TaskScheduler, aucun span parent | `@Observed` sur la méthode |
| Modulith scheduler natif | Replay non instrumenté | `TracingAspect` (AOP) |

---

## Architecture de la solution

```
HTTP Request
  └─ [traceId: abc] HTTP Filter (auto)
       ├─ KafkaTemplate.send()
       │    └─ header traceparent injecté → [observationEnabled=true]
       │         └─ @KafkaListener (thread kafka-consumer-1)
       │              └─ [traceId: abc restauré depuis header]
       │
       ├─ ApplicationEventPublisher.publishEvent()
       │    └─ @ApplicationModuleListener (thread modulith-async-1)
       │         └─ [traceId: abc propagé par ContextPropagatingTaskDecorator]
       │
       └─ @Scheduled OutboxDispatcher (thread scheduler-1)
            └─ [traceId: xyz NOUVEAU — @Observed crée un span racine]
```

---

## Composants de la solution

### 1. `AsyncTracingConfig.java`
Configure l'`AsyncTaskExecutor` avec `ContextPropagatingTaskDecorator`.  
Couvre : `@Async`, `@ApplicationModuleListener`.

```java
executor.setTaskDecorator(new ContextPropagatingTaskDecorator());
```

**Prérequis** : Être le bean executor par défaut (implementer `AsyncConfigurer`).

### 2. `KafkaObservabilityConfig.java`
Active `setObservationEnabled(true)` sur la factory et le template.  
Couvre : `@KafkaListener`, `KafkaTemplate.send()`.

**Piège** : Si tu déclares une factory custom, la property YAML `observation-enabled: true`
est ignorée — tu dois appeler `setObservationEnabled(true)` programmatiquement.

**Piège batch** : Les batch listeners n'ont pas d'observation par défaut.
Ajouter `factory.setRecordObservationsInBatch(true)` si tu as des `@KafkaListener` en mode batch.

### 3. `OutboxDispatcher.java` et `EventReplayJob.java`
`@Observed` sur chaque méthode `@Scheduled`.  
Couvre : outbox dispatcher, replay ShedLock.

**Pourquoi @Observed et pas la propriété auto ?**  
`ScheduledTasksObservabilityAutoConfiguration` crée une Observation (métriques),
mais pas un span Zipkin/OTLP avec `traceId` dans les logs MDC de façon garantie.
`@Observed` garantit un span complet avec `traceId` visible dans ELK.

### 4. `TracingAspect.java` (optionnel)
AOP sur `IncompleteEventPublications.resubmit*()`.  
Activer uniquement si tu utilises `spring.modulith.events.republication-interval`
(scheduler natif Modulith) sans wrapper `@Scheduled` custom.

---

## Dépendances Maven

```xml
<!-- AOP — OBLIGATOIRE pour @Observed et TracingAspect -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-aop</artifactId>
</dependency>

<!-- Tracing bridge — choisir Brave (Zipkin) ou OTel selon ton backend -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-tracing-bridge-brave</artifactId>
</dependency>
<dependency>
    <groupId>io.zipkin.reporter2</groupId>
    <artifactId>zipkin-reporter-brave</artifactId>
</dependency>

<!-- Modulith observability — métriques events -->
<dependency>
    <groupId>org.springframework.modulith</groupId>
    <artifactId>spring-modulith-observability</artifactId>
</dependency>

<!-- ShedLock -->
<dependency>
    <groupId>net.javacrumbs.shedlock</groupId>
    <artifactId>shedlock-spring</artifactId>
</dependency>
```

---

## Configuration minimale `application.yml`

```yaml
spring:
  kafka:
    template:
      observation-enabled: true
    listener:
      observation-enabled: true

management:
  tracing:
    sampling:
      probability: 1.0
  observations:
    annotations:
      enabled: true

logging:
  pattern:
    correlation: "[${spring.application.name},%X{traceId:-},%X{spanId:-}]"
```

---

## Guide de debug

### Comment savoir si ça fonctionne

Active le debug controller en dev :
```yaml
app.debug.tracing.enabled: true
```

### Test 1 — HTTP (baseline)

```bash
curl http://localhost:8080/debug/tracing/http
```

**Réponse attendue :**
```json
{
  "traceId": "abc123def456...",
  "spanId": "def456...",
  "mdc_traceId": "abc123def456...",
  "status": "OK"
}
```

**Si KO :**
- `traceId` vide → `micrometer-tracing-bridge-brave` absent du classpath
- `mdc_traceId` vide mais `traceId` présent → pattern de log manquant, ajouter :
  ```yaml
  logging.pattern.correlation: "[${spring.application.name},%X{traceId:-},%X{spanId:-}]"
  ```

---

### Test 2 — Propagation @Async

```bash
curl http://localhost:8080/debug/tracing/async
```

**Réponse attendue :**
```json
{
  "http_traceId": "abc123",
  "async_result": {
    "async_traceId": "abc123",
    "thread_name": "modulith-async-1"
  },
  "propagated": true,
  "diagnostic": "OK — ContextPropagatingTaskDecorator fonctionne"
}
```

**Si `propagated: false` :**
1. Vérifier que `AsyncTracingConfig` est bien chargé → `@EnableAsync` présent ?
2. Vérifier que l'executor utilisé est bien celui configuré avec le `TaskDecorator` :
   - Le thread name doit contenir `modulith-async-` (ou ton préfixe configuré)
   - Si le thread s'appelle `ForkJoinPool.commonPool-worker-1` → l'executor n'est pas celui configuré
3. Vérifier qu'il n'y a pas un autre `@Bean Executor` qui override le tien

---

### Test 3 — Kafka consumer

**Méthode 1 — logs** : envoyer un message Kafka et chercher `traceId` dans les logs du consumer :
```
grep "traceId" app.log | grep "kafka-consumer"
```
Si vide → `observationEnabled` non activé ou factory custom sans `setObservationEnabled(true)`.

**Méthode 2 — header Kafka** : activer le logging DEBUG :
```yaml
logging.level.org.springframework.kafka.listener.KafkaMessageListenerContainer: DEBUG
```
Chercher dans les logs : `traceparent` dans les headers du record.

**Méthode 3 — actuator** :
```bash
curl http://localhost:8080/actuator/observations
```
Tu dois voir des entrées `spring.kafka.listener` si `observationEnabled=true`.

**Si le header `traceparent` est absent du message Kafka :**
- `KafkaTemplate.setObservationEnabled(true)` non appelé côté producteur
- Ou le producteur est dans un autre service qui n'a pas la config

---

### Test 4 — @Scheduled (outbox dispatcher)

**Dans les logs :** chercher les lignes du thread `scheduler-` :
```bash
grep "scheduler-" app.log | grep "traceId"
```

**Si `traceId` vide dans les logs @Scheduled :**
1. Vérifier que `@Observed` est présent sur la méthode schedulée
2. Vérifier que `management.observations.annotations.enabled=true` est dans la config
3. Vérifier que `spring-boot-starter-aop` est dans le classpath :
   ```bash
   # Dans les logs de démarrage, chercher :
   grep "ObservedAspect" app.log
   # Doit apparaître lors du démarrage si AOP est configuré
   ```
4. Test rapide : ajouter un log explicite dans la méthode :
   ```java
   log.info("traceId MDC = {}", MDC.get("traceId")); // doit être non-null
   ```

---

### Test 5 — ShedLock replay (EventReplayJob)

Même vérification que le Test 4 + vérifier ShedLock :
```bash
# Vérifier que le lock est bien acquis (table shedlock en base)
SELECT * FROM shedlock WHERE name = 'modulith-event-replay';
```

Si le lock n'est jamais acquis → ShedLock non configuré correctement (datasource, `@EnableSchedulerLock`).

---

### Checklist de démarrage complète

```
□ spring-boot-starter-aop dans pom.xml
□ micrometer-tracing-bridge-brave dans pom.xml
□ zipkin-reporter-brave dans pom.xml (ou otel équivalent)
□ spring-modulith-observability dans pom.xml
□ management.observations.annotations.enabled=true dans application.yml
□ management.tracing.sampling.probability=1.0 (en dev)
□ spring.kafka.template.observation-enabled=true dans application.yml
□ spring.kafka.listener.observation-enabled=true dans application.yml
  OU setObservationEnabled(true) dans ta factory custom
□ AsyncTracingConfig.java avec ContextPropagatingTaskDecorator
□ @Observed sur chaque méthode @Scheduled
□ logging.pattern.correlation configuré
```

---

## Erreurs fréquentes et solutions

| Symptôme | Cause probable | Solution |
|---|---|---|
| `traceId` vide partout | Bridge Micrometer absent | Ajouter `micrometer-tracing-bridge-brave` |
| `traceId` présent en HTTP, absent en `@Async` | `ContextPropagatingTaskDecorator` manquant | Vérifier `AsyncTracingConfig` |
| `traceId` présent en HTTP, absent en Kafka consumer | `observationEnabled` non activé | `setObservationEnabled(true)` sur la factory |
| Kafka consumer: nouveau `traceId` au lieu du parent | Factory custom sans observation | Ajouter `setObservationEnabled(true)` à ta factory custom |
| `@Scheduled` sans `traceId` | `@Observed` manquant ou AOP non activé | Vérifier `annotations.enabled=true` + AOP |
| `@Observed` sans effet | `spring-boot-starter-aop` absent | Ajouter la dépendance AOP |
| Metrics Kafka disparues | `observationEnabled` désactive les timers | Normal — les timers sont remplacés par les observations |
| Batch listener sans traceId | `observationEnabled` ne couvre pas les batches | Ajouter `setRecordObservationsInBatch(true)` |
