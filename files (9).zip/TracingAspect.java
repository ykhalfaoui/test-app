package com.crok4it.tracing.config;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Aspect de tracing pour les cas où tu utilises le scheduler natif de Modulith
 * (spring.modulith.events.republication-interval) au lieu d'un @Scheduled custom.
 *
 * Dans ce cas, tu ne contrôles pas la méthode appelante donc tu ne peux pas
 * mettre @Observed dessus — cet aspect intercepte l'appel à resubmit*
 * et crée un span racine.
 *
 * ACTIVÉ SEULEMENT si spring.modulith.events.republication-interval est défini
 * (ConditionalOnProperty). Si tu utilises EventReplayJob.java à la place,
 * désactive cet aspect via : app.tracing.modulith-replay-aspect.enabled=false
 */
@Aspect
@Component
@ConditionalOnProperty(
    name  = "app.tracing.modulith-replay-aspect.enabled",
    havingValue = "true",
    matchIfMissing = false
)
public class TracingAspect {

    private static final Logger log = LoggerFactory.getLogger(TracingAspect.class);

    private final Tracer tracer;

    public TracingAspect(Tracer tracer) {
        this.tracer = tracer;
    }

    /**
     * Intercepte le replay natif de Modulith pour créer un span racine.
     * Utiliser uniquement si spring.modulith.events.republication-interval est actif.
     */
    @Around("execution(* org.springframework.modulith.events.IncompleteEventPublications.resubmit*(..))")
    public Object traceModulithNativeReplay(ProceedingJoinPoint pjp) throws Throwable {
        Span span = tracer.nextSpan()
                .name("modulith.native.replay")
                .tag("scheduler", "modulith-native")
                .start();

        log.debug("Modulith native replay démarré — traceId={}", span.context().traceId());

        try (Tracer.SpanInScope ws = tracer.withSpan(span)) {
            return pjp.proceed();
        } catch (Throwable t) {
            span.error(t);
            throw t;
        } finally {
            span.end();
        }
    }
}
