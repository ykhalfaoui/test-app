package com.crok4it.tracing.config;

import org.springframework.boot.autoconfigure.kafka.ConcurrentKafkaListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

/**
 * Active l'observation Micrometer native de spring-kafka pour le tracing
 * end-to-end HTTP → Kafka producer → Kafka consumer.
 *
 * POURQUOI NÉCESSAIRE MALGRÉ LES PROPERTIES YAML :
 * La property spring.kafka.listener.observation-enabled=true applique
 * l'observation sur la factory auto-configurée PAR DÉFAUT.
 * Si tu déclares ta propre ConcurrentKafkaListenerContainerFactory
 * (ce qui est courant pour configurer l'inbox pattern, les DLQ, etc.),
 * la property n'a aucun effet — tu dois appeler setObservationEnabled(true)
 * explicitement sur ta factory.
 *
 * ATTENTION : setObservationEnabled(true) désactive automatiquement les
 * MicrometerTimers classiques (spring.kafka.listener timer).
 * Les timers sont remplacés par les observations Micrometer — c'est voulu.
 *
 * PROPAGATION RÉELLE : spring-kafka injecte le header "traceparent" (W3C)
 * ou les headers B3 sur chaque ProducerRecord. Côté consumer, le header
 * est extrait et le span parent est restauré avant d'appeler ton @KafkaListener.
 */
@Configuration
public class KafkaObservabilityConfig {

    /**
     * Factory pour les @KafkaListener (inbox pattern, consumers métier).
     *
     * On utilise le ConcurrentKafkaListenerContainerFactoryConfigurer auto-configuré
     * par Boot pour conserver TOUTE la configuration Boot (deserializers, error handlers,
     * retry, etc.) et on ajoute juste l'observation par-dessus.
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<Object, Object> kafkaListenerContainerFactory(
            ConcurrentKafkaListenerContainerFactoryConfigurer configurer,
            ConsumerFactory<Object, Object> consumerFactory) {

        ConcurrentKafkaListenerContainerFactory<Object, Object> factory =
                new ConcurrentKafkaListenerContainerFactory<>();

        // Applique toute la config Boot auto-configurée en premier
        configurer.configure(factory, consumerFactory);

        // Active l'observation Micrometer — propagation du traceId via headers Kafka
        factory.getContainerProperties().setObservationEnabled(true);

        return factory;
    }

    /**
     * KafkaTemplate avec observation pour la propagation côté producer (outbox pattern).
     *
     * IMPORTANT : On réutilise la ProducerFactory auto-configurée par Boot.
     * Ne jamais créer une nouvelle ProducerFactory ici — on perdrait la config Boot
     * (serializers, transaction manager, etc.).
     */
    @Bean
    public KafkaTemplate<Object, Object> kafkaTemplate(
            ProducerFactory<Object, Object> producerFactory) {

        KafkaTemplate<Object, Object> template = new KafkaTemplate<>(producerFactory);

        // Injecte le header traceparent sur chaque message produit
        template.setObservationEnabled(true);

        return template;
    }
}
