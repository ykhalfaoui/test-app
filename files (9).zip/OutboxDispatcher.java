package com.crok4it.tracing.scheduler;

import io.micrometer.observation.annotation.Observed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Dispatcher de l'outbox pattern — s'exécute dans le thread du TaskScheduler.
 *
 * POURQUOI @Observed EST NÉCESSAIRE ICI :
 * Les threads @Scheduled utilisent le TaskScheduler (ScheduledExecutorService),
 * pas l'AsyncTaskExecutor couvert par ContextPropagatingTaskDecorator.
 * Il n'existe pas de contexte parent à propager — c'est un point d'entrée autonome.
 *
 * ScheduledTasksObservabilityAutoConfiguration (Boot 3.2+) crée bien une Observation
 * pour les @Scheduled, mais elle génère des métriques (timer), pas forcément un span
 * Zipkin/OTLP avec traceId dans les logs MDC.
 *
 * @Observed garantit la création d'un SPAN avec traceId visible dans :
 *   - les logs ECS (MDC traceId, spanId)
 *   - Zipkin / Grafana Tempo
 *   - les métriques Micrometer (timer outbox.dispatch)
 *
 * PRÉREQUIS : management.observations.annotations.enabled=true
 *             + spring-boot-starter-aop sur le classpath
 */
@Component
public class OutboxDispatcher {

    private static final Logger log = LoggerFactory.getLogger(OutboxDispatcher.class);

    @Scheduled(fixedDelayString = "${app.outbox.dispatch-interval:5000}")
    @Observed(
        name = "outbox.dispatch",
        contextualName = "outbox-salesforce-dispatch",
        lowCardinalityKeyValues = {
            "component", "outbox",
            "module",    "salesforce"
        }
    )
    public void dispatch() {
        // traceId garanti dans MDC ici — visible dans les logs ECS
        log.debug("Outbox dispatch démarré — traceId={}", getTraceId());

        // TODO: appeler ton OutboxService ici
        // outboxService.processOutboxEntries();
    }

    // Helper de debug — à supprimer en production
    private String getTraceId() {
        return org.slf4j.MDC.get("traceId");
    }
}
